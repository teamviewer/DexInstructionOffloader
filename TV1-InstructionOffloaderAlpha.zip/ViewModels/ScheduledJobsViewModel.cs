﻿using Avalonia.Controls;
using Avalonia.Threading;
using LiveChartsCore;
using LiveChartsCore.SkiaSharpView;
using LiveChartsCore.SkiaSharpView.Painting;
using Newtonsoft.Json;
using ReactiveUI;
using SkiaSharp;
using Spire.Xls.Charts;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Reactive;
using System.Reactive.Linq;
using System.Threading;
using System.Threading.Tasks;
using TV1_InstructionOffloader.Models;
using TV1_InstructionOffloader.Helpers;
using Axis = LiveChartsCore.SkiaSharpView.Axis;



namespace TV1_InstructionOffloader.ViewModels
{
    /// <summary>
    /// Keeps <see cref="ScheduledJob"/> objects in-memory, persists them to disk, and signals
    /// the window when the user clicks <b>Edit</b> so the UI can switch to the Instruction tab.
    /// </summary>
    public class ScheduledJobsViewModel : ReactiveObject
    {
        public TimeSpan AverageDuration => ExecutionHistory.Count == 0
        ? TimeSpan.Zero
        : TimeSpan.FromSeconds(ExecutionHistory
            .Where(j => j.EndTime > j.StartTime)
            .Average(j => (j.EndTime - j.StartTime).TotalSeconds));

        public string AverageDurationFormatted
        {
            get
            {
                var avg = AverageDuration;
                if (avg.TotalMinutes <= 0)
                    return "00h 00m";

                int days = avg.Days;
                int hours = avg.Hours;
                int minutes = avg.Minutes;

                if (days > 0)
                    return $"{days:D2}d {hours:D2}h {minutes:D2}m";
                if (hours > 0)
                    return $"{hours:D2}h {minutes:D2}m";
                return $"{minutes:D2}m";
            }
        }

        private ISeries[] _chartSeries = Array.Empty<ISeries>();
        public ISeries[] ChartSeries
        {
            get => _chartSeries;
            set => this.RaiseAndSetIfChanged(ref _chartSeries, value);
        }



        public void RefreshChart()
        {
            var buckets = ExecutionHistory
                .GroupBy(j => Math.Floor((NormalizeHistoryTime(j.StartTime).TimeOfDay.TotalMinutes) / 15))
                .Select(g => new { TimeBucket = g.Key, Count = g.Count() })
                .OrderBy(g => g.TimeBucket)
                .ToList();

            ChartSeries = new ISeries[]
            {
        new ColumnSeries<int>
        {
            Values = buckets.Select(b => b.Count).ToArray(),
            Name = "Job Count"
        }
            };

            XAxes = new Axis[]
            {
        new Axis
        {
            Labels = buckets.Select(b => $"{b.TimeBucket * 15:00}m").ToArray(),
            LabelsRotation = 45
        }
            };

            YAxes = new Axis[]
            {
        new Axis
        {
            Name = "Jobs",
            MinLimit = 0
        }
            };

            this.RaisePropertyChanged(nameof(ChartSeries));
            this.RaisePropertyChanged(nameof(XAxes));
            this.RaisePropertyChanged(nameof(YAxes));
        }

        // ──────────────────  Public collection bound to DataGrid  ──────────────────
        public ObservableCollection<ScheduledJob> ScheduledJobs { get; } = new();
        public ObservableCollection<string> LogLines { get; } = new();
        public ObservableCollection<ScheduledJob> Jobs { get; } = new();

        private ObservableCollection<JobExecutionHistory> _executionHistory = new();
        public ObservableCollection<JobExecutionHistory> ExecutionHistory
        {
            get => _executionHistory;
            set
            {
                this.RaiseAndSetIfChanged(ref _executionHistory, value);
                this.RaisePropertyChanged(nameof(TotalJobCount));
                this.RaisePropertyChanged(nameof(AverageDuration));
            }
        }

        // ──────────────────  Timestamp display mode (Local vs UTC) ──────────────────
        private bool _showUtcTimestamps;
        public bool ShowUtcTimestamps
        {
            get => _showUtcTimestamps;
            set
            {
                if (value == _showUtcTimestamps)
                    return;

                this.RaiseAndSetIfChanged(ref _showUtcTimestamps, value);

                // Recompute any time-bucketed charts when the time basis changes.
                PopulateChartData();

                // Some views bind directly to this flag.
                this.RaisePropertyChanged(nameof(ShowUtcTimestamps));
            }
        }

        private DateTime NormalizeHistoryTime(DateTime dt)
        {
            // History is stored as DateTime (likely local). Normalize for chart grouping.
            return ShowUtcTimestamps ? dt.ToUniversalTime() : dt.ToLocalTime();
        }

        private DateTime ChartNow => ShowUtcTimestamps ? DateTime.UtcNow : DateTime.Now;
        private DateTime ChartToday => ChartNow.Date;


        // Distinct history rows for charts.
        // History can contain duplicate entries when SaveHistory is triggered twice per tick or when history is merged on startup.
        // Charts should count each execution once.
        private IEnumerable<JobExecutionHistory> GetDistinctHistoryForCharts()
        {
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            foreach (var h in ExecutionHistory ?? new System.Collections.ObjectModel.ObservableCollection<JobExecutionHistory>())
            {
                if (h == null)
                    continue;

                var execId = h.ExecutionId != Guid.Empty ? h.ExecutionId.ToString() : string.Empty;
                var jobId = !string.IsNullOrWhiteSpace(h.JobId) ? h.JobId : string.Empty;
                var resp = h.ResponseId ?? string.Empty;
                var start = h.StartTime != default ? h.StartTime.ToString("O") : string.Empty;

                // Prefer ExecutionId; fall back to JobId+ResponseId+StartTime if ExecutionId is missing.
                var key = !string.IsNullOrWhiteSpace(execId)
                    ? execId
                    : $"{jobId}|{resp}|{start}";

                if (seen.Add(key))
                    yield return h;
            }
        }

        // ──────────────────  Logging helper ──────────────────
        private readonly Action<string>? _logger;

        /// <summary>External subscribers (MainWindow, tests) can hook this instead of passing a logger delegate.</summary>
        public event Action<string>? LogMessage;

        /// <summary>Central log helper – writes to _logger delegate <b>and</b> raises <see cref="LogMessage"/>.</summary>
        public void Log(string msg)
        {
            _logger?.Invoke(msg);
            LogMessage?.Invoke(msg);
        }

        // ──────────────────  State flags ──────────────────string msg) => _logger?.Invoke(msg);

        // ──────────────────  State flags ──────────────────
        private bool _isLoadingJobs;                 // TRUE while reading JSON on startup

        // ──────────────────  Selection ─────────────────────
        private ScheduledJob? _selectedScheduledJob;
        public ScheduledJob? SelectedScheduledJob
        {
            get => _selectedScheduledJob;
            set
            {
                this.RaiseAndSetIfChanged(ref _selectedScheduledJob, value);
                Log(value == null ? "SelectedScheduledJob = null" : $"Selected = {value.InstructionName}");
                this.RaisePropertyChanged(nameof(IsScheduledJobSelected));
            }
        }
        public bool IsScheduledJobSelected => _selectedScheduledJob != null;

        // ──────────────────  Events & Commands ──────────────────
        public event Action<ScheduledJob>? EditRequested; // Window subscribes → switch tab + load form
        public event Action? JobsLoaded;
        public List<Platform> Platforms { get; set; } = new();
        public ObservableCollection<DateTime> OverloadedSlots { get; set; } = new();

        public ReactiveCommand<Unit, Unit> CreateJobCommand { get; }
        public ReactiveCommand<Unit, Unit> DeleteJobCommand { get; }
        public ReactiveCommand<ScheduledJob, ScheduledJob?> EditJobCommand { get; }

        // ──────────────────  Paths  ──────────────────
        private static readonly string DataFolderPath = AppPaths.BaseDirectory;

        private static readonly string JobsFilePath = AppPaths.ScheduledJobsPath;

        // ──────────────────  Constructor  ──────────────────
        public ScheduledJobsViewModel(Action<string>? logger = null)
        {
            _logger = logger;

            var canEditOrDelete = this.WhenAnyValue(vm => vm.SelectedScheduledJob)
                                       .Select(j => j != null);

            CreateJobCommand = ReactiveCommand.CreateFromTask(CreateJobAsync);
            DeleteJobCommand = ReactiveCommand.Create(DeleteSelectedJob, canEditOrDelete);
            EditJobCommand = ReactiveCommand.Create<ScheduledJob, ScheduledJob?>(job =>
            {
                if (job != null)
                {
                    Log($"EditJobCommand invoked for JobId = {job.JobId}");
                    EditRequested?.Invoke(job);
                }
                else
                {
                    Log("EditJobCommand invoked with null job.");
                }
                return job;
            }, canEditOrDelete);

        }

        // ──────────────────  Disk I/O  ──────────────────
        public async Task LoadJobsAsync()
        {
            EnsureDataFolderExists();
            _isLoadingJobs = true;
            try
            {
                if (!File.Exists(JobsFilePath)) { Log("No scheduled_jobs.json – starting clean\n"); return; }

                var json = await File.ReadAllTextAsync(JobsFilePath);
                var jobs = JsonConvert.DeserializeObject<List<ScheduledJob>>(json) ?? new();

                ScheduledJobs.Clear();
                foreach (var j in jobs)
                {
                    if (j.Recurrence == "One-time") j.Recurrence = "Once";
                    ScheduledJobs.Add(j);
                }
                Log($"Loaded {ScheduledJobs.Count} job(s) from disk\n");
                JobsLoaded?.Invoke();
            }
            catch (Exception ex) { Log("Load error: " + ex.Message + "\n"); }
            finally { _isLoadingJobs = false; }
        }

        private static readonly SemaphoreSlim _saveLock = new(1, 1);


        public async Task SaveJobsAsync()
        {
            if (_isLoadingJobs) return; // Avoid clobber during startup

            await _saveLock.WaitAsync();
            try
            {
                EnsureDataFolderExists();
                var json = JsonConvert.SerializeObject(ScheduledJobs, Formatting.Indented);
                await File.WriteAllTextAsync(JobsFilePath, json);
            }
            catch (Exception ex)
            {
                Log("Save error: " + ex.Message + "\n");
            }
            finally
            {
                _saveLock.Release();
            }
        }


        // ──────────────────  Helpers  ──────────────────
        private static string HHMMSS(TimeSpan? ts) => ts?.ToString(@"hh\:mm\:ss") ?? "";
        private static void CopyEditableFields(ScheduledJob dest, ScheduledJob src)
        {
            dest.PlatformFqdn = src.PlatformFqdn;
            dest.InstructionName = src.InstructionName;
            dest.Recurrence = src.Recurrence;
            dest.StartTime = src.StartTime;
            dest.JobType = src.JobType;
            dest.Status = src.Status;
            // add more as needed
        }
        private void EnsureDataFolderExists()
        {
            if (!Directory.Exists(DataFolderPath)) Directory.CreateDirectory(DataFolderPath);
        }


        public async Task CreateJobAsync() => await CreateJobAsyncInternal(SelectedScheduledJob);

        /// <summary>Create job programmatically.</summary>
        public async Task CreateJobAsync(ScheduledJob newJob) => await CreateJobAsyncInternal(newJob);

        private async Task CreateJobAsyncInternal(ScheduledJob? job)
        {
            if (job == null)
            {
                Log("⚠️ Create: job is null");
                return;
            }

            // Duplicate check (same FQDN + Instruction + Recurrence + StartTime)
            bool duplicate = ScheduledJobs.Any(j =>
                j.JobId != job.JobId &&
                j.PlatformFqdn.Equals(job.PlatformFqdn, StringComparison.OrdinalIgnoreCase) &&
                j.InstructionName.Equals(job.InstructionName, StringComparison.OrdinalIgnoreCase) &&
                j.Recurrence.Equals(job.Recurrence, StringComparison.OrdinalIgnoreCase) &&
                HHMMSS(j.StartTime) == HHMMSS(job.StartTime));

            if (duplicate)
            {
                Log($"⏩ Duplicate not added: {job.InstructionName}");
                return;
            }

            // ───────── Manual deep-clone (keeps Parameters intact) ─────────
            // NOTE: This clone is what gets serialized to Jobs.json.
            // It MUST carry the same targeting fields the scheduler uses.
            var clone = new ScheduledJob
            {
                JobId = string.IsNullOrWhiteSpace(job.JobId) ? Guid.NewGuid().ToString() : job.JobId,
                InstructionName = job.InstructionName,
                InstructionId = job.InstructionId,
                InstructionType = job.InstructionType,
                PlatformAlias = job.PlatformAlias,
                PlatformFqdn = job.PlatformFqdn,
                AppRegistrationId = job.AppRegistrationId,
                CertThumbprint = job.CertThumbprint,
                AuthenticationMode = job.AuthenticationMode,
                InstructionTtlMinutes = job.InstructionTtlMinutes,
                InstructionTtlUnit = job.InstructionTtlUnit,
                ResponseTtlMinutes = job.ResponseTtlMinutes,
                ResponseTtlUnit = job.ResponseTtlUnit,
                ExportFormat = job.ExportFormat,
                Consumer = job.Consumer,

                // Export behavior (must be persisted into scheduled_jobs.json)
                ExportMode = job.ExportMode,
                ExportFolderMode = job.ExportFolderMode,
                ServerSideFallbackAfterFailures = job.ServerSideFallbackAfterFailures,
                ServerExportIssued = job.ServerExportIssued,
                ServerExportIssuedUtc = job.ServerExportIssuedUtc,
                PagingExportFailureCount = job.PagingExportFailureCount,
                JobType = job.JobType,
                Status = job.Status,
                StartDate = job.StartDate,
                EndDate = job.EndDate,
                StartTime = job.StartTime,
                Recurrence = job.Recurrence,
                DaysOfWeek = job.DaysOfWeek?.ToList() ?? new(),
                WeeklyRepeatCount = job.WeeklyRepeatCount,
                MonthlyRepeatCount = job.MonthlyRepeatCount,
                MonthlyWeekOffsets = job.MonthlyWeekOffsets?.ToList() ?? new(),
                MonthlyDayFallback = job.MonthlyDayFallback,
                TargetingMethod = job.TargetingMethod,

                // NEW targeting fields (what the UI saves and what the scheduler reads)
                TargetingFqdn = job.TargetingFqdn,
                TargetingManagementGroup = job.TargetingManagementGroup,
                CoverageTagName = job.CoverageTagName,
                CoverageTagValue = job.CoverageTagValue,

                // Legacy/compat fields (some older scheduler logic still references these)
                FqdnInput = job.FqdnInput,
                MatchType = job.MatchType,
                ManagementGroupId = job.ManagementGroupId,
                CoverageTag = job.CoverageTag,
                CoverageValue = job.CoverageValue,

                IsRunning = job.IsRunning,
                Parameters = job.Parameters != null
                                      ? new Dictionary<string, string>(job.Parameters)
                                      : new Dictionary<string, string>()
            };

            // Normalize targeting so ONLY the selected mode is persisted.
            // Also mirror values into the legacy fields so the scheduler can't "lose" the target.
            var m = (clone.TargetingMethod ?? string.Empty).Trim();
            if (m.Equals("FQDN", StringComparison.OrdinalIgnoreCase))
            {
                clone.TargetingManagementGroup = string.Empty;
                clone.ManagementGroupId = null;
                clone.CoverageTagName = string.Empty;
                clone.CoverageTagValue = string.Empty;
                clone.CoverageTag = null;
                clone.CoverageValue = null;

                // legacy mirror
                clone.FqdnInput = string.IsNullOrWhiteSpace(clone.TargetingFqdn) ? clone.FqdnInput : clone.TargetingFqdn;
                if (string.IsNullOrWhiteSpace(clone.MatchType))
                    clone.MatchType = "Equals";
            }
            else if (m.Equals("MG", StringComparison.OrdinalIgnoreCase) || m.Equals("Management Group", StringComparison.OrdinalIgnoreCase))
            {
                clone.TargetingFqdn = string.Empty;
                clone.FqdnInput = null;
                clone.MatchType = null;
                clone.CoverageTagName = string.Empty;
                clone.CoverageTagValue = string.Empty;
                clone.CoverageTag = null;
                clone.CoverageValue = null;
            }
            else if (m.Equals("Coverage", StringComparison.OrdinalIgnoreCase) ||
                     m.Equals("CoverageTag", StringComparison.OrdinalIgnoreCase) ||
                     m.Equals("Coverage Tag", StringComparison.OrdinalIgnoreCase))
            {
                clone.TargetingFqdn = string.Empty;
                clone.FqdnInput = null;
                clone.MatchType = null;

                // legacy mirror
                clone.CoverageTag = string.IsNullOrWhiteSpace(clone.CoverageTagName) ? clone.CoverageTag : clone.CoverageTagName;
                clone.CoverageValue = string.IsNullOrWhiteSpace(clone.CoverageTagValue) ? clone.CoverageValue : clone.CoverageTagValue;
            }
            // ────────────────────────────────────────────────────────────────

            ScheduledJobs.Add(clone);
            Log($"➕ Added: {clone.InstructionName}");

            await SaveJobsAsync();
        }

        public void UpdateJobDurationsFromHistory()
        {
            var grouped = ExecutionHistory
                .Where(h => h.DurationSeconds > 0)
                .GroupBy(h => h.JobId);

            foreach (var group in grouped)
            {
                var job = ScheduledJobs.FirstOrDefault(j => j.JobId == group.Key);
                if (job != null)
                {
                    var durations = group.Select(h => h.DurationSeconds);
                    job.AverageDuration = TimeSpan.FromSeconds(durations.Average());
                    job.MaxDuration = TimeSpan.FromSeconds(durations.Max());
                }
            }

            this.RaisePropertyChanged(nameof(ScheduledJobs));
        }


        public async Task UpdateJobAsync(ScheduledJob edited)
        {
            if (edited == null || string.IsNullOrWhiteSpace(edited.JobId))
            {
                Log("⚠️ UpdateJobAsync called with null or invalid JobId.");
                return;
            }

            var row = ScheduledJobs.FirstOrDefault(j => j.JobId == edited.JobId);
            if (row == null)
            {
                Log($"⚠️ UpdateJobAsync: JobId {edited.JobId} not found.");
                return;
            }

            Log($"🔄 Updating scheduled job {edited.JobId}");

            // ────── Simple strings (trim) ──────
            row.PlatformFqdn = edited.PlatformFqdn?.Trim();
            row.PlatformAlias = edited.PlatformAlias?.Trim();
            row.AppRegistrationId = edited.AppRegistrationId?.Trim();
            row.CertThumbprint = edited.CertThumbprint?.Trim();
            row.InstructionName = edited.InstructionName?.Trim();
            row.AuthenticationMode = edited.AuthenticationMode?.Trim();
            row.TargetingMethod = edited.TargetingMethod?.Trim();
            row.Recurrence = edited.Recurrence?.Trim();
            row.ExportFormat = edited.ExportFormat?.Trim();
            row.Consumer = edited.Consumer?.Trim();

            // ────── Export behavior ──────
            row.ExportMode = edited.ExportMode;
            row.ExportFolderMode = edited.ExportFolderMode;
            row.ServerSideFallbackAfterFailures = edited.ServerSideFallbackAfterFailures;
            row.ServerExportIssued = edited.ServerExportIssued;
            row.ServerExportIssuedUtc = edited.ServerExportIssuedUtc;
            row.PagingExportFailureCount = edited.PagingExportFailureCount;

            // ────── Targeting fields ──────
            row.TargetingFqdn = (edited.TargetingFqdn ?? string.Empty).Trim();
            row.TargetingManagementGroup = (edited.TargetingManagementGroup ?? string.Empty).Trim();
            row.CoverageTagName = (edited.CoverageTagName ?? string.Empty).Trim();
            row.CoverageTagValue = (edited.CoverageTagValue ?? string.Empty).Trim();

            // Normalize targeting so ONLY the selected mode is persisted.
            // Keep legacy fields in sync so the scheduler cannot "lose" the active target.
            var tm = (row.TargetingMethod ?? string.Empty).Trim();
            if (tm.Equals("FQDN", StringComparison.OrdinalIgnoreCase))
            {
                row.TargetingManagementGroup = string.Empty;
                row.ManagementGroupId = null;
                row.CoverageTagName = string.Empty;
                row.CoverageTagValue = string.Empty;
                row.CoverageTag = null;
                row.CoverageValue = null;

                row.FqdnInput = string.IsNullOrWhiteSpace(row.TargetingFqdn) ? row.FqdnInput : row.TargetingFqdn;
                if (string.IsNullOrWhiteSpace(row.MatchType))
                    row.MatchType = "Equals";
            }
            else if (tm.Equals("MG", StringComparison.OrdinalIgnoreCase) || tm.Equals("Management Group", StringComparison.OrdinalIgnoreCase))
            {
                row.TargetingFqdn = string.Empty;
                row.FqdnInput = null;
                row.MatchType = null;
                row.CoverageTagName = string.Empty;
                row.CoverageTagValue = string.Empty;
                row.CoverageTag = null;
                row.CoverageValue = null;
            }
            else if (tm.Equals("Coverage", StringComparison.OrdinalIgnoreCase) ||
                     tm.Equals("CoverageTag", StringComparison.OrdinalIgnoreCase) ||
                     tm.Equals("Coverage Tag", StringComparison.OrdinalIgnoreCase))
            {
                row.TargetingFqdn = string.Empty;
                row.FqdnInput = null;
                row.MatchType = null;

                row.CoverageTag = string.IsNullOrWhiteSpace(row.CoverageTagName) ? row.CoverageTag : row.CoverageTagName;
                row.CoverageValue = string.IsNullOrWhiteSpace(row.CoverageTagValue) ? row.CoverageValue : row.CoverageTagValue;
            }

            // ────── IDs / numeric ──────
            row.InstructionId = edited.InstructionId;
            row.InstructionTtlMinutes = edited.InstructionTtlMinutes;
            row.ResponseTtlMinutes = edited.ResponseTtlMinutes;
            row.WeeklyRepeatCount = edited.WeeklyRepeatCount;
            row.MonthlyRepeatCount = edited.MonthlyRepeatCount;
            row.MonthlyDayFallback = edited.MonthlyDayFallback;
            row.ExportTtlMinutes = edited.ExportTtlMinutes;
            row.ManagementGroupId = edited.ManagementGroupId;


            // ────── Unit strings ──────
            row.InstructionTtlUnit = edited.InstructionTtlUnit?.Trim();
            row.ResponseTtlUnit = edited.ResponseTtlUnit?.Trim();

            // ────── Dates / times ──────
            row.StartDate = edited.StartDate;
            row.EndDate = edited.EndDate;
            row.StartTime = edited.StartTime;

            // ────── Collections (clone) ──────
            row.MonthlyWeekOffsets = edited.MonthlyWeekOffsets?.ToList() ?? new List<int>();
            row.DaysOfWeek = edited.DaysOfWeek?.ToList() ?? new List<DayOfWeek>();

            // ────── Parameters (NEW) ──────
            row.Parameters = edited.Parameters != null
                             ? new Dictionary<string, string>(edited.Parameters)
                             : new Dictionary<string, string>();

            // ────── Status / job-tracking fields ──────
            row.Status = edited.Status;
            row.FqdnInput = edited.FqdnInput;
            row.MatchType = edited.MatchType;
            row.ManagementGroupId = edited.ManagementGroupId;
            row.CoverageTag = edited.CoverageTag;
            row.CoverageValue = edited.CoverageValue;
            row.IsRunning = edited.IsRunning;
            row.IsEnabled = edited.IsEnabled;
            row.RuntimeStatus = edited.RuntimeStatus;
            row.RetryCount = edited.RetryCount;
            row.MaxRetries = edited.MaxRetries;
            row.Cooldown = edited.Cooldown;
            row.EnableExport = edited.EnableExport;

            Log($"✅ Updated job '{row.InstructionName}' ({row.JobId})");

            // Refresh UI & persist
            var idx = ScheduledJobs.IndexOf(row);
            ScheduledJobs[idx] = row;

            this.RaisePropertyChanged(nameof(ScheduledJobs));   // force DataGrid repaint
            await SaveJobsAsync();
            ResetScheduleFlags(row);
        }


        private static void ResetScheduleFlags(ScheduledJob job)
        {
            // If these fields exist in your class, clear them.
            job.HasLoggedInitialStatus = false;

            // Only include the ones your model actually has ─ comment out others.
            job.LastSkipLoggedUtc = null;
            job.LastLogWindowUtc = null;
            job.LastEvaluatedWindow = null;
            // job.NextCheckUtc       = null;   // ← only if you add it later
        }

        public class JobTimelineEntry
        {
            public string JobName { get; set; }
            public DateTime StartTime { get; set; }
            public DateTime EndTime { get; set; }
        }

        public ObservableCollection<JobTimelineEntry> JobTimeline { get; set; } = new();
        public void UpdateJobTimeline()
        {
            JobTimeline.Clear();

            foreach (var history in ExecutionHistory)
            {
                if (history.StartTime != default && history.EndTime != default)
                {
                    JobTimeline.Add(new JobTimelineEntry
                    {
                        JobName = history.JobName,
                        StartTime = history.StartTime,
                        EndTime = history.EndTime
                    });
                }
            }
        }

        public void DeleteSelectedJob()
        {
            if (SelectedScheduledJob == null) return;
            ScheduledJobs.Remove(SelectedScheduledJob);
            _ = SaveJobsAsync();
        }
        private string _selectedChart = "Concurrent Job Load (Day/Hour)";
        public string SelectedChart
        {
            get => _selectedChart;
            set
            {
                this.RaiseAndSetIfChanged(ref _selectedChart, value);
                PopulateChartData(); // 🔁 auto-update on change
            }
        }


        public bool IsHeatmapSelected
        {
            get => SelectedChart == "Concurrent Job Load (Heatmap)";
            set { if (value) SelectedChart = "Concurrent Job Load (Heatmap)"; }
        }

        public bool IsBucketChartSelected
        {
            get => SelectedChart == "Job Duration Ranges"; // match switch case in PopulateChartData
            set { if (value) SelectedChart = "Job Duration Ranges"; }
        }

        public bool IsAvgDurationSelected
        {
            get => SelectedChart == "Average Duration per Day"; // match switch case in PopulateChartData
            set { if (value) SelectedChart = "Average Duration per Day"; }
        }

        public ISeries[] DurationSeries { get; set; }


        public ISeries[] DurationBucketSeries { get; set; }
        public ISeries[] AvgDurationSeries { get; set; }

        private Axis[] _xAxes = Array.Empty<Axis>();
        public Axis[] XAxes
        {
            get => _xAxes;
            set => this.RaiseAndSetIfChanged(ref _xAxes, value);
        }

        private Axis[] _yAxes = Array.Empty<Axis>();
        public Axis[] YAxes
        {
            get => _yAxes;
            set => this.RaiseAndSetIfChanged(ref _yAxes, value);
        }


        public List<string> ChartModes { get; } = new()
            {
                "Jobs per Hour of Day",
                "Top Longest Jobs",
           //     "Recurrence Pattern Distribution",
                "Concurrent Job Load (Day/Hour)",
             //   "Optimization Hints",
                "Jobs per Day of Week",
                "Average Duration per Day",
                "Job Duration Ranges"
            };



        public void UpdateJobsPerHourChart()
        {
            // This should reflect ACTUAL executions, not just configured ScheduledJobs.StartTime.
            // It must also honor the Local/UTC toggle.
            var counts = new int[24];

            // Optional: last 7 days
            var cutoffUtc = DateTime.UtcNow.AddDays(-7);

            foreach (var entry in GetDistinctHistoryForCharts())
            {
                if (entry.StartTime == default)
                    continue;

                if (entry.StartTime.ToUniversalTime() < cutoffUtc)
                    continue;

                var t = NormalizeHistoryTime(entry.StartTime);
                counts[t.Hour]++;
            }

            ChartSeries = new ISeries[]
            {
        new ColumnSeries<int>
        {
            Name = "Jobs Executed",
            Values = counts
        }
            };

            XAxes = new Axis[]
            {
        new Axis
        {
            Labels = Enumerable.Range(0, 24).Select(h => ChartToday.AddHours(h).ToString("htt")).ToArray(),
            LabelsRotation = 15
        }
            };

            YAxes = new Axis[]
            {
        new Axis { Name = "Run Count" }
            };
        }



        public void UpdateLongestDurationJobsChart()
        {
            var top = ScheduledJobs
                .Where(j => (j.AverageDuration?.TotalMinutes ?? 0) > 0)
                .OrderByDescending(j => j.AverageDuration?.TotalMinutes ?? 0)
                .Take(10)
                .ToList();

            var jobNames = top.Select(j => j.InstructionName ?? "Unnamed").ToArray();

            ChartSeries = new ISeries[]
            {
        new RowSeries<double>
        {
            Name = "Avg Duration (min)",
            Values = top.Select(j => j.AverageDuration?.TotalMinutes ?? 0).ToArray(),
            Stroke = null
        },
        new RowSeries<double>
        {
            Name = "Max Duration (min)",
            Values = top.Select(j => j.MaxDuration?.TotalMinutes ?? 0).ToArray(),
            Stroke = null
        }
            };

            XAxes = new Axis[]
            {
        new Axis
        {
            Labels = jobNames,
            LabelsRotation = 0,
            LabelsPaint = new SolidColorPaint(SKColors.Black)
        }
            };

            YAxes = new Axis[]
            {
        new Axis { Name = "Minutes", MinLimit = 0 }
            };

            this.RaisePropertyChanged(nameof(ChartSeries));
            this.RaisePropertyChanged(nameof(XAxes));
            this.RaisePropertyChanged(nameof(YAxes));
        }


        public void UpdateRecurrenceDistributionChart()
        {

            Log("📊 UpdateRecurrenceDistributionChart() called");
            var counts = ScheduledJobs
                .GroupBy(j => j.Recurrence?.Trim() ?? "Unknown")
                .OrderByDescending(g => g.Count())
                .ToDictionary(g => g.Key, g => g.Count());

            if (!counts.Any())
                counts["None Scheduled"] = 1;

            ChartSeries = counts.Select(kvp =>
                new PieSeries<int>
                {
                    Name = kvp.Key,
                    Values = new[] { kvp.Value },
                    InnerRadius = 20
                }).ToArray();

            XAxes = Array.Empty<Axis>();
            YAxes = Array.Empty<Axis>();

            this.RaisePropertyChanged(nameof(ChartSeries));
        }


        public void UpdateConcurrentOverlapHeatmap()
        {
            var timeline = new int[24]; // hourly buckets
            foreach (var h in ExecutionHistory)
            {
                var start = NormalizeHistoryTime(h.StartTime);
                var end = NormalizeHistoryTime(h.EndTime);

                for (var time = start; time <= end; time = time.AddHours(1))
                {
                    timeline[time.Hour]++;
                }
            }

            ChartSeries = new ISeries[]
            {
                new ColumnSeries<int>
                {
                    Name = "Concurrent Jobs",
                    Values = timeline
                }
            };
            XAxes = new Axis[]
            {
                new Axis
                {
                    Labels = Enumerable.Range(0, 24).Select(h => ChartToday.AddHours(h).ToString("htt")).ToArray(),
                    LabelsRotation = 15
                }
            };
            YAxes = new Axis[]
            {
                new Axis { Name = "Job Count" }
            };
        }

        public void UpdateOptimizationHints()
        {
            Log("⚙ UpdateOptimizationHints() called");
            var hints = new List<string>();

            // Example: Long-running jobs
            var longest = ScheduledJobs
                .Where(j => (j.AverageDuration?.TotalMinutes ?? 0) > 0)
                .OrderByDescending(j => j.AverageDuration?.TotalMinutes ?? 0)
                .Take(5);

            foreach (var job in longest)
            {
                var name = job.InstructionName ?? "Unnamed";
                var mins = Math.Round(job.AverageDuration?.TotalMinutes ?? 0);
                hints.Add($"⏱ {name}: High avg duration ({mins} min)");
            }

            // Example: Recurrence gaps
            var noRecurrence = ScheduledJobs
                .Where(j => string.IsNullOrWhiteSpace(j.Recurrence))
                .ToList();

            if (noRecurrence.Any())
                hints.Add($"⚠️ {noRecurrence.Count} job(s) missing recurrence info");

            // Fallback if empty
            if (hints.Count == 0)
                hints.Add("✔ All jobs look well distributed and timed.");

            ChartSeries = new ISeries[]
            {
        new RowSeries<double>
        {
            Values = hints.Select((_, i) => (double)(hints.Count - i)).ToArray(),
            Stroke = null,
            DataLabelsSize = 14,
            DataLabelsPaint = new SolidColorPaint(SKColors.Black),
            DataLabelsPosition = LiveChartsCore.Measure.DataLabelsPosition.Middle,
            DataLabelsFormatter = (point) => hints[(int)point.Index]
        }
            };

            XAxes = Array.Empty<Axis>();
            YAxes = Array.Empty<Axis>();

            this.RaisePropertyChanged(nameof(ChartSeries));
        }



        public void PopulateChartData()
        {
            Log($"📊 PopulateChartData: ExecutionHistory Count = {ExecutionHistory.Count}");
            Log($"📍 SelectedChartView = {SelectedChart}");

            // Duration Buckets
            var buckets = new[] { "0–15 min", "15–30 min", "30–45 min", "45–60 min", "1–4 hrs", "4–6 hrs", "6–12 hrs", "12+ hrs" };
            var bucketCounts = new Dictionary<string, int>(buckets.ToDictionary(b => b, b => 0));

            foreach (var entry in GetDistinctHistoryForCharts())
            {
                var minutes = entry.DurationSeconds / 60.0;
                string bucket = minutes switch
                {
                    <= 15 => "0–15 min",
                    <= 30 => "15–30 min",
                    <= 45 => "30–45 min",
                    <= 60 => "45–60 min",
                    <= 240 => "1–4 hrs",
                    <= 360 => "4–6 hrs",
                    <= 720 => "6–12 hrs",
                    _ => "12+ hrs"
                };
                bucketCounts[bucket]++;
            }

            Log("📊 Duration Bucket Chart Data:");
            foreach (var bucket in buckets)
            {
                //Log($"• X: {bucket}, Y: {bucketCounts[bucket]}");
            }

            DurationBucketSeries = new ISeries[]
            {
        new ColumnSeries<int>
        {
            Values = bucketCounts.Values.ToArray(),
            Name = "Jobs"
        }
            };

            // Average Duration Over Time
            var avgByDate = ExecutionHistory
                .GroupBy(e => NormalizeHistoryTime(e.StartTime).Date)
                .Select(g => new
                {
                    Date = g.Key,
                    Avg = g.Average(e => e.DurationSeconds / 60.0)
                })
                .OrderBy(x => x.Date)
                .ToList();

            Log($"📅 avgByDate.Count = {avgByDate.Count}");
            Log("📈 Avg Duration Chart Data:");
            foreach (var x in avgByDate)
            {
                // Log($"• X: {x.Date.ToShortDateString()}, Y: {x.Avg:F2} min");
            }

            AvgDurationSeries = new ISeries[]
            {
        new LineSeries<double>
        {
            Values = avgByDate.Select(x => x.Avg).ToArray(),
            Name = "Avg Duration (min)"
        }
            };

            AvgXAxes = new Axis[]
            {
        new Axis
        {
            Labels = avgByDate.Select(x => x.Date.ToShortDateString()).ToArray(),
            LabelsRotation = 15
        }
            };

            AvgYAxes = new Axis[]
            {
        new Axis
        {
            Name = "Minutes"
        }
            };

            // Chart view switching logic
            switch (SelectedChart)
            {
                case "Jobs per Hour of Day":
                    UpdateJobsPerHourChart();
                    break;

                case "Top Longest Jobs":
                    UpdateLongestDurationJobsChart();
                    break;

                case "Recurrence Pattern Distribution":
                    UpdateRecurrenceDistributionChart();
                    break;

                case "Concurrent Job Density":
                    UpdateConcurrentOverlapHeatmap();
                    break;

                case "Optimization Hints":
                    UpdateOptimizationHints();
                    break;


                case "Jobs per Day of Week":
                    UpdateDayOfWeekSummaryChart();
                    break;

                case "Concurrent Job Load (Day/Hour)":
                    var heatmapData = new int[7, 24]; // [DayOfWeek][Hour]

                    foreach (var entry in GetDistinctHistoryForCharts())
                    {
                        var start = NormalizeHistoryTime(entry.StartTime);
                        var end = NormalizeHistoryTime(entry.EndTime);

                        for (var time = start; time <= end; time = time.AddHours(1))
                        {
                            int day = ((int)time.DayOfWeek + 6) % 7; // shift so Monday=0
                            int hour = time.Hour;
                            heatmapData[day, hour]++;
                        }
                    }

                    var series = new List<ISeries>();
                    var days = new[] { "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun" };
                    for (int d = 0; d < 7; d++)
                    {
                        var row = new ColumnSeries<int>
                        {
                            Name = days[d],
                            Values = Enumerable.Range(0, 24).Select(h => heatmapData[d, h]).ToArray(),
                            Stroke = null
                        };
                        series.Add(row);
                    }

                    ChartSeries = series.ToArray();
                    XAxes = new Axis[]
                    {
                        new Axis
                        {
                            Name = "Hour",
                            Labels = Enumerable.Range(0, 24)
                                               .Select(h => ChartToday.AddHours(h).ToString("htt"))
                                               .ToArray(),
                            LabelsRotation = 15
                        }
                    };
                    YAxes = new Axis[]
                    {
                        new Axis { Name = "Job Count" }
                    };
                    break;

                case "Average Duration per Day":
                    ChartSeries = AvgDurationSeries;
                    XAxes = AvgXAxes;
                    YAxes = AvgYAxes;
                    break;

                case "Job Duration Ranges":
                    ChartSeries = DurationBucketSeries;
                    XAxes = new Axis[]
                    {
                new Axis
                {
                    Labels = buckets,
                    LabelsRotation = 15
                }
                    };
                    YAxes = new Axis[]
                    {
                new Axis { Name = "Job Count" }
                    };
                    break;


            }

            this.RaisePropertyChanged(nameof(DurationBucketSeries));
            this.RaisePropertyChanged(nameof(AvgDurationSeries));
            this.RaisePropertyChanged(nameof(AvgXAxes));
            this.RaisePropertyChanged(nameof(AvgYAxes));
            this.RaisePropertyChanged(nameof(ChartSeries));
            this.RaisePropertyChanged(nameof(XAxes));
            this.RaisePropertyChanged(nameof(YAxes));
        }



        // Use an absolute path anchored to the app base directory so history persists reliably
        // regardless of current working directory (debugger, shortcut, installer, tray mode, etc.).
        private static readonly string ExecutionHistoryPath = AppPaths.ExecutionHistoryPath;
        public Axis[] AvgXAxes { get; set; }
        public Axis[] AvgYAxes { get; set; }

        private ISeries[] _activeChartSeries = Array.Empty<ISeries>();
        public ISeries[] ActiveChartSeries
        {
            get => _activeChartSeries;
            set => this.RaiseAndSetIfChanged(ref _activeChartSeries, value);
        }

        private Axis[] _activeXAxes = Array.Empty<Axis>();
        public Axis[] ActiveXAxes
        {
            get => _activeXAxes;
            set => this.RaiseAndSetIfChanged(ref _activeXAxes, value);
        }

        private Axis[] _activeYAxes = Array.Empty<Axis>();
        public Axis[] ActiveYAxes
        {
            get => _activeYAxes;
            set => this.RaiseAndSetIfChanged(ref _activeYAxes, value);
        }

        public async Task LoadExecutionHistoryAsync()
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(ExecutionHistoryPath)!);
            }
            catch
            {
                // If we can't create the folder, the read will fail and we will log below.
            }

            if (!File.Exists(ExecutionHistoryPath))
            {
                Log("No execution_history.json found.");
                return;
            }

            try
            {
                var json = await File.ReadAllTextAsync(ExecutionHistoryPath);
                var history = JsonConvert.DeserializeObject<List<JobExecutionHistory>>(json) ?? new();
                // Keep the same ObservableCollection instance to avoid DataGrid sort/reset churn.
                if (ExecutionHistory == null)
                    ExecutionHistory = new ObservableCollection<JobExecutionHistory>();

                ExecutionHistory.Clear();
                foreach (var h in history.OrderByDescending(h => h.StartTime))
                    ExecutionHistory.Add(h);

                Log($"📊 Loaded {ExecutionHistory.Count} execution history entries.");
            }
            catch (Exception ex)
            {
                Log($"❌ Failed to load execution history: {ex.Message}");
            }
        }
        public int TotalJobCount => ExecutionHistory?.Count ?? 0;





        public void UpdateDayOfWeekSummaryChart()
        {
            // This chart should reflect ACTUAL executions, not ScheduledJobs.DaysOfWeek.
            // Every15 / Every30 / Daily jobs often have DaysOfWeek empty, which makes the old chart show 0s.

            var orderedDays = new[]
            {
        DayOfWeek.Monday,
        DayOfWeek.Tuesday,
        DayOfWeek.Wednesday,
        DayOfWeek.Thursday,
        DayOfWeek.Friday,
        DayOfWeek.Saturday,
        DayOfWeek.Sunday
    };

            // Optional: limit to last 7 days so it doesn’t become “all-time”
            var cutoffUtc = DateTime.UtcNow.AddDays(-7);

            // Use ExecutionHistory (history tab) since that reflects real runs
            var history = GetDistinctHistoryForCharts();

            var counts = orderedDays.ToDictionary(d => d, _ => 0);

            foreach (var entry in history)
            {
                // Guard: ignore obviously-uninitialized timestamps
                if (entry.StartTime == default)
                    continue;

                // Keep consistent with your “Show UTC timestamps” toggle elsewhere if you want,
                // but day-of-week grouping should match the chart’s displayed time choice.
                // Here we use LocalTime so it matches what most users expect in the UI.
                var startBasis = NormalizeHistoryTime(entry.StartTime);

                // Filter to recent history
                if (entry.StartTime.ToUniversalTime() < cutoffUtc)
                    continue;

                // If you want to count only "Instruction" jobs or only "Exported", filter here:
                // if (!string.Equals(entry.JobType, "Instruction", StringComparison.OrdinalIgnoreCase)) continue;

                counts[startBasis.DayOfWeek]++;
            }

            var series = new ColumnSeries<int>
            {
                Name = "Jobs Executed",
                Values = orderedDays.Select(d => counts[d]).ToArray(),
                Stroke = null
            };

            ChartSeries = new ISeries[] { series };

            XAxes = new Axis[]
            {
        new Axis
        {
            Labels = orderedDays.Select(d => d.ToString().Substring(0, 3)).ToArray(),
            LabelsRotation = 15
        }
            };

            YAxes = new Axis[]
            {
        new Axis { Name = "Run Count" }
            };

            this.RaisePropertyChanged(nameof(ChartSeries));
            this.RaisePropertyChanged(nameof(XAxes));
            this.RaisePropertyChanged(nameof(YAxes));
        }


    }
}