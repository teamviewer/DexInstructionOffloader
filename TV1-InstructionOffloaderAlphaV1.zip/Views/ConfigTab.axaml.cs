﻿using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;
using Avalonia.Media;
using Avalonia.ReactiveUI;
using Avalonia.Threading;
using Avalonia.VisualTree;
using DocumentFormat.OpenXml.Spreadsheet;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reactive.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using TV1_InstructionOffloader.Helpers;
using TV1_InstructionOffloader.Models;
using TV1_InstructionOffloader.Services;
using TV1_InstructionOffloader.ViewModels;


namespace TV1_InstructionOffloader.Views
{
    public partial class ConfigTab : UserControl
    {
        private IDisposable? _instructionSearchTextSub;
        public sealed record PlatformDisplay(string GroupName, string PlatformFqdn, bool IsDefault)
        {
            public override string ToString() => GroupName;
        }

        private MainWindow? _main;

        public readonly ComboBox? TagNameCombo;
        public readonly ComboBox? TagValueCombo;
        public event Action<IReadOnlyList<Platform>>? PlatformsUpdated;
        private bool _isPlatformChanging = false;

        private ComboBox? _platformBox;
        private TextBox? _fqdnInputBox;
        private ListBox? _fqdnSuggestListBox;
        private System.Threading.CancellationTokenSource? _fqdnSearchCts;
        private string _lastFqdnSuggestQuery = string.Empty;
        private bool _suppressFqdnSuggest = false;
        private ComboBox? _mgDropdown;
        private StackPanel? _coveragePanel;
        private TextBox? _instructionTtlBox;
        private ComboBox? _instructionTtlUnitDropdown;
        private TextBox? _responseTtlBox;
        private ComboBox? _responseTtlUnitDropdown;
        private bool _isHandlingPlatformChange = false;

        // Guard flags to prevent duplicate control discovery / event wiring.
        private bool _controlsAttached = false;
        private bool _eventsAttached = false;
        private bool _innerTabEventsAttached = false;

        // Manual Run click reentrancy guard.
        private bool _isManualRunInProgress = false;

        // Scheduled job editor state.
        // Do not infer edit intent solely from JobsViewModel.SelectedScheduledJob – users often want
        // to create a NEW job even if one is selected in the Scheduled Jobs tab.
        private bool _isEditingScheduledJob = false;
        private string? _editingScheduledJobId = null;



        // Scheduled Job -> ConfigTab editor race fixes.
        // When we programmatically switch to the ConfigTab (e.g. "Edit Job" from Scheduled Jobs),
        // the visual tree may not be attached yet and/or the Platform/Instruction lists may not be populated.
        // These helpers let PopulateFromScheduledJobAsync deterministically wait for the UI to be ready.
        private readonly SemaphoreSlim _jobPopulateGate = new SemaphoreSlim(1, 1);
        private TaskCompletionSource<bool>? _controlsReadyTcs;

        private ComboBox? _recurrenceComboBox;
        private StackPanel? _recurrenceDayPanel;
        private StackPanel? _weeklyRepeatRow;
        private StackPanel? _monthlyPanel;
        private StackPanel? _daysOfWeekRow;
        private Button? _newScheduledJobButton;
        private TextBox? _logTextBox;
        private ScheduledJobsViewModel? _jobsVm;
        private DatePicker? _startDatePicker;
        private DatePicker? _endDatePicker;
        private TimePicker? _startTimePicker;
        private NumericUpDown? _monthlyRepeatCount;
        private ComboBox? _exportFormatComboBox;
        private ComboBox? _consumerDropdown;
        private Platform? _selectedPlatform;
        private string _fqdn = "";
        private string? _consumerName;
        private ComboBox _platformComboBox;
        private TextBox _platformFqdnTextBox;
        private TextBox _appRegIdTextBox;
        private TextBox _certThumbprintTextBox;
        private Button? _previewButton;
        private Button? _runNowButton;
        private InstructionDefinition? _selectedInstruction;
        private Platform? _platform;
        private string _platformUrl = "";
        private ListBox? _instructionListBox;
        private ConfigTab? _configTab;
        private ComboBox? _coverageTagNameDropdown;
        private ComboBox? _coverageTagValueDropdown;
        private InstructionService _instructionService;
        private string? _token;
        private TextBox _searchBox;
        private TokenStoreService _tokenStoreService;
        private AuthenticationService _authService;
        private InstructionHelper _instructionHelper;
        private string _platformAlias = "";
        private PlatformsTab? _platformsTab;
        private TextBox? _manualInstructionIdBox;
        private readonly MainWindow _mainWindow;
        public event Action<string, string>? PlatformSelected;
        private RadioButton? _fqdnRadio;
        private RadioButton? _mgRadio;
        private RadioButton? _coverageRadio;
        private TextBox? _targetingFqdnBox;
        private JobSchedulerService _scheduler;
        private List<InstructionDefinition> _allInstructions = new();
        private ManagementGroup? _selectedManagementGroup;
        private readonly ConfigHelper _configHelper = new ConfigHelper();
        private ConfigTabViewModel _vm;

        private ListBox? _automationListBox;

        public string? PlatformUrl => _platformUrl;
        public event Action<string, string>? PlatformChanged;
        public event Action? PlatformListChanged;

        public ConfigTab(
            InstructionService instructionService,
            TokenStoreService tokenStoreService,
            AuthenticationService authService,
            InstructionHelper instructionHelper)
        {
            InitializeComponent();
            _config = _configHelper.Load();
            // OnAttachedToVisualTree handles control lookup and event wiring.

            _vm = new ConfigTabViewModel();
            DataContext = _vm;
            // Subscribe to PlatformSaved on PlatformsTabHost
            var platformsHost = this.FindControl<PlatformsTab>("PlatformsTabHost");
            if (platformsHost?.DataContext is PlatformConfigViewModel platformVm)
            {
                platformVm.PlatformSaved += async () =>
                {
                    try
                    {
                        ReloadPlatformList();
                        ExportOptionsHost?.LoadPlatformDropdown();
                        ExportOptionsHost?.RefreshPlatforms();
                    }
                    catch (Exception ex)
                    {
                        LogHelper.Error($"❌ Error refreshing ExportOptionsTab: {ex}");
                    }

                    try
                    {
                        await SwitchToExportOptionsTabAsync("✅ Platform saved — switching to Export Options tab.");
                    }
                    catch (Exception ex)
                    {
                        LogHelper.Error($"❌ Failed to switch to Export Options tab: {ex}");
                    }
                };
            }


            _automationListBox = this.FindControl<ListBox>("AutomationListBox");


            _instructionService = instructionService;
            _tokenStoreService = tokenStoreService;
            _authService = authService;
            _instructionHelper = instructionHelper;
            _searchBox = this.FindControl<TextBox>("InstructionSearchBox_2")
                      ?? this.FindControl<TextBox>("InstructionSearchBox");

            _vm.PlatformsChanged += list => PlatformsUpdated?.Invoke(list);


            _vm.PlatformsChanged += list => ExportOptionsHost?.SetPlatforms(list.ToList());
            TagNameCombo = this.FindControl<ComboBox>("CoverageTagNameDropdown");
            TagValueCombo = this.FindControl<ComboBox>("CoverageTagValueDropdown");

            var logTextBox = this.FindControl<TextBox>("LogTextBox");
            if (logTextBox != null)
                _vm.SetLogTextBox(logTextBox);


        }

        public void SwitchToPlatformTab(string? message = null)
        {
            try
            {
                // Defer until the inner tab control exists and is ready.
                Dispatcher.UIThread.Post(() =>
                {
                    try
                    {
                        var innerTabs = this.FindControl<TabControl>("ConfigTabInnerTabControl");
                        if (innerTabs == null)
                        {
                            LogHelper.Info("❌ ConfigTabInnerTabControl not found — cannot switch to Platforms tab.");
                            return;
                        }

                        // Prefer the named tab item from XAML: <TabItem x:Name="PlatformsTabItem">
                        var platformTab = this.FindControl<TabItem>("PlatformsTabItem");
                        if (platformTab != null)
                        {
                            innerTabs.SelectedItem = platformTab;
                            LogHelper.Info("✅ Switched to Platforms tab (SelectedItem set).");
                        }
                        else
                        {
                            // Fallback: header match
                            int idx = -1;
                            if (innerTabs.Items is System.Collections.IList list)
                            {
                                for (int i = 0; i < list.Count; i++)
                                {
                                    if (list[i] is TabItem ti)
                                    {
                                        var hdr = ti.Header?.ToString() ?? string.Empty;
                                        if (hdr.IndexOf("Platform", StringComparison.OrdinalIgnoreCase) >= 0)
                                        {
                                            idx = i;
                                            break;
                                        }
                                    }
                                }
                            }

                            if (idx >= 0)
                            {
                                innerTabs.SelectedIndex = idx;
                                LogHelper.Info($"✅ Switched to Platforms tab (SelectedIndex={idx}).");
                            }
                            else
                            {
                                LogHelper.Info("❌ Could not locate Platforms tab item by name or header.");
                            }
                        }

                        if (!string.IsNullOrWhiteSpace(message))
                            LogHelper.Info(message);
                    }
                    catch (Exception ex2)
                    {
                        LogHelper.Error($"❌ SwitchToPlatformTab failed (deferred): {ex2.Message}");
                    }
                }, DispatcherPriority.Loaded);
            }
            catch (Exception ex)
            {
                LogHelper.Error($"❌ SwitchToPlatformTab failed: {ex.Message}");
            }
        }


        public void RefreshPlatformsTabFromConfig(string? selectAlias = null)
        {
            try
            {
                Dispatcher.UIThread.Post(async () =>
                {
                    try
                    {
                        // Avoid OpenXML Control ambiguity by fully-qualifying Avalonia Control.
                        var platformsHost = this.FindControl<Avalonia.Controls.Control>("PlatformsTabHost");
                        if (platformsHost?.DataContext is ViewModels.PlatformConfigViewModel platformsVm)
                        {
                            // If no alias is provided (first-run), select PH and open editor.
                            var aliasToSelect = string.IsNullOrWhiteSpace(selectAlias) ? "PH" : selectAlias;
                            var openEditor = string.IsNullOrWhiteSpace(selectAlias);

                            platformsVm.ReloadFromConfig(aliasToSelect, openEditor);
                            await NudgeUserToEditPlaceholderAsync("Placeholder refresh completed; issued nudge.");
                            return;
                        }

                        LogHelper.Info("⚠️ PlatformsTabHost/DataContext is not PlatformConfigViewModel — cannot refresh Platforms tab.");
                    }
                    catch (Exception ex2)
                    {
                        LogHelper.Error($"❌ RefreshPlatformsTabFromConfig failed (deferred): {ex2.Message}");
                    }
                }, DispatcherPriority.Loaded);
            }
            catch (Exception ex)
            {
                LogHelper.Error($"❌ RefreshPlatformsTabFromConfig failed: {ex.Message}");
            }
        }





        public async Task SwitchToExportOptionsTabAsync(string? message = null)
        {
            LogHelper.Info("LOGGING THE SWAP — entered SwitchToExportOptionsTabAsync");

            // give Avalonia a moment to finish any work on the ConfigTab UI
            await Task.Delay(100);

            var innerTabs = this.FindControl<TabControl>("ConfigTabInnerTabControl");
            if (innerTabs == null)
            {
                LogHelper.Info("❌ ConfigTabInnerTabControl not found — cannot switch to Export Options tab.");
                return;
            }

            // Try by x:Name
            var exportTab = innerTabs.FindControl<TabItem>("ExportOptionsTabItem");
            if (exportTab != null)
            {
                innerTabs.SelectedItem = exportTab;
                LogHelper.Info("✅ Switched to Export Options tab by name.");
            }
            else
            {
                // Try by header text
                exportTab = innerTabs.Items
                    .OfType<TabItem>()
                    .FirstOrDefault(t =>
                        string.Equals(t.Header?.ToString(), "Export Options", StringComparison.OrdinalIgnoreCase));

                if (exportTab != null)
                {
                    innerTabs.SelectedItem = exportTab;
                    LogHelper.Info("⚠️ Switched by header text instead of name.");
                }
                else
                {
                    // Final fallback: dynamic index
                    var idx = innerTabs.Items
                        .OfType<TabItem>()
                        .Select((tab, i) => (tab, i))
                        .FirstOrDefault(x =>
                            string.Equals(x.tab.Header?.ToString(), "Export Options", StringComparison.OrdinalIgnoreCase))
                        .i;

                    if (idx >= 0)
                    {
                        innerTabs.SelectedIndex = idx;
                        LogHelper.Info($"⚠️ Switched by dynamic index {idx}.");
                    }
                    else
                    {
                        LogHelper.Info("❌ Could not locate Export Options tab by name, header, or index.");
                    }
                }
            }
            ReloadPlatformList();
            ExportOptionsHost?.LoadPlatformDropdown();
            ExportOptionsHost?.RefreshPlatforms();
            // Diagnostic: list what tabs we actually see
            foreach (var item in innerTabs.Items.OfType<TabItem>())
                LogHelper.Debug($"Tab after delay: {item.Header}");

            if (!string.IsNullOrWhiteSpace(message))
                LogHelper.Info(message);
        }




        public int? GetManualResponseId()
        {
            var box = this.FindControl<TextBox>("ManualInstructionIdBox");
            if (box == null || string.IsNullOrWhiteSpace(box.Text))
                return null;

            if (int.TryParse(box.Text.Trim(), out int id))
                return id;

            return null;
        }

        private void HookControls()
        {
            _platformBox = this.FindControl<ComboBox>("PlatformComboBox");
            var defaultFqdn = ConfigHelper.GetDefaultPlatformUrl();

            if (_platformBox != null && _platformBox.ItemsSource is IEnumerable<Platform> platforms)
            {
                var match = platforms.FirstOrDefault(p => p.PlatformFqdn == defaultFqdn) ?? platforms.FirstOrDefault();
                if (match != null)
                {
                    _platformBox.SelectedItem = match;
                    _selectedPlatform = match;

                    // Do not authenticate here. Platform authentication and instruction data loading
                    // is triggered when the user navigates to the Instructions inner tab.

                    LogHelper.Info($"✅ Auto-selected platform = {match.PlatformFqdn}");
                    RaisePlatformSelected(); // ensure mainwindow receives it
                }
            }
            _mgDropdown = this.FindControl<ComboBox>("ManagementGroupDropdown");
            if (_mgDropdown != null)
            {
                _mgDropdown.SelectionChanged += (_, _) =>
                {
                    _selectedManagementGroup = _mgDropdown.SelectedItem as ManagementGroup;
                    LogHelper.Info($"📦 Selected MG changed to: {_selectedManagementGroup?.Name} / {_selectedManagementGroup?.UsableId}");
                };
            }


            if (_platformBox != null)
            {
                _platformBox.SelectionChanged += PlatformBox_SelectionChanged;
                ReloadPlatformList();
                LogHelper.Info("[HookControls] _platformBox is found.");
            }
        }

        private void RaisePlatformSelected()
        {
            if (_selectedPlatform != null)
            {
                LogHelper.Info($".... Raising platform selection ... Alias: {_selectedPlatform.GroupName}, FQDN: {_selectedPlatform.PlatformFqdn}");
                PlatformSelected?.Invoke(_selectedPlatform.GroupName ?? "", _selectedPlatform.PlatformFqdn ?? "");
            }
            else
            {
                LogHelper.Warn("⚠️ RaisePlatformSelected called but _selectedPlatform is null.");
            }
        }


        public Platform? GetSelectedPlatform()
        {
            return _platformBox?.SelectedItem as Platform ?? _selectedPlatform;
        }


        protected override void OnAttachedToVisualTree(VisualTreeAttachmentEventArgs e)
        {
            base.OnAttachedToVisualTree(e);

            if (_hasAttachedToVisualTreeOnce)
            {
                // Avoid repeating expensive startup work when Avalonia re-attaches visuals.
                return;
            }
            _hasAttachedToVisualTreeOnce = true; LogHelper.Info("🧩 ConfigTab.OnAttachedToVisualTree triggered");

            AttachControls();
            /*
                        if (AutomationTabControl != null && _instructionService != null && _logTextBox != null)
                        {
                            AutomationTabControl.SetDependencies(_instructionService, _fqdn, _token ?? "", _logTextBox, _authService);
                        }
            */

            _platformBox = this.FindControl<ComboBox>("PlatformComboBox");
            if (_platformBox == null)
            {
                LogHelper.Warn("⚠ PlatformComboBox not found.");
                return;
            }

            // Populate the platform list (and select the default) now that we are attached to the visual tree.
            // NOTE: Do NOT authenticate here. We authenticate when the user navigates to Instructions, or when
            // the user explicitly changes platform.
            ReloadPlatformList();

            // Ensure platform state is pushed to MainWindow
            if (_platformBox?.SelectedItem is Platform selected)
            {
                _selectedPlatform = selected;
                _platformUrl = selected.PlatformFqdn;
                LogHelper.Info($"📡 Final selected platform: {_selectedPlatform?.GroupName} / {_platformUrl}");
                RaisePlatformSelected(); // Notify MainWindow
            }
            else
            {
                LogHelper.Warn("⚠️ No platform selected after fallback.");
            }

            AttachEvents(); // ✅ AFTER _platformBox is initialized

            // If the Instructions inner tab is already selected when ConfigTab is first shown,
            // SelectionChanged may not fire. Kick off the same auto-load/auth path once.
            if (!_hasTriggeredInitialLoad)
            {
                _hasTriggeredInitialLoad = true;
                Dispatcher.UIThread.Post(async () =>
                {
                    try
                    {
                        var innerTabs = this.FindControl<TabControl>("ConfigTabInnerTabControl");
                        var instructionsTab = this.FindControl<TabItem>("InstructionsTab");
                        if (innerTabs != null && instructionsTab != null && innerTabs.SelectedItem == instructionsTab)
                            await EnsurePlatformContextAndInstructionDataAsync();
                    }
                    catch (Exception ex)
                    {
                        LogHelper.Error($"❌ Initial Instructions tab auto-load failed: {ex.Message}");
                    }
                });
            }
        }

        private Task WaitForControlsReadyAsync(CancellationToken ct)
        {
            // Fast-path if controls are already attached.
            if (_controlsAttached && _platformBox != null && _instructionListBox != null)
                return Task.CompletedTask;

            // Lazily create a waiter. This is completed once AttachControls runs.
            _controlsReadyTcs ??= new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);

            if (ct.CanBeCanceled)
                ct.Register(() => _controlsReadyTcs.TrySetCanceled(ct));

            return _controlsReadyTcs.Task;
        }

        private async Task WaitForPlatformListAsync(TimeSpan timeout, CancellationToken ct)
        {
            var startUtc = DateTime.UtcNow;
            while (true)
            {
                ct.ThrowIfCancellationRequested();

                bool ready = false;
                await Dispatcher.UIThread.InvokeAsync(() =>
                {
                    if (_platformBox?.ItemsSource is IEnumerable<Platform> ps && ps.Any())
                        ready = true;
                });

                if (ready)
                    return;

                if (DateTime.UtcNow - startUtc > timeout)
                    return;

                await Task.Delay(50, ct);
            }
        }

        private async Task WaitForInstructionListAsync(TimeSpan timeout, CancellationToken ct)
        {
            var startUtc = DateTime.UtcNow;
            while (true)
            {
                ct.ThrowIfCancellationRequested();

                bool ready = false;
                await Dispatcher.UIThread.InvokeAsync(() =>
                {
                    if ((_vm?.Instructions?.Count ?? 0) > 0 || _allInstructions.Count > 0)
                        ready = true;
                });

                if (ready)
                    return;

                if (DateTime.UtcNow - startUtc > timeout)
                    return;

                await Task.Delay(50, ct);
            }
        }

        private async Task<Platform?> EnsurePlatformContextForJobAsync(ScheduledJob job, CancellationToken ct)
        {
            await WaitForControlsReadyAsync(ct);

            if (_platformBox == null)
                _platformBox = this.FindControl<ComboBox>("PlatformComboBox");

            if (_platformBox == null)
                return null;

            // Ensure platform list exists.
            await Dispatcher.UIThread.InvokeAsync(() =>
            {
                if (_platformBox.ItemsSource == null)
                    ReloadPlatformList();
            });

            await WaitForPlatformListAsync(TimeSpan.FromSeconds(5), ct);

            Platform? matchedPlatform = null;
            await Dispatcher.UIThread.InvokeAsync(() =>
            {
                if (_platformBox.ItemsSource is IEnumerable<Platform> platforms)
                {
                    matchedPlatform = platforms.FirstOrDefault(p =>
                        string.Equals(p.PlatformFqdn, job.PlatformFqdn, StringComparison.OrdinalIgnoreCase) ||
                        string.Equals(p.GroupName, job.PlatformAlias, StringComparison.OrdinalIgnoreCase) ||
                        string.Equals(p.Alias, job.PlatformAlias, StringComparison.OrdinalIgnoreCase));
                }
            });

            if (matchedPlatform == null)
                return null;

            // Force the pipeline even if the same platform is already selected (SelectionChanged may not fire).
            await Dispatcher.UIThread.InvokeAsync(() =>
            {
                _suppressPlatformSelectionChanged = true;
                _platformBox.SelectedItem = matchedPlatform;
                _suppressPlatformSelectionChanged = false;
                SetSelectedPlatform(matchedPlatform);
            });

            await HandlePlatformSelectionAsync(matchedPlatform, forceAuth: true);
            await WaitForInstructionListAsync(TimeSpan.FromSeconds(20), ct);

            return matchedPlatform;
        }

        public string GetSelectedPlatformUrl()
        {
            if (_platformBox?.SelectedItem is Platform platform)
            {
                _platformAlias = platform.Alias ?? "";
                LogHelper.Info($"📡 GetSelectedPlatformUrl → {_platformAlias} / {platform.PlatformFqdn}");
                return platform.PlatformFqdn ?? "";
            }

            if (_selectedPlatform != null)
            {
                _platformAlias = _selectedPlatform.Alias ?? "";
                LogHelper.Info($"📡 Fallback to _selectedPlatform → {_platformAlias} / {_selectedPlatform.PlatformFqdn}");
                return _selectedPlatform.PlatformFqdn ?? "";
            }

            _platformAlias = "";
            var fallback = _platformFqdnTextBox?.Text ?? "";
            LogHelper.Warn($"⚠️ GetSelectedPlatformUrl fallback → {fallback}");
            return fallback;
        }

        // Called by MainWindow after authentication/refresh so ConfigTab features
        // (preview targets, FQDN suggestions, consumer/MG loading) can use the
        // current platform token without re-authing or falling into "not authenticated" states.
        public void SetAuthContext(string fqdn, string token)
        {
            _fqdn = fqdn;
            _token = token;
        }

        // Run is enabled only after a successful Preview.
        public void SetRunNowEnabled(bool enabled)
        {
            try
            {
                _runNowButton ??= this.FindControl<Button>("RunNowButton");
                if (_runNowButton != null)
                    _runNowButton.IsEnabled = enabled;
            }
            catch { }
        }






        public string GetCurrentToken() => _token ?? string.Empty;

        public InstructionDefinition? GetSelectedInstructionDefinition()
        {
            return _selectedInstruction ?? _vm?.SelectedInstruction;
        }

        public string GetSelectedTargetingMode()
        {
            // Normalized to match existing scheduler/runner strings.
            if (_fqdnRadio?.IsChecked == true) return "FQDN";
            if (_mgRadio?.IsChecked == true) return "Management Group";
            if (_coverageRadio?.IsChecked == true) return "Coverage Tag";
            return string.Empty;
        }

        public string GetTargetingFqdn() => _fqdnInputBox?.Text?.Trim() ?? string.Empty;

        public ManagementGroup? GetSelectedManagementGroup()
        {
            return _mgDropdown?.SelectedItem as ManagementGroup;
        }

        public (string Name, string Value) GetSelectedCoverageTag()
        {
            var name = (_coverageTagNameDropdown?.SelectedItem as string) ?? string.Empty;
            var value = (_coverageTagValueDropdown?.SelectedItem as string) ?? string.Empty;
            return (name, value);
        }

        private async void OnPlatformChanged(object? sender, SelectionChangedEventArgs e)
        {
            if (_isHandlingPlatformChange) return;
            _isHandlingPlatformChange = true;

            try
            {
                if (_platformBox?.SelectedItem is not Platform platform) return;

                _fqdn = platform.PlatformFqdn;
                _consumerName = platform.DefaultConsumer ?? "Explorer";

                LogHelper.Info($"🔄 Platform switched to {_fqdn} (default consumer = {_consumerName})");

                if (_main == null)
                {
                    LogHelper.Error("❌ Main window reference is null.");
                    return;
                }

                if (!_config.EnableDevTokenReuse || !_main.TokenStore.TryGetToken(_fqdn, out _token) || string.IsNullOrWhiteSpace(_token))
                {
                    LogHelper.Info("ℹ️ No valid cached token → authenticating…");

                    // IMPORTANT: Use the currently selected platform item from the dropdown.
                    // Do NOT use any stale/outer variable here, otherwise Alias/UserId won't flow into auth.
                    var settings = new PlatformSettings
                    {
                        Alias = string.IsNullOrWhiteSpace(platform.Alias) ? (platform.GroupName ?? null) : platform.Alias,
                        PlatformFqdn = _fqdn,
                        AppId = platform.AppId,
                        CertThumbprint = platform.CertThumbprint,
                        UseCert = platform.UseCert,
                        UserId = string.IsNullOrWhiteSpace(platform.UserId) ? null : platform.UserId
                    };
                    _main?.AppendUiLog($"🧪 AUTH DEBUG: Alias={settings.Alias ?? "(none)"}, UseCert={settings.UseCert}, AppId={(string.IsNullOrWhiteSpace(settings.AppId) ? "(missing)" : settings.AppId)}, Thumb={(string.IsNullOrWhiteSpace(settings.CertThumbprint) ? "(missing)" : (settings.CertThumbprint.Length > 6 ? new string('*', settings.CertThumbprint.Length - 6) + settings.CertThumbprint[^6..] : settings.CertThumbprint))}, UPN={(string.IsNullOrWhiteSpace(settings.UserId) ? "(none)" : settings.UserId)}, Fqdn={settings.PlatformFqdn}");
                    LogHelper.Info($"🧪 AUTH DEBUG (ConfigTab): alias={settings.Alias ?? "(none)"}, fqdn={settings.PlatformFqdn}, useCert={settings.UseCert}, appId={(string.IsNullOrWhiteSpace(settings.AppId) ? "(missing)" : settings.AppId)}, upn={(string.IsNullOrWhiteSpace(settings.UserId) ? "(none)" : "(set)")}");

                    var authResult = await _authService.AuthenticateAsync(settings);
                    if (string.IsNullOrWhiteSpace(authResult?.Token))
                    {
                        LogHelper.Error("❌ Authentication failed — aborting platform switch.");
                        return;
                    }

                    _token = authResult.Token;



                    if (_config.EnableDevTokenReuse)
                    {

                        // Token store is keyed by platform host/FQDN. Do not use any URL-with-scheme variable here.
                        _main.TokenStore.SaveToken(_fqdn, _token);

                        LogHelper.Info("✅ Authenticated and token cached.");
                    }

                    string? displayName = await _authService.GetDisplayNameFromWhoAmIAsync(_fqdn, _token);
                    _main.SetLoggedInUserDisplay(displayName ?? authResult.PrincipalName ?? "Unknown");
                    _main.SetSelectedPlatformDisplay(_fqdn);
                }
                else
                {
                    LogHelper.Info("✅ Re-using cached token.");

                    // Validate the cached token. If whoami returns 401/403, treat it as invalid and re-auth.
                    // (GetDisplayNameFromWhoAmIAsync returns null on non-success.)
                    _main.SetSelectedPlatformDisplay(_fqdn);
                    string? displayName = await _authService.GetDisplayNameFromWhoAmIAsync(_fqdn, _token);
                    if (string.IsNullOrWhiteSpace(displayName))
                    {
                        LogHelper.Info("⚠️ Cached token rejected by whoami → forcing re-authentication.");

                        // Best-effort: clear cached token for this platform so we don't loop.
                        try { _main.TokenStore.RemoveToken(_fqdn); } catch { }

                        var settings = new PlatformSettings
                        {
                            Alias = string.IsNullOrWhiteSpace(platform.Alias) ? (platform.GroupName ?? null) : platform.Alias,
                            PlatformFqdn = _fqdn,
                            AppId = platform.AppId,
                            CertThumbprint = platform.CertThumbprint,
                            UseCert = platform.UseCert,
                            UserId = string.IsNullOrWhiteSpace(platform.UserId) ? null : platform.UserId
                        };

                        _main?.AppendUiLog($"🧪 AUTH DEBUG: Alias={settings.Alias ?? "(none)"}, UseCert={settings.UseCert}, AppId={(string.IsNullOrWhiteSpace(settings.AppId) ? "(missing)" : settings.AppId)}, Thumb={(string.IsNullOrWhiteSpace(settings.CertThumbprint) ? "(missing)" : (settings.CertThumbprint.Length > 6 ? new string('*', settings.CertThumbprint.Length - 6) + settings.CertThumbprint[^6..] : settings.CertThumbprint))}, UPN={(string.IsNullOrWhiteSpace(settings.UserId) ? "(none)" : settings.UserId)}, Fqdn={settings.PlatformFqdn}");

                        var authResult = await _authService.AuthenticateAsync(settings);
                        if (string.IsNullOrWhiteSpace(authResult?.Token))
                        {
                            LogHelper.Error("❌ Authentication failed — aborting platform switch.");
                            return;
                        }

                        _token = authResult.Token;
                        if (_config.EnableDevTokenReuse)
                        {
                            _main.TokenStore.SaveToken(_fqdn, _token);
                            LogHelper.Info("✅ Authenticated and token cached.");
                        }

                        displayName = await _authService.GetDisplayNameFromWhoAmIAsync(_fqdn, _token);
                        _main.SetLoggedInUserDisplay(displayName ?? authResult.PrincipalName ?? "Unknown");
                    }
                    else
                    {
                        _main.SetLoggedInUserDisplay(displayName);
                    }
                }

                await _instructionHelper.LoadManagementGroupsAsync(_fqdn, _token, _mgDropdown, _logTextBox);
                await _instructionHelper.LoadCustomPropertiesAsync(_fqdn, _token, _coverageTagNameDropdown, _coverageTagValueDropdown, _logTextBox);
                _allInstructions = await _instructionHelper.LoadInstructionsAsync(_fqdn, _token, _logTextBox);

                // Preserve XAML binding: do not assign ItemsSource directly. Populate the VM list.
                if (_instructionListBox != null)
                {
                    SetInstructions(_allInstructions);
                }
            }
            finally
            {
                _isHandlingPlatformChange = false;
            }
        }


        private readonly MainWindow _configWindow;

        public ConfigTab(MainWindow configWindow)
        {
            _configWindow = configWindow;
            InitializeComponent();
            //AutomationTabControl = this.FindControl<AutomationTab>("AutomationTabControl");

            AttachEvents();
        }


        private string? GetDefaultPlatformFqdn()
        {
            string path = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "TV1_InstructionOffloader",
                "appsettings.json");

            if (!File.Exists(path))
                return null;

            try
            {
                var json = JObject.Parse(File.ReadAllText(path));
                string defaultAlias = json["DefaultPlatformAlias"]?.ToString()?.Trim() ?? "";
                var platforms = json["Platforms"] as JArray;

                if (platforms == null) return null;

                foreach (var entry in platforms.OfType<JObject>())
                {
                    string? url = entry["PlatformFqdn"]?.ToString()?.Trim();
                    string? alias = entry["Alias"]?.ToString()?.Trim();

                    if (alias != null && alias.Equals(defaultAlias, StringComparison.OrdinalIgnoreCase))
                        return url;
                }

                // fallback to first
                return platforms.FirstOrDefault()?["PlatformFqdn"]?.ToString()?.Trim();
            }
            catch (Exception ex)
            {
                LogHelper.Error($"❌ Failed to read default platform: {ex.Message}");
                return null;
            }
        }



        private void AttachControls()
        {
            if (_controlsAttached)
                return;

            _controlsAttached = true;

            _recurrenceComboBox = this.FindControl<ComboBox>("RecurrenceComboBox");
            _recurrenceDayPanel = this.FindControl<StackPanel>("RecurrenceDayPanel");
            _weeklyRepeatRow = this.FindControl<StackPanel>("WeeklyRepeatRow");
            _monthlyPanel = this.FindControl<StackPanel>("MonthlyPanel");
            _instructionListBox = this.FindControl<ListBox>("InstructionListBox");
            _daysOfWeekRow = this.FindControl<StackPanel>("DaysOfWeekRow");
            _newScheduledJobButton = this.FindControl<Button>("NewScheduledJobButton");
            _logTextBox = this.FindControl<TextBox>("LogTextBox");
            _startDatePicker = this.FindControl<DatePicker>("StartDatePicker");
            _endDatePicker = this.FindControl<DatePicker>("EndDatePicker");
            _startTimePicker = this.FindControl<TimePicker>("StartTimePicker");
            _monthlyRepeatCount = this.FindControl<NumericUpDown>("MonthlyRepeatCount");
            _exportFormatComboBox = this.FindControl<ComboBox>("ExportFormatComboBox");
            _consumerDropdown = this.FindControl<ComboBox>("ConsumerDropdown");
            _previewButton = this.FindControl<Button>("PreviewTargetsButton");
            _runNowButton = this.FindControl<Button>("RunNowButton");

            // Run is enabled only after a successful Preview.
            if (_runNowButton != null)
                _runNowButton.IsEnabled = false;
            _logTextBox = this.FindControl<TextBox>("LogTextBox");
            _coverageTagNameDropdown = this.FindControl<ComboBox>("CoverageTagNameComboBox");
            _coverageTagValueDropdown = this.FindControl<ComboBox>("CoverageTagValueComboBox");
            _fqdnInputBox = this.FindControl<TextBox>("FqdnInputBox");
            _fqdnSuggestListBox = this.FindControl<ListBox>("FqdnSuggestListBox");
            //AutomationTabControl = this.FindControl<AutomationTab>("AutomationTabControl");
            _manualInstructionIdBox = this.FindControl<TextBox>("ManualInstructionIdBox");
            _fqdnRadio = this.FindControl<RadioButton>("FqdnRadio");
            _mgRadio = this.FindControl<RadioButton>("MgRadio");
            _coverageRadio = this.FindControl<RadioButton>("CoverageTagRadio");
            _targetingFqdnBox = this.FindControl<TextBox>("FqdnInputBox");

            // Signal any pending "Edit Job" waits now that controls exist.
            _controlsReadyTcs?.TrySetResult(true);

        }

        private void AttachEvents()
        {
            if (_eventsAttached)
                return;

            _eventsAttached = true;

            if (_recurrenceComboBox != null)
            {
                _recurrenceComboBox.SelectionChanged -= RecurrenceComboBox_SelectionChanged;
                _recurrenceComboBox.SelectionChanged += RecurrenceComboBox_SelectionChanged;
            }

            if (_newScheduledJobButton != null)
            {
                _newScheduledJobButton.Click -= NewScheduledJobButton_Click;
                _newScheduledJobButton.Click += NewScheduledJobButton_Click;
            }

            if (_previewButton != null)
            {
                _previewButton.Click -= PreviewButton_Click;
                _previewButton.Click += PreviewButton_Click;
            }

            if (_runNowButton != null)
            {
                _runNowButton.Click -= RunNowButton_Click;
                _runNowButton.Click += RunNowButton_Click;
            }

            if (_instructionListBox != null)
            {
                _instructionListBox.SelectionChanged -= InstructionListBox_SelectionChanged;
                _instructionListBox.SelectionChanged += InstructionListBox_SelectionChanged;
            }

            if (_platformBox != null)
            {
                _platformBox.SelectionChanged -= PlatformBox_SelectionChanged;
                _platformBox.SelectionChanged += PlatformBox_SelectionChanged;
            }

            var fetchExportButton = this.FindControl<Button>("FetchExportButton");
            if (fetchExportButton != null)
            {
                fetchExportButton.Click -= FetchExportButton_Click;
                fetchExportButton.Click += FetchExportButton_Click;
            }

            _main = App.Current?.ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop
                ? desktop.MainWindow as MainWindow
                : null;

            if (_searchBox != null)
            {
                // This should only be wired once; guarded by _eventsAttached.
                // NOTE: Some Avalonia text input paths do not emit a stable stream when IME/composition is involved.
                // Keep this simple + resilient: debounce, distinct, then marshal to UI thread and update the bound list.

                _instructionSearchTextSub?.Dispose();
                _instructionSearchTextSub = _searchBox.GetObservable(TextBox.TextProperty)
                      .Throttle(TimeSpan.FromMilliseconds(200))
                      .DistinctUntilChanged()
                      .Subscribe(text =>
                      {
                          Dispatcher.UIThread.Post(() => OnSearchTextChanged(text));
                      });

                // Also allow an immediate refresh when the user hits Enter.
                _searchBox.KeyUp -= InstructionSearchBox_KeyUp;
                _searchBox.KeyUp += InstructionSearchBox_KeyUp;
            }

            if (_fqdnInputBox != null)
            {
                _fqdnInputBox.GetObservable(TextBox.TextProperty)
                    .Skip(1)
                    .Throttle(TimeSpan.FromMilliseconds(250))
                    .ObserveOn(AvaloniaScheduler.Instance)
                    .Subscribe(text => _ = UpdateFqdnSuggestionsAsync(text));
            }

            if (_fqdnSuggestListBox != null)
            {
                _fqdnSuggestListBox.SelectionChanged -= FqdnSuggestListBox_SelectionChanged;
                _fqdnSuggestListBox.SelectionChanged += FqdnSuggestListBox_SelectionChanged;
            }

            DataContext = _vm;

            _vm.PlatformVm.PlatformSaved -= PlatformVm_PlatformSaved;
            _vm.PlatformVm.PlatformSaved += PlatformVm_PlatformSaved;

            HookInnerTabAutoLoad();
        }

        private void NewScheduledJobButton_Click(object? sender, RoutedEventArgs e)
        {
            _jobsVm ??= new ScheduledJobsViewModel();
            _jobsVm.SelectedScheduledJob = null;

            // Explicitly exit edit mode.
            _isEditingScheduledJob = false;
            _editingScheduledJobId = null;

            ClearJobEditorForm();
            RecurrenceComboBox_SelectionChanged(_recurrenceComboBox, null);
            LogHelper.Info("🆕 New Job initialized.\n");
        }

        private void PreviewButton_Click(object? sender, RoutedEventArgs e)
        {
            OnPreviewClicked();
        }

        private void RunNowButton_Click(object? sender, RoutedEventArgs e)
        {
            OnRunNowClicked();
        }

        private void InstructionListBox_SelectionChanged(object? sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (_instructionListBox?.SelectedItem is InstructionDefinition def)
                {
                    _selectedInstruction = def;
                    _vm.SelectedInstruction = def;
                }
                else
                {
                    _selectedInstruction = null;
                    _vm.SelectedInstruction = null;
                }
            }
            catch (Exception ex)
            {
                LogHelper.Error($"❌ Instruction selection change failed: {ex.Message}");
            }
        }

        private async void FetchExportButton_Click(object? sender, RoutedEventArgs e)
        {
            if (Application.Current?.ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop &&
                desktop.MainWindow is MainWindow mw)
            {
                LogHelper.Info("🧪 FetchExportButton clicked from ConfigTab.");
                await mw.RunOnFetchExportClickedFromConfig();
            }
        }

        private void PlatformVm_PlatformSaved()
        {
            ReloadPlatformList();
            LogHelper.Info("🔄 Reloaded platform list");

            var exportTab = this.FindControl<ExportOptionsTab>("ExportOptionsHost");
            if (exportTab != null)
            {
                exportTab.LoadPlatformDropdown();
                exportTab.RefreshPlatforms();
                LogHelper.Info("✅ ExportOptionsTab refreshed via FindControl");
            }
            else
            {
                LogHelper.Warn("⚠️ ExportOptionsTabHost not found via FindControl");
            }
        }

        private void HookInnerTabAutoLoad()
        {
            if (_innerTabEventsAttached)
                return;

            var innerTabs = this.FindControl<TabControl>("ConfigTabInnerTabControl");
            if (innerTabs == null)
                return;

            _innerTabEventsAttached = true;

            innerTabs.SelectionChanged -= InnerTabs_SelectionChanged;
            innerTabs.SelectionChanged += InnerTabs_SelectionChanged;
        }

        private void InnerTabs_SelectionChanged(object? sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (sender is not TabControl tabs)
                    return;

                // Only auto-load/auth when switching to the Instructions tab.
                if (tabs.SelectedItem is TabItem ti &&
                    (ti.Name?.Equals("InstructionsTab", StringComparison.OrdinalIgnoreCase) == true))
                {
                    Dispatcher.UIThread.Post(async () =>
                    {
                        // If we are in the middle of populating the editor from an existing scheduled job,
                        // do NOT auto-load/refresh here. PopulateFromScheduledJobAsync is responsible for
                        // forcing auth + loading lists, and a concurrent refresh here can clear selections.
                        if (_isPopulatingJob)
                            return;

                        // If we already have data + token, don't reload the lists, but DO ensure the top-right status is updated.
                        if ((_vm.Instructions?.Count ?? 0) > 0 && !string.IsNullOrWhiteSpace(_token))
                        {
                            await EnsureMainWindowStatusAsync();
                            return;
                        }

                        await EnsurePlatformContextAndInstructionDataAsync();
                    });
                }
            }
            catch (Exception ex)
            {
                LogHelper.Error($"❌ Inner tab switch handling failed: {ex.Message}");
            }
        }

        private async Task EnsureMainWindowStatusAsync()
        {
            // Best-effort UI header update. Never throws. Debounced to avoid whoami storms.
            try
            {
                if (_isUpdatingHeaderStatus)
                    return;

                var nowUtc = DateTime.UtcNow;
                if (_lastHeaderStatusUtc != DateTime.MinValue && (nowUtc - _lastHeaderStatusUtc) < TimeSpan.FromSeconds(1))
                    return;

                _isUpdatingHeaderStatus = true;
                _lastHeaderStatusUtc = nowUtc;

                _main ??= App.Current?.ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop
                    ? desktop.MainWindow as MainWindow
                    : null;

                if (_main == null)
                    return;

                if (string.IsNullOrWhiteSpace(_fqdn) || string.IsNullOrWhiteSpace(_token))
                    return;

                string? displayName = null;
                try
                {
                    displayName = await _authService.GetDisplayNameFromWhoAmIAsync(_fqdn, _token);
                }
                catch
                {
                    // Never throw from status refresh
                }

                var userText = displayName ?? "Unknown";
                Dispatcher.UIThread.Post(() =>
                {
                    _main?.SetLoggedInUserDisplay(userText);
                    _main?.SetSelectedPlatformDisplay(_fqdn);
                });
            }
            catch
            {
                // Never throw from status refresh
            }
            finally
            {
                _isUpdatingHeaderStatus = false;
            }
        }


        private async Task EnsurePlatformContextAndInstructionDataAsync()
        {
            try
            {
                if (_platformBox == null)
                    return;

                // If nothing is selected (common on first navigation), pick a sensible default.
                if (_platformBox.SelectedItem == null)
                {
                    // Only rebuild the list if we genuinely have no items.
                    if (_platformBox.ItemsSource == null)
                        ReloadPlatformList();

                    if (_platformBox.SelectedItem == null)
                    {
                        if (_platformBox.ItemsSource is IEnumerable<Platform> src)
                            _platformBox.SelectedItem = src.FirstOrDefault();
                        else if (_platformBox.Items?.Cast<Platform>().Any() == true)
                            _platformBox.SelectedItem = _platformBox.Items.Cast<Platform>().FirstOrDefault();
                    }
                }

                if (_platformBox.SelectedItem is Platform p)
                    await HandlePlatformSelectionAsync(p);
            }
            catch (Exception ex)
            {
                LogHelper.Error($"❌ Failed to auto-load Instructions tab data: {ex.Message}");
            }
        }


        public void SelectDefaultPlatform()
        {
            string? defaultFqdn = GetDefaultPlatformFqdn();
            string? defaultAlias = GetDefaultPlatformAlias();

            if (_platformBox?.Items == null)
            {
                LogHelper.Warn("⚠️ Platform dropdown is null or empty.");
                return;
            }

            foreach (var item in _platformBox.Items)
            {
                if (item is Platform p &&
                    (p.PlatformFqdn.Equals(defaultFqdn, StringComparison.OrdinalIgnoreCase) ||
                     p.Alias.Equals(defaultAlias, StringComparison.OrdinalIgnoreCase)))
                {
                    _platformBox.SelectedItem = p;
                    LogHelper.Info($"🔧 Default platform selected: {p.PlatformFqdn}");
                    return;
                }
            }

            LogHelper.Warn($"⚠️ No matching platform found for Alias: {defaultAlias} or FQDN: {defaultFqdn}");
        }

        private AppSettings? _config;

        private string? GetDefaultPlatformAlias()
        {
            string path = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "TV1_InstructionOffloader",
                "appsettings.json");

            if (!File.Exists(path))
                return null;

            try
            {
                var json = JObject.Parse(File.ReadAllText(path));
                return json["DefaultPlatformAlias"]?.ToString()?.Trim();
            }
            catch (Exception ex)
            {
                LogHelper.Error($"❌ Failed to read default alias: {ex.Message}");
                return null;
            }
        }


        public event Func<Task>? CreateJobRequested;

        private void HookCreateButton()
        {
            var createButton = this.FindControl<Button>("CreateOrUpdateJobButton");
            if (createButton != null)
            {
                createButton.Click -= CreateOrUpdateJobButton_Click; // remove if already wired
                createButton.Click += CreateOrUpdateJobButton_Click;
            }
        }


        public UserControl? PlatformsTab => this.FindControl<UserControl>("PlatformsTabHost");


        public void SetPlatform(Platform? platform)
        {
            _platform = platform;
            _platformUrl = _platform?.PlatformFqdn ?? "";
            _logTextBox.Text += $"[🔁 Synced platform URL from ConfigTab: {_platformUrl}]\n";
        }
        private void OnSearchTextChanged(string? text)
        {

            // Keep XAML binding intact; update the bound collection instead of overwriting ItemsSource.
            if (_vm?.Instructions == null)
                return;

            var previousSelectedId = _selectedInstruction?.Id ?? _vm.SelectedInstruction?.Id;

            IEnumerable<InstructionDefinition> toShow;
            if (string.IsNullOrWhiteSpace(text))
            {
                toShow = _allInstructions;
            }
            else
            {
                toShow = _allInstructions.Where(i =>
                    i.Name?.Contains(text, StringComparison.OrdinalIgnoreCase) == true ||
                    i.Description?.Contains(text, StringComparison.OrdinalIgnoreCase) == true);
            }

            _vm.Instructions.Clear();
            foreach (var inst in toShow)
                _vm.Instructions.Add(inst);

            if (previousSelectedId.HasValue)
            {
                var match = _vm.Instructions.FirstOrDefault(x => x.Id == previousSelectedId.Value);
                if (match != null)
                {
                    _vm.SelectedInstruction = match;
                    if (_instructionListBox != null)
                        _instructionListBox.SelectedItem = match;
                }
            }
        }

        private void InstructionSearchBox_KeyUp(object? sender, KeyEventArgs e)
        {
            if (e.Key != Key.Enter)
                return;

            // Force an immediate refresh on Enter for users who expect it.
            try
            {
                OnSearchTextChanged(_searchBox?.Text);
            }
            catch (Exception ex)
            {
                LogHelper.Warn($"⚠️ Instruction search refresh failed: {ex.Message}");
            }
        }

        private async Task UpdateFqdnSuggestionsAsync(string? text)
        {
            try
            {
                if (_suppressFqdnSuggest)
                    return;

                EnsureTargetingControls();

                // Only show suggestions when FQDN mode is selected.
                if (_fqdnRadio?.IsChecked != true)
                {
                    if (_fqdnSuggestListBox != null)
                    {
                        _fqdnSuggestListBox.IsVisible = false;
                        _fqdnSuggestListBox.ItemsSource = null;
                    }
                    return;
                }

                var query = (text ?? string.Empty).Trim();
                if (_fqdnSuggestListBox == null)
                    return;

                // Avoid re-querying for the exact same string.
                if (string.Equals(query, _lastFqdnSuggestQuery, StringComparison.OrdinalIgnoreCase))
                    return;

                if (query.Length < 2)
                {
                    _fqdnSuggestListBox.IsVisible = false;
                    _fqdnSuggestListBox.ItemsSource = null;
                    return;
                }

                // Must be authenticated to query devices.
                if (string.IsNullOrWhiteSpace(_fqdn) || string.IsNullOrWhiteSpace(_token))
                {
                    _fqdnSuggestListBox.IsVisible = false;
                    _fqdnSuggestListBox.ItemsSource = null;
                    return;
                }

                _fqdnSearchCts?.Cancel();
                _fqdnSearchCts?.Dispose();
                _fqdnSearchCts = new CancellationTokenSource();
                var ct = _fqdnSearchCts.Token;

                // Debounce so typing "de" → "desk" doesn't fire 4 requests.
                // We cancel the CTS on each keystroke, so only the final pause actually runs.
                await Task.Delay(300, ct);

                // Track the last query only after the debounce so we still re-run after quick edits.
                _lastFqdnSuggestQuery = query;

                var results = await _instructionService.SearchDeviceFqdnsAsync(_fqdn, _token, query, 25, ct);
                if (ct.IsCancellationRequested)
                    return;

                if (results == null || results.Count == 0)
                {
                    _fqdnSuggestListBox.IsVisible = false;
                    _fqdnSuggestListBox.ItemsSource = null;
                    return;
                }

                var ordered = results
                    .Where(x => !string.IsNullOrWhiteSpace(x))
                    .Distinct(StringComparer.OrdinalIgnoreCase)
                    .OrderBy(x => x, StringComparer.OrdinalIgnoreCase)
                    .ToList();

                _fqdnSuggestListBox.ItemsSource = ordered;
                _fqdnSuggestListBox.IsVisible = true;
            }
            catch (TaskCanceledException)
            {
                // ignore
            }
            catch (Exception ex)
            {
                LogHelper.Info($"... FQDN search failed: {ex.Message}");
                if (_fqdnSuggestListBox != null)
                {
                    _fqdnSuggestListBox.IsVisible = false;
                    _fqdnSuggestListBox.ItemsSource = null;
                }
            }
        }

        private void FqdnSuggestListBox_SelectionChanged(object? sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (_fqdnSuggestListBox == null || _fqdnInputBox == null)
                    return;

                if (_fqdnSuggestListBox.SelectedItem is not string fqdn || string.IsNullOrWhiteSpace(fqdn))
                    return;

                _suppressFqdnSuggest = true;
                _fqdnInputBox.Text = fqdn;
                _fqdnSuggestListBox.IsVisible = false;
                _fqdnSuggestListBox.ItemsSource = null;
                _fqdnSuggestListBox.SelectedItem = null;
            }
            finally
            {
                _suppressFqdnSuggest = false;
            }
        }


        private async void OnPreviewClicked()
        {
            if (Application.Current?.ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop &&
                desktop.MainWindow is MainWindow mw)
            {
                await mw.TriggerPreviewFromConfigTabAsync();
            }
            else
            {
                LogHelper.Warn("⚠️ Could not access MainWindow from ConfigTab.");
            }
        }
        public PlatformConfigViewModel? GetPlatformViewModel()
        {
            if (this.FindControl<UserControl>("PlatformsTab") is PlatformsTab pt &&
                pt.DataContext is PlatformConfigViewModel vm)
                return vm;

            return null;
        }

        private bool _hasTriggeredInitialLoad = false;
        private bool _isPopulatingJob = false;
        private bool _isUpdatingHeaderStatus = false;
        private DateTime _lastHeaderStatusUtc = DateTime.MinValue;


        private bool _hasAttachedToVisualTreeOnce = false;
        private string? _lastLoadedPlatformFqdn;
        private bool _suppressPlatformSelectionChanged = false;

        /// <summary>
        /// Core platform selection pipeline (token reuse/auth + load platform-scoped data + update status).
        /// This is a Task so tab-activation logic can await it without causing duplicate loads.
        /// </summary>
        private async Task HandlePlatformSelectionAsync(Platform selected, bool forceAuth = false)
        {
            if (_isPlatformChanging) return;
            _isPlatformChanging = true;

            try
            {
                // Ensure we have a valid MainWindow reference before we touch TokenStore or header UI.
                _main ??= App.Current?.ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop
                    ? desktop.MainWindow as MainWindow
                    : null;

                // 1️⃣ Update local state
                _selectedPlatform = selected;
                _fqdn = selected.PlatformFqdn;
                _platformUrl = _fqdn;
                _platformAlias = selected.Alias ?? "";
                _consumerName = string.IsNullOrWhiteSpace(selected.DefaultConsumer) ? "Explorer" : selected.DefaultConsumer;

                _platformFqdnTextBox?.SetCurrentValue(TextBox.TextProperty, selected.PlatformFqdn);
                _appRegIdTextBox?.SetCurrentValue(TextBox.TextProperty, selected.AppId);
                _certThumbprintTextBox?.SetCurrentValue(TextBox.TextProperty, selected.CertThumbprint);

                bool platformChanged = _lastLoadedPlatformFqdn == null ||
                    !string.Equals(_lastLoadedPlatformFqdn, _fqdn, StringComparison.OrdinalIgnoreCase);

                LogHelper.Info($"🔁 Platform {(platformChanged ? "changed" : "re-selected")} → {_fqdn} (Consumer: {_consumerName})");

                // 2️⃣ Token reuse or authentication
                var tokenStore = _main?.TokenStore;

                var settings = new PlatformSettings
                {
                    Alias = string.IsNullOrWhiteSpace(selected.Alias) ? (selected.GroupName ?? null) : selected.Alias,
                    PlatformFqdn = _fqdn,
                    AppId = selected.AppId,
                    CertThumbprint = selected.CertThumbprint,
                    UseCert = selected.UseCert,
                    UserId = string.IsNullOrWhiteSpace(selected.UserId) ? null : selected.UserId
                };

                bool haveCached = _config.EnableDevTokenReuse && tokenStore != null &&
                                  tokenStore.TryGetToken(_fqdn, out _token) &&
                                  !string.IsNullOrWhiteSpace(_token);

                if (forceAuth || !haveCached)
                {
                    if (forceAuth)
                        LogHelper.Info("🔐 Forcing authentication for platform context…");
                    else
                        LogHelper.Info("ℹ️ No valid cached token → authenticating…");

                    var tokenResult = await _authService.AuthenticateAsync(settings);
                    if (string.IsNullOrWhiteSpace(tokenResult?.Token))
                    {
                        LogHelper.Error("❌ Authentication failed. Aborting platform switch.");
                        return;
                    }

                    _token = tokenResult.Token;
                    if (_config.EnableDevTokenReuse)
                    {
                        // Only persist if we actually have a token store.
                        tokenStore?.SaveToken(_platformUrl, _token);
                    }

                    await EnsureMainWindowStatusAsync();
                }
                else
                {
                    // We have a cached token. Validate it once (whoami). If invalid/expired, reauth and continue.
                    LogHelper.Info("✅ Re-using cached token (validating…)");

                    string? display = null;
                    try { display = await _authService.GetDisplayNameFromWhoAmIAsync(_fqdn, _token); }
                    catch { /* ignore */ }

                    if (string.IsNullOrWhiteSpace(display))
                    {
                        LogHelper.Warn("⚠️ Cached token failed whoami (likely expired) → re-authenticating…");

                        var tokenResult = await _authService.AuthenticateAsync(settings);
                        if (string.IsNullOrWhiteSpace(tokenResult?.Token))
                        {
                            LogHelper.Error("❌ Authentication failed. Aborting platform switch.");
                            return;
                        }

                        _token = tokenResult.Token;
                        if (_config.EnableDevTokenReuse)
                            tokenStore?.SaveToken(_platformUrl, _token);

                        await EnsureMainWindowStatusAsync();
                    }
                    else
                    {
                        // Update the header with the validated display name without re-calling whoami elsewhere.
                        Dispatcher.UIThread.Post(() =>
                        {
                            _main?.SetLoggedInUserDisplay(display);
                            _main?.SetSelectedPlatformDisplay(_fqdn);
                        });
                    }
                }

                // 3️⃣ Reload platform-scoped data (ONLY when needed)
                // You requested: refresh ONLY when the platform changes, on logon, or when the user presses manual refresh.
                // In practice this means: when the platform is merely re-selected (same alias/fqdn) we should NOT
                // re-query instructions/MGs/tags unless the UI has no data yet.

                bool needConsumers = platformChanged || (_consumerDropdown?.ItemCount ?? 0) == 0;
                if (needConsumers)
                    await OnLoadConsumersAsync(_fqdn, _token);

                var previousSelectedId = _selectedInstruction?.Id ?? _vm.SelectedInstruction?.Id;
                bool needInstructions = platformChanged || (_vm.Instructions?.Count ?? 0) == 0;
                bool needMgs = platformChanged || (_mgDropdown?.ItemCount ?? 0) == 0;
                bool needTags = platformChanged || (_coverageTagNameDropdown?.ItemCount ?? 0) == 0;

                if (needInstructions)
                {
                    try
                    {
                        _allInstructions = await _instructionHelper.LoadInstructionsAsync(_fqdn, _token, _logTextBox) ?? new List<InstructionDefinition>();
                    }
                    catch (Exception ex) when (ex.Message.Contains("401", StringComparison.OrdinalIgnoreCase) || ex.Message.Contains("Unauthorized", StringComparison.OrdinalIgnoreCase))
                    {
                        LogHelper.Warn("⚠️ Instructions load returned Unauthorized → re-authenticating and retrying once…");

                        var tokenResult = await _authService.AuthenticateAsync(settings);
                        if (string.IsNullOrWhiteSpace(tokenResult?.Token))
                        {
                            LogHelper.Error("❌ Authentication failed. Aborting platform switch.");
                            return;
                        }

                        _token = tokenResult.Token;
                        if (_config.EnableDevTokenReuse)
                            tokenStore?.SaveToken(_platformUrl, _token);

                        _allInstructions = await _instructionHelper.LoadInstructionsAsync(_fqdn, _token, _logTextBox) ?? new List<InstructionDefinition>();
                    }

                    // Keep UI binding intact (XAML binds to _vm.Instructions). Do NOT overwrite ItemsSource.
                    _vm.Instructions.Clear();
                    foreach (var inst in _allInstructions)
                        _vm.Instructions.Add(inst);

                    // Restore selection if possible
                    if (previousSelectedId.HasValue)
                    {
                        var match = _allInstructions.FirstOrDefault(x => x.Id == previousSelectedId.Value);
                        if (match != null)
                        {
                            _vm.SelectedInstruction = match;
                            if (_instructionListBox != null)
                                _instructionListBox.SelectedItem = match;
                        }
                    }

                    LogHelper.Info($"🧮 Instructions loaded: {_allInstructions.Count}");
                }

                if (needMgs)
                {
                    try
                    {
                        await _instructionHelper.LoadManagementGroupsAsync(_fqdn, _token, _mgDropdown, _logTextBox);
                    }
                    catch (Exception ex) when (ex.Message.Contains("401", StringComparison.OrdinalIgnoreCase) || ex.Message.Contains("Unauthorized", StringComparison.OrdinalIgnoreCase))
                    {
                        LogHelper.Warn("⚠️ Management Groups load returned Unauthorized → re-authenticating and retrying once…");

                        var tokenResult = await _authService.AuthenticateAsync(settings);
                        if (string.IsNullOrWhiteSpace(tokenResult?.Token))
                        {
                            LogHelper.Error("❌ Authentication failed. Aborting platform switch.");
                            return;
                        }

                        _token = tokenResult.Token;
                        if (_config.EnableDevTokenReuse)
                            tokenStore?.SaveToken(_platformUrl, _token);

                        await _instructionHelper.LoadManagementGroupsAsync(_fqdn, _token, _mgDropdown, _logTextBox);
                    }
                }

                if (needTags)
                {
                    try
                    {
                        await _instructionHelper.LoadCustomPropertiesAsync(_fqdn, _token, _coverageTagNameDropdown, _coverageTagValueDropdown, _logTextBox);
                    }
                    catch (Exception ex) when (ex.Message.Contains("401", StringComparison.OrdinalIgnoreCase) || ex.Message.Contains("Unauthorized", StringComparison.OrdinalIgnoreCase))
                    {
                        LogHelper.Warn("⚠️ Coverage Tags load returned Unauthorized → re-authenticating and retrying once…");

                        var tokenResult = await _authService.AuthenticateAsync(settings);
                        if (string.IsNullOrWhiteSpace(tokenResult?.Token))
                        {
                            LogHelper.Error("❌ Authentication failed. Aborting platform switch.");
                            return;
                        }

                        _token = tokenResult.Token;
                        if (_config.EnableDevTokenReuse)
                            tokenStore?.SaveToken(_platformUrl, _token);

                        await _instructionHelper.LoadCustomPropertiesAsync(_fqdn, _token, _coverageTagNameDropdown, _coverageTagValueDropdown, _logTextBox);
                    }
                }
                _lastLoadedPlatformFqdn = _fqdn;
                // Only raise the selection event on true platform changes (or first-ever load)
                // so downstream listeners don't treat reselects as a refresh trigger.
                if (platformChanged || !_hasTriggeredInitialLoad)
                {
                    _hasTriggeredInitialLoad = true;
                    RaiseCurrentSelection();
                }
            }
            catch (Exception ex)
            {
                LogHelper.Error($"❌ Error during platform switch: {ex.Message}");
            }
            finally
            {
                _isPlatformChanging = false;
            }
        }

        private async void PlatformBox_SelectionChanged(object? sender, SelectionChangedEventArgs? e)
        {
            if (_suppressPlatformSelectionChanged)
                return;

            if (_platformBox?.SelectedItem is Platform selected)
                await HandlePlatformSelectionAsync(selected);
        }

        private void RaiseCurrentSelection()
        {
            if (!string.IsNullOrWhiteSpace(_platformAlias) && !string.IsNullOrWhiteSpace(_fqdn))
            {
                LogHelper.Info($"📣 Raising platform selection → Alias: {_platformAlias}, FQDN: {_fqdn}");
                PlatformSelected?.Invoke(_platformAlias, _fqdn);
            }
            else
            {
                LogHelper.Warn("⚠️ Cannot raise platform selection — alias or FQDN is missing.");
            }
        }

        private async Task NudgeUserToEditPlaceholderAsync(string? extraLog = null)
        {
            try
            {
                // Ensure we’re on UI thread
                await Avalonia.Threading.Dispatcher.UIThread.InvokeAsync(async () =>
                {
                    // 1) Switch to the Platforms inner tab so the user sees where to edit.
                    SwitchToPlatformTab();

                    // 2) Access the Platforms tab VM (PlatformConfigViewModel).
                    var platformsHost = this.FindControl<Avalonia.Controls.Control>("PlatformsTabHost");
                    if (platformsHost?.DataContext is ViewModels.PlatformConfigViewModel platformsVm)
                    {
                        // 3) Detect placeholder:
                        var p = platformsVm.SelectedPlatform;
                        bool isPlaceholder =
                            p != null &&
                            (
                                string.Equals(p.Alias?.Trim(), "PH", StringComparison.OrdinalIgnoreCase) ||
                                string.Equals(p.GroupName?.Trim(), "Platform Placeholder - Edit Me", StringComparison.OrdinalIgnoreCase) ||
                                string.IsNullOrWhiteSpace(p.PlatformFqdn)
                            );

                        if (!isPlaceholder)
                        {
                            if (!string.IsNullOrWhiteSpace(extraLog))
                                LogHelper.Info(extraLog);
                            return;
                        }

                        // 4) Show a clear popup
                        await ShowWarningAsync(
                            "Before you can run instructions, please edit the placeholder platform.\n\n" +
                            "Set a friendly name (Alias/Group), paste the platform FQDN, and (optionally) supply AppId and Cert Thumbprint."
                        );

                        // 5) Open the editor, reusing the existing command (same as clicking the Edit button).
                        try
                        {
                            if (!platformsVm.IsEditing)
                            {
                                platformsVm.EditPlatformCommand.Execute().Subscribe();
                                LogHelper.Info("✏️ Opened platform editor for placeholder.");
                            }
                        }
                        catch (Exception ex)
                        {
                            LogHelper.Warn($"⚠️ Could not auto-open editor: {ex.Message}");
                        }
                    }
                    else
                    {
                        LogHelper.Warn("⚠️ PlatformsTabHost/DataContext is not PlatformConfigViewModel — cannot open editor.");
                    }
                });
            }
            catch (Exception exOuter)
            {
                LogHelper.Warn($"⚠️ NudgeUserToEditPlaceholder failed: {exOuter.Message}");
            }
        }


        private bool _isLoadingConsumers = false;

        private async Task OnLoadConsumersAsync(string fqdn, string token)
        {
            if (_isLoadingConsumers) return;
            _isLoadingConsumers = true;

            try
            {
                LogHelper.Debug($"🌐 Loading consumers for: {fqdn}");

                var consumers = await _instructionService.LoadConsumersAsync(fqdn, token);
                if (consumers == null || consumers.Count == 0) return;

                _consumerDropdown.ItemsSource = consumers;

                if (consumers.Contains(_consumerName))
                    _consumerDropdown.SelectedItem = _consumerName;
                else
                    _consumerDropdown.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                LogHelper.Error($"❌ Failed to load consumers: {ex.Message}");
            }
            finally
            {
                _isLoadingConsumers = false;
            }
        }


        public Dictionary<string, object> CollectParametersFromPanels()
        {
            var dict = new Dictionary<string, object>();

            var panels = new[]
            {
        this.FindControl<StackPanel>("FqdnParametersPanel"),
        this.FindControl<StackPanel>("ParametersPanel")
    };

            foreach (var panel in panels)
            {
                if (panel == null) continue;

                foreach (var row in panel.Children.OfType<StackPanel>())
                {
                    if (row.Children.Count < 2) continue;

                    string? key = row.Children[1] switch
                    {
                        { Tag: string t } => t,
                        _ when row.Children[0] is TextBlock lbl => lbl.Text?.TrimEnd(':'),
                        _ => null
                    };

                    if (string.IsNullOrWhiteSpace(key)) continue;

                    object? val = row.Children[1] switch
                    {
                        TextBox tb => tb.Text,
                        ComboBox cb when cb.SelectedItem is ComboBoxItem cbi => cbi.Content?.ToString() ?? "",
                        ComboBox cb => cb.SelectedItem?.ToString() ?? "",
                        NumericUpDown nud => nud.Value ?? 0,
                        CheckBox chk => chk.IsChecked ?? false,
                        _ => null
                    };

                    if (val != null)
                        dict[key] = val;
                }
            }

            LogHelper.Info($"🧪 Collected {dict.Count} parameters\n");
            return dict;
        }



        private async void OnRunNowClicked()
        {
            // Prevent accidental double-execution due to UI re-entrancy or duplicate event wiring.
            if (_isManualRunInProgress)
            {
                LogHelper.Info("⚠️ Run is already in progress — ignoring duplicate click.\n");
                return;
            }

            if (_selectedInstruction == null)
            {
                LogHelper.Info("⚠️ No instruction selected.\n");
                return;
            }

            var parameters = CollectParametersFromPanels();
            string targetingMode = "FQDN";
            string fqdnInput = _fqdnInputBox?.Text?.Trim() ?? "";
            string matchType = "Begins With"; // Replace with actual dropdown if needed
            ManagementGroup? mg = _mgDropdown?.SelectedItem as ManagementGroup;
            string coverageTag = _coverageTagNameDropdown?.SelectedItem?.ToString() ?? "";
            string coverageValue = _coverageTagValueDropdown?.SelectedItem?.ToString() ?? "";
            var selectedFqdns = new List<string>(); // Populate from UI if needed
            int instructionTtl = int.TryParse(_instructionTtlBox?.Text, out var ttl) ? ttl : 10;
            int responseTtl = int.TryParse(_responseTtlBox?.Text, out var rttl) ? rttl : 1440;

            // Determine targeting mode from radio buttons
            if (this.FindControl<RadioButton>("MgRadio")?.IsChecked == true)
                targetingMode = "MG";
            else if (this.FindControl<RadioButton>("CoverageTagRadio")?.IsChecked == true)
                targetingMode = "Coverage";

            _platformUrl = GetSelectedPlatformUrl();
            if (string.IsNullOrWhiteSpace(_platformUrl))
            {
                LogHelper.Info("❌ Platform URL is missing.\n");
                return;
            }

            // Ensure we have a token (Preview may have authenticated via MainWindow and not populated _token here).
            if (string.IsNullOrWhiteSpace(_token))
            {
                if (_tokenStoreService != null && _tokenStoreService.TryGetToken(_platformUrl, out var cached) && !string.IsNullOrWhiteSpace(cached))
                {
                    _token = cached;
                }
            }

            // If still missing, force auth via the approved pipeline (token expired / reauth scenario).
            if (string.IsNullOrWhiteSpace(_token) && _selectedPlatform != null)
            {
                LogHelper.Warn("⚠️ No token available for Run → forcing authentication via platform selection pipeline…");
                await HandlePlatformSelectionAsync(_selectedPlatform, forceAuth: true);
            }

            if (string.IsNullOrWhiteSpace(_token))
            {
                LogHelper.Error("❌ No authentication token found — cannot run instruction.\n");
                return;
            }

            var logger = new TextBoxLogger(_logTextBox);

            _isManualRunInProgress = true;
            try
            {
                await _instructionService.RunInstructionFromMainTabAsync(
                    _selectedInstruction,
                    parameters,
                    targetingMode,
                    _platformUrl,
                    _token,
                    _consumerName ?? "Explorer",
                    fqdnInput,
                    matchType,
                    mg,
                    coverageTag,
                    coverageValue,
                    selectedFqdns,
                    instructionTtl,
                    responseTtl,
                    logger
                );
            }
            finally
            {
                _isManualRunInProgress = false;
            }
        }




        private void ClearJobEditorForm()
        {
            // Placeholder for clearing job form fields
        }
        public string? SetSelectedPlatform(Platform platform)
        {
            _platformComboBox ??= this.FindControl<ComboBox>("PlatformComboBox");
            _platformFqdnTextBox ??= this.FindControl<TextBox>("PlatformFqdnBox");
            _appRegIdTextBox ??= this.FindControl<TextBox>("AppIdBox");
            _certThumbprintTextBox ??= this.FindControl<TextBox>("CertThumbprintBox");

            if (_platformComboBox == null)
            {
                LogHelper.Error("❌ _platformComboBox is null in SetSelectedPlatform.");
                return null;
            }

            _platformComboBox.SelectedItem = platform;
            _platformFqdnTextBox?.SetCurrentValue(TextBox.TextProperty, platform.PlatformFqdn);
            _appRegIdTextBox?.SetCurrentValue(TextBox.TextProperty, platform.AppId);
            _certThumbprintTextBox?.SetCurrentValue(TextBox.TextProperty, platform.CertThumbprint);
            _platformUrl = platform.PlatformFqdn;

            LogHelper.Info($"✅ SetSelectedPlatform: {platform.GroupName} ({platform.PlatformFqdn})");
            return _platformUrl;
        }







        private void RecurrenceComboBox_SelectionChanged(object? sender, SelectionChangedEventArgs? e)
        {
            if (sender is not ComboBox cb || cb.SelectedItem is not ComboBoxItem item)
                return;

            string mode = item.Content?.ToString() ?? "Once";
            LogHelper.Info($"📅 Recurrence changed to: {mode}");

            // 🔁 Safely hide all recurrence rows
            _recurrenceDayPanel?.SetValue(IsVisibleProperty, false);
            _weeklyRepeatRow?.SetValue(IsVisibleProperty, false);
            _monthlyPanel?.SetValue(IsVisibleProperty, false);
            _daysOfWeekRow?.SetValue(IsVisibleProperty, false);

            // ✅ Show based on mode
            switch (mode)
            {
                case "Daily":
                    _recurrenceDayPanel?.SetValue(IsVisibleProperty, true);
                    _daysOfWeekRow?.SetValue(IsVisibleProperty, true);
                    break;
                case "Weekly":
                    _recurrenceDayPanel?.SetValue(IsVisibleProperty, true);
                    _weeklyRepeatRow?.SetValue(IsVisibleProperty, true);
                    _daysOfWeekRow?.SetValue(IsVisibleProperty, true);
                    break;
                case "Monthly":
                    _recurrenceDayPanel?.SetValue(IsVisibleProperty, true);
                    _monthlyPanel?.SetValue(IsVisibleProperty, true);
                    _daysOfWeekRow?.SetValue(IsVisibleProperty, true);
                    break;
            }
        }




        public event Action<InstructionDefinition?>? InstructionSelected;

        private void InitializeComponent() => AvaloniaXamlLoader.Load(this);

        /// <summary>Loads the platform list **and selects the default** (or first).</summary>
        private void ReloadPlatformList()
        {
            var platformList = BuildPlatformList();
            LogHelper.Info($"🔍 ReloadPlatformList: Found {platformList.Count} platforms");

            if (_platformBox == null)
            {
                LogHelper.Error("❌ _platformBox is null in ReloadPlatformList.");
                return;
            }

            // Changing ItemsSource will often raise SelectionChanged with a null SelectedItem.
            // Suppress the handler while we rebuild the list and explicitly select the default.
            _suppressPlatformSelectionChanged = true;
            _platformBox.ItemsSource = platformList;
            //AutomationTabControl?.SetPlatformList(platformList.ToList());

            if (platformList.Count > 0)
            {
                var defaultFqdn = GetDefaultPlatformFqdn();
                var defaultPlatform = platformList.FirstOrDefault(p =>
                    p.PlatformFqdn.Equals(defaultFqdn, StringComparison.OrdinalIgnoreCase));

                if (defaultPlatform == null)
                {
                    defaultPlatform = platformList[0];
                    LogHelper.Warn("⚠️ Default platform not found in list. Falling back to first.");
                }

                LogHelper.Info($"✅ Default platform selected: {defaultPlatform.PlatformFqdn}");
                _platformBox.SelectedItem = defaultPlatform;

                // Now that the selection is stable, trigger the platform pipeline exactly once.
                Avalonia.Threading.Dispatcher.UIThread.Post(async () =>
                {
                    try
                    {
                        _suppressPlatformSelectionChanged = false;
                        if (_platformBox.SelectedItem is Platform sel)
                            await HandlePlatformSelectionAsync(sel);
                    }
                    catch (Exception ex)
                    {
                        LogHelper.Error($"❌ Initial platform load failed: {ex.Message}");
                    }
                });
            }
            else
            {
                LogHelper.Warn("⚠ No platforms found. Setting placeholder item.");
                _platformBox.ItemsSource = new[] { "(no platforms found)" };
                _platformBox.SelectedIndex = 0;
                _suppressPlatformSelectionChanged = false;
                //AutomationTabControl?.SetPlatformList(new List<Platform>());

                ExportOptionsHost?.SetPlatforms(platformList.ToList());
                ExportOptionsHost?.LoadPlatformDropdown();
                ExportOptionsHost?.RefreshPlatforms();


            }
        }




        private Platform? LoadOrCreateDefaultPlatform()
        {
            string roamingDir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "TV1_InstructionOffloader");

            string settingsPath = Path.Combine(roamingDir, "appsettings.json");

            if (!Directory.Exists(roamingDir))
                Directory.CreateDirectory(roamingDir);

            if (!File.Exists(settingsPath))
            {
                _fqdnInputBox ??= this.FindControl<TextBox>("FqdnInputBox");
                string userFqdn = _fqdnInputBox?.Text?.Trim();

                if (string.IsNullOrWhiteSpace(userFqdn))
                {
                    LogHelper.Warn("⚠️ No FQDN entered — cannot create default appsettings.");
                    return null;
                }

                var defaultPlatform = new PlatformSettings
                {
                    Alias = "User Platform",
                    PlatformFqdn = userFqdn,
                    AppId = "",
                    CertThumbprint = "",
                    AuthenticationMode = "Cert",
                    DefaultConsumer = "Explorer",
                    DefaultMG = "",
                    IsDefault = true
                };

                var appSettings = new AppSettings
                {
                    Platforms = new List<PlatformSettings> { defaultPlatform },
                    ReauthMinutes = 5,
                    DefaultConsumer = "Explorer",
                    DefaultMG = "",
                    Export = new ExportSettings
                    {
                        PageSize = 2000,
                        MaxConcurrentRequests = 6
                    },
                    Headless = new HeadlessSettings
                    {
                        UseSql = false,
                        SqlConnectionString = "",
                        JsonStorePath = "InstructionRunStore.json",
                        OutputFolder = "Exports",
                        LogFilePath = "headless.log",
                        ResultCheckIntervalMinutes = 10,
                        AutoRecover = true
                    },
                    DefaultPlatformAlias = defaultPlatform.Alias,
                    DefaultPlatformFqdn = defaultPlatform.PlatformFqdn,
                    PlatformSettings = null
                };

                string json = JsonConvert.SerializeObject(appSettings, Formatting.Indented);
                File.WriteAllText(settingsPath, json);
                LogHelper.Info($"✅ Created appsettings.json using FQDN: {userFqdn}");
            }

            return null; // Optionally: return loaded default platform here
        }

        public async Task RefreshAllAsync()
        {
            try
            {
                LogHelper.Info("🔄 Refreshing platform data...");

                // 0) Resolve selected platform
                Platform? selected = null;
                if (_platformBox?.SelectedItem is Platform pSel)
                {
                    selected = pSel;
                }
                else if (!string.IsNullOrWhiteSpace(_fqdn))
                {
                    var items = _platformBox?.Items?.OfType<Platform>().ToList() ?? new List<Platform>();
                    selected = items.FirstOrDefault(p =>
                        string.Equals(p.PlatformFqdn, _fqdn, StringComparison.OrdinalIgnoreCase) ||
                        string.Equals(p.Alias, _fqdn, StringComparison.OrdinalIgnoreCase));
                }

                if (selected == null)
                {
                    LogHelper.Warn("⚠️ No platform selected — cannot refresh.");
                    return;
                }

                var fqdn = selected.PlatformFqdn;
                LogHelper.Info($"Authentication to {fqdn}");

                // 1) Get token: try cache first, else one-stop auth
                string token;
                if (_config.EnableDevTokenReuse && _main?.TokenStore.TryGetToken(fqdn, out var cached) == true && !string.IsNullOrWhiteSpace(cached))
                {
                    token = cached;
                    LogHelper.Info($"🔑 Using cached token for {fqdn}.");
                }
                else
                {
                    var settings = new PlatformSettings
                    {
                        PlatformFqdn = selected.PlatformFqdn,
                        AppId = selected.AppId,
                        CertThumbprint = selected.CertThumbprint,
                        UseCert = selected.UseCert
                    };

                    var authResult = await AuthHelper.AuthenticateIsolatedAsync(settings);

                    if (string.IsNullOrWhiteSpace(authResult?.Token))
                    {
                        LogHelper.Error("❌ Authentication failed. Aborting refresh.");
                        return;
                    }

                    token = authResult.Token;
                    _authService.Token = token;
                    _authService.SetPlatformConfig(settings);
                    _authService.SetExpirationTime(_authService.GetTokenExpirationTime() ?? DateTime.UtcNow.AddMinutes(10));

                    //_main?.TokenStore.SaveToken(fqdn, token); // persist for other tabs
                    // (Optional) update top badges
                    try
                    {
                        var displayName = await _authService.GetDisplayNameFromWhoAmIAsync(fqdn, token);
                        _main?.SetLoggedInUserDisplay(displayName ?? authResult.PrincipalName ?? "Unknown");
                        _main?.SetSelectedPlatformDisplay(fqdn);
                    }
                    catch { /* best effort */ }
                    LogHelper.Info($"🔑 Acquired new token for {fqdn}.");
                }

                // 2) Refresh controls – always refetch live controls in case fields are stale
                _mgDropdown ??= this.FindControl<ComboBox>("ManagementGroupDropdown");
                _consumerDropdown ??= this.FindControl<ComboBox>("ConsumerDropdown");
                _coverageTagNameDropdown = this.FindControl<ComboBox>("CoverageTagNameDropdown");
                _coverageTagValueDropdown = this.FindControl<ComboBox>("CoverageTagValueDropdown");

                // 3) Management Groups
                await _instructionHelper.LoadManagementGroupsAsync(fqdn, token, _mgDropdown, _logTextBox);
                LogHelper.Info("📦 Refreshed management groups.");

                // 4) Consumers (use ConsumerService path that works)
                var consumerService = new ConsumerService();
                var consumers = await consumerService.GetConsumersAsync(fqdn, token);
                await Avalonia.Threading.Dispatcher.UIThread.InvokeAsync(() =>
                {
                    if (_consumerDropdown != null)
                    {
                        var list = consumers?.ToList() ?? new List<string>();
                        _consumerDropdown.ItemsSource = list;
                        _consumerDropdown.SelectedIndex = list.Count > 0 ? 0 : -1;
                    }
                });
                LogHelper.Info("📄 Refreshed consumers.");

                // 5) Coverage Tags
                await _instructionHelper.LoadCustomPropertiesAsync(
                    fqdn, token,
                    _coverageTagNameDropdown, _coverageTagValueDropdown, _logTextBox);
                await Avalonia.Threading.Dispatcher.UIThread.InvokeAsync(() =>
                {
                    if (_coverageTagNameDropdown != null && _coverageTagNameDropdown.SelectedIndex < 0 && _coverageTagNameDropdown.ItemCount > 0)
                        _coverageTagNameDropdown.SelectedIndex = 0;
                    if (_coverageTagValueDropdown != null && _coverageTagValueDropdown.SelectedIndex < 0 && _coverageTagValueDropdown.ItemCount > 0)
                        _coverageTagValueDropdown.SelectedIndex = 0;
                });
                LogHelper.Info("📑 Refreshed coverage tags.");

                // 6) Automations (policies)
                var automationTab = this.FindControl<AutomationTab>("AutomationTabHost");
                if (automationTab != null)
                {
                    await automationTab.LoadPoliciesAsync();
                    LogHelper.Info("🤖 Refreshed automations (policies).");
                }

                // 7) Instructions
                _allInstructions = await _instructionHelper.LoadInstructionsAsync(fqdn, token, _logTextBox);
                SetInstructions(_allInstructions);
                LogHelper.Info("📜 Refreshed instructions.");

                // 8) Commit the fresh context last to avoid mid-refresh races
                _fqdn = fqdn;
                _token = token;

                LogHelper.Info("✅ Platform refresh complete!");
            }
            catch (Exception ex)
            {
                LogHelper.Error($"❌ Refresh failed: {ex}");
            }
        }






        private static IList<Platform> BuildPlatformList()
        {
            var list = new List<Platform>();

            string roamingDir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "TV1_InstructionOffloader");

            string roamingPath = Path.Combine(roamingDir, "appsettings.json");
            string fallbackPath = Path.Combine("data", "appsettings.json");
            string pathInUse = File.Exists(roamingPath) ? roamingPath : fallbackPath;

            LogHelper.Info($"📄 Reading platforms from: {pathInUse}");

            if (!File.Exists(pathInUse))
            {
                LogHelper.Warn($"⚠ File not found: {Path.GetFullPath(pathInUse)}");
                return list;
            }

            try
            {
                var root = JObject.Parse(File.ReadAllText(pathInUse));
                var arr = root["Platforms"] as JArray ?? new JArray();

                foreach (var entry in arr.OfType<JObject>())
                {
                    string url = entry["PlatformFqdn"]?.ToString()?.Trim() ?? "";
                    if (url.Length == 0) continue;

                    string alias = entry["Alias"]?.ToString()?.Trim();
                    string display = string.IsNullOrWhiteSpace(alias) ? url : alias;
                    bool isDef = entry["IsDefault"]?.ToObject<bool>() == true;

                    string appId = entry["AppId"]?.ToString();
                    string thumbprint = entry["CertThumbprint"]?.ToString();

                    // Respect persisted UseCert when present. If missing (older configs), fall back to
                    // enabling cert auth only when appId + thumbprint are provided.
                    bool useCert = entry["UseCert"]?.ToObject<bool?>() ?? (!string.IsNullOrWhiteSpace(appId) && !string.IsNullOrWhiteSpace(thumbprint));

                    list.Add(new Platform
                    {
                        Alias = alias,
                        GroupName = display,
                        PlatformFqdn = url,
                        AppId = appId,
                        CertThumbprint = thumbprint,
                        DefaultConsumer = entry["DefaultConsumer"]?.ToString(),
                        IsDefault = isDef,
                        UseCert = useCert
                    });
                }

                LogHelper.Info($"✅ Final list count: {list.Count}");
            }
            catch (Exception ex)
            {
                LogHelper.Error($"❌ Failed to parse platform settings: {ex.Message}");
            }

            return list
                .OrderByDescending(p => p.IsDefault)
                .ThenBy(p => p.GroupName, StringComparer.OrdinalIgnoreCase)
                .ToList();
        }


        // public ExportOptionsTab? ExportOptionsHost => this.FindControl<ExportOptionsTab>("ExportOptionsHost");


        public void SetInstructions(IEnumerable<InstructionDefinition> instructions)
        {
            try
            {
                var list = (instructions ?? Enumerable.Empty<InstructionDefinition>()).ToList();

                _allInstructions = list;


                // If the user typed into the instruction search before instructions finished loading, apply it now.
                if (_searchBox != null && !string.IsNullOrWhiteSpace(_searchBox.Text))
                {
                    OnSearchTextChanged(_searchBox.Text);
                    return;
                }

                if (_vm?.Instructions == null)
                    return;

                var prevId = _vm.SelectedInstruction?.Id ?? _selectedInstruction?.Id;

                _vm.Instructions.Clear();
                foreach (var inst in list)
                    _vm.Instructions.Add(inst);

                if (prevId.HasValue)
                {
                    var match = _vm.Instructions.FirstOrDefault(i => i.Id == prevId.Value);
                    if (match != null)
                    {
                        _vm.SelectedInstruction = match;
                        _selectedInstruction = match;
                        if (_instructionListBox != null)
                            _instructionListBox.SelectedItem = match;
                    }
                }
            }
            catch (Exception ex)
            {
                LogHelper.Warn($"⚠️ SetInstructions failed: {ex.Message}");
            }
        }

        private void EnsureTargetingControls()
        {
            _fqdnInputBox ??= this.FindControl<TextBox>("FqdnInputBox");
            _fqdnSuggestListBox ??= this.FindControl<ListBox>("FqdnSuggestListBox");
            _mgDropdown ??= this.FindControl<ComboBox>("ManagementGroupDropdown");
            _coveragePanel ??= this.FindControl<StackPanel>("CoverageDropdownPanel");
        }

        private void TargetModeRadio_Checked(object? _, RoutedEventArgs __)
        {
            EnsureTargetingControls();

            bool fqdn = this.FindControl<RadioButton>("FqdnRadio")?.IsChecked == true;
            bool mg = this.FindControl<RadioButton>("MgRadio")?.IsChecked == true;
            bool coverage = this.FindControl<RadioButton>("CoverageTagRadio")?.IsChecked == true;

            var fqdnInputBox = this.FindControl<TextBox>("FqdnInputBox");
            var mgDropdown = this.FindControl<ComboBox>("ManagementGroupDropdown");
            var coveragePanel = this.FindControl<StackPanel>("CoverageDropdownPanel");

            if (fqdnInputBox != null) fqdnInputBox.IsVisible = fqdn;
            if (mgDropdown != null) mgDropdown.IsVisible = mg;
            if (coveragePanel != null) coveragePanel.IsVisible = coverage;

            if (fqdn && _fqdnSuggestListBox != null)
            {
                _fqdnSuggestListBox.IsVisible = _fqdnSuggestListBox.ItemCount > 0;
            }

            if (!fqdn && _fqdnSuggestListBox != null)
            {
                _fqdnSuggestListBox.IsVisible = false;
                _fqdnSuggestListBox.ItemsSource = null;
            }

        }

        public void UpdateTargetingVisibility(string mode)
        {
            EnsureTargetingControls();
            bool fqdn = mode.Equals("fqdn", StringComparison.OrdinalIgnoreCase);
            bool mg = mode.StartsWith("mg", StringComparison.OrdinalIgnoreCase);
            bool cov = mode.StartsWith("tag", StringComparison.OrdinalIgnoreCase) ||
                        mode.StartsWith("coverage", StringComparison.OrdinalIgnoreCase);

            if (_fqdnInputBox != null) _fqdnInputBox.IsVisible = fqdn;
            if (_mgDropdown != null) _mgDropdown.IsVisible = mg;
            if (_coveragePanel != null) _coveragePanel.IsVisible = cov;

            if (_fqdnSuggestListBox != null)
            {
                _fqdnSuggestListBox.IsVisible = fqdn && _fqdnSuggestListBox.ItemCount > 0;
                if (!fqdn)
                    _fqdnSuggestListBox.ItemsSource = null;
            }

            if (!fqdn && _fqdnSuggestListBox != null)
            {
                _fqdnSuggestListBox.IsVisible = false;
                _fqdnSuggestListBox.ItemsSource = null;
            }
        }

        private void EnsureTtlControls()
        {
            _instructionTtlBox ??= this.FindControl<TextBox>("InstructionTtlBox");
            _instructionTtlUnitDropdown ??= this.FindControl<ComboBox>("InstructionTtlUnitDropdown");
            _responseTtlBox ??= this.FindControl<TextBox>("ResponseTtlBox");
            _responseTtlUnitDropdown ??= this.FindControl<ComboBox>("ResponseTtlUnitDropdown");
        }

        public void PopulateTtlFields(InstructionDefinition def)
        {
            if (def == null) return;
            EnsureTtlControls();

            int instrMin = def.InstructionTtlMinutes <= 0 ? 10 : def.InstructionTtlMinutes;
            int respMin = def.ResponseTtlMinutes <= 0 ? 10 : def.ResponseTtlMinutes;

            if (_instructionTtlUnitDropdown != null)
                _instructionTtlUnitDropdown.SelectedItem =
                    _instructionTtlUnitDropdown.Items.OfType<ComboBoxItem>()
                    .FirstOrDefault(i => (string?)i.Content == "minutes");

            if (_instructionTtlBox != null)
                _instructionTtlBox.Text = instrMin.ToString();

            if (_responseTtlUnitDropdown != null)
                _responseTtlUnitDropdown.SelectedItem =
                    _responseTtlUnitDropdown.Items.OfType<ComboBoxItem>()
                    .FirstOrDefault(i => (string?)i.Content == "minutes");

            if (_responseTtlBox != null)
                _responseTtlBox.Text = respMin.ToString();
        }


        private void OnConsumerChanged(object? _, SelectionChangedEventArgs __)
        {
            if (DataContext is not MainWindow mw) return;
            if (_consumerDropdown?.SelectedItem is string s && s.Length > 0)
                mw.UpdateConsumer(s);
        }

        private async void CreateOrUpdateJobButton_Click(object? sender, RoutedEventArgs e)
        {
            LogHelper.Info("🧪 CreateOrUpdateJobButton_Click triggered");
            await CreateOrUpdateJobFromConfigTabAsync();
        }

        public (string TargetingMethod, string TargetingFqdn, string TargetingManagementGroup, string CoverageTagName, string CoverageTagValue) GetTargetingDetails()
        {
            EnsureTargetingControls();

            string method = "FQDN";
            if (_mgRadio?.IsChecked == true)
                method = "MG";
            else if (_coverageRadio?.IsChecked == true)
                method = "Coverage";

            // IMPORTANT:
            // Only return the *active* targeting details based on the selected radio button.
            // This prevents jobs from being saved with both FQDN and MG (or tag) populated.

            if (string.Equals(method, "MG", StringComparison.OrdinalIgnoreCase))
            {
                var mgName = (_mgDropdown?.SelectedItem as ManagementGroup)?.Name
                             ?? _mgDropdown?.SelectedItem?.ToString()
                             ?? string.Empty;

                return (
                    method,
                    string.Empty,
                    mgName,
                    string.Empty,
                    string.Empty
                );
            }

            if (string.Equals(method, "Coverage", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(method, "CoverageTag", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(method, "Coverage Tag", StringComparison.OrdinalIgnoreCase))
            {
                return (
                    method,
                    string.Empty,
                    string.Empty,
                    _coverageTagNameDropdown?.SelectedItem?.ToString() ?? string.Empty,
                    _coverageTagValueDropdown?.SelectedItem?.ToString() ?? string.Empty
                );
            }

            // FQDN (default)
            var fqdnText = _fqdnInputBox?.Text?.Trim() ?? string.Empty;
            return (
                "FQDN",
                fqdnText,
                string.Empty,
                string.Empty,
                string.Empty
            );
        }


        // VisualTree lookup avoids NameScope issues (TabItem content, templates, etc.)
        private T? TryFindNamedInVisualTree<T>(string name) where T : Avalonia.StyledElement
        {
            if (string.IsNullOrWhiteSpace(name))
                return null;

            foreach (var v in this.GetVisualDescendants())
            {
                if (v is T typed && string.Equals(typed.Name, name, StringComparison.Ordinal))
                    return typed;
            }

            return null;
        }

        private ExportMode GetSelectedExportMode()
        {
            // Default is Pagination (ExportPagingRadio is checked by default in XAML).
            try
            {
                var paging = TryFindNamedInVisualTree<Avalonia.Controls.RadioButton>("ExportPagingRadio");
                var server = TryFindNamedInVisualTree<Avalonia.Controls.RadioButton>("ExportServerRadio");
                var both = TryFindNamedInVisualTree<Avalonia.Controls.RadioButton>("ExportBothRadio");

                if (server?.IsChecked == true)
                    return ExportMode.ServerOnly;

                if (both?.IsChecked == true)
                    return ExportMode.PagingThenServer;

                return ExportMode.PagingOnly;
            }
            catch
            {
                // If anything goes wrong reading UI state, prefer Pagination to avoid unexpected server-side behavior.
                return ExportMode.PagingOnly;
            }
        }

        private ExportFolderMode GetSelectedExportFolderMode()
        {
            try
            {
                var dd = TryFindNamedInVisualTree<Avalonia.Controls.ComboBox>("ExportFolderModeDropdown");
                var idx = dd?.SelectedIndex ?? 3;

                return idx switch
                {
                    0 => ExportFolderMode.Flat,
                    1 => ExportFolderMode.ByInstruction,
                    2 => ExportFolderMode.ByDate,
                    _ => ExportFolderMode.ByInstructionThenDate
                };
            }
            catch
            {
                return ExportFolderMode.ByInstructionThenDate;
            }
        }


        // Public wrappers for MainWindow job save logic.
        // These intentionally default to Pagination-only / ByInstructionThenDate when UI state cannot be read.
        public ExportMode GetSelectedExportModeFromUi() => GetSelectedExportMode();
        public ExportFolderMode GetSelectedExportFolderModeFromUi() => GetSelectedExportFolderMode();

        private static (string unit, int value) SplitMinutesIntoBestUnit(int minutes)
        {
            if (minutes % 1440 == 0) return ("days", minutes / 1440);
            if (minutes % 60 == 0) return ("hours", minutes / 60);
            return ("minutes", minutes);
        }

        public void SetPlatforms(IEnumerable<Platform> platforms)
        {
            var dropdown = this.FindControl<ComboBox>("PlatformComboBox");
            if (dropdown != null)
            {
                var list = platforms.ToList();
                var previouslySelected = dropdown.SelectedItem as Platform;
                dropdown.ItemsSource = list;

                // Do NOT force-select index 0 every time we re-bind platforms.
                // It causes unwanted platform switches/auth attempts during startup.
                if (previouslySelected != null)
                {
                    var match = list.FirstOrDefault(p =>
                        string.Equals(p.PlatformFqdn, previouslySelected.PlatformFqdn, StringComparison.OrdinalIgnoreCase));
                    if (match != null)
                        dropdown.SelectedItem = match;
                }

                if (dropdown.SelectedItem == null)
                {
                    var sel = list.FirstOrDefault(p => p.IsDefault) ?? list.FirstOrDefault();
                    if (sel != null)
                        dropdown.SelectedItem = sel;
                }
            }
        }

        public CheckBox GetDOWCheckBox(DayOfWeek d) => d switch
        {
            DayOfWeek.Monday => this.FindControl<CheckBox>("ChkMon"),
            DayOfWeek.Tuesday => this.FindControl<CheckBox>("ChkTue"),
            DayOfWeek.Wednesday => this.FindControl<CheckBox>("ChkWed"),
            DayOfWeek.Thursday => this.FindControl<CheckBox>("ChkThu"),
            DayOfWeek.Friday => this.FindControl<CheckBox>("ChkFri"),
            DayOfWeek.Saturday => this.FindControl<CheckBox>("ChkSat"),
            DayOfWeek.Sunday => this.FindControl<CheckBox>("ChkSun"),
            _ => throw new ArgumentOutOfRangeException(nameof(d))
        };

        public (ComboBox? name, ComboBox? value) WireCoverageCombos() => (TagNameCombo, TagValueCombo);
        public void PopulateFromScheduledJob(ScheduledJob job)
        {
            // Keep existing call sites working, but do the real work asynchronously so we can await platform auth + list loads.
            _ = PopulateFromScheduledJobAsync(job);
        }

        public bool IsPopulatingJob => _isPopulatingJob;

        public async Task PopulateFromScheduledJobAsync(ScheduledJob job)
        {
            LogHelper.Info($"📝 Populating form for job: {job.InstructionName} (ID: {job.JobId})");

            // Enter edit mode explicitly when populated from an existing job.
            _isEditingScheduledJob = true;
            _editingScheduledJobId = job.JobId;
            if (_jobsVm != null)
                _jobsVm.SelectedScheduledJob = job;

            _isPopulatingJob = true;
            await _jobPopulateGate.WaitAsync();
            try
            {
                // Basic schedule fields first (safe even before platform data is loaded)
                SetComboBoxSelectionByContent(_recurrenceComboBox, job.Recurrence ?? "Once");
                _startDatePicker?.SetCurrentValue(DatePicker.SelectedDateProperty, job.StartDate);
                _endDatePicker?.SetCurrentValue(DatePicker.SelectedDateProperty, job.EndDate);
                _startTimePicker?.SetCurrentValue(TimePicker.SelectedTimeProperty, job.StartTime ?? new TimeSpan(9, 0, 0));
                _monthlyRepeatCount?.SetCurrentValue(NumericUpDown.ValueProperty, job.MonthlyRepeatCount > 0 ? job.MonthlyRepeatCount : 1);

                // ✅ Select platform and FORCE auth + list load so we don't lose the editor state to 401 refreshes.
                // This also fixes the "Edit Job → Instructions tab is empty until you click away/back" race by waiting
                // for the visual tree + platform list + instruction list to be ready before selecting anything.
                Platform? matchedPlatform = null;
                try
                {
                    using var platCts = new CancellationTokenSource(TimeSpan.FromSeconds(30));
                    matchedPlatform = await EnsurePlatformContextForJobAsync(job, platCts.Token);
                    if (matchedPlatform != null)
                        LogHelper.Info($"✅ Platform ready for edit: {matchedPlatform.GroupName} ({matchedPlatform.PlatformFqdn})");
                    else
                        LogHelper.Warn($"❌ No matching platform found for FQDN: {job.PlatformFqdn} or Alias: {job.PlatformAlias}");
                }
                catch (Exception ex)
                {
                    LogHelper.Warn($"⚠️ Platform load during edit failed: {ex.Message}");
                }

                // ✅ Select instruction (after platform pipeline loads the list)
                if (_instructionListBox != null && job.InstructionId > 0)
                {
                    LogHelper.Info($"🔍 Looking for instruction ID: {job.InstructionId}");
                    var match = _allInstructions.FirstOrDefault(i => i.Id == job.InstructionId);
                    if (match != null)
                    {
                        LogHelper.Info($"✅ Instruction match found: {match.Name} (ID: {match.Id})");
                        _instructionListBox.SelectedItem = match;
                        _selectedInstruction = match;
                        _vm.SelectedInstruction = match;

                        Dispatcher.UIThread.Post(() => PopulateTtlFields(match));
                    }
                    else
                    {
                        LogHelper.Warn($"❌ No matching instruction found for ID: {job.InstructionId}");
                    }
                }

                // ✅ Set week-of-month checkboxes
                void SetWeekOfMonthCheckbox(string controlName, int offset)
                {
                    var cb = this.FindControl<CheckBox>(controlName);
                    if (cb != null)
                        cb.IsChecked = job.MonthlyWeekOffsets?.Contains(offset) == true;
                }

                SetWeekOfMonthCheckbox("ChkWeek1", 1);
                SetWeekOfMonthCheckbox("ChkWeek2", 2);
                SetWeekOfMonthCheckbox("ChkWeek3", 3);
                SetWeekOfMonthCheckbox("ChkWeek4", 4);
                SetWeekOfMonthCheckbox("ChkWeekLast", -1);

                // ✅ Set day-of-week checkboxes
                void SetDayOfWeekCheckboxes(List<DayOfWeek>? days)
                {
                    days ??= new List<DayOfWeek>();
                    void Set(string name, DayOfWeek day)
                    {
                        var cb = this.FindControl<CheckBox>(name);
                        if (cb != null)
                            cb.IsChecked = days.Contains(day);
                    }

                    Set("ChkMon", DayOfWeek.Monday);
                    Set("ChkTue", DayOfWeek.Tuesday);
                    Set("ChkWed", DayOfWeek.Wednesday);
                    Set("ChkThu", DayOfWeek.Thursday);
                    Set("ChkFri", DayOfWeek.Friday);
                    Set("ChkSat", DayOfWeek.Saturday);
                    Set("ChkSun", DayOfWeek.Sunday);
                }

                SetDayOfWeekCheckboxes(job.DaysOfWeek);

                // ✅ Targeting + export UI (after platform pipeline so dropdowns are populated)
                try
                {
                    EnsureTargetingControls();

                    // Export mode radios
                    var paging = this.FindControl<RadioButton>("ExportPagingRadio");
                    var server = this.FindControl<RadioButton>("ExportServerRadio");
                    var both = this.FindControl<RadioButton>("ExportBothRadio");

                    if (paging != null && server != null && both != null)
                    {
                        paging.IsChecked = job.ExportMode == ExportMode.PagingOnly;
                        server.IsChecked = job.ExportMode == ExportMode.ServerOnly;
                        both.IsChecked = job.ExportMode == ExportMode.PagingThenServer;
                    }

                    // Folder mode dropdown
                    var folderDd = this.FindControl<ComboBox>("ExportFolderModeDropdown");
                    if (folderDd != null)
                    {
                        folderDd.SelectedIndex = job.ExportFolderMode switch
                        {
                            ExportFolderMode.Flat => 0,
                            ExportFolderMode.ByInstruction => 1,
                            ExportFolderMode.ByDate => 2,
                            _ => 3
                        };
                    }

                    // Targeting
                    var method = (job.TargetingMethod ?? "FQDN").Trim();
                    if (string.Equals(method, "MG", StringComparison.OrdinalIgnoreCase) ||
                        string.Equals(method, "Management Group", StringComparison.OrdinalIgnoreCase))
                    {
                        if (_mgRadio != null)
                            _mgRadio.IsChecked = true;

                        TargetModeRadio_Checked(this, null);

                        if (_mgDropdown != null)
                        {
                            // Prefer ID selection when available.
                            if (job.ManagementGroupId.HasValue)
                            {
                                var matchById = _mgDropdown.Items?.OfType<ManagementGroup>()
                                    .FirstOrDefault(m => m.UsableId == job.ManagementGroupId.Value);
                                if (matchById != null)
                                    _mgDropdown.SelectedItem = matchById;
                            }

                            if (_mgDropdown.SelectedItem == null && !string.IsNullOrWhiteSpace(job.TargetingManagementGroup))
                            {
                                var matchByName = _mgDropdown.Items?.OfType<ManagementGroup>()
                                    .FirstOrDefault(m => string.Equals(m.Name, job.TargetingManagementGroup, StringComparison.OrdinalIgnoreCase));
                                if (matchByName != null)
                                    _mgDropdown.SelectedItem = matchByName;
                            }
                        }
                    }
                    else if (string.Equals(method, "Coverage", StringComparison.OrdinalIgnoreCase) ||
                             string.Equals(method, "CoverageTag", StringComparison.OrdinalIgnoreCase) ||
                             string.Equals(method, "Coverage Tag", StringComparison.OrdinalIgnoreCase))
                    {
                        if (_coverageRadio != null)
                            _coverageRadio.IsChecked = true;

                        TargetModeRadio_Checked(this, null);

                        if (_coverageTagNameDropdown != null && !string.IsNullOrWhiteSpace(job.CoverageTagName))
                            _coverageTagNameDropdown.SelectedItem = job.CoverageTagName;

                        if (_coverageTagValueDropdown != null && !string.IsNullOrWhiteSpace(job.CoverageTagValue))
                            _coverageTagValueDropdown.SelectedItem = job.CoverageTagValue;
                    }
                    else
                    {
                        if (_fqdnRadio != null)
                            _fqdnRadio.IsChecked = true;

                        TargetModeRadio_Checked(this, null);

                        if (_fqdnInputBox != null)
                            _fqdnInputBox.Text = job.TargetingFqdn ?? string.Empty;
                    }
                }
                catch (Exception ex)
                {
                    LogHelper.Warn($"⚠️ Populate targeting/export UI failed: {ex.Message}");
                }
            }
            catch (Exception ex)
            {
                LogHelper.Error($"❌ PopulateFromScheduledJobAsync failed: {ex}");
            }
            finally
            {
                try { _jobPopulateGate.Release(); } catch { }
                _isPopulatingJob = false;
            }
        }

        public ConfigTab() : this(
                        new InstructionService(),
                        new TokenStoreService(),
                        new AuthenticationService(),
                        new InstructionHelper())
        {
        }

        private void SetComboBoxSelectionByContent(ComboBox? comboBox, string? content)
        {
            if (comboBox == null || string.IsNullOrWhiteSpace(content))
                return;

            foreach (var item in comboBox.Items)
            {
                if (item is ComboBoxItem cbi && string.Equals(cbi.Content?.ToString(), content, StringComparison.OrdinalIgnoreCase))
                {
                    comboBox.SelectedItem = cbi;
                    return;
                }

                if (string.Equals(item?.ToString(), content, StringComparison.OrdinalIgnoreCase))
                {
                    comboBox.SelectedItem = item;
                    return;
                }
            }
        }

        public void SetDependencies(
     InstructionService instructionService,
     TokenStoreService tokenStoreService,
     AuthenticationService authService,
     InstructionHelper instructionHelper,
     ScheduledJobsViewModel jobsVm,
     JobSchedulerService scheduler)
        {
            _instructionService = instructionService;
            _tokenStoreService = tokenStoreService;
            _authService = authService;
            _instructionHelper = instructionHelper;
            _jobsVm = jobsVm;
            _scheduler = scheduler;
        }




        public void SetJobScheduler(ScheduledJobsViewModel jobsVm, JobSchedulerService scheduler)
        {
            _jobsVm = jobsVm;
            _scheduler = scheduler;

            if (DataContext is ConfigTabViewModel vm)
            {
                vm.Scheduler = scheduler;
                vm.JobsViewModel = jobsVm;
            }
            LogHelper.Info($"📦 SetJobScheduler called: jobsVm null? {_jobsVm == null}, scheduler null? {_scheduler == null}");

        }



        public async Task CreateOrUpdateJobFromConfigTabAsync()
        {
            try
            {
                // Validate required fields for Instruction jobs.
                if (_selectedInstruction == null || _selectedInstruction.Id <= 0)
                {
                    await ShowWarningAsync("Please select an instruction before creating a scheduled instruction job.");
                    return;
                }

                // Create new by default. Only update when we've explicitly entered edit mode
                // (e.g., via "Edit Job" on the Scheduled Jobs tab).
                bool isEdit = _isEditingScheduledJob && !string.IsNullOrWhiteSpace(_editingScheduledJobId);
                string jobId = isEdit
                    ? _editingScheduledJobId!
                    : Guid.NewGuid().ToString();

                var parameters = CollectParametersFromPanels();
                _platformUrl = GetSelectedPlatformUrl();
                _fqdn = _platformUrl;

                LogHelper.Info($"🌐 Selected platform → Alias: \"{_platformAlias}\", FQDN: \"{_fqdn}\"");

                var (method, fqdn, mg, tagName, tagValue) = GetTargetingDetails();

                // Normalize MG selection so it is always persisted for scheduler runs.
                // The scheduler currently relies on TargetingManagementGroup and/or ManagementGroupId.
                int? selectedMgId = null;
                if (method.Equals("MG", StringComparison.OrdinalIgnoreCase))
                {
                    if (_mgDropdown?.SelectedItem is ManagementGroup mgObj)
                    {
                        mg = mgObj.Name ?? string.Empty;
                        selectedMgId = mgObj.UsableId;
                    }
                    else if (_mgDropdown?.SelectedItem is ComboBoxItem mgItem)
                    {
                        mg = mgItem.Content?.ToString() ?? string.Empty;
                    }
                    else if (!string.IsNullOrWhiteSpace(_mgDropdown?.SelectedItem?.ToString()))
                    {
                        mg = _mgDropdown!.SelectedItem!.ToString()!;
                    }

                    // If SelectedItem wasn't a ManagementGroup, attempt to pull an ID from SelectedValue.
                    if (!selectedMgId.HasValue && int.TryParse(_mgDropdown?.SelectedValue?.ToString(), out var parsedMgId))
                        selectedMgId = parsedMgId;
                }

                // Enforce targeting requirements: user must choose either MG, FQDN, or Coverage Tag.
                // Additionally, platforms can opt-in to requiring coverage targeting (no blank scope).
                bool requireCoverage = _selectedPlatform?.RequireCoverage == true;

                // When coverage targeting is used on a platform that requires a scope, mimic the "global" UI behavior
                // by forcing the scope to "All Devices" (-1) if the user didn't explicitly pick an MG.
                if (requireCoverage && (method.Equals("Coverage", StringComparison.OrdinalIgnoreCase) || method.Equals("CoverageTag", StringComparison.OrdinalIgnoreCase)))
                {
                    if (string.IsNullOrWhiteSpace(mg))
                        mg = "All Devices";

                    if (!selectedMgId.HasValue)
                        selectedMgId = -1;
                }
                if (string.IsNullOrWhiteSpace(method))
                {
                    await ShowWarningAsync("Please select a targeting mode (FQDN, Management Group, or Coverage Tag).");
                    return;
                }

                if (method.Equals("FQDN", StringComparison.OrdinalIgnoreCase))
                {
                    if (string.IsNullOrWhiteSpace(fqdn))
                    {
                        await ShowWarningAsync("Please enter a device FQDN (or use the suggestion list) before creating the job.");
                        return;
                    }
                }
                else if (method.Equals("MG", StringComparison.OrdinalIgnoreCase))
                {
                    if (string.IsNullOrWhiteSpace(mg))
                    {
                        await ShowWarningAsync(requireCoverage
                            ? "This platform requires coverage targeting. Please select a Management Group (or switch to FQDN/Coverage Tag) before creating the job."
                            : "Please select a Management Group before creating the job.");
                        return;
                    }
                }
                else if (method.Equals("Coverage", StringComparison.OrdinalIgnoreCase) || method.Equals("CoverageTag", StringComparison.OrdinalIgnoreCase))
                {
                    if (string.IsNullOrWhiteSpace(tagName) || string.IsNullOrWhiteSpace(tagValue))
                    {
                        await ShowWarningAsync("Please select both Coverage Tag Name and Coverage Tag Value before creating the job.");
                        return;
                    }
                }
                else
                {
                    await ShowWarningAsync($"Unknown targeting mode '{method}'. Please select FQDN, Management Group, or Coverage Tag.");
                    return;
                }


                int ttl = int.TryParse(_instructionTtlBox?.Text, out var parsedTtl) ? parsedTtl : 10;

                var job = new ScheduledJob
                {
                    JobId = jobId,
                    InstructionName = _selectedInstruction?.Name ?? "(no instruction)",
                    InstructionId = _selectedInstruction?.Id ?? 0,
                    InstructionType = "Instruction",

                    PlatformFqdn = _fqdn,
                    PlatformAlias = _platformAlias,
                    AppRegistrationId = _appRegIdTextBox?.Text ?? "",
                    CertThumbprint = _certThumbprintTextBox?.Text ?? "",
                    AuthenticationMode = "Cert",

                    InstructionTtlMinutes = ttl,
                    InstructionTtlUnit = (_instructionTtlUnitDropdown?.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Minutes",
                    ResponseTtlMinutes = int.TryParse(_responseTtlBox?.Text, out var rttl) ? rttl : 24,
                    ResponseTtlUnit = (_responseTtlUnitDropdown?.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Hours",

                    ExportFormat = (_exportFormatComboBox?.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "CSV",
                    Consumer = (_consumerDropdown?.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Explorer",

                    ExportMode = GetSelectedExportMode(),
                    ExportFolderMode = GetSelectedExportFolderMode(),

                    JobType = "Instruction",
                    Status = "Enabled",
                    StartDate = _startDatePicker?.SelectedDate?.Date ?? DateTime.Today,
                    EndDate = _endDatePicker?.SelectedDate?.Date ?? DateTime.Today.AddYears(2),
                    StartTime = _startTimePicker?.SelectedTime ?? new TimeSpan(9, 0, 0),
                    Recurrence = (_recurrenceComboBox?.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Once",

                    EnableExport = true,
                    ExportTtlMinutes = ttl + 2, // Export starts after instruction TTL
                    RuntimeStatus = "Waiting",
                    MaxRetries = 3,
                    RetryCount = 0,
                    Cooldown = TimeSpan.FromMinutes(5),

                    DaysOfWeek = GetSelectedDaysOfWeek(),
                    WeeklyRepeatCount = 1,
                    MonthlyRepeatCount = (int)(_monthlyRepeatCount?.Value ?? 1),
                    MonthlyWeekOffsets = new List<int> { 1, 2, 3, 4, -1 },
                    MonthlyDayFallback = 1,

                    Parameters = parameters.ToDictionary(kvp => kvp.Key, kvp => kvp.Value?.ToString() ?? ""),

                    TargetingMethod = method,
                    TargetingFqdn = fqdn,
                    TargetingManagementGroup = mg,
                    CoverageTagName = tagName,
                    CoverageTagValue = tagValue,

                    IsRunning = false,
                    IsEnabled = true
                };

                // Normalize targeting so the job only carries the *active* targeting fields.
                // This prevents confusing "FQDN + MG" state when only one mode is actually selected.
                var normMethod = (job.TargetingMethod ?? string.Empty).Trim();
                if (normMethod.Equals("FQDN", StringComparison.OrdinalIgnoreCase))
                {
                    job.TargetingManagementGroup = string.Empty;
                    job.ManagementGroupId = null;
                    job.CoverageTagName = string.Empty;
                    job.CoverageTagValue = string.Empty;
                }
                else if (normMethod.Equals("MG", StringComparison.OrdinalIgnoreCase) || normMethod.Equals("Management Group", StringComparison.OrdinalIgnoreCase))
                {
                    job.TargetingFqdn = string.Empty;
                    job.CoverageTagName = string.Empty;
                    job.CoverageTagValue = string.Empty;
                }
                else if (normMethod.Equals("Coverage", StringComparison.OrdinalIgnoreCase) || normMethod.Equals("CoverageTag", StringComparison.OrdinalIgnoreCase) || normMethod.Equals("Coverage Tag", StringComparison.OrdinalIgnoreCase))
                {
                    job.TargetingFqdn = string.Empty;
                    // Keep MG fields only if the platform requires a scope and we resolved a usable MG id/name.
                    if (!requireCoverage)
                    {
                        job.TargetingManagementGroup = string.Empty;
                        job.ManagementGroupId = null;
                    }
                }

                // Ensure targeting details are persisted correctly (name + usable id), so the scheduler can execute without UI state.
                if (string.Equals(job.TargetingMethod, "MG", StringComparison.OrdinalIgnoreCase))
                {
                    if (_mgDropdown?.SelectedItem is ManagementGroup selectedMg)
                    {
                        job.TargetingManagementGroup = selectedMg.Name ?? string.Empty;
                        job.ManagementGroupId = selectedMg.UsableId;

                        // Normalize display label for "All Devices" (UsableId <= 0).
                        if (selectedMg.UsableId <= 0)
                            job.TargetingManagementGroup = "All Devices";
                    }
                    else if (_mgDropdown?.SelectedItem is string mgName)
                    {
                        job.TargetingManagementGroup = mgName;
                        if (string.Equals(mgName, "All Devices", StringComparison.OrdinalIgnoreCase) ||
                            string.Equals(mgName, "Global", StringComparison.OrdinalIgnoreCase))
                        {
                            job.ManagementGroupId = -1;
                        }
                    }
                }
                else
                {
                    // For non-MG targeting, only clear MG values when the run scope truly doesn't need them.
                    // Coverage-based targeting can still require an explicit scope ("All Devices"/global) on some platforms.
                    bool isCoverageTargeting =
                        string.Equals(job.TargetingMethod, "Coverage", StringComparison.OrdinalIgnoreCase) ||
                        string.Equals(job.TargetingMethod, "CoverageTag", StringComparison.OrdinalIgnoreCase) ||
                        string.Equals(job.TargetingMethod, "DynamicCoverage", StringComparison.OrdinalIgnoreCase) ||
                        string.Equals(job.TargetingMethod, "Dynamic Coverage", StringComparison.OrdinalIgnoreCase);

                    if (isCoverageTargeting && selectedMgId.HasValue)
                    {
                        job.ManagementGroupId = selectedMgId.Value;

                        if (string.IsNullOrWhiteSpace(job.TargetingManagementGroup))
                            job.TargetingManagementGroup = mg ?? string.Empty;

                        if (job.ManagementGroupId <= 0 && string.IsNullOrWhiteSpace(job.TargetingManagementGroup))
                            job.TargetingManagementGroup = "All Devices";
                    }
                    else
                    {
                        job.ManagementGroupId = null;
                        job.TargetingManagementGroup = string.Empty;
                    }
                }

                if (isEdit)
                {
                    await _jobsVm.UpdateJobAsync(job);
                    LogHelper.Info($"✏️ Updated job: {job.InstructionName}");

                    // After an update, revert to "new job" mode to prevent accidental overwrites.
                    _isEditingScheduledJob = false;
                    _editingScheduledJobId = null;
                    if (_jobsVm != null)
                        _jobsVm.SelectedScheduledJob = null;
                }
                else
                {
                    LogHelper.Info($"📋 _jobsVm is null? {_jobsVm == null}");
                    LogHelper.Info($"📋 job is null? {job == null}");

                    await _jobsVm.CreateJobAsync(job);
                    LogHelper.Info($"➕ Created new job: {job.InstructionName}");
                }
            }
            catch (Exception ex)
            {
                LogHelper.Info($"❌ Error saving job: {ex.Message}");
            }

        }

        private async Task ShowWarningAsync(string message)
        {
            try
            {
                var owner = TopLevel.GetTopLevel(this) as Window;
                if (owner == null)
                {
                    LogHelper.Warn($"⚠️ {message}");
                    return;
                }

                var dialog = new Window
                {
                    Title = "Warning",
                    Width = 520,
                    Height = 220,
                    WindowStartupLocation = WindowStartupLocation.CenterOwner,
                    Content = new StackPanel
                    {
                        Spacing = 10,
                        Margin = new Thickness(16),
                        Children =
                        {
                            new TextBlock
                            {
                                Text = message,
                                TextWrapping = TextWrapping.Wrap
                            },
                            new Button
                            {
                                Content = "OK",
                                HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Center,
                                Width = 100,
                                IsDefault = true,
                                IsCancel = true
                            }
                        }
                    }
                };

                if (dialog.Content is StackPanel sp && sp.Children.OfType<Button>().FirstOrDefault() is Button ok)
                    ok.Click += (_, _) => dialog.Close();

                await dialog.ShowDialog(owner);
            }
            catch (Exception ex)
            {
                LogHelper.Warn($"⚠️ Warning dialog failed: {ex.Message}. Message: {message}");
            }
        }


        public void SetAuthService(AuthenticationService authService)
        {
            _authService = authService;
            _platformsTab ??= this.FindControl<PlatformsTab>("PlatformsTabHost");
            _platformsTab?.SetAuthService(authService);
        }

        public void SetPlatforms(List<Platform> platforms)
        {
            _platformsTab ??= this.FindControl<PlatformsTab>("PlatformsTabHost");
            _platformsTab?.SetPlatforms(platforms.Select(p => new PlatformSettings
            {
                PlatformFqdn = p.PlatformFqdn,
                Alias = p.Alias,
                AppId = p.AppId,
                CertThumbprint = p.CertThumbprint,
                DefaultConsumer = p.DefaultConsumer,
                IsDefault = p.IsDefault,
                RequireCoverage = p.RequireCoverage
            }).ToList());
        }


        private List<DayOfWeek> GetSelectedDaysOfWeek()
        {
            var list = new List<DayOfWeek>();
            var row = this.FindControl<StackPanel>("DaysOfWeekRow");
            if (row == null) return list;

            foreach (var cb in row.Children.OfType<CheckBox>())
            {
                if (cb.IsChecked != true) continue;
                switch (cb.Content?.ToString())
                {
                    case "Mon": list.Add(DayOfWeek.Monday); break;
                    case "Tue": list.Add(DayOfWeek.Tuesday); break;
                    case "Wed": list.Add(DayOfWeek.Wednesday); break;
                    case "Thu": list.Add(DayOfWeek.Thursday); break;
                    case "Fri": list.Add(DayOfWeek.Friday); break;
                    case "Sat": list.Add(DayOfWeek.Saturday); break;
                    case "Sun": list.Add(DayOfWeek.Sunday); break;
                }
            }
            return list;
        }



    }
}