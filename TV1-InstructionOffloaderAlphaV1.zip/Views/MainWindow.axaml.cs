﻿
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Markup.Xaml;
using Avalonia.Media;
using Avalonia.ReactiveUI;
using Avalonia.Threading;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using ReactiveUI;
using Splat.ModeDetection;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Reactive.Concurrency;
using System.Reactive.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Input;
using TV1_InstructionOffloader.Helpers;
using TV1_InstructionOffloader.Models;
using TV1_InstructionOffloader.Services;
using TV1_InstructionOffloader.ViewModels;
using TV1_InstructionOffloader.Views;
using TV1_PlatformOffloader.Models;
using ScheduledJobModel = TV1_InstructionOffloader.Models.ScheduledJob;

namespace TV1_InstructionOffloader
{


    public partial class MainWindow : Window, INotifyPropertyChanged


    {
        private ComboBox _mgDropdown;
        private ComboBox _coverageTagNameDropdown;
        private ComboBox _coverageTagValueDropdown;
        private StackPanel _coverageDropdownPanel;
        private ComboBox _consumerDropdown;
        private TextBox _fqdnBox;
        private RadioButton _fqdnRadio;
        private RadioButton _mgRadio;
        private RadioButton _coverageRadio;
        private ListBox? _instructionListBox;
        private bool _configTabControlsHooked = false;
        private TextBox _searchBox;
        private RadioButton _authInteractiveRadio;
        private RadioButton _authCertRadio;
        private Button _browseExportPathButton;
        private Button _authButton;
        private Button _previewTargetButton;
        private Button _runNowButton;
        private TextBox _exportFilePathBox;
        private TextBox _logTextBox;
        private TextBox _targetingFqdnBox;
        private Dictionary<string, InstructionDefinition> _instructionMap = new();
        private string _consumerName = "Explorer";
        private AppSettings _config;
        private ComboBox _consumerComboBox;
        private string _selectedConsumer = "Explorer";
        private string? _token;
        private string? _fqdn;
        private TextBlock _instructionDescriptionTextBlock;
        private AuthenticationService _authService;
        private TokenStoreService _tokenStoreService;
        private InstructionHelper _instructionHelper;
        private StackPanel _fileExportOptionsPanel;
        private StackPanel _dbExportOptionsPanel;
        private List<InstructionDefinition> _allInstructions = new();
        private TV1_InstructionOffloader.Models.PlatformConfigData _selectedPlatform;
        private TextBox? _platformFqdnTextBox;
        private TextBox? _appRegIdTextBox;
        private TextBox? _certThumbprintTextBox;
        private ComboBox? _authModeComboBox;
        private Button? _createJobButton;
        private ListBox? _scheduledJobsList;
        private TextBox _manualInstructionIdBox;
        private Button _fetchExportButton;
        private InstructionDefinition? _selectedInstruction;
        private ConsumerService _consumerService;
        private InstructionService _instructionService = new();
        private ComboBox _targetingModeComboBox;
        private ComboBox _matchTypeComboBox;
        private ComboBox _coverageTagNameComboBox;
        private ComboBox _coverageTagValueComboBox;
        private TextBox _fqdnTextBox;
        private ListBox _selectedFqdnListBox;
        private ComboBox _managementGroupComboBox;
        private bool _isRunning = false;
        private List<InstructionDefinition> _instructionDefinitions = new();
        private TextBox _instructionTtlBox;
        private ComboBox _instructionTtlUnitDropdown;
        private TextBox _responseTtlBox;
        private ComboBox _responseTtlUnitDropdown;
        private ComboBox _exportFormatComboBox;
        private ResultTrackerCoordinator _coordinator;
        private Action<string> _logger;
        private string selectedName;
        private IInstructionFetcher _instructionFetcher;
        private IResultTracker _resultTracker;
        private ResultTrackerCoordinator _resultCoordinator;
        private string _platformUrl;
        private IInstructionFetcher _fetcher;
        private IResultTracker _tracker;
        private ComboBox _platformComboBox;
        private ObservableCollection<Platform> _platforms = new();
        private ScheduledJobModel? _currentScheduledJob;
        private DataGrid? _scheduledJobsDataGrid;
        private ComboBox _recurrenceComboBox;
        private bool _isEditMode = false;
        private DatePicker _startDatePicker;
        private DatePicker _endDatePicker;
        private ComboBox _weeklyDayComboBox;
        private NumericUpDown _weeklyRepeatCount;
        private NumericUpDown _monthlyRepeatCount;
        private NumericUpDown _monthlyDay;
        private StackPanel _dailyDaysPanel = null!;
        private StackPanel _weeklyPanel = null!;
        private StackPanel _monthlyPanel = null!;
        private ScheduledJob? _currentJob;
        private StackPanel _recurrenceDayPanel = null!;
        private StackPanel _weeklyRepeatRow = null!;
        private CheckBox _chkWeek1 = null!;
        private CheckBox _chkWeek2 = null!;
        private CheckBox _chkWeek3 = null!;
        private CheckBox _chkWeek4 = null!;
        private CheckBox _chkWeekLast = null!;
        private StackPanel _daysOfWeekRow = null!;
        private Button _createScheduledJobButton = null!;   // the “Create Job” button
        private TimePicker? _startTimePicker;
        private string _currentInstructionName = "Instruction";
        private int _currentInstructionId = 0;
        private Button _newScheduledJobButton = null!;
        private ObservableCollection<ScheduledJob> _scheduledJobs;
        private JobSchedulerService? _scheduler;
        private bool _schedulerStarted = false;
        private IInstructionJobExecutor? _instructionExecutor;
        private StackPanel? _parametersPanel;
        private StackPanel? _parametersFqdnPanel;
        private ScheduledJobsViewModel? _jobsVm;
        private bool _gridReady;
        private ConfigTab _configTab;
        private readonly Dictionary<string, string> _tokenMap = new(); // FQDN → token
        private ComboBox? _platformDropdown;
        private ComboBox? _tagNameDropdown;
        private Button? _runInstructionButton;
        private DataGrid? _jobsDataGrid;
        private ConfigTab? _configTabControl;
        private string _loggedInUserDisplay = "👤 Not logged in";
        private string _selectedPlatformDisplay = "🌐 No platform selected";
        private readonly HashSet<string> _loggedMessages = new();
        private JobSchedulerService? _jobScheduler;
        private PlatformsTab? _platformsTab;
        private string? _currentPlatformAlias;
        private string? _currentPlatformFqdn;
        private Platform? _lastSelectedPlatform;
        private bool _platformManuallyChanged = false;
        private TabControl? _tabControl;
        private JobSchedulerService _jobSchedulerService;
        //private ExportOptionsTab? _exportOptionsTab;


        public string CurrentPlatformAlias => _currentPlatformAlias;
        public string CurrentPlatformFqdn => _currentPlatformFqdn;
        public string CurrentToken => _token;

        public TokenStoreService TokenStore => _tokenStoreService;

		private string? ResolveTokenForFqdn(string? fqdn)
		{
			try
			{
				if (!string.IsNullOrWhiteSpace(fqdn) && _tokenStoreService != null && _tokenStoreService.TryGetToken(fqdn, out var stored) && !string.IsNullOrWhiteSpace(stored))
				{
					// Keep the window's token in sync so older call sites that still use _token keep working.
					_token = stored;
					return stored;
				}
			}
			catch
			{
				// ignore
			}

			return _token;
		}

		private string? ResolveTokenForJob(ScheduledJob? job)
		{
			if (job != null && !string.IsNullOrWhiteSpace(job.PlatformFqdn))
				return ResolveTokenForFqdn(job.PlatformFqdn);

			return ResolveTokenForFqdn(_fqdn ?? _platformUrl ?? _selectedPlatform?.PlatformFqdn);
		}

		private async Task<string?> EnsureTokenAsync(string? fqdn, bool allowRefresh = true)
		{
			// 1) Try cached/store token first.
			var token = ResolveTokenForFqdn(fqdn);
			if (!string.IsNullOrWhiteSpace(token))
				return token;

			// 2) If missing, try a full refresh (first login or token-expiry reauth).
			//    RefreshAllAsync is the one place that must repopulate MGs, consumers, tags, and instructions.
			if (allowRefresh && _configTab != null)
			{
				try
				{
					await _configTab.RefreshAllAsync();
				}
				catch
				{
					// best effort
				}

				token = ResolveTokenForFqdn(fqdn);
				if (!string.IsNullOrWhiteSpace(token))
					return token;
			}

			return null;
		}

        // Scheduled date/time/recurrence
        public DateTime ScheduledDate { get; set; } = DateTime.Today;
        public TimeSpan ScheduledTime { get; set; } = TimeSpan.Zero;


        private string _scheduledRecurrence;

        public string ScheduledRecurrence
        {
            get => _scheduledRecurrence;
            set
            {
                if (_scheduledRecurrence != value)
                {
                    _scheduledRecurrence = value;
                    OnPropertyChanged(nameof(ScheduledRecurrence));
                    OnPropertyChanged(nameof(IsDailyRecurrence)); // keep if used for logic or UI visibility
                }
            }
        }


        public event PropertyChangedEventHandler? PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }




        private string GetSelectedTargetingMethod()
        {
            // These fields are assumed to be defined elsewhere in the class:
            // RadioButton _fqdnRadio, _mgRadio, _coverageRadio;

            if (_fqdnRadio?.IsChecked == true) return "FQDN";
            if (_mgRadio?.IsChecked == true) return "MG";
            if (_coverageRadio?.IsChecked == true) return "Tag";

            // Fallback
            return "FQDN";
        }


        public bool IsDailyRecurrence => ScheduledRecurrence == "Daily";

        public bool ScheduledMon { get; set; }
        public bool ScheduledTue { get; set; }
        public bool ScheduledWed { get; set; }
        public bool ScheduledThu { get; set; }
        public bool ScheduledFri { get; set; }
        public bool ScheduledSat { get; set; }
        public bool ScheduledSun { get; set; }


        // FIXES: Ensured token checks, single auth, tab display update
        public MainWindow()
        {
            _authService = new AuthenticationService();
            var configHelper = new ConfigHelper();
            _config = configHelper.Load();

            try
            {
                if (_config?.Platforms != null)
                {
                    foreach (var p in _config.Platforms)
                    {
                        var alias = string.IsNullOrWhiteSpace(p.Alias) ? "(none)" : p.Alias.Trim();
                        var fqdn = string.IsNullOrWhiteSpace(p.PlatformFqdn) ? "(none)" : p.PlatformFqdn.Trim();
                        var upn = string.IsNullOrWhiteSpace(p.UserId) ? "(none)" : "(set)";
                        LogHelper.Info($"🧪 CONFIG DEBUG: Platform alias='{alias}', fqdn='{fqdn}', useCert={p.UseCert}, userId={upn}");
                    }
                }
            }
            catch
            {
                // Non-fatal
            }


            var platforms = _config.Platforms;
            _consumerName = platforms?.FirstOrDefault()?.DefaultConsumer ?? "Explorer";
            PlatformService.KnownPlatforms = (_config.Platforms ?? new List<PlatformSettings>())
                .Select(p => new Platform
                {
                    // Never allow empty alias for runtime objects; fall back to FQDN.
                    Alias = string.IsNullOrWhiteSpace(p.Alias) ? (p.PlatformFqdn ?? "") : p.Alias,
                    GroupName = string.IsNullOrWhiteSpace(p.Alias) ? p.PlatformFqdn : p.Alias,
                    PlatformFqdn = p.PlatformFqdn,
                    AppId = p.AppId,
                    CertThumbprint = p.CertThumbprint,
                    UseCert = p.UseCert,
                    UserId = p.UserId ?? "",
                    DefaultConsumer = p.DefaultConsumer,
                    IsDefault = p.IsDefault
                }).ToList();

            _logger = msg => Console.WriteLine(msg);
            _tokenStoreService = new TokenStoreService();
            _instructionHelper = new InstructionHelper();

            // Apply persisted timestamp display preference early.
            LogHelper.UseUtc = _config.UseUtcTimestamps;

            InitializeComponent();
            _logTextBox = this.FindControl<TextBox>("LogTextBox");
            _jobsVm = new ScheduledJobsViewModel(msg =>
                 _logTextBox.Text += $"[{DateTime.Now:HH:mm:ss}] {msg}\n");


            _jobsVm.JobsLoaded += OnJobsLoaded;
            this.Opened += async (_, _) =>
            {
                Log("📝 MainWindow opened.");
                try
                {
                    // Avalonia already applies DPI scaling. Applying an extra RenderTransform here can clip UI
                    // (notably the top tab strip) on some Win10 VMs / mixed-DPI setups.
                    var screen = Screens.ScreenFromVisual(this);
                    double scale = screen?.Scaling ?? 1.0;
                    LogHelper.Info($"📏 Screen scaling reported by Avalonia: {scale:F2} (no additional RenderTransform applied)");
                }
                catch (Exception ex)
                {
                    LogHelper.Error($"⚠️ Failed to read DPI scaling: {ex.Message}");
                }

// ① Load Jobs FIRST
                await _jobsVm.LoadJobsAsync();
                Log($"📋 Jobs loaded: {_jobsVm.ScheduledJobs.Count}");
                await _jobsVm.LoadExecutionHistoryAsync();
                _jobsVm.PopulateChartData();

                Log($"📈 Chart series count: {_jobsVm.DurationSeries?.Length ?? 0}");

                foreach (var job in _jobsVm.ScheduledJobs)
                    Log($"📌 Loaded job: {job.InstructionName} — Enabled: {job.IsEnabled}");

                // ② Attach controls + events
                AttachControls();
                AttachEvents();
                AttachDayCheckboxLogging();

                // History UTC/local toggle (display-only)
                try
                {
                    var utcToggle = this.FindControl<Avalonia.Controls.ToggleSwitch>("HistoryUtcToggle");
                    if (utcToggle != null)
                    {
                        utcToggle.IsChecked = _config.UseUtcTimestamps;
                        utcToggle.Checked += (_, _) => OnHistoryUtcToggleChanged(true);
                        utcToggle.Unchecked += (_, _) => OnHistoryUtcToggleChanged(false);
                        ApplyHistoryTimeColumnVisibility(_config.UseUtcTimestamps);
                    }
                }
                catch
                {
                    // Non-fatal
                }

                // ③ Update targeting UI visibility
                UpdateTargetingVisibility();

                // ④ ConfigTab setup
                _configTab = this.FindControl<ConfigTab>("ConfigTabHost");
                if (_configTab == null)
                {
                    Log("❌ ConfigTabHost not found – check XAML.");
                    return;
                }

                if (_configTab.DataContext is ConfigTabViewModel vm)
                {
                    vm.PlatformsChanged += list =>
                    {
                        Log("🔁 PlatformsChanged received from ConfigTab VM.");
                        RefreshPlatformDropdown(list);
                        _configTab?.SetPlatforms(vm.Platforms);
                    };

                    if (vm.Platforms.Count > 0)
                        RefreshPlatformDropdown(vm.Platforms);
                    else
                        Log("⚠️ No platforms available yet.");
                }
                await EnsureFirstRunSetupAsync();
                _configTab.SetAuthService(_authService);
                _configTab.SetPlatforms(_platforms);
                _configTab.PlatformSelected += (alias, fqdn) =>
                {
                    _currentPlatformAlias = alias;
                    _currentPlatformFqdn = fqdn;
                    LogHelper.Info($"✅ MainWindow received platform selection → Alias: {alias}, FQDN: {fqdn}");
                };

                // Scheduler is initialized when jobs are loaded (OnJobsLoaded). Do not start it twice here.

                //  _exportOptionsTab = this.FindControl<ExportOptionsTab>("ExportOptionsHost");
                //  _configTab?.SetExportOptionsTab(_exportOptionsTab);

                AttachControls();
                HookConfigTabControls();

                // await AuthenticateAndInitialize(); // moved to ConfigTab selection to prevent early cert-auth without UPN

                // Platform data (Consumers/MGs/Instructions/Coverage) is loaded by ConfigTab when it is ready.
                // Avoid doing it here to prevent duplicate API calls and log spam.

                InitializeFetcher();
                UpdateTargetingVisibility();
            };

            _scheduledJobsDataGrid = this.FindControl<DataGrid>("ScheduledJobsDataGrid");
            if (_scheduledJobsDataGrid != null)
                _scheduledJobsDataGrid.ItemsSource = _jobsVm.ScheduledJobs;

            DataContext = _jobsVm;

            _jobsVm.EditRequested += job =>
            {
                Dispatcher.UIThread.Post(async () =>
                {
                    _currentScheduledJob = job;

                    int retries = 0;
                    while (!_configTabControlsHooked && retries++ < 20)
                        await Task.Delay(100);

                    if (!_configTabControlsHooked)
                    {
                        _logTextBox.Text += "❌ ConfigTab controls not ready after waiting.\n";
                        return;
                    }

                    var tabControl = this.FindControl<TabControl>("MainTabControl");
                    await Task.Delay(300);

                    var configTabItem = this.FindControl<TabItem>("ConfigTabItem");

                    if (tabControl != null && configTabItem != null)
                    {
                        tabControl.SelectedItem = configTabItem;
                        _logTextBox.Text += "🔁 Switched to Config tab\n";
                    }
                    else
                    {
                        _logTextBox.Text += "⚠️ Could not locate Config tab or TabControl.\n";
                        return;
                    }

                    await Task.Delay(150);

                    _tabControl = this.FindControl<TabControl>("MainTabControl");

                    var innerTabControl = _configTab?.FindControl<TabControl>("ConfigTabInnerTabControl");
                    var instructionsTab = _configTab?.FindControl<TabItem>("InstructionsTab");

                    if (innerTabControl != null && instructionsTab != null)
                    {
                        innerTabControl.SelectedItem = instructionsTab;
                        _logTextBox.Text += "🔀 Switched to Instructions sub-tab\n";
                    }
                    else
                    {
                        _logTextBox.Text += "⚠️ Could not locate Instructions sub-tab.\n";
                    }

                    await Task.Delay(150);
                    RecurrenceComboBox_SelectionChanged(_recurrenceComboBox, null);

                    // Populate editor AFTER navigation, but ensure the platform context is authenticated and loaded before applying job fields.
                    await Dispatcher.UIThread.InvokeAsync(async () =>
                    {
                        if (_configTab != null)
                            await _configTab.PopulateFromScheduledJobAsync(job);

                        RecurrenceComboBox_SelectionChanged(_recurrenceComboBox, null);
                    });

                    _logTextBox.Text += $"✏️ Editing scheduled job: {job.InstructionName} (ID: {job.InstructionId})\n";
                });
            };


            _authService = new AuthenticationService(
                configHelper,
                _logTextBox,
                null,
                _tokenStoreService,
                _consumerName,
                this
            );

            var startDatePicker = this.FindControl<DatePicker>("StartDatePicker");
            if (startDatePicker != null)
                startDatePicker.SelectedDate = DateTime.Today;

            var endDatePicker = this.FindControl<DatePicker>("EndDatePicker");
            if (endDatePicker != null)
                endDatePicker.SelectedDate ??= DateTime.Today.AddYears(2);

            _logger = (text) => _logTextBox.Text += text + "\n";
            _tracker = new JsonResultTrackerService("results.json");
            _coordinator = new ResultTrackerCoordinator(_tracker, _fetcher, _logger);

            var consumerDropdown = this.FindControl<ComboBox>("ConsumerDropdown");
            if (consumerDropdown != null)
            {
                consumerDropdown.SelectedItem = _consumerName;
                consumerDropdown.SelectionChanged += (_, _) =>
                {
                    if (consumerDropdown.SelectedItem is string selected)
                    {
                        _consumerName = selected;
                        _logTextBox.Text += $"👤 Consumer changed to: {_consumerName}\n";

                        if (_config.Platforms != null && _config.Platforms.Count > 0)
                            _config.Platforms[0].DefaultConsumer = _consumerName;

                        configHelper.Save(_config);
                    }
                };
            }
        }

        private void InitializeComponent()
        {
            AvaloniaXamlLoader.Load(this);

        }
        private void LoadJobsButton_Click(object sender, RoutedEventArgs e)
        {
            Console.WriteLine("Load Jobs button clicked");
        }

        private async void OnRefreshButtonClick(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
        {
            await _configTab.RefreshAllAsync();
        }

        private void InitializeFetcher()
        {
            if (!string.IsNullOrWhiteSpace(_platformUrl) && !string.IsNullOrWhiteSpace(_token))
            {
                _fetcher = new InstructionFetcherService(_platformUrl, _token);
                _coordinator = new ResultTrackerCoordinator(_tracker, _fetcher, _logger);
            }
            else
            {
                // _logTextBox.Text += "❌ Cannot initialize fetcher — platform URL or token is missing.\n";
            }
        }
        public ScheduledJobsViewModel ScheduledJobsVM { get; }
        public void RefreshScheduledJobs()
        {
            var jobs = JobStorageHelper.LoadJobs(logMessage => LogHelper.Info(logMessage));


            LogHelper.Info($"🔄 Refreshed scheduled jobs. Count: {jobs.Count}");
        }


        private void AttachControls()
        {
            _searchBox = this.FindControl<TextBox>("InstructionSearchBox_2");
            _mgDropdown = this.FindControl<ComboBox>("ManagementGroupDropdown");
            _coverageDropdownPanel = this.FindControl<StackPanel>("CoverageDropdownPanel");
            _coverageTagNameDropdown = this.FindControl<ComboBox>("CoverageTagNameDropdown");
            _coverageTagValueDropdown = this.FindControl<ComboBox>("CoverageTagValueDropdown");
            _instructionDescriptionTextBlock = this.FindControl<TextBlock>("InstructionDescriptionTextBlock");
            _consumerDropdown = this.FindControl<ComboBox>("ConsumerDropdown");
            _fqdnBox = this.FindControl<TextBox>("PlatformFqdnBox");

            _targetingFqdnBox = this.FindControl<TextBox>("FqdnInputBox");
            _fqdnRadio = this.FindControl<RadioButton>("FqdnRadio");
            _mgRadio = this.FindControl<RadioButton>("MgRadio");
            _coverageRadio = this.FindControl<RadioButton>("CoverageTagRadio");
            _authInteractiveRadio = this.FindControl<RadioButton>("AuthInteractiveRadio");
            _authCertRadio = this.FindControl<RadioButton>("AuthCertRadio");
            _targetingModeComboBox = this.FindControl<ComboBox>("TargetingModeComboBox");
            _managementGroupComboBox = this.FindControl<ComboBox>("ManagementGroupComboBox");
            //_previewTargetButton = this.FindControl<Button>("PreviewTargetsButton");
            _matchTypeComboBox = this.FindControl<ComboBox>("MatchTypeComboBox");
            _fqdnTextBox = this.FindControl<TextBox>("FqdnInputBox");
            _selectedFqdnListBox = this.FindControl<ListBox>("SelectedFqdnListBox");
            _coverageTagNameComboBox = this.FindControl<ComboBox>("CoverageTagNameDropdown");
            _coverageTagNameDropdown = _coverageTagNameComboBox;
            _coverageTagValueComboBox = this.FindControl<ComboBox>("CoverageTagValueDropdown");
            _coverageTagValueDropdown = _coverageTagValueComboBox;
            _browseExportPathButton = this.FindControl<Button>("BrowseExportPathButton");
            _exportFilePathBox = this.FindControl<TextBox>("ExportFilePathBox");
            _logTextBox = this.FindControl<TextBox>("LogTextBox");
            _authButton = this.FindControl<Button>("AuthenticateButton");
            _runNowButton = this.FindControl<Button>("RunNowButton");
            _fileExportOptionsPanel = this.FindControl<StackPanel>("FileExportOptionsPanel");
            _dbExportOptionsPanel = this.FindControl<StackPanel>("DbExportOptionsPanel");
            _managementGroupComboBox = _mgDropdown;
            _instructionTtlBox = this.FindControl<TextBox>("InstructionTtlBox");
            _instructionTtlUnitDropdown = this.FindControl<ComboBox>("InstructionTtlUnitDropdown");
            _responseTtlBox = this.FindControl<TextBox>("ResponseTtlBox");
            _responseTtlUnitDropdown = this.FindControl<ComboBox>("ResponseTtlUnitDropdown");
            // ----- TTL unit drop-downs ---------------------------------
            if (_instructionTtlUnitDropdown != null && _instructionTtlUnitDropdown.SelectedIndex < 0)
                _instructionTtlUnitDropdown.SelectedIndex = 0;   // Minutes

            if (_responseTtlUnitDropdown != null && _responseTtlUnitDropdown.SelectedIndex < 0)
                _responseTtlUnitDropdown.SelectedIndex = 1;       // Hours
                                                                  // other finds …
            _parametersPanel = this.FindControl<StackPanel>("ParametersPanel");
            _parametersFqdnPanel = this.FindControl<StackPanel>("FqdnParametersPanel");
            _exportFormatComboBox = this.FindControl<ComboBox>("ExportFormatComboBox");
            _manualInstructionIdBox = this.FindControl<TextBox>("ManualInstructionIdBox");
            _fetchExportButton = this.FindControl<Button>("FetchExportButton");
            //            _platformComboBox = this.FindControl<ComboBox>("PlatformComboBox");

            _createJobButton = this.FindControl<Button>("CreateScheduledJobButton");
            _scheduledJobsDataGrid = this.FindControl<DataGrid>("ScheduledJobsDataGrid");

            _platformFqdnTextBox = this.FindControl<TextBox>("PlatformFqdnBox");   // If your XAML TextBox has Name="PlatformFqdnBox"
            _appRegIdTextBox = this.FindControl<TextBox>("AppIdBox");
            _certThumbprintTextBox = this.FindControl<TextBox>("CertThumbprintBox");


            {
                //_logTextBox.Text += "❌ ScheduledJobsListBox is still null. Check x:Name and tab loading.\n";
                return;
            }

            // only once, right here
            _scheduledJobs = new ObservableCollection<ScheduledJob>();

            _logTextBox.Text += $"_fqdnBox is {(_fqdnBox == null ? "null" : "found")}\n";
            _logTextBox.Text += $"_platformFqdnTextBox is {(_platformFqdnTextBox == null ? "null" : "found")}\n";
            _logTextBox.Text += $"_appRegIdTextBox is {(_appRegIdTextBox == null ? "null" : "found")}\n";
            _logTextBox.Text += $"_certThumbprintTextBox is {(_certThumbprintTextBox == null ? "null" : "found")}\n";
            _recurrenceComboBox = this.FindControl<ComboBox>("InstructionRecurrenceComboBox");

            _scheduledJobsDataGrid = this.FindControl<DataGrid>("ScheduledJobsDataGrid");
            if (_scheduledJobsDataGrid == null)
            {
                _logTextBox.Text += "❌ ScheduledJobsDataGrid not found in XAML.\n";
            }
            else
            {
                _logTextBox.Text += "✅ ScheduledJobsDataGrid found.\n";
            }
            // inside AttachEvents  (or OnLoaded / AttachedToVisualTree)



            _startDatePicker = this.FindControl<DatePicker>("StartDatePicker");
            _endDatePicker = this.FindControl<DatePicker>("EndDatePicker");
            _weeklyDayComboBox = this.FindControl<ComboBox>("WeeklyDayComboBox");
            _weeklyRepeatCount = this.FindControl<NumericUpDown>("WeeklyRepeatCount");
            _monthlyRepeatCount = this.FindControl<NumericUpDown>("MonthlyRepeatCount");
            _monthlyDay = this.FindControl<NumericUpDown>("MonthlyDay");


			_instructionExecutor ??= new RealInstructionJobExecutor(_instructionService, job => ResolveTokenForJob(job));



        }


        private void AttachEvents()
        {


            // ───────── search-box throttle ─────────
            _searchBox?.GetObservable(TextBox.TextProperty)
                       .Skip(1)
                       .Throttle(TimeSpan.FromMilliseconds(300))
                       .ObserveOn(AvaloniaScheduler.Instance)
                       .Subscribe(OnSearchTextChanged);



            // ───────── targeting radios ─────────
            if (_fqdnRadio != null) _fqdnRadio.Checked += TargetModeRadio_Checked;
            if (_mgRadio != null) _mgRadio.Checked += TargetModeRadio_Checked;
            if (_coverageRadio != null) _coverageRadio.Checked += TargetModeRadio_Checked;

            // hook preview on check
            _fqdnRadio?.AddHandler(RadioButton.CheckedEvent, async (_, _) => await OnPreviewTargetClicked());
            _mgRadio?.AddHandler(RadioButton.CheckedEvent, async (_, _) => await OnPreviewTargetClicked());
            _coverageRadio?.AddHandler(RadioButton.CheckedEvent, async (_, _) => await OnPreviewTargetClicked());

            // ───────── instruction list & buttons ─────────
            // ───────── instruction list & buttons ─────────
            _instructionListBox?.AddHandler(SelectingItemsControl.SelectionChangedEvent, OnInstructionSelected);

            if (_previewTargetButton != null)
            {
                _previewTargetButton.AddHandler(Button.ClickEvent,
                                                async (_, _) => await OnPreviewTargetClicked());
                _previewTargetButton.IsEnabled = true;
            }


            // ───────── consumer dropdown ─────────
            _consumerDropdown?.AddHandler(ComboBox.SelectionChangedEvent, OnConsumerChanged);

            // (keep the rest of your existing code below as-is, but
            //  replace any this.FindControl<…>() look-ups with the
            //  cached _configTab versions you assigned in HookConfigTabHost)


            if (_managementGroupComboBox != null)
            {
                _managementGroupComboBox.SelectionChanged += async (_, _) => await OnPreviewTargetClicked();
            }

            if (_coverageTagNameComboBox != null)
            {
                _coverageTagNameComboBox.SelectionChanged += async (_, _) => await OnPreviewTargetClicked();
            }

            if (_coverageTagValueComboBox != null)
            {
                _coverageTagValueComboBox.SelectionChanged += async (_, _) => await OnPreviewTargetClicked();
            }

            if (_fqdnTextBox != null)
            {
                // Use GetObservable to watch Text property changes
                _fqdnTextBox.GetObservable(TextBox.TextProperty)
                   .Skip(1)
                   .Throttle(TimeSpan.FromMilliseconds(500))
                   .ObserveOn(AvaloniaScheduler.Instance)  // Use AvaloniaScheduler.Instance instead
                   .Subscribe(async _ => await OnPreviewTargetClicked());
            }
            if (_jobsVm != null && _logTextBox != null)
            {
                _jobsVm.LogMessage += (msg) =>
                {
                    if (_logTextBox != null)
                    {
                        Dispatcher.UIThread.Post(() => _logTextBox.Text += msg + "\n");
                    }
                };
            }
            // ───────── Recurrence Combo (inside AttachEvents) ─────────
            if (_configTab != null)
            {
                _recurrenceComboBox = _configTab.FindControl<ComboBox>("RecurrenceComboBox");
                if (_recurrenceComboBox == null)
                {
                    Log("❌ RecurrenceComboBox not found!");
                }
                else
                {
                    _recurrenceComboBox.SelectionChanged += RecurrenceComboBox_SelectionChanged;
                    Log("✅ RecurrenceComboBox handler attached.");
                }
            }
            else
            {
                Log("ℹ️ _configTab is null in AttachEvents – will wire RecurrenceComboBox in HookConfigTabHost()");
            }



            _platformComboBox = this.FindControl<ComboBox>("PlatformComboBox");
            if (_platformComboBox is null)
            {
                // ConfigTab (and its PlatformComboBox) may not be loaded yet during MainWindow startup.
                // Avoid logging an error here; wiring is handled later when ConfigTab is loaded.
                Log("ℹ️ PlatformComboBox not yet available (ConfigTab not loaded). ");
            }
            else
            {
                _platformComboBox.SelectionChanged += PlatformComboBox_SelectionChanged;
                Log("✅ PlatformComboBox handler attached.");
            }
            // ── Populate Platform dropdown with same list as Platforms config tab ──
            if (_platformComboBox != null)
            {
                var initialPlatforms = ReadPlatformsFromConfig();
                if (initialPlatforms != null && initialPlatforms.Count > 0)
                {
                    _platforms = new ObservableCollection<Platform>(initialPlatforms);
                    RefreshPlatformDropdown(_platforms);
                }
            }



            _recurrenceDayPanel = this.FindControl<StackPanel>("RecurrenceDayPanel");
            _weeklyRepeatRow = this.FindControl<StackPanel>("WeeklyRepeatRow");
            _monthlyPanel = this.FindControl<StackPanel>("MonthlyPanel");
            _monthlyRepeatCount = this.FindControl<NumericUpDown>("MonthlyRepeatCount");
            Debug.WriteLine(_monthlyPanel == null ? "MonthlyPanel NOT found" : "MonthlyPanel OK");






            _chkWeek1 = this.FindControl<CheckBox>("ChkWeek1");
            _chkWeek2 = this.FindControl<CheckBox>("ChkWeek2");
            _chkWeek3 = this.FindControl<CheckBox>("ChkWeek3");
            _chkWeek4 = this.FindControl<CheckBox>("ChkWeek4");
            _chkWeekLast = this.FindControl<CheckBox>("ChkWeekLast");
            _daysOfWeekRow = this.FindControl<StackPanel>("DaysOfWeekRow");
            Log(_daysOfWeekRow == null ? "DaysOfWeekRow NOT found" : "DaysOfWeekRow OK");


            if (_monthlyDay != null)
            {
                // Apply job value or default
                int day = _currentJob?.MonthlyDayFallback ?? 1;
                if (day < 1 || day > 31) day = 1;
                _monthlyDay.Value = day;

                // Final fallback
                if (_monthlyDay.Value is null or < 1 or > 31)
                    _monthlyDay.Value = 1;
            }



            // after HookConfigTabControls() has set _newScheduledJobButton
            if (_newScheduledJobButton != null)
            {
                _newScheduledJobButton.Click += (_, _) =>
                {
                    _jobsVm.SelectedScheduledJob = null;
                    ClearJobEditorForm();  // reset form fields
                    _logTextBox.Text += "🆕 New Job initialized.\n";
                };
            }
            else
            {
                LogHelper.Warn("_newScheduledJobButton is null – check x:Name=\"NewScheduledJobButton\" in ConfigTab.axaml.");
            }


            // Apply defaults or use _currentJob if available
            if (_weeklyRepeatCount != null)
            {
                int weekly = (_currentJob?.WeeklyRepeatCount ?? 0) > 0
                             ? _currentJob!.WeeklyRepeatCount
                             : 1;
                _weeklyRepeatCount.Value = weekly;
            }
            else
            {
                _logTextBox.Text += "⚠️ WeeklyRepeatCount control not found.\n";
            }


            // Monthly repeat
            if (_monthlyRepeatCount != null)
            {
                var monthly = (_currentJob?.MonthlyRepeatCount ?? 0) > 0
                              ? _currentJob!.MonthlyRepeatCount
                              : 1;                // fallback
                _monthlyRepeatCount.Value = monthly;
            }


            if (_createScheduledJobButton != null)
            {
                _createScheduledJobButton.Click += async (_, _) =>
                {
                    try
                    {
                        // If editing an existing job, preserve JobId
                        bool isEdit = _jobsVm.SelectedScheduledJob != null;
                        var jobId = isEdit
                            ? _jobsVm.SelectedScheduledJob!.JobId
                            : Guid.NewGuid().ToString();

                        var paramDict = _configTab.CollectParametersFromPanels()
                            .Where(kvp => kvp.Value != null)
                            .ToDictionary(kvp => kvp.Key, kvp => kvp.Value?.ToString() ?? "");

                        var (method, fqdn, mg, tagName, tagValue) = _configTab.GetTargetingDetails();


                        // TTL values in UI are stored with a unit, but the scheduler expects minutes.
                        var instrTtlValue = int.TryParse(_instructionTtlBox?.Text, out var iTtl) ? iTtl : 10;
                        var instrTtlUnit = (_instructionTtlUnitDropdown?.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Minutes";
                        var instrTtlMinutes = ConvertTtlToMinutes(instrTtlValue, instrTtlUnit);

                        var respTtlValue = int.TryParse(_responseTtlBox?.Text, out var rTtl) ? rTtl : 24;
                        var respTtlUnit = (_responseTtlUnitDropdown?.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Hours";
                        var respTtlMinutes = ConvertTtlToMinutes(respTtlValue, respTtlUnit);

                        // Resolve selected platform for alias/FQDN. Alias is used for export options keys.
                        var selectedPlatform = _configTab?.GetSelectedPlatform();
                        var platformAlias = selectedPlatform?.Alias
                            ?? (isEdit ? _jobsVm.SelectedScheduledJob?.PlatformAlias : null)
                            ?? string.Empty;

                        var platformFqdn = selectedPlatform?.PlatformFqdn
                            ?? (isEdit ? _jobsVm.SelectedScheduledJob?.PlatformFqdn : null)
                            ?? _platformFqdnTextBox?.Text
                            ?? string.Empty;

                        // Export mode/folder mode are per-job selections from the Config tab UI.
                        // Do NOT use the global default when saving a job.
                        var exportMode = _configTab?.GetSelectedExportModeFromUi() ?? ExportMode.PagingOnly;
                        var exportFolderMode = _configTab?.GetSelectedExportFolderModeFromUi() ?? ExportFolderMode.ByInstructionThenDate;

                        var updatedJob = new ScheduledJob
                        {
                            JobId = jobId,
                            InstructionName = _currentInstructionName ?? "Instruction",
                            InstructionId = _currentInstructionId,

                            // TTLs (minutes are what the scheduler uses)
                            InstructionTtlMinutes = instrTtlMinutes,
                            InstructionTtlUnit = instrTtlUnit,
                            ResponseTtlMinutes = respTtlMinutes,
                            ResponseTtlUnit = respTtlUnit,

                            // Recurrence
                            Recurrence = (_recurrenceComboBox.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Once",
                            DaysOfWeek = GetSelectedDaysOfWeek(),
                            WeeklyRepeatCount = (int)(_weeklyRepeatCount?.Value ?? 1),
                            MonthlyRepeatCount = (int)(_monthlyRepeatCount?.Value ?? 1),
                            MonthlyDayFallback = (int)(_monthlyDay?.Value ?? 1),
                            MonthlyWeekOffsets = GetSelectedMonthlyWeekOffsets(),

                            // Schedule
                            StartDate = GetCalendarDate(_startDatePicker?.SelectedDate),
                            EndDate = GetCalendarDate(_endDatePicker?.SelectedDate),
                            StartTime = _startTimePicker?.SelectedTime,

                            // Targeting / Auth / Export
                            TargetingMethod = method,
                            TargetingFqdn = fqdn,
                            TargetingManagementGroup = mg,
                            CoverageTagName = tagName,
                            CoverageTagValue = tagValue,

                            PlatformAlias = platformAlias,
                            PlatformFqdn = platformFqdn,

                            AppRegistrationId = _appRegIdTextBox?.Text ?? "",
                            CertThumbprint = _certThumbprintTextBox?.Text ?? "",
                            ExportFormat = _exportFormatComboBox?.SelectedItem?.ToString() ?? "CSV",
                            Consumer = _consumerDropdown?.SelectedItem?.ToString() ?? "Explorer",
                            AuthenticationMode = _authModeComboBox?.SelectedItem?.ToString() ?? "",

                            // Export behavior
                            EnableExport = isEdit ? (_jobsVm.SelectedScheduledJob?.EnableExport ?? true) : true,
                            ExportTtlMinutes = respTtlMinutes,
                            ExportMode = exportMode,
                            ExportFolderMode = exportFolderMode,

                            Parameters = paramDict
                        };

                        LogHelper.Info($"JOB SAVE DEBUG: exportMode={updatedJob.ExportMode} folderMode={updatedJob.ExportFolderMode} alias='{updatedJob.PlatformAlias}' fqdn='{updatedJob.PlatformFqdn}'");

                        _jobsVm.SelectedScheduledJob = updatedJob;
                        await _jobsVm.CreateJobAsync();  // handles create vs update internally
                        RefreshScheduledJobs();

                        _logTextBox.Text += $"✅ Job “{updatedJob.InstructionName}” {(isEdit ? "updated" : "created")}.\n";
                    }
                    catch (Exception ex)
                    {
                        _logTextBox.Text += $"❌ Failed to create/update job: {ex.Message}\n";
                    }
                };
            }

            //  The executor that actually runs an instruction.
			_instructionExecutor ??= new RealInstructionJobExecutor(_instructionService, job => ResolveTokenForJob(job));


        }

        // ───────────────────────────── OnMainWindowOpened() ─────────────────────────────
        private void OnMainWindowOpened(object? sender, EventArgs e)
        {
            // Optional fallback startup logic — usually not needed unless you delay init
            //_scheduler ??= new JobSchedulerService(_jobsVm, _instructionExecutor);
        }

        private void OnHistoryUtcToggleChanged(bool useUtc)
        {
            try
            {
                _config.UseUtcTimestamps = useUtc;
                LogHelper.UseUtc = useUtc;
                try { new ConfigHelper().Save(_config); } catch { /* ignore */ }

                _scheduler?.SetUseUtcTimestamps(useUtc);
                _jobScheduler?.SetUseUtcTimestamps(useUtc);
                _jobSchedulerService?.SetUseUtcTimestamps(useUtc);

                ApplyHistoryTimeColumnVisibility(useUtc);
            }
            catch
            {
                // Non-fatal
            }
        }

        private void ApplyHistoryTimeColumnVisibility(bool showUtc)
        {
            try
            {
                var grid = this.FindControl<Avalonia.Controls.DataGrid>("HistoryGrid");
                if (grid == null)
                    return;

                foreach (var col in grid.Columns)
                {
                    var header = col.Header?.ToString() ?? "";

                    // Treat these as time columns we can toggle.
                    bool isUtc = header.Contains("(UTC)", StringComparison.OrdinalIgnoreCase) || header.Contains("UTC", StringComparison.OrdinalIgnoreCase);
                    bool isLocal = header.Contains("Local", StringComparison.OrdinalIgnoreCase);

                    if (isUtc)
                        col.IsVisible = showUtc;
                    else if (isLocal)
                        col.IsVisible = !showUtc;
                }
            }
            catch
            {
                // Non-fatal
            }
        }


        private async Task EnsureFirstRunSetupAsync()
        {
            try
            {
                var platforms = _config?.Platforms ?? new List<PlatformSettings>();

                bool hasConfiguredPlatform =
                    platforms.Any(p =>
                        p != null &&
                        !string.IsNullOrWhiteSpace(p.Alias) &&
                        !string.IsNullOrWhiteSpace(p.PlatformFqdn) &&
                        !string.Equals(p.Alias.Trim(), "PH", StringComparison.OrdinalIgnoreCase) &&
                        !p.Alias.Contains("placeholder", StringComparison.OrdinalIgnoreCase));

                var defaultAlias = (_config?.DefaultPlatformAlias ?? string.Empty).Trim();

                bool hasValidDefault =
                    !string.IsNullOrWhiteSpace(defaultAlias) &&
                    platforms.Any(p =>
                        p != null &&
                        !string.IsNullOrWhiteSpace(p.Alias) &&
                        string.Equals(p.Alias.Trim(), defaultAlias, StringComparison.OrdinalIgnoreCase));

                if (hasConfiguredPlatform && hasValidDefault)
                    return;
                // If we have at least one real platform but no valid default, pick the first real platform
                // and persist it as the default. This avoids incorrectly forcing the user into the placeholder flow.
                if (hasConfiguredPlatform && !hasValidDefault && _config != null)
                {
                    var firstReal = platforms.FirstOrDefault(p =>
                        p != null &&
                        !string.IsNullOrWhiteSpace(p.Alias) &&
                        !string.IsNullOrWhiteSpace(p.PlatformFqdn) &&
                        !string.Equals(p.Alias.Trim(), "PH", StringComparison.OrdinalIgnoreCase) &&
                        !p.Alias.Contains("placeholder", StringComparison.OrdinalIgnoreCase));

                    if (firstReal != null && !string.IsNullOrWhiteSpace(firstReal.Alias))
                    {
                        _config.DefaultPlatformAlias = firstReal.Alias.Trim();
                        try { new ConfigHelper().Save(_config); } catch { /* ignore */ }
                        LogHelper.Info($"✅ Default platform alias was missing/invalid. Set to '{_config.DefaultPlatformAlias}'.");
                        return;
                    }
                }



                // Assume local time by default.
                if (_config != null)
                    _config.UseUtcTimestamps = false;
                LogHelper.UseUtc = false;

                await Dispatcher.UIThread.InvokeAsync(() =>
                {
                    try
                    {
                        var mainTabs = this.FindControl<TabControl>("MainTabControl");
                        if (mainTabs != null)
                        {
                            var configTabItem = this.FindControl<TabItem>("ConfigTabItem");
                            if (configTabItem != null)
                                mainTabs.SelectedItem = configTabItem;
                            else
                                mainTabs.SelectedIndex = Math.Min(2, mainTabs.ItemCount - 1);
                        }

                        _configTab?.SwitchToPlatformTab("⚠️ First run: edit the placeholder platform (do NOT click Add).");
                        _configTab?.RefreshPlatformsTabFromConfig("PH"); // deterministic placeholder

                    }
                    catch
                    {
                        // non-fatal
                    }
                });
            }
            catch
            {
                // non-fatal
            }
        }






        private static DateTime? GetCalendarDate(object? boxed)
        {
            // Avalonia 11 – SelectedDate is DateTime?
            if (boxed is DateTime dt)
                return dt.Date;

            // Avalonia 0.10 / 0.11 – SelectedDate is DateTimeOffset?
            if (boxed is DateTimeOffset dto)
                return dto.Date;

            return null;   // picker cleared or not set
        }

        public ICommand RefreshCommand { get; }




        /// <summary>
        /// Creates the correct input row for one parameter (label + editor).
        /// </summary>
        // ─────────────────────────────────────────────────────────────
        // EXISTING METHOD – keeps working for ParameterDefinition
        // ─────────────────────────────────────────────────────────────
        private Control BuildParameterRow(ParameterDefinition p)
        {
            var row = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };

            // label
            var lbl = new TextBlock
            {
                Text = p.DisplayName + ":",
                Width = 170,
                VerticalAlignment = Avalonia.Layout.VerticalAlignment.Center
            };

            // editor (ComboBox if choices, else TextBox)
            Control editor;
            if (p.AllowedValues is { Count: > 0 })
            {
                editor = new ComboBox
                {
                    ItemsSource = p.AllowedValues,
                    SelectedIndex = 0,
                    Width = 250,
                    Tag = p.Name         // used later when gathering values
                };
            }
            else
            {
                editor = new TextBox
                {
                    Width = 250,
                    Tag = p.Name
                };
            }

            row.Children.Add(lbl);
            row.Children.Add(editor);
            return row;
        }

        // ─────────────────────────────────────────────────────────────
        // NEW OVERLOAD – handles Parameter (fixes the compile error)
        // ─────────────────────────────────────────────────────────────
        private Control BuildParameterRow(Parameter p)
        {
            // If Parameter *inherits* from ParameterDefinition you could just cast:
            //     return BuildParameterRow((ParameterDefinition)p);
            // …but if it doesn't, map the fields manually as below.
            var proxy = new ParameterDefinition
            {
                Name = p.Name,
                DisplayName = p.DisplayName ?? p.Name,
                AllowedValues = p.AllowedValues
            };

            return BuildParameterRow(proxy);
        }




        // ──────────────────────────────────────────────────────────────────────────────
        //  Keep / reuse token on platform change
        // ──────────────────────────────────────────────────────────────────────────────

        private string? _pendingJobType = null;

        private async void PlatformComboBox_SelectionChanged(object? sender, SelectionChangedEventArgs e)
        {
            if (_platformComboBox?.SelectedItem is not Platform selectedPlatform)
            {
                _logTextBox.Text += "⚠️ Platform selection is null or invalid.\n";
                return;
            }

            _platformComboBox.SelectionChanged -= PlatformComboBox_SelectionChanged;

            ShowLoadingIndicator("🔄 Switching platform and loading data...");

            try
            {
                // ── 1. Sync internal state ──────────────────────────────
                _fqdn = selectedPlatform.PlatformFqdn;
                _platformUrl = selectedPlatform.PlatformFqdn;
                _consumerName = string.IsNullOrWhiteSpace(selectedPlatform.DefaultConsumer)
                                    ? "Explorer"
                                    : selectedPlatform.DefaultConsumer;

                // Build a normalized platform config object for downstream services/logging.
                // (Some platform objects used in dropdowns may have Alias/UserId blank depending on where they came from.)
                _selectedPlatform = new TV1_InstructionOffloader.Models.PlatformConfigData
                {
                    PlatformFqdn = selectedPlatform.PlatformFqdn,
                    AppId = selectedPlatform.AppId,
                    CertThumbprint = selectedPlatform.CertThumbprint,
                    UseCert = selectedPlatform.UseCert,
                    Alias = selectedPlatform.Alias ?? string.Empty,
                    GroupName = selectedPlatform.GroupName ?? string.Empty,
                    IsDefault = selectedPlatform.IsDefault,
                    UserId = selectedPlatform.UserId ?? string.Empty
                };

                _platformFqdnTextBox?.SetCurrentValue(TextBox.TextProperty, selectedPlatform.PlatformFqdn);
                _appRegIdTextBox?.SetCurrentValue(TextBox.TextProperty, selectedPlatform.AppId);
                _certThumbprintTextBox?.SetCurrentValue(TextBox.TextProperty, selectedPlatform.CertThumbprint);
                _consumerDropdown?.SetCurrentValue(ComboBox.SelectedItemProperty, _consumerName);
                _configTabControl?.SetPlatform(selectedPlatform);

                _logTextBox.Text += $"🔄 Platform switched to: {_platformUrl}\n";

                // IMPORTANT: The dropdown Platform items may not always carry hidden fields (e.g., UserId/UPN),
                // and some older mapping paths left Alias blank while still showing a GroupName.
                // Resolve a stable Alias + optional UserId from config by FQDN so cert auth can use it.
                string resolvedAlias = !string.IsNullOrWhiteSpace(selectedPlatform.Alias)
                    ? selectedPlatform.Alias
                    : (!string.IsNullOrWhiteSpace(selectedPlatform.GroupName)
                        ? selectedPlatform.GroupName
                        : selectedPlatform.PlatformFqdn);

                string? resolvedUserId = !string.IsNullOrWhiteSpace(selectedPlatform.UserId) ? selectedPlatform.UserId : null;
                if (string.IsNullOrWhiteSpace(resolvedUserId))
                {
                    try
                    {
                        var ch = new ConfigHelper();
                        var cfg = ch.Load();
                        var match = cfg.Platforms
                            .FirstOrDefault(p => string.Equals(p.PlatformFqdn, selectedPlatform.PlatformFqdn, StringComparison.OrdinalIgnoreCase));

                        // TEMP DEBUG: confirm we are reading the expected config and whether it contains UserId.
                        _logTextBox.Text += $"🧪 CONFIG DEBUG: Path = {ch.ConfigPath}\n";
                        _logTextBox.Text += $"🧪 CONFIG DEBUG: Platforms = {(cfg.Platforms?.Count ?? 0)}\n";
                        _logTextBox.Text += $"🧪 CONFIG DEBUG: Match.UserId = {(string.IsNullOrWhiteSpace(match?.UserId) ? "(none)" : match!.UserId)}\n";

                        resolvedUserId = string.IsNullOrWhiteSpace(match?.UserId) ? null : match!.UserId;
                    }
                    catch (Exception ex)
                    {
                        _logTextBox.Text += $"🧪 CONFIG DEBUG: Failed reading config for UserId: {ex.Message}\n";
                        resolvedUserId = null;
                    }
                }

                var platformSettings = new PlatformSettings
                {
                    Alias = string.IsNullOrWhiteSpace(resolvedAlias) ? null : resolvedAlias,
                    PlatformFqdn = selectedPlatform.PlatformFqdn,
                    AppId = selectedPlatform.AppId,
                    CertThumbprint = selectedPlatform.CertThumbprint,
                    UseCert = selectedPlatform.UseCert,
                    UserId = resolvedUserId
                };

                if (platformSettings.UseCert && string.IsNullOrWhiteSpace(platformSettings.UserId))
                {
                    LogHelper.Info("...... Certificate auth requires a UPN/UserId for this platform. Skipping automatic authentication.");
                    return;
                }

                // TEMP DEBUG: show which auth inputs are being used (UPN is optional).
                var thumb = platformSettings.CertThumbprint ?? "";
                var thumbMasked = string.IsNullOrWhiteSpace(thumb)
                    ? "(missing)"
                    : (thumb.Length > 6 ? new string('*', thumb.Length - 6) + thumb[^6..] : thumb);
                _logTextBox.Text += "🧪 AUTH DEBUG\n";
                _logTextBox.Text += $"   Alias       = {(string.IsNullOrWhiteSpace(platformSettings.Alias) ? "(no-alias)" : platformSettings.Alias)}\n";
                _logTextBox.Text += $"   PlatformFqdn = {platformSettings.PlatformFqdn}\n";
                _logTextBox.Text += $"   UseCert      = {platformSettings.UseCert}\n";
                _logTextBox.Text += $"   AppId        = {(string.IsNullOrWhiteSpace(platformSettings.AppId) ? "(missing)" : platformSettings.AppId)}\n";
                _logTextBox.Text += $"   Thumbprint   = {thumbMasked}\n";
                _logTextBox.Text += $"   UserId/UPN   = {(string.IsNullOrWhiteSpace(platformSettings.UserId) ? "(none)" : platformSettings.UserId)}\n";

                _logTextBox.Text += "🔐 Starting authentication...\n";
                var authResult = await _authService.AuthenticateAsync(platformSettings);
                if (string.IsNullOrWhiteSpace(authResult?.Token))
                {
                    var reason = string.IsNullOrWhiteSpace(authResult?.FailureReason) ? "(no details)" : authResult!.FailureReason;
                    _logTextBox.Text += $"❌ Authentication failed. Cannot load platform data. Reason: {reason}\n";
                    return;
                }

                _token = authResult.Token;

				// Ensure MainWindow and downstream callers always see the same token.
				try
				{
					_tokenStoreService?.StoreToken(_platformUrl, _token);
					if (!string.IsNullOrWhiteSpace(_platformUrl))
						_tokenMap[_platformUrl] = _token;
				}
				catch
				{
					// Ignore persistence/cache failures; token is still held in memory.
				}

				try
				{
					_fetcher = new InstructionFetcherService(_platformUrl, _token);
				}
				catch
				{
					// Don't let fetcher init failures block platform load.
				}

                // Keep ConfigTab in sync (preview targets, device search suggestions, consumer/MG loading).
                _configTab?.SetAuthContext(_platformUrl, _token);

                if (!string.IsNullOrWhiteSpace(_token) && _token.Length >= 6)
                {
                    string suffix = _token.Substring(_token.Length - 6);
                    LogHelper.Info($"🔐 Using token for {_platformUrl} ending in: ...{suffix}");
                }

                _logTextBox.Text += $"✅ Authenticated as: {authResult.PrincipalName}\n";

                var expiry = _authService.GetTokenExpirationTime();
                if (expiry.HasValue)
                    _logTextBox.Text += $"🕒 Token expires at: {expiry.Value:t}\n";

                // ── 2. Load platform-dependent data ─────────────────────
                await _instructionHelper.LoadManagementGroupsAsync(_platformUrl, _token, _mgDropdown, _logTextBox);
                await _instructionHelper.LoadCustomPropertiesAsync(_platformUrl, _token, _coverageTagNameDropdown, _coverageTagValueDropdown, _logTextBox);
                await OnLoadConsumersAsync();
                // Refresh Automations
                var automationTab = this.FindControl<AutomationTab>("AutomationTabHost");
                if (automationTab != null)
                {
                    await automationTab.LoadPoliciesAsync();
                    LogHelper.Info("🤖 Refreshed automations (policies).");
                }

                _allInstructions = await _instructionHelper.LoadInstructionsAsync(_platformUrl, _token, _logTextBox);
                _configTab?.SetInstructions(_allInstructions);

                _instructionListBox.SelectionChanged -= InstructionListBox_SelectionChanged;
                _instructionListBox.SelectionChanged += InstructionListBox_SelectionChanged;

                _logTextBox.Text += "✅ Platform data refreshed.\n";

                // ── 3. Navigate to correct tab based on job type ────────
                if (_pendingJobType == "Automation")
                {
                    //     _tabControl.SelectedIndex = 1; // assuming index 1 is AutomationTab
                    _logTextBox.Text += "🔁 Navigated to AutomationTab.\n";
                }
                else
                {
                    //  _tabControl.SelectedIndex = 0; // ConfigTab default
                    _logTextBox.Text += "🔁 Navigated to ConfigTab.\n";
                }

                _pendingJobType = null;
            }
            catch (Exception ex)
            {
                _logTextBox.Text += $"❌ Error during platform switch: {ex.Message}\n";
            }
            finally
            {
                _platformComboBox.SelectionChanged += PlatformComboBox_SelectionChanged;
                HideLoadingIndicator();
            }
        }





        private void InstructionListBox_SelectionChanged(object? sender, SelectionChangedEventArgs e)
        {
            if (_instructionListBox.SelectedItem is InstructionDefinition def)
            {
                _selectedInstruction = def;
                Log($"📌 Instruction selected: {def.Name}");
            }
        }

        private async Task<T?> RetryFindControl<T>(string name, int retries = 5, int delayMs = 100) where T : Control
        {
            for (int i = 0; i < retries; i++)
            {
                var control = this.FindControl<T>(name);
                if (control != null)
                    return control;

                await Task.Delay(delayMs);
            }

            LogHelper.Warn($"⚠️ Control '{name}' not found after {retries} retries.");
            return null;
        }


        private void OnJobsLoaded()
{
    if (_jobsVm == null)
        return;

    _instructionExecutor ??= new RealInstructionJobExecutor(_instructionService, job => ResolveTokenForJob(job));

    if (_scheduler == null)
    {
        LogHelper.Info("STARTING TIMERS");
        _scheduler = new JobSchedulerService(_jobsVm, _instructionService, _instructionExecutor, _authService);

        if (_configTab != null)
        {
            _configTab.SetJobScheduler(_jobsVm, _scheduler);
        }
        else
        {
            // ConfigTab may not be loaded yet; HookConfigTabControls will attach the scheduler when available.
            LogHelper.Info("ℹ️ ConfigTab not loaded yet in OnJobsLoaded; deferring SetJobScheduler.");
        }

        _scheduler.LogInitialSchedule();
    }

    // Always refresh the scheduler's job list after any load/save.
    // This fixes first-run behavior where no jobs file exists at startup, and ensures newly-created jobs run
    // without requiring an app restart.
    _scheduler.Start(_jobsVm.ScheduledJobs.ToList());
    _schedulerStarted = true;


            _scheduler.LogInitialSchedule();

            if (!_schedulerStarted)
            {
                _schedulerStarted = true;
                _scheduler.Start(_jobsVm.ScheduledJobs.ToList());
            }
        }

        private async Task OnAuthenticateButtonClicked()
        {
            _logTextBox.Text += "🔐 Authenticate button clicked…\n";

            try
            {
                // 1️⃣  Reload appsettings for defaults
                var configHelper = new ConfigHelper();
                _config = configHelper.Load();

                // 2️⃣  Resolve the platform URL in this order:
                //     a  What the user typed in the FQDN TextBox
                //     b  The platform selected in the drop-down
                //     c  The first platform in appsettings
                string platformUrl = _fqdnBox?.Text?.Trim();
                LogHelper.Info($"🔍 Checking _fqdnBox: {(string.IsNullOrWhiteSpace(platformUrl) ? "empty" : platformUrl)}");

                if (string.IsNullOrWhiteSpace(platformUrl))
                {
                    platformUrl = (_platformDropdown?.SelectedItem as Platform)?.PlatformFqdn;
                    LogHelper.Info($"🔍 Checking _platformDropdown: {(string.IsNullOrWhiteSpace(platformUrl) ? "empty" : platformUrl)}");
                }

                if (string.IsNullOrWhiteSpace(platformUrl))
                {
                    platformUrl = _config?.DefaultPlatformAlias?.Trim();
                    LogHelper.Info($"🔍 Checking _config.DefaultPlatformAlias: {(string.IsNullOrWhiteSpace(platformUrl) ? "empty" : platformUrl)}");

                    if (!string.IsNullOrWhiteSpace(platformUrl))
                    {
                        var match = _config?.Platforms?

                            .FirstOrDefault(p => string.Equals(p.PlatformFqdn?.Trim(), platformUrl, StringComparison.OrdinalIgnoreCase));

                        if (match != null)
                        {
                            platformUrl = match.PlatformFqdn;
                            LogHelper.Info($"✅ Matched platform from config: {platformUrl}");
                        }
                        else
                        {
                            LogHelper.Warn($"⚠️ No matching platform found for alias: {platformUrl}");
                        }
                    }
                }


                if (string.IsNullOrWhiteSpace(platformUrl))
                {
                    _logTextBox.Text += "❌ No platform URL specified.\n";
                    return;
                }

                // 3️⃣  Build the auth settings object
                var settings = new TV1_InstructionOffloader.Models.PlatformSettings
                {
                    PlatformFqdn = platformUrl,
                    AppId = _appRegIdTextBox?.Text?.Trim()
                                      ?? (_platformDropdown?.SelectedItem as Platform)?.AppId
                                      ?? "",
                    CertThumbprint = _certThumbprintTextBox?.Text?.Trim()
                                      ?? (_platformDropdown?.SelectedItem as Platform)?.CertThumbprint
                                      ?? "",
                    UseCert = _authCertRadio?.IsChecked == true,
                    AuthenticationMode = (_authModeComboBox?.SelectedItem as ComboBoxItem)
                                         ?.Content?.ToString() ?? ""
                };

                // 4️⃣  Call the authentication service
                var authResult = await _authService.AuthenticateAsync(settings);
                if (string.IsNullOrWhiteSpace(authResult?.Token))
                {
                    Log("❌ Authentication failed — aborting platform switch.");
                    return;
                }

                _token = authResult.Token;
                _configTab?.SetAuthContext(_platformUrl, _token);
                LoggedInUserDisplay = $"User: {authResult.PrincipalName}";
                SelectedPlatformDisplay = $"Server: {SelectedPlatformDisplay}";
                Log("✅ Authenticated and token cached.");

            }
            catch (Exception ex)
            {
                _logTextBox.Text += $"❌ Authentication error: {ex.Message}\n";
            }


        }

        private void ClearJobEditorForm()
        {
            // ───── TTLs ─────
            if (_instructionTtlBox != null) _instructionTtlBox.Text = "10";
            _instructionTtlUnitDropdown?.SetCurrentValue(ComboBox.SelectedIndexProperty, 0);

            if (_responseTtlBox != null) _responseTtlBox.Text = "24";
            _responseTtlUnitDropdown?.SetCurrentValue(ComboBox.SelectedIndexProperty, 1);

            // ───── Recurrence ─────
            _recurrenceComboBox?.SetCurrentValue(ComboBox.SelectedIndexProperty, 0);

            _weeklyRepeatCount?.SetCurrentValue(NumericUpDown.ValueProperty, 1);
            _monthlyRepeatCount?.SetCurrentValue(NumericUpDown.ValueProperty, 1);
            _monthlyDay?.SetCurrentValue(NumericUpDown.ValueProperty, 1);

            // ───── Calendar ─────
            _startDatePicker?.SetCurrentValue(DatePicker.SelectedDateProperty, null);
            _endDatePicker?.SetCurrentValue(DatePicker.SelectedDateProperty, null);
            _startTimePicker?.SetCurrentValue(TimePicker.SelectedTimeProperty, null);

            // ───── Text boxes / dropdowns ─────
            if (_platformFqdnTextBox != null) _platformFqdnTextBox.Text = "";
            if (_appRegIdTextBox != null) _appRegIdTextBox.Text = "";
            if (_certThumbprintTextBox != null) _certThumbprintTextBox.Text = "";

            _exportFormatComboBox?.SetCurrentValue(ComboBox.SelectedIndexProperty, 0);
            _consumerDropdown?.SetCurrentValue(ComboBox.SelectedIndexProperty, 0);

            // ───── Day-of-week checkboxes ─────
            ResetDayOfWeekCheckboxes();
        }



        private void ResetDayOfWeekCheckboxes()
        {
            string[] cbNames = { "ChkMon", "ChkTue", "ChkWed",
                         "ChkThu", "ChkFri", "ChkSat", "ChkSun" };

            foreach (var name in cbNames)
            {
                var cb = this.FindControl<CheckBox>(name);
                if (cb != null)
                    cb.IsChecked = false;   // safely reset
            }
        }




        public ObservableCollection<ScheduledJob> ScheduledJobs => ScheduledJobsVM?.ScheduledJobs;
        public ScheduledJob SelectedScheduledJob
        {
            get => ScheduledJobsVM?.SelectedScheduledJob;
            set
            {
                if (ScheduledJobsVM != null)
                {
                    ScheduledJobsVM.SelectedScheduledJob = value;
                    OnPropertyChanged(nameof(SelectedScheduledJob));
                }
            }
        }





        private void RecurrenceComboBox_SelectionChanged(object? sender, SelectionChangedEventArgs e)
        {
            if (sender is not ComboBox cb || cb.SelectedItem is not ComboBoxItem item) return;

            string mode = item.Content?.ToString() ?? "Once";
            Log($"📅 Recurrence changed to: {mode}");

            // 🔁 Reset all rows/panels
            _recurrenceDayPanel.IsVisible = false;
            _weeklyRepeatRow.IsVisible = false;
            _monthlyPanel.IsVisible = false;
            _daysOfWeekRow.IsVisible = false;

            switch (mode)
            {
                case "Daily":
                    _recurrenceDayPanel.IsVisible = true;
                    _daysOfWeekRow.IsVisible = true;
                    break;

                case "Weekly":
                    _recurrenceDayPanel.IsVisible = true;
                    _weeklyRepeatRow.IsVisible = true;
                    _daysOfWeekRow.IsVisible = true;
                    break;

                case "Monthly":
                    _recurrenceDayPanel.IsVisible = true;
                    _monthlyPanel.IsVisible = true;
                    _daysOfWeekRow.IsVisible = true;
                    break;

                case "Hourly":          // ← NEW
                case "Every 15 Min":    // ← NEW (label it however you like)
                                        // no extra UI needed
                    break;

                    // "Once" → nothing shown
            }
        }


        private void AttachDayCheckboxLogging()
        {
            void Wire(string name)
            {
                var cb = this.FindControl<CheckBox>(name);
                if (cb == null)
                {
                    LogHelper.Debug($"⚠️ Day checkbox '{name}' not found.\n");
                    return;
                }
                cb.Checked += DayCheckboxChanged;
                cb.Unchecked += DayCheckboxChanged;
            }

            // names must match x:Name in XAML
            Wire("ChkMon");
            Wire("ChkTue");
            Wire("ChkWed");
            Wire("ChkThu");
            Wire("ChkFri");
            Wire("ChkSat");
            Wire("ChkSun");
        }


        private void DayCheckboxChanged(object? sender, RoutedEventArgs e)
        {
            Log("Day-checkbox change → " +
                (GetSelectedDaysOfWeek().Any()
                    ? string.Join(", ", GetSelectedDaysOfWeek())
                    : "None selected"));
        }


        private List<int> GetSelectedMonthlyWeekOffsets()
        {
            var weeks = new List<int>();
            if (_chkWeek1.IsChecked == true) weeks.Add(1);
            if (_chkWeek2.IsChecked == true) weeks.Add(2);
            if (_chkWeek3.IsChecked == true) weeks.Add(3);
            if (_chkWeek4.IsChecked == true) weeks.Add(4);
            if (_chkWeekLast.IsChecked == true) weeks.Add(-1);   // use -1 to mean "Last"
            return weeks;
        }

        private List<DayOfWeek> GetSelectedDaysOfWeek()
        {
            var list = new List<DayOfWeek>();

            // Always query the live visual tree
            var row = this.FindControl<StackPanel>("DaysOfWeekRow");
            if (row == null) return list;

            foreach (var cb in row.Children.OfType<CheckBox>())
            {
                if (cb.IsChecked != true) continue;

                switch (cb.Content?.ToString())
                {
                    case "Mon": list.Add(DayOfWeek.Monday); break;
                    case "Tue": list.Add(DayOfWeek.Tuesday); break;
                    case "Wed": list.Add(DayOfWeek.Wednesday); break;
                    case "Thu": list.Add(DayOfWeek.Thursday); break;
                    case "Fri": list.Add(DayOfWeek.Friday); break;
                    case "Sat": list.Add(DayOfWeek.Saturday); break;
                    case "Sun": list.Add(DayOfWeek.Sunday); break;
                }
            }
            return list;
        }



        /// Push all fields from a ScheduledJob into the Instructions tab UI.
        private void PopulateInstructionsTab(ScheduledJob job)
        {
            // ───────── Platform / auth ─────────
            _platformFqdnTextBox?.SetCurrentValue(TextBox.TextProperty, job.PlatformFqdn ?? "");


            var selectedPlatform = _platforms.FirstOrDefault(p => p.PlatformFqdn.Equals(job.PlatformFqdn, StringComparison.OrdinalIgnoreCase));
            if (selectedPlatform != null)
            {
                var platformSettings = new PlatformSettings
                {
                    PlatformFqdn = selectedPlatform.PlatformFqdn,
                    AppId = selectedPlatform.AppId,
                    CertThumbprint = selectedPlatform.CertThumbprint,
                    UseCert = selectedPlatform.UseCert
                };

                Dispatcher.UIThread.Post(async () =>
                {
                    var platformSettings = new PlatformSettings
                    {
                        PlatformFqdn = selectedPlatform.PlatformFqdn,
                        AppId = selectedPlatform.AppId,
                        CertThumbprint = selectedPlatform.CertThumbprint,
                        UseCert = selectedPlatform.UseCert
                    };

                    var authResult = await _authService.AuthenticateAsync(platformSettings, forceReauth: true);
                    if (!string.IsNullOrEmpty(authResult.Token))
                    {
                        _fqdn = platformSettings.PlatformFqdn;
                        _token = authResult.Token;

                        _configTab?.SetAuthContext(_fqdn, _token);

                        await OnLoadConsumersAsync();
                        _allInstructions = await _instructionHelper.LoadInstructionsAsync(_fqdn, _token, _logTextBox);
                        if (_instructionListBox != null)

                            await _instructionHelper.LoadManagementGroupsAsync(_fqdn, _token, _mgDropdown, _logTextBox);
                        await _instructionHelper.LoadCustomPropertiesAsync(_fqdn, _token, _coverageTagNameDropdown, _coverageTagValueDropdown, _logTextBox);

                        _configTab?.SetInstructions(_allInstructions);
                        // Refresh Automations
                        var automationTab = this.FindControl<AutomationTab>("AutomationTabHost");
                        if (automationTab != null)
                        {
                            await automationTab.LoadPoliciesAsync();
                            LogHelper.Info("🤖 Refreshed automations (policies).");
                        }

                    }

                    else
                    {
                        LogHelper.Info($"❌ Failed to authenticate platform {platformSettings.PlatformFqdn}.");
                    }
                });

            }
            else
            {
                LogHelper.Info($"⚠️ No matching platform found for {job.PlatformFqdn}.");
            }


            _appRegIdTextBox?.SetCurrentValue(TextBox.TextProperty, job.AppRegistrationId ?? "");
            _certThumbprintTextBox?.SetCurrentValue(TextBox.TextProperty, job.CertThumbprint ?? "");

            // ───────── Instruction selection ─────────
            if (_instructionListBox != null && !string.IsNullOrEmpty(job.InstructionName))
            {
                var match = _instructionListBox.Items
                                                .Cast<InstructionDefinition>()
                                                .FirstOrDefault(i => i.Name == job.InstructionName);

                if (match != null)
                {
                    _instructionListBox.SelectedItem = match;

                    if (_parametersPanel != null)
                    {
                        RenderParameters(_parametersPanel, match.Parameters);
                        if (job.Parameters is { Count: > 0 })
                            RehydrateParameters(_parametersPanel, job.Parameters);
                    }
                }
            }

            // ───────── TTLs ─────────
            _instructionTtlBox?.SetCurrentValue(TextBox.TextProperty, job.InstructionTtlMinutes.ToString());
            SetComboBoxSelectionByContent(_instructionTtlUnitDropdown, job.InstructionTtlUnit ?? "Minutes");

            _responseTtlBox?.SetCurrentValue(TextBox.TextProperty, job.ResponseTtlMinutes.ToString());
            SetComboBoxSelectionByContent(_responseTtlUnitDropdown, job.ResponseTtlUnit ?? "Hours");

            // ───────── Targeting mode ─────────
            SetComboBoxSelectionByContent(_targetingModeComboBox, job.TargetingMethod ?? "FQDN");
            if (_fqdnRadio != null) _fqdnRadio.IsChecked = job.TargetingMethod == "FQDN";
            if (_mgRadio != null) _mgRadio.IsChecked = job.TargetingMethod == "MG";
            if (_coverageRadio != null) _coverageRadio.IsChecked = job.TargetingMethod == "Tag";
            _fqdnBox?.SetCurrentValue(TextBox.TextProperty, job.PlatformFqdn ?? "");

            // ───────── Export / consumer ─────────
            SetComboBoxSelectionByContent(_exportFormatComboBox, job.ExportFormat ?? "CSV");
            SetComboBoxSelectionByContent(_consumerDropdown, job.Consumer ?? "Explorer");

            // ───────── Dates / times ─────────
            _startDatePicker?.SetCurrentValue(DatePicker.SelectedDateProperty, job.StartDate);
            _endDatePicker?.SetCurrentValue(DatePicker.SelectedDateProperty, job.EndDate);
            _startTimePicker?.SetCurrentValue(TimePicker.SelectedTimeProperty, job.StartTime ?? new TimeSpan(9, 0, 0));

            // ───────── Recurrence layout ─────────
            SetComboBoxSelectionByContent(_recurrenceComboBox, job.Recurrence ?? "Once");

            _recurrenceDayPanel?.SetCurrentValue(StackPanel.IsVisibleProperty, false);
            _weeklyRepeatRow?.SetCurrentValue(StackPanel.IsVisibleProperty, false);
            _monthlyPanel?.SetCurrentValue(StackPanel.IsVisibleProperty, false);
            _monthlyRepeatCount?.SetCurrentValue(NumericUpDown.IsVisibleProperty, false);

            switch (job.Recurrence)
            {
                case "Daily":
                    _recurrenceDayPanel?.SetCurrentValue(StackPanel.IsVisibleProperty, true);
                    break;

                case "Weekly":
                    _recurrenceDayPanel?.SetCurrentValue(StackPanel.IsVisibleProperty, true);
                    _weeklyRepeatRow?.SetCurrentValue(StackPanel.IsVisibleProperty, true);
                    _weeklyRepeatCount?.SetCurrentValue(NumericUpDown.ValueProperty,
                        job.WeeklyRepeatCount > 0 ? job.WeeklyRepeatCount : 1);
                    break;

                case "Monthly":
                    _recurrenceDayPanel?.SetCurrentValue(StackPanel.IsVisibleProperty, true);
                    _monthlyPanel?.SetCurrentValue(StackPanel.IsVisibleProperty, true);
                    _monthlyRepeatCount?.SetCurrentValue(NumericUpDown.IsVisibleProperty, true);
                    _monthlyRepeatCount?.SetCurrentValue(NumericUpDown.ValueProperty,
                        job.MonthlyRepeatCount > 0 ? job.MonthlyRepeatCount : 1);

                    SetWeekOfMonthCheckbox("ChkWeek1", 1);
                    SetWeekOfMonthCheckbox("ChkWeek2", 2);
                    SetWeekOfMonthCheckbox("ChkWeek3", 3);
                    SetWeekOfMonthCheckbox("ChkWeek4", 4);
                    SetWeekOfMonthCheckbox("ChkWeekLast", -1);

                    break;
                case "Hourly":
                case "Every 15 Minutes":
                    // These don't need visible day-of-week or repeat config
                    _recurrenceDayPanel?.SetCurrentValue(StackPanel.IsVisibleProperty, false);
                    _weeklyRepeatRow?.SetCurrentValue(StackPanel.IsVisibleProperty, false);
                    _monthlyPanel?.SetCurrentValue(StackPanel.IsVisibleProperty, false);
                    _monthlyRepeatCount?.SetCurrentValue(NumericUpDown.IsVisibleProperty, false);
                    break;

            }

            // ✅ Always set the weekday checkboxes
            SetDayOfWeekCheckboxes(job.DaysOfWeek);

            // ───────── Local helper methods ─────────
            void SetWeekOfMonthCheckbox(string controlName, int offset)
            {
                var cb = this.FindControl<CheckBox>(controlName);
                if (cb != null)
                    cb.IsChecked = job.MonthlyWeekOffsets?.Contains(offset) == true;
            }

            void SetDayOfWeekCheckboxes(List<DayOfWeek>? days)
            {
                days ??= new List<DayOfWeek>();

                void Set(string name, DayOfWeek day)
                {
                    var cb = this.FindControl<CheckBox>(name);
                    if (cb != null)
                        cb.IsChecked = days.Contains(day);
                }

                Set("ChkMon", DayOfWeek.Monday);
                Set("ChkTue", DayOfWeek.Tuesday);
                Set("ChkWed", DayOfWeek.Wednesday);
                Set("ChkThu", DayOfWeek.Thursday);
                Set("ChkFri", DayOfWeek.Friday);
                Set("ChkSat", DayOfWeek.Saturday);
                Set("ChkSun", DayOfWeek.Sunday);
            }
        }


        private void ShowLoadingIndicator(string message)
        {
            _logTextBox.Text += $"⏳ {message}\n";
        }

        private void HideLoadingIndicator()
        {
            _logTextBox.Text += "✅ Done.\n";
        }



        private void RehydrateParameters(StackPanel host, Dictionary<string, string> saved)
        {
            foreach (var row in host.Children.OfType<StackPanel>())
            {
                if (row.Children.Count < 2) continue;
                var label = row.Children[0] as TextBlock;
                var input = row.Children[1];

                if (label == null) continue;
                var key = label.Text?.TrimEnd(':');
                if (string.IsNullOrWhiteSpace(key) || !saved.ContainsKey(key)) continue;

                var val = saved[key];

                switch (input)
                {
                    case TextBox tb: tb.Text = val; break;
                    case ComboBox cb: cb.SelectedItem = val; break;
                    case NumericUpDown nu when int.TryParse(val, out var num): nu.Value = num; break;
                }
            }
        }
        private void WriteJobToggle(ScheduledJob job)
        {
            Log($"🔄 Job '{job.InstructionName}' ⇒ Enabled: {job.IsEnabled}, Export: {(job.EnableExport ? "On" : "Off")}\n");
        }

        private void JobsGrid_OnLoaded(object? sender, RoutedEventArgs e)
        {
            _gridReady = true;        // let future toggle events log
        }


        private void ExportToggled(object? sender, RoutedEventArgs e)
        {
            if (sender is ToggleSwitch ts && ts.DataContext is ScheduledJob job)
            {
                if (job.EnableExport == ts.IsChecked)   // no real change → skip
                    return;

                job.EnableExport = ts.IsChecked == true;
                _jobsVm?.SaveJobsAsync();
                WriteJobToggle(job);                    // single-line helper
            }
        }

        private void JobEnabledToggled(object? sender, RoutedEventArgs e)
        {
            if (sender is CheckBox cb && cb.DataContext is ScheduledJob job)
            {
                if (job.IsEnabled == (cb.IsChecked == true))   // value unchanged
                    return;

                job.IsEnabled = cb.IsChecked == true;
                _jobsVm?.SaveJobsAsync();
                WriteJobToggle(job);
            }
        }

        private async void OnRefreshPlatformInfoClick(object? sender, RoutedEventArgs e)
        {
            try
            {
                await _configTab.RefreshAllAsync();
            }
            catch (Exception ex)
            {
                LogHelper.Error($"❌ Refresh failed: {ex.Message}");
            }
        }


        // Helper to set ComboBox selection by content string
        private void SetComboBoxSelectionByContent(ComboBox? comboBox, string? content)
        {
            if (comboBox == null || string.IsNullOrWhiteSpace(content))
                return;

            foreach (var item in comboBox.Items)
            {
                // Support ComboBoxItem with Content
                if (item is ComboBoxItem cbi &&
                    string.Equals(cbi.Content?.ToString(), content, StringComparison.OrdinalIgnoreCase))
                {
                    comboBox.SelectedItem = cbi;
                    return;
                }

                // Support direct string items (e.g., from ItemsSource="Minutes,Hours,Days")
                if (string.Equals(item?.ToString(), content, StringComparison.OrdinalIgnoreCase))
                {
                    comboBox.SelectedItem = item;
                    return;
                }
            }

            _logTextBox.Text += $"⚠️ ComboBox '{comboBox.Name}' has no matching item for '{content}'\n";
        }

        private void TabControl_SelectionChanged(object? sender, SelectionChangedEventArgs e)
        {
            if (DataContext is ScheduledJobsViewModel vm &&
                HistoryTab.IsSelected) // x:Name="HistoryTab"
            {
                Dispatcher.UIThread.Post(() =>
                {
                    vm.PopulateChartData();  // Force refresh
                });
            }
        }



        private void RecurrenceCombo_SelectionChanged(object? sender, SelectionChangedEventArgs e)
        {
            string sel = (sender as ComboBox)?.SelectedItem is ComboBoxItem cbi
                ? cbi.Content?.ToString() ?? ""
                : "";

            _recurrenceDayPanel.IsVisible = sel is "Daily" or "Weekly";
            _weeklyRepeatRow.IsVisible = sel == "Weekly";
        }



        private async void SaveConfigButton_Click(object? sender, RoutedEventArgs e)
        {
            if (_currentScheduledJob == null)
            {
                _logTextBox.Text += "⚠️ No job selected for saving.\n";
                return;
            }

            // Update current job properties from UI
            _currentScheduledJob.PlatformFqdn = _platformFqdnTextBox.Text ?? "";
            _currentScheduledJob.AppRegistrationId = _appRegIdTextBox.Text ?? "";
            _currentScheduledJob.CertThumbprint = _certThumbprintTextBox.Text ?? "";

            // Call ViewModel to update and save
            await _jobsVm.UpdateJobAsync(_currentScheduledJob);

            _logTextBox.Text += "✅ Scheduled job saved.\n";
        }

        private void LoadPlatformConfigToUI()
        {
            if (_currentScheduledJob == null)
                return;

            _platformFqdnTextBox.Text = _currentScheduledJob.PlatformFqdn;
            _appRegIdTextBox.Text = _currentScheduledJob.AppRegistrationId;
            _certThumbprintTextBox.Text = _currentScheduledJob.CertThumbprint;

            if (_authModeComboBox.SelectedItem is ComboBoxItem cbi && cbi.Content is string mode)
            {
                _authModeComboBox.SelectedItem = cbi;
            }
            else
            {
                _authModeComboBox.SelectedItem = _currentScheduledJob.AuthenticationMode;
            }
        }

        private void PlatformFqdnTextBox_TextChanged(object? sender, EventArgs e)
        {
            if (_currentScheduledJob != null)
                _currentScheduledJob.PlatformFqdn = _platformFqdnTextBox.Text ?? "";
        }

        private void AppRegIdTextBox_TextChanged(object? sender, EventArgs e)
        {
            if (_currentScheduledJob != null)
                _currentScheduledJob.AppRegistrationId = _appRegIdTextBox.Text ?? "";
        }

        private void CertThumbprintTextBox_TextChanged(object? sender, EventArgs e)
        {
            if (_currentScheduledJob != null)
                _currentScheduledJob.CertThumbprint = _certThumbprintTextBox.Text ?? "";
        }

        private void AuthModeComboBox_SelectionChanged(object? sender, SelectionChangedEventArgs e)
        {
            if (_currentScheduledJob == null) return;

            if (_authModeComboBox.SelectedItem is ComboBoxItem cbi && cbi.Content is string mode)
            {
                _currentScheduledJob.AuthenticationMode = mode;
            }
        }

        private void OnScheduledJobSelected(object? sender, SelectionChangedEventArgs e)
        {
            if (_scheduledJobsList?.SelectedItem is ScheduledJobModel selectedJob)
            {
                _currentScheduledJob = selectedJob;
                LoadPlatformConfigToUI();
            }
        }

        public async Task RunOnFetchExportClickedFromConfig()
        {
            await OnFetchExportClicked(); // or inline it here if you want to move it
        }


        private PlatformSettings? ResolveCurrentPlatformSettingsForAuth(string? alias, string? fqdn)
        {
            try
            {
                if (_config?.Platforms == null || _config.Platforms.Count == 0)
                    return null;

                // Prefer alias (this is how the rest of your code keys settings/export options)
                if (!string.IsNullOrWhiteSpace(alias))
                {
                    var byAlias = _config.Platforms.FirstOrDefault(p =>
                        !string.IsNullOrWhiteSpace(p.Alias) &&
                        string.Equals(p.Alias, alias, StringComparison.OrdinalIgnoreCase));

                    if (byAlias != null)
                        return byAlias;
                }

                // Next try fqdn
                if (!string.IsNullOrWhiteSpace(fqdn))
                {
                    var byFqdn = _config.Platforms.FirstOrDefault(p =>
                        !string.IsNullOrWhiteSpace(p.PlatformFqdn) &&
                        string.Equals(p.PlatformFqdn, fqdn, StringComparison.OrdinalIgnoreCase));

                    if (byFqdn != null)
                        return byFqdn;
                }

                // Final fallback: use current UI selection if available
                var currentAlias = CurrentPlatformAlias;
                if (!string.IsNullOrWhiteSpace(currentAlias))
                {
                    var byCurrentAlias = _config.Platforms.FirstOrDefault(p =>
                        !string.IsNullOrWhiteSpace(p.Alias) &&
                        string.Equals(p.Alias, currentAlias, StringComparison.OrdinalIgnoreCase));

                    if (byCurrentAlias != null)
                        return byCurrentAlias;
                }

                var currentFqdn = CurrentPlatformFqdn;
                if (!string.IsNullOrWhiteSpace(currentFqdn))
                {
                    var byCurrentFqdn = _config.Platforms.FirstOrDefault(p =>
                        !string.IsNullOrWhiteSpace(p.PlatformFqdn) &&
                        string.Equals(p.PlatformFqdn, currentFqdn, StringComparison.OrdinalIgnoreCase));

                    if (byCurrentFqdn != null)
                        return byCurrentFqdn;
                }

                return null;
            }
            catch
            {
                return null;
            }
        }


        private async Task OnFetchExportClicked()
        {
            _logTextBox.Text += $"🧪 Raw ManualInstructionIdBox.Text = '{_manualInstructionIdBox?.Text}'\n";
            _logTextBox.Text += $"🧪 _manualInstructionIdBox is {(_manualInstructionIdBox == null ? "null" : "not null")}\n";
            _logTextBox.Text += $"🧪 IsVisible: {_manualInstructionIdBox?.IsVisible}, IsEnabled: {_manualInstructionIdBox?.IsEnabled}\n";

            string rawText = _configTab?.FindControl<TextBox>("ManualInstructionIdBox")?.Text ?? "";
            _logTextBox.Text += $"🧪 Raw ManualInstructionIdBox.Text = '{rawText}'\n";

            if (string.IsNullOrWhiteSpace(rawText) || !int.TryParse(rawText, out int responseId))
            {
                _logTextBox.Text += "❌ Invalid or missing Response ID. Please enter a valid number.\n";
                return;
            }

            _logTextBox.Text += $"🔍 Starting export for Instruction ID: {responseId}...\n";

            var platformFqdn = CurrentPlatformFqdn;
            if (string.IsNullOrWhiteSpace(platformFqdn))
            {
                _logTextBox.Text += "❌ No platform selected or platform FQDN is empty.\n";
                return;
            }

            _platformUrl = platformFqdn;

            string instructionName = "Instruction";
            if (_instructionListBox?.SelectedItem is InstructionDefinition instr)
            {
                instructionName = instr.Name;
                Log($"📄 Selected instruction name: {instructionName}");
            }
            else
            {
                Log("⚠️ No instruction selected — using default name.");
            }

            try
            {
                var logger = new TextBoxLogger(_logTextBox);

                string alias = CurrentPlatformAlias ?? "";
                _logTextBox.Text += $"🪪 Using CurrentPlatformAlias: '{alias}'\n";


                if (!_config.ExportOptions.TryGetValue(alias, out var exportOption) || string.IsNullOrWhiteSpace(exportOption.ExportFolder))
                {
                    _logTextBox.Text += $"❌ No export path configured for platform alias '{alias}'.\n";
                    return;
                }
                _logTextBox.Text += $"📁 Export Folder: {exportOption.ExportFolder}\n";

                string safeName = SanitizeFileName(instructionName);
                _logTextBox.Text += $"📄 Instruction Name (sanitized): {safeName}\n";

                string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
                _logTextBox.Text += $"⏱️ Timestamp: {timestamp}\n";

                string fileName = $"{safeName}_{responseId}_{timestamp}.csv";
                _logTextBox.Text += $"📦 File Name: {fileName}\n";

                string fullPath = Path.Combine(exportOption.ExportFolder, fileName);
                _logTextBox.Text += $"📍 Full Path: {fullPath}\n";

                string format = exportOption.Format ?? "CSV";
                _logTextBox.Text += $"📊 Format: {format}\n";
                _logTextBox.Text += $"🔢 Response ID: {responseId}\n";

                Directory.CreateDirectory(exportOption.ExportFolder);

                // Always acquire/validate token via AuthenticationService (handles expiry + refresh + cached reuse).
                try
                {
                    var platformSettings = ResolveCurrentPlatformSettingsForAuth(alias, platformFqdn);
                    if (platformSettings == null)
                    {
                        _logTextBox.Text += $"❌ Could not resolve platform settings for alias '{alias}' / fqdn '{platformFqdn}'.";
                        return;
                    }

                    var authResult = await _authService.AuthenticateAsync(platformSettings);
                    if (authResult == null || string.IsNullOrWhiteSpace(authResult.Token))
                    {
                        _logTextBox.Text += $"❌ Authentication failed. Cannot export. Reason: {authResult?.FailureReason ?? "Unknown"}";
                        return;
                    }

                    _token = authResult.Token;
                    if (!string.IsNullOrWhiteSpace(authResult.ConsumerName))
                        _consumerName = authResult.ConsumerName;

                    _logTextBox.Text += $"🔐 Export using token ending: ...{(_token.Length >= 6 ? _token[^6..] : _token)}";
                }
                catch (Exception exAuth)
                {
                    _logTextBox.Text += $"❌ Authentication failed. Cannot export. Reason: {exAuth.Message}";
                    return;
                }

                await ExportHelper.ExportInstructionResultsWithProgressAsync(
                    _platformUrl,
                    _token,
                    _consumerName,
                    responseId,
                    fullPath,
                    format,
                    logger,
                    pageSize: _config?.Export?.PageSize ?? 2000,
                    maxConcurrentRequests: _config?.Export?.MaxConcurrentRequests ?? 6);
                _logTextBox.Text += $"✅ Export completed successfully: {fullPath}\n";
            }
            catch (Exception ex)
            {
                _logTextBox.Text += $"❌ Error during export: {ex.Message}\n";
            }
        }


        // Helper to remove illegal filename characters
        private static string SanitizeFileName(string input)
        {
            foreach (char c in Path.GetInvalidFileNameChars())
                input = input.Replace(c, '_');
            return input;
        }
        public async Task TriggerPreviewFromConfigTabAsync()
        {
            try
            {
                if (_configTab == null)
                {
                    LogHelper.Warn("⚠️ _configTab is null in TriggerPreviewFromConfigTabAsync.");
                    _logTextBox.Text += "⚠️ ConfigTab not available yet.\n";
                    return;
                }

                // Sync platform from ConfigTab so auth + preview are using the selected platform.
                _platformUrl = _configTab.GetSelectedPlatformUrl();
                _fqdn = _platformUrl;
                LogHelper.Info($"🔁 Synced platform URL from ConfigTab: {_platformUrl}");

                await OnPreviewTargetClickedFromConfigTabAsync();
            }
            catch (Exception ex)
            {
                LogHelper.Error($"❌ TriggerPreviewFromConfigTabAsync failed: {ex.Message}");
                _logTextBox.Text += $"❌ Preview failed: {ex.Message}\n";
            }
        }

        private async Task OnPreviewTargetClickedFromConfigTabAsync()
        {
            try
            {
                LogHelper.Info("🔍 Preview Target button clicked...");

                if (_configTab == null)
                {
                    LogHelper.Info("❌ ConfigTab is not available.");
                    return;
                }

                var selectedPlatform = _configTab.GetSelectedPlatform();
                if (selectedPlatform == null)
                {
                    LogHelper.Info("⚠️ Not authenticated. Please authenticate first.");
                    return;
                }

                var selectedPlatformUrl = _configTab.GetSelectedPlatformUrl();
                if (string.IsNullOrWhiteSpace(selectedPlatformUrl))
                {
                    selectedPlatformUrl = selectedPlatform.PlatformFqdn;
                }

                if (string.IsNullOrWhiteSpace(selectedPlatformUrl))
                {
                    LogHelper.Info("⚠️ No platform selected.");
                    return;
                }

                var token = !string.IsNullOrWhiteSpace(_configTab.GetCurrentToken())
                    ? _configTab.GetCurrentToken()
                    : (!string.IsNullOrWhiteSpace(selectedPlatform.Token)
                        ? selectedPlatform.Token
                        : _token);

                if (string.IsNullOrWhiteSpace(token))
                {
                    LogHelper.Info("⚠️ Not authenticated. Please authenticate first.");
                    return;
                }

                // Preview is initiated from ConfigTab, so read targeting + selected instruction from ConfigTab controls.
                var def = _configTab.GetSelectedInstructionDefinition();
                if (def == null || def.Id <= 0)
                {
                    LogHelper.Info("⚠️ No instruction selected.");
                    return;
                }

                bool compulsoryCoverageEnabled = selectedPlatform.RequireCoverage == true;
                string targetingMode = _configTab.GetSelectedTargetingMode();

                JObject scopeQuery;
                if (targetingMode.Equals("FQDN", StringComparison.OrdinalIgnoreCase))
                {
                    var fqdn = _configTab.GetTargetingFqdn();
                    if (string.IsNullOrWhiteSpace(fqdn))
                    {
                        LogHelper.Info("⚠️ No FQDN provided.");
                        return;
                    }

                    scopeQuery = JObject.FromObject(new
                    {
                        Attribute = "fqdn",
                        Operator = "==",
                        Value = fqdn.Trim()
                    });
                }
                else if (targetingMode.Equals("Management Group", StringComparison.OrdinalIgnoreCase))
                {
                    var mg = _configTab.GetSelectedManagementGroup();
                    if (mg == null)
                    {
                        LogHelper.Info("⚠️ No management group selected.");
                        return;
                    }

                    if (mg.UsableId <= 0)
                    {
                        scopeQuery = compulsoryCoverageEnabled
                            ? JObject.FromObject(new { Attribute = "managementgroup", Operator = "==", Value = "global" })
                            : new JObject();
                    }
                    else
                    {
                        scopeQuery = JObject.FromObject(new
                        {
                            Attribute = "managementgroup",
                            Operator = "==",
                            Value = mg.UsableId.ToString()
                        });
                    }
                }
                else if (targetingMode.Equals("Coverage Tag", StringComparison.OrdinalIgnoreCase))
                {
                    var (name, value) = _configTab.GetSelectedCoverageTag();
                    if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(value))
                    {
                        LogHelper.Info("⚠️ Coverage Tag Name/Value must be selected.");
                        return;
                    }

                    scopeQuery = JObject.FromObject(new
                    {
                        Attribute = name,
                        Operator = "==",
                        Value = value
                    });
                }
                else
                {
                    LogHelper.Info("⚠️ No valid targeting mode selected.");
                    return;
                }

                var instructionService = new InstructionService();

                JObject result = await instructionService.PreviewTargetsAsync(
                    selectedPlatformUrl,
                    token,
                    def.Id,
                    scopeQuery);

                int total = 0;
                int online = 0;
                int offline = 0;

                if (result != null)
                {
                    online = result.Value<int?>("TotalDevicesOnline") ?? 0;
                    offline = result.Value<int?>("TotalDevicesOffline") ?? 0;
                    total = result.Value<int?>("TotalDevices") ?? 0;

                    var summary = result["Summary"] as JObject;
                    if (summary != null)
                    {
                        total = summary.Value<int?>("EstimatedCount") ?? total;
                    }

                    if (total == 0)
                    {
                        if (result["Targets"] is JArray arr)
                            total = arr.Count;
                        else if (result["Items"] is JArray arr2)
                            total = arr2.Count;
                    }

                    if (total == 0 && (online > 0 || offline > 0))
                        total = online + offline;
                }

                // Update the *ConfigTab* UI (these labels live inside ConfigTab.axaml)
                // rather than searching MainWindow.
                var host = (Avalonia.Controls.Control?)_configTab ?? this;

                var estimatedLabel = host.FindControl<Avalonia.Controls.TextBlock>("EstimatedCountLabel")
                                   ?? host.FindControl<Avalonia.Controls.TextBlock>("EstimatedTargetsLabel")
                                   ?? host.FindControl<Avalonia.Controls.TextBlock>("EstimatedTargetsText")
                                   ?? host.FindControl<Avalonia.Controls.TextBlock>("EstimatedTargets");

                var onlineLabel = host.FindControl<Avalonia.Controls.TextBlock>("OnlineCountLabel")
                                ?? host.FindControl<Avalonia.Controls.TextBlock>("OnlineTargetsLabel")
                                ?? host.FindControl<Avalonia.Controls.TextBlock>("OnlineTargetsText")
                                ?? host.FindControl<Avalonia.Controls.TextBlock>("OnlineTargets");

                var offlineLabel = host.FindControl<Avalonia.Controls.TextBlock>("OfflineCountLabel")
                                 ?? host.FindControl<Avalonia.Controls.TextBlock>("OfflineTargetsLabel")
                                 ?? host.FindControl<Avalonia.Controls.TextBlock>("OfflineTargetsText")
                                 ?? host.FindControl<Avalonia.Controls.TextBlock>("OfflineTargets");

                // Optional raw JSON surface (only if present in AXAML)
                var rawJsonBox = host.FindControl<Avalonia.Controls.TextBox>("PreviewTargetsRawJsonTextBox")
                              ?? host.FindControl<Avalonia.Controls.TextBox>("PreviewTargetsRawJson")
                              ?? host.FindControl<Avalonia.Controls.TextBox>("PreviewRawJson");

                if (estimatedLabel != null)
                    estimatedLabel.Text = $"Estimated: {total}";

                if (onlineLabel != null)
                    onlineLabel.Text = $"Online: {online}";

                if (offlineLabel != null)
                    offlineLabel.Text = $"Offline: {offline}";

                if (rawJsonBox != null)
                    rawJsonBox.Text = result?.ToString(Formatting.Indented) ?? "(no data)";

                LogHelper.Info($"✅ Preview loaded. Estimated={total}, Online={online}, Offline={offline}");

                // Preview succeeded — ensure ConfigTab has the token context and enable Run.
                try
                {
                    _token = token;
                    _platformUrl = selectedPlatformUrl;
                    _fqdn = selectedPlatformUrl;

                    _configTab.SetAuthContext(selectedPlatformUrl, token);
                    _configTab.SetRunNowEnabled(true);
                }
                catch { }
            }
            catch (Exception ex)
            {
                LogHelper.Info($"❌ Preview failed: {ex.Message}");
            }
        }




        private async Task OnPreviewTargetClicked()
        {
            // In your platform selection event or initialization code
            _platformUrl = CurrentPlatformFqdn;

            _logTextBox.Text += "🔍 Preview Target button clicked...\n";

            // Disable Run button at start
            if (_runNowButton != null)
                _runNowButton.IsEnabled = false;

            try
            {
				// Always resolve the freshest token before preview.
				// If missing, allow a full RefreshAllAsync (first-login / token-expired reauth) which also repopulates MGs/consumers/instructions.
				var token = await EnsureTokenAsync(CurrentPlatformFqdn ?? _platformUrl ?? _fqdn, allowRefresh: true);
				if (string.IsNullOrWhiteSpace(token))
				{
					_logTextBox.Text += "⚠️ Not authenticated. Please authenticate first.\n";
					return;
				}

                if (_selectedInstruction == null)
                {
                    _logTextBox.Text += "⚠️ No instruction selected for preview.\n";
                    return;
                }
                _logTextBox.Text += $"📡 Debug: CurrentPlatformFqdn = {CurrentPlatformFqdn}\n";

                if (CurrentPlatformFqdn == null)
                {
                    _logTextBox.Text += "⚠️ No platform selected.\n";
                    return;
                }

                string targetingMode = "";

                if (_fqdnRadio.IsChecked == true)
                    targetingMode = "FQDN";
                else if (_mgRadio.IsChecked == true)
                    targetingMode = "Management Group";  // Use full string as expected
                else if (_coverageRadio.IsChecked == true)
                    targetingMode = "Coverage Tag";
                else
                {
                    _logTextBox.Text += "⚠️ No targeting mode selected.\n";
                    return;
                }

                _logTextBox.Text += $"🔍 Selected targeting mode: '{targetingMode}'\n";


                var scopeQuery = BuildScopeQuery(targetingMode);
                _logTextBox.Text += $"📦 Preview Payload:\n{scopeQuery.ToString(Newtonsoft.Json.Formatting.Indented)}\n";

                var previewResult = await _instructionService.PreviewTargetsAsync(
                    _platformUrl,
                    token,
                    _selectedInstruction.Id,
                    scopeQuery);

                if (previewResult != null)
                {
                    _logTextBox.Text += $"📊 Preview Target result received.\n";
                    DisplayPreviewResult(previewResult);

                    if (_runNowButton != null)
                        _runNowButton.IsEnabled = true;  // Enable run button on success
                }
                else
                {
                    _logTextBox.Text += "⚠️ No preview data returned.\n";
                    if (_runNowButton != null)
                        _runNowButton.IsEnabled = false;
                }
            }
            catch (Exception ex)
            {
                _logTextBox.Text += $"❌ Error fetching preview target: {ex.Message}\n";
                if (_runNowButton != null)
                    _runNowButton.IsEnabled = false;
            }
        }

        public void SetPlatform(Platform platform)
        {
            _selectedPlatform = new TV1_InstructionOffloader.Models.PlatformConfigData
            {
                PlatformFqdn = platform.PlatformFqdn,
                AppId = platform.AppId,
                CertThumbprint = platform.CertThumbprint,
                GroupName = platform.GroupName ?? "",
                IsDefault = platform.IsDefault
            };

            _platformUrl = platform.PlatformFqdn;
            _fqdn = platform.PlatformFqdn;

            LogHelper.Info($"🌐 MainWindow.SetPlatform → {_platformUrl}");
        }

        private void LoadPlatforms()
        {
            var configHelper = new ConfigHelper();
            var config = configHelper.Load();

            if (config.Platforms != null)
            {
                //   _platforms = new ObservableCollection<Platform>(config.Platforms);
                //_platformComboBox.ItemsSource = _platforms;

                // Set selected platform to first or default
                _platformComboBox.SelectedItem = _platforms.FirstOrDefault();
            }
        }

        private TV1_InstructionOffloader.Models.PlatformConfigData MapPlatformToPlatformConfig(Platform p)
        {
            return new TV1_InstructionOffloader.Models.PlatformConfigData
            {
                PlatformFqdn = p.PlatformFqdn,
                AppId = p.AppId,
                CertThumbprint = p.CertThumbprint,
                UseCert = p.UseCert,
                Alias = !string.IsNullOrWhiteSpace(p.Alias) ? p.Alias : (p.GroupName ?? string.Empty),
                GroupName = p.GroupName ?? string.Empty,
                IsDefault = p.IsDefault,
                UserId = p.UserId ?? string.Empty
            };
        }


        // Day-of-week check-boxes (Config ▶ Instructions tab)
        private CheckBox? _chkMon, _chkTue, _chkWed, _chkThu, _chkFri, _chkSat, _chkSun;


        public async Task OnLoadCoverageTagsAsync()
        {
            try
            {
                var token = ResolveTokenForFqdn(_fqdn ?? _platformUrl ?? (_platformComboBox?.SelectedItem as Platform)?.PlatformFqdn);
                if (string.IsNullOrWhiteSpace(token))
                {
                    LogHelper.Info("⚠️ No valid token available, cannot load coverage tags.");
                    return;
                }

                if (_coverageTagNameDropdown == null || _coverageTagValueDropdown == null)
                {
                    LogHelper.Info("❌ Coverage tag dropdown(s) not found.");
                    return;
                }

                await _instructionHelper.LoadCustomPropertiesAsync(
                    _fqdn,
                    token,
                    _coverageTagNameDropdown,
                    _coverageTagValueDropdown,
                    _logTextBox);

                LogHelper.Info("📑 Loaded coverage tags.");
            }
            catch (Exception ex)
            {
                LogHelper.Error($"❌ Failed to load coverage tags: {ex.Message}");
            }
        }


        private async Task RefreshPlatformDataAsync(Platform platform)
        {
            try
            {
                _fqdn = platform.PlatformFqdn;
                _platformUrl = _fqdn;

                // Optionally update any config or services that depend on platform URL
                // ...

                // Refresh consumers, instructions, management groups, coverage tags
                await _instructionHelper.LoadManagementGroupsAsync(_fqdn, _token, _mgDropdown, _logTextBox);
                await _instructionHelper.LoadCustomPropertiesAsync(_fqdn, _token, _coverageTagNameDropdown, _coverageTagValueDropdown, _logTextBox);
                await OnLoadConsumersAsync();
                _allInstructions = await _instructionHelper.LoadInstructionsAsync(_fqdn, _token, _logTextBox);
                _configTab?.SetInstructions(_allInstructions);
                _configTab?.SetSelectedPlatform(platform);
                // Refresh Automations
                var automationTab = this.FindControl<AutomationTab>("AutomationTabHost");
                if (automationTab != null)
                {
                    await automationTab.LoadPoliciesAsync();
                    LogHelper.Info("🤖 Refreshed automations (policies).");
                }

                _logTextBox.Text += $"✅ Platform data refreshed for {platform.GroupName}\n";
            }
            catch (Exception ex)
            {
                _logTextBox.Text += $"❌ Error refreshing platform data: {ex.Message}\n";
            }
        }

        public async Task RunInstructionWithParametersAsync(
      InstructionDefinition definition,
      Dictionary<string, object> parameters,
      string targetingMode,
      string fqdnInput,
      string matchType,
      ManagementGroup? mg,
      string coverageTagName,
      string coverageTagValue,
      List<string> selectedFqdns,
      int instructionTtl,
      int responseTtl)
        {
            var logger = new TextBoxLogger(_logTextBox);
            if (string.IsNullOrWhiteSpace(_fqdn))
            {
                _fqdn = _platformUrl = _selectedPlatform?.PlatformFqdn;
                _logTextBox.Text += $"🔁 Fallback: _fqdn set to {_fqdn}\n";
            }

			var token = ResolveTokenForFqdn(_fqdn);
			if (string.IsNullOrWhiteSpace(token))
			{
				_logTextBox.Text += "❌ No authentication token found. Please authenticate and try again.\n";
				return;
			}

            // Convert parameters to Dictionary<string, string>
            var stringParams = parameters
                .Where(kvp => kvp.Value != null)
                .ToDictionary(kvp => kvp.Key, kvp => kvp.Value?.ToString() ?? "");
            _logTextBox.Text += "📦 Preparing to send instruction with the following parameters:\n";
            _logTextBox.Text += $"   Instruction: {definition?.Name} (ID: {definition?.Id})\n";
            _logTextBox.Text += $"   Targeting Mode: {targetingMode}\n";
            _logTextBox.Text += $"   Platform URL: {_fqdn}\n";
            _logTextBox.Text += $"   Token: {(string.IsNullOrWhiteSpace(token) ? "[empty]" : $"...{token[^6..]}")}\n";
            _logTextBox.Text += $"   Consumer: {_consumerName}\n";
            _logTextBox.Text += $"   FQDN Input: {fqdnInput}\n";
            _logTextBox.Text += $"   Match Type: {matchType}\n";
            _logTextBox.Text += $"   Management Group: {(mg != null ? $"{mg.Name} (ID: {mg.UsableId})" : "[none]")}\n";
            _logTextBox.Text += $"   Coverage Tag: {coverageTagName}\n";
            _logTextBox.Text += $"   Coverage Value: {coverageTagValue}\n";
            _logTextBox.Text += $"   Selected FQDNs: {(selectedFqdns.Count > 0 ? string.Join(", ", selectedFqdns) : "[none]")}\n";
            _logTextBox.Text += $"   Instruction TTL: {instructionTtl} minutes\n";
            _logTextBox.Text += $"   Response TTL: {responseTtl} minutes\n";
            _logTextBox.Text += $"   Parameters: {JsonConvert.SerializeObject(parameters, Formatting.Indented)}\n";
            bool requireCoverage = (_platformComboBox?.SelectedItem as TV1_InstructionOffloader.Models.Platform)?.RequireCoverage == true;

            await _instructionService.RunInstructionFromMainTabAsync(
            definition,
            parameters,  // ✅ Correct type: Dictionary<string, object>
            targetingMode,
            _fqdn,
            token,
            _consumerName,
            fqdnInput,
            matchType,
            mg,
            coverageTagName,
            coverageTagValue,
            selectedFqdns,
            instructionTtl,
            responseTtl,
            logger,
            compulsoryCoverageEnabled: requireCoverage);
        }



        public async Task TryRunSelectedInstructionAsync()
        {
            if (_instructionListBox.SelectedItem is not InstructionDefinition definition)
            {
                _logTextBox.Text += "❌ No instruction selected or invalid type.\n";
                return;
            }

            var parametersDict = _configTab.CollectParametersFromPanels();

            var fqdnInput = _fqdnTextBox?.Text?.Trim() ?? "";
            var matchType = _matchTypeComboBox?.SelectedItem?.ToString() ?? "Begins With";

            ManagementGroup? mg = _managementGroupComboBox?.SelectedItem as ManagementGroup;
            string coverageTagName = _coverageTagNameComboBox?.SelectedItem?.ToString() ?? "";
            string coverageTagValue = _coverageTagValueComboBox?.SelectedItem?.ToString() ?? "";

            var selectedFqdns = _selectedFqdnListBox?.Items?.Cast<string>().ToList() ?? new List<string>();
            string targetingMode = _fqdnRadio.IsChecked == true ? "FQDN" :
                                   _mgRadio.IsChecked == true ? "MG" :
                                   _coverageRadio.IsChecked == true ? "Coverage" : "";

            var instructionTtlText = _instructionTtlBox?.Text ?? "10";
            var instructionTtlUnit = (_instructionTtlUnitDropdown?.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Minutes";
            int instructionTtl = ConvertTtlToMinutes(instructionTtlText, instructionTtlUnit);

            var responseTtlText = _responseTtlBox?.Text ?? "24";
            var responseTtlUnit = (_responseTtlUnitDropdown?.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Hours";
            int responseTtl = ConvertTtlToMinutes(responseTtlText, responseTtlUnit);

            await RunInstructionWithParametersAsync(
                definition,
                parametersDict,
                targetingMode,
                fqdnInput,
                matchType,
                mg,
                coverageTagName,
                coverageTagValue,
                selectedFqdns,
                instructionTtl,
                responseTtl
            );
        }

        private void OnManagementGroupChanged(object? sender, SelectionChangedEventArgs e)
        {
            if (_managementGroupComboBox.SelectedItem is ManagementGroup selected)
            {
                _logTextBox.Text += $"📌 MG selected: {selected.Name} (ID: {selected.UsableId})\n";
            }
            else
            {
                _logTextBox.Text += "⚠️ No MG selected.\n";
            }
        }
        private int ConvertTtlToMinutes(string valueStr, string unit)
        {
            if (!int.TryParse(valueStr, out int value)) return 0;
            return unit switch
            {
                "Minutes" => value,
                "Hours" => value * 60,
                "Days" => value * 1440,
                _ => value
            };
        }

        private async Task OnBrowseExportPathClicked()
        {
            var dialog = new OpenFolderDialog { Title = "Select Export Folder" };
            var result = await dialog.ShowAsync(this);
            if (!string.IsNullOrWhiteSpace(result))
                _exportFilePathBox.Text = result;
        }
        private async Task UpdatePreviewAsync()
        {
            try
            {
                if (_selectedInstruction == null || _selectedPlatform == null)
                    return;

                var token = ResolveTokenForFqdn(_selectedPlatform.PlatformFqdn);
                if (string.IsNullOrWhiteSpace(token))
                    return;

                var targetingMode = (_targetingModeComboBox?.SelectedItem as ComboBoxItem)?.Content?.ToString();
                var scopeQuery = BuildScopeQuery(targetingMode);

                var previewResult = await _instructionService.PreviewTargetsAsync(
                    _selectedPlatform.PlatformFqdn,
                    token,
                    _selectedInstruction.Id,
                    scopeQuery);

                // Use previewResult to update your UI, e.g. labels and tables

            }
            catch (Exception ex)
            {
                _logTextBox.Text += $"❌ Error previewing targets: {ex.Message}\n";
            }
        }

        private JObject BuildScopeQuery(string targetingMode)
        {
            switch (targetingMode)
            {
                case "FQDN":
                    var fqdnList = _fqdnTextBox?.Text?
                        .Split(new[] { '\r', '\n', ',' }, StringSplitOptions.RemoveEmptyEntries)
                        .Select(x => x.Trim())
                        .Where(x => !string.IsNullOrWhiteSpace(x))
                        .ToList() ?? new List<string>();

                    if (fqdnList.Count == 1)
                    {
                        return JObject.FromObject(new
                        {
                            Attribute = "Fqdn",
                            Operator = "==",
                            Value = fqdnList.First()
                        });
                    }
                    else
                    {
                        return JObject.FromObject(new
                        {
                            Attribute = "Fqdn",
                            Operator = "in",
                            Value = fqdnList
                        });
                    }

                case "Coverage Tag":
                    string tag = _coverageTagNameComboBox?.SelectedItem?.ToString() ?? "";
                    string value = _coverageTagValueComboBox?.SelectedItem?.ToString() ?? "";

                    if (!string.IsNullOrWhiteSpace(tag) && !string.IsNullOrWhiteSpace(value))
                    {
                        string tagExpression = $"{tag}={value}";
                        return JObject.FromObject(new
                        {
                            Attribute = "TagTxt",
                            Operator = "",
                            Value = tagExpression
                        });
                    }
                    throw new Exception("Coverage Tag or Value not selected.");

                case "Management Group":
                    if (_managementGroupComboBox.SelectedItem is ManagementGroup mg)
                    {
                        // "All Devices" is represented as <= 0 (0 or -1 depending on how the list is built).
                        // When coverage is compulsory, multi-tenant expects managementgroup == "global".
                        if (mg.UsableId <= 0)
                        {
                            bool requireCoverage = (_platformComboBox?.SelectedItem as Platform)?.RequireCoverage == true;
                            return requireCoverage
                                ? JObject.FromObject(new { Attribute = "managementgroup", Operator = "==", Value = "global" })
                                : new JObject();
                        }

                        return JObject.FromObject(new
                        {
                            Attribute = "managementgroup",
                            Operator = "==",
                            Value = mg.UsableId.ToString()
                        });
                    }
                    throw new Exception("Management Group not selected.");

                default:
                    throw new Exception("Invalid or unsupported targeting mode.");
            }
        }


        private void OnSearchTextChanged(string? search)
        {
            if (_instructionListBox is null || _allInstructions is null)
                return;

            if (string.IsNullOrWhiteSpace(search))
            {
				// When the search box is cleared (often happens implicitly when switching tabs),
				// restore the full instruction list instead of leaving a previously-filtered (possibly empty) view.
				_instructionListBox.ItemsSource = _allInstructions;
				return;
            }

            var filtered = _allInstructions
                .Where(i => (!string.IsNullOrWhiteSpace(i.Name) &&
                             i.Name.Contains(search, StringComparison.OrdinalIgnoreCase)) ||
                            (!string.IsNullOrWhiteSpace(i.Description) &&
                             i.Description.Contains(search, StringComparison.OrdinalIgnoreCase)))
                .ToList();

            _instructionListBox.ItemsSource = filtered;
            _instructionListBox.SelectedIndex = -1;
        }


        private string? _lastConsumer = null;



        private void OnConsumerChanged(object? sender, SelectionChangedEventArgs e)
        {
            if (_consumerDropdown.SelectedItem is not string selected || selected == _lastConsumer)
                return;  // No actual change

            _lastConsumer = selected;

            _consumerName = selected;
            _logTextBox.Text += $"🔄 Consumer changed to: {_consumerName}\n";

            // Save the change to config
            var configHelper = new ConfigHelper();
            var config = configHelper.Load();

            if (config.Platforms != null && config.Platforms.Count > 0)
            {
                config.Platforms[0].DefaultConsumer = _consumerName;
                configHelper.Save(config);
            }
        }

        // Called by ConfigTab to keep MainWindow's consumer context in sync.
        public void UpdateConsumer(string consumer)
        {
            if (string.IsNullOrWhiteSpace(consumer))
                return;

            if (string.Equals(_consumerName, consumer, StringComparison.OrdinalIgnoreCase))
                return;

            _consumerName = consumer;
            _lastConsumer = consumer;

            try
            {
                if (_consumerDropdown != null)
                    _consumerDropdown.SelectedItem = consumer;
            }
            catch
            {
                // ignore UI race during startup
            }
        }

        private bool _consumersLoaded = false;

        public async Task OnLoadConsumersAsync()
        {
            if (_consumersLoaded)
                return; // Already loaded

            try
            {
                var token = ResolveTokenForFqdn(_fqdn ?? _platformUrl ?? (_platformComboBox?.SelectedItem as Platform)?.PlatformFqdn);
                if (string.IsNullOrWhiteSpace(token))
                {
                    LogHelper.Info("⚠️ No valid token available, cannot load consumers.");
                    return;
                }

                if (_consumerComboBox == null)
                {
                    LogHelper.Info("❌ _consumerComboBox is null. Ensure HookConfigTabControls() ran and ConsumerDropdown is defined correctly.");
                    return;
                }

                var selectedPlatform = _platformComboBox?.SelectedItem as Platform;
                if (selectedPlatform == null)
                {
                    LogHelper.Info("...... No platform is selected yet (ConfigTab not ready). Skipping consumer load.");
                    return;
                }

                _consumerService = new ConsumerService();
                var consumers = await _consumerService.GetConsumersAsync(_fqdn, token);

                if (consumers == null || consumers.Count == 0)
                {
                    LogHelper.Info("⚠️ No consumers available.");
                    return;
                }

                _consumerComboBox.ItemsSource = consumers;

                var defaultConsumer = string.IsNullOrWhiteSpace(selectedPlatform.DefaultConsumer)
                    ? "Explorer"
                    : selectedPlatform.DefaultConsumer;

                string tokenLogSafe = string.IsNullOrWhiteSpace(token) || token.Length < 6
                    ? "[too short]"
                    : $"...{token[^6..]}";

                LogHelper.Info($"🔐 Using token for {_fqdn} ending in: {tokenLogSafe}");
                Log($"🔐 Using token for {_fqdn} ending in: {tokenLogSafe}");

                // If the API returned a plain list of consumer names, consumers will contain strings.
                // Select the desired default if present; otherwise select the first.
                if (consumers.Contains(defaultConsumer))
                {
                    _consumerComboBox.SelectedItem = defaultConsumer;
                    LogHelper.Info($"✅ Set default consumer: {defaultConsumer}");
                }
                else
                {
                    _consumerComboBox.SelectedIndex = 0;
                    LogHelper.Info($"⚠️ Default consumer '{defaultConsumer}' not found in list, selected first instead.");
                }

                LogHelper.Info($"✅ Loaded {consumers.Count} consumers.");
                _consumersLoaded = true;
            }
            catch (Exception ex)
            {
                LogHelper.Info($"❌ Failed to load consumers: {ex.Message}");
            }
        }

        private void RefreshPlatformDropdown(IReadOnlyList<Platform> list)
        {
            if (_platformComboBox == null) return;

            _platformComboBox.ItemsSource = list;

            // choose the default row (alias with IsDefault=true) or fall back to first
            var sel = list.FirstOrDefault(p => p.IsDefault) ?? list.FirstOrDefault();

            // Setting SelectedItem will naturally raise SelectionChanged once the control is ready.
            // Do NOT manually call PlatformComboBox_SelectionChanged here; it causes double-auth and
            // can fire before the tab controls are fully loaded.
            _platformComboBox.SelectedItem = sel;

            // Immediately push details into the panel (safe; does not require auth/token).
            if (sel != null)
                PushPlatformToFields(sel);
        }

        private void PushPlatformToFields(Platform p)
        {
            if (_platformFqdnTextBox == null)   // controls not ready yet
            {
                Dispatcher.UIThread.Post(() => PushPlatformToFields(p),
                                          DispatcherPriority.Loaded);
                return;
            }

            // ↳ Use SetCurrentValue so Avalonia won’t complain if the property is read-only at this moment
            _platformFqdnTextBox?.SetCurrentValue(TextBox.TextProperty, p.PlatformFqdn);
            _appRegIdTextBox?.SetCurrentValue(TextBox.TextProperty, p.AppId);
            _certThumbprintTextBox?.SetCurrentValue(TextBox.TextProperty, p.CertThumbprint);

            if (_consumerDropdown != null)
                _consumerDropdown.SelectedItem =
                    string.IsNullOrWhiteSpace(p.DefaultConsumer) ? "Explorer" : p.DefaultConsumer;
        }




        private IReadOnlyList<Platform> ReadPlatformsFromConfig()
        {
            var cfg = new ConfigHelper().Load();

            if (cfg.Platforms is null || cfg.Platforms.Count == 0)
                return Array.Empty<Platform>();

            string defaultAlias = cfg.DefaultPlatformAlias ?? "";

            var list = cfg.Platforms
                          .Select(p =>
                          {
                              // ► never allow an empty caption
                              string alias = string.IsNullOrWhiteSpace(p.Alias) ? p.PlatformFqdn : p.Alias;

                              return new Platform
                              {
                                  // Never allow empty Alias; use the same caption we display.
                                  Alias = alias,
                                  GroupName = alias,
                                  PlatformFqdn = p.PlatformFqdn,
                                  AppId = p.AppId,
                                  CertThumbprint = p.CertThumbprint,
                                  UseCert = p.UseCert,
                                  UserId = p.UserId ?? "",
                                  DefaultConsumer = p.DefaultConsumer,
                                  IsDefault = alias.Equals(defaultAlias, StringComparison.OrdinalIgnoreCase)
                              };
                          })
                          .OrderByDescending(p => p.IsDefault)     // put default first
                          .ThenBy(p => p.GroupName)                // then A-Z
                          .ToList();

            return list;
        }


        public string LoggedInUserDisplay
        {
            get => _loggedInUserDisplay;
            set
            {
                _loggedInUserDisplay = value;
                LogHelper.Info($"🔐 LoggedInUserDisplay set to: {value}");
                RaisePropertyChanged(nameof(LoggedInUserDisplay));
            }
        }


        public string SelectedPlatformDisplay
        {
            get => _selectedPlatformDisplay;
            set
            {
                _selectedPlatformDisplay = value;
                LogHelper.Info($"🌍 SelectedPlatformDisplay set to: {value}");
                RaisePropertyChanged(nameof(SelectedPlatformDisplay));
            }
        }



        protected void RaisePropertyChanged(string propertyName) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));


        private async void RunNowButton_Click(object? sender, RoutedEventArgs e)
        {
            if (_isRunning)
            {
                _logTextBox.Text += "⚠️ Instruction is already running. Please wait...\n";
                return;
            }

            _isRunning = true;

            try
            {
                if (_instructionListBox.SelectedItem is not string selectedName)
                {
                    _logTextBox.Text += "❌ No instruction selected.\n";
                    return;
                }

                if (!_instructionMap.TryGetValue(selectedName, out var definition))
                {
                    _logTextBox.Text += "❌ Instruction definition not found.\n";
                    return;
                }

                var parameters = _configTab.CollectParametersFromPanels(); // <- returns Dictionary<string, object>

                string? targetingMode = null;
                if (_fqdnRadio.IsChecked == true)
                    targetingMode = "FQDN";
                else if (_mgRadio.IsChecked == true)
                    targetingMode = "MG";
                else if (_coverageRadio.IsChecked == true)
                    targetingMode = "Coverage";

                _logTextBox.Text += $"📌 Targeting mode: {targetingMode ?? "null"}\n";
                _logTextBox.Text += $"❌ FQDN = {_fqdn}.\n";

                string fqdnInput = _fqdnTextBox?.Text ?? "";
                string matchType = _matchTypeComboBox?.SelectedItem?.ToString() ?? "";
                string coverageTagName = _coverageTagNameComboBox?.SelectedItem?.ToString() ?? "";
                string coverageTagValue = _coverageTagValueComboBox?.SelectedItem?.ToString() ?? "";
                var mg = _managementGroupComboBox?.SelectedItem as ManagementGroup;
                var selectedFqdns = _selectedFqdnListBox?.Items.Cast<string>().ToList() ?? new List<string>();

                int instructionTtl = ConvertTtlToMinutes(_instructionTtlBox.Text, (_instructionTtlUnitDropdown.SelectedItem as ComboBoxItem)?.Content?.ToString());
                int responseTtl = ConvertTtlToMinutes(_responseTtlBox.Text, (_responseTtlUnitDropdown.SelectedItem as ComboBoxItem)?.Content?.ToString());

                var logger = new TextBoxLogger(_logTextBox);
                bool requireCoverage = (_platformComboBox?.SelectedItem as TV1_InstructionOffloader.Models.Platform)?.RequireCoverage == true;

				var token = ResolveTokenForFqdn(_fqdn ?? _platformUrl ?? _selectedPlatform?.PlatformFqdn);
				if (string.IsNullOrWhiteSpace(token))
				{
					_logTextBox.Text += "❌ No authentication token found. Please authenticate and try again.\n";
					return;
				}

                await _instructionService.RunInstructionFromMainTabAsync(
                    definition,
                    parameters,
                    targetingMode,
                    _fqdn,
                    token,
                    _consumerName,
                    fqdnInput,
                    matchType,
                    mg,
                    coverageTagName,
                    coverageTagValue,
                    selectedFqdns,
                    instructionTtl,
                    responseTtl,
                    logger);
            }
            finally
            {
                _isRunning = false;
            }
        }




        private void TargetModeRadio_Checked(object? sender, RoutedEventArgs e)
        {
            // Manually uncheck the others
            if (sender == _fqdnRadio)
            {
                _mgRadio.IsChecked = false;
                _coverageRadio.IsChecked = false;
            }
            else if (sender == _mgRadio)
            {
                _fqdnRadio.IsChecked = false;
                _coverageRadio.IsChecked = false;
            }
            else if (sender == _coverageRadio)
            {
                _fqdnRadio.IsChecked = false;
                _mgRadio.IsChecked = false;
            }

            UpdateTargetingVisibility();

            _logTextBox.Text += ($"[Checked] FQDN: {_fqdnRadio.IsChecked}, MG: {_mgRadio.IsChecked}, Coverage: {_coverageRadio.IsChecked}");
            if (_configTab != null)
                _configTab.UpdateTargetingVisibility(GetSelectedTargetingMethod());

        }


        private void OnExportFormatChanged(object? sender, RoutedEventArgs e)
        {
            string selectedFormat;

            if (sender is RadioButton rb)
            {
                selectedFormat = rb.Content?.ToString() ?? "Unknown";
            }
            else
            {
                // Called manually (e.g., on window open), try to infer selected format
                _logTextBox.Text += "ℹ️ Initializing export format panel visibility without sender.\n";

                // Check which one is checked manually
                if (this.FindControl<RadioButton>("CsvRadio")?.IsChecked == true) selectedFormat = "CSV";
                else if (this.FindControl<RadioButton>("TsvRadio")?.IsChecked == true) selectedFormat = "TSV";
                else if (this.FindControl<RadioButton>("XlsxRadio")?.IsChecked == true) selectedFormat = "XLSX";
                else if (this.FindControl<RadioButton>("SqlRadio")?.IsChecked == true) selectedFormat = "SQL";
                else if (this.FindControl<RadioButton>("MySqlRadio")?.IsChecked == true) selectedFormat = "MySQL";
                else if (this.FindControl<RadioButton>("OracleRadio")?.IsChecked == true) selectedFormat = "Oracle";
                else selectedFormat = "Unknown";
            }

            bool isFileExport = selectedFormat is "CSV" or "TSV" or "XLSX";

            _fileExportOptionsPanel.IsVisible = isFileExport;
            _dbExportOptionsPanel.IsVisible = !isFileExport;

            _logTextBox.Text += $"🛰 Export format changed to: {selectedFormat}\n";
            _logTextBox.Text += $"📁 FileExportOptionsPanel.IsVisible = {_fileExportOptionsPanel.IsVisible}\n";
            _logTextBox.Text += $"🗄️ DbExportOptionsPanel.IsVisible = {_dbExportOptionsPanel.IsVisible}\n";
        }

        // MainWindow.axaml.cs
        // -----------------------------------------------------------------
        private void OnInstructionSelected(object? sender, SelectionChangedEventArgs e)
        {
            // ─── 1. Guard clauses ───────────────────────────────────────────────
            if (_instructionListBox?.SelectedItem is not InstructionDefinition def)
            {
                Log("⚠️  OnInstructionSelected fired, but no item selected.");
                return;
            }

            // ─── 2. Update backing field & log ─────────────────────────────────
            _selectedInstruction = def;
            Log($"ℹ️  Instruction selected: {_selectedInstruction.Name} "
                + $"(ID {_selectedInstruction.Id})");

            // ─── 3. Description text ───────────────────────────────────────────
            _instructionDescriptionTextBlock ??=
                _configTab.FindControl<TextBlock>("InstructionDescriptionTextBlock");

            _instructionDescriptionTextBlock.Text = def.Description ?? "(no description)";

            // ─── 4. Parameter editors ──────────────────────────────────────────
            _parametersPanel ??= _configTab.FindControl<StackPanel>("ParametersPanel");

            if (_parametersPanel == null)
            {
                Log("❌ ParametersPanel not found – cannot build editors.");
                return;
            }

            _parametersPanel.Children.Clear();
            foreach (var p in def.Parameters ?? new List<Parameter>())
                _parametersPanel.Children.Add(BuildParameterRow(p));

            // ─── 5. TTL values – show exactly as minutes ───────────────────────
            _configTab.PopulateTtlFields(def);

            // ─── 6. UI state: enable Preview / disable Run until Preview done ──
            if (_previewTargetButton != null) _previewTargetButton.IsEnabled = true;
            if (_runNowButton != null) _runNowButton.IsEnabled = false;
        }


        private void LogOnce(string message)
        {
            if (_loggedMessages.Contains(message)) return;
            _loggedMessages.Add(message);
            _logTextBox.Text += $"{DateTime.Now:HH:mm:ss} {message}\n";
        }



        private void DisplayPreviewResult(JObject previewResult)
        {
            // This is often called after an await; always marshal UI updates back to the UI thread.
            Dispatcher.UIThread.Post(() =>
            {
                try
                {
                    var configTab = this.FindControl<ConfigTab>("ConfigTabHost");

                    var estimatedLabel = configTab?.FindControl<TextBlock>("EstimatedCountLabel")
                                       ?? configTab?.FindControl<TextBlock>("EstimatedTargetsLabel")
                                       ?? configTab?.FindControl<TextBlock>("EstimatedTargetsText")
                                       ?? configTab?.FindControl<TextBlock>("EstimatedTargets");

                    var onlineLabel = configTab?.FindControl<TextBlock>("OnlineCountLabel")
                                    ?? configTab?.FindControl<TextBlock>("OnlineTargetsLabel")
                                    ?? configTab?.FindControl<TextBlock>("OnlineTargetsText")
                                    ?? configTab?.FindControl<TextBlock>("OnlineTargets");

                    var offlineLabel = configTab?.FindControl<TextBlock>("OfflineCountLabel")
                                     ?? configTab?.FindControl<TextBlock>("OfflineTargetsLabel")
                                     ?? configTab?.FindControl<TextBlock>("OfflineTargetsText")
                                     ?? configTab?.FindControl<TextBlock>("OfflineTargets");

                    int online = previewResult["TotalDevicesOnline"]?.Value<int>() ?? 0;
                    int offline = previewResult["TotalDevicesOffline"]?.Value<int>() ?? 0;
                    int estimated = previewResult.SelectToken("Summary.EstimatedCount")?.Value<int?>()
                                  ?? previewResult["EstimatedCount"]?.Value<int?>()
                                  ?? (online + offline);

                    if (estimatedLabel != null)
                        estimatedLabel.Text = $"Estimated: {estimated:N0}";
                    else
                        _logTextBox.Text += "⚠️ EstimatedCountLabel not found.";

                    if (onlineLabel != null)
                        onlineLabel.Text = $"Online: {online:N0}";
                    else
                        _logTextBox.Text += "⚠️ OnlineCountLabel not found.";

                    if (offlineLabel != null)
                        offlineLabel.Text = $"Offline: {offline:N0}";
                    else
                        _logTextBox.Text += "⚠️ OfflineCountLabel not found.";
                }
                catch (Exception ex)
                {
                    try
                    {
                        _logTextBox.Text += $"❌ Failed to update preview UI: {ex.Message}";
                    }
                    catch { }
                }
            });
        }


        private void UpdateTargetingVisibility()
        {
            if (_targetingFqdnBox != null)
                _targetingFqdnBox.IsVisible = false;

            if (_mgDropdown != null)
                _mgDropdown.IsVisible = false;

            if (_coverageDropdownPanel != null)
                _coverageDropdownPanel.IsVisible = false;

            if (_fqdnRadio?.IsChecked == true && _targetingFqdnBox != null)
            {
                _targetingFqdnBox.IsVisible = true;
            }
            else if (_mgRadio?.IsChecked == true && _mgDropdown != null)
            {
                _mgDropdown.IsVisible = true;
            }
            else if (_coverageRadio?.IsChecked == true && _coverageDropdownPanel != null)
            {
                _coverageDropdownPanel.IsVisible = true;
            }
        }



        private void RenderParameters(StackPanel panel, List<Parameter>? parameters)
        {
            panel.Children.Clear();                    // ← wipe previous rows

            if (parameters == null || parameters.Count == 0)
                return;

            foreach (var param in parameters)
            {
                var row = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                    Spacing = 8,
                    Margin = new Thickness(0, 4, 0, 4)
                };

                // Label
                row.Children.Add(new TextBlock
                {
                    Text = $"{param.Name}:",
                    Width = 150,
                    VerticalAlignment = VerticalAlignment.Center
                });

                // Input
                Control input;
                if (param.AllowedValues is { Count: > 0 })
                {
                    input = new ComboBox
                    {
                        Width = 200,
                        ItemsSource = param.AllowedValues,
                        SelectedItem = param.DefaultValue ?? param.AllowedValues.First()
                    };
                }
                else
                {
                    input = new TextBox
                    {
                        Width = 200,
                        Text = param.DefaultValue ?? ""
                    };
                }

                input.Tag = param.Name;                // tag for later lookup
                row.Children.Add(input);
                panel.Children.Add(row);
            }
        }

        private string? ResolvePlatformUrl()
        {
            _fqdnBox ??= this.FindControl<TextBox>("FqdnBox");
            LogHelper.Info($"📦 _fqdnBox is {(_fqdnBox == null ? "null" : "initialized")}");

            string? platformUrl = _fqdnBox?.Text?.Trim();
            LogHelper.Info($"🔍 FQDN from _fqdnBox: {platformUrl}");

            if (string.IsNullOrWhiteSpace(platformUrl))
            {
                platformUrl = (_platformDropdown?.SelectedItem as Platform)?.PlatformFqdn?.Trim();
                LogHelper.Info($"🔍 FQDN from _platformDropdown: {platformUrl}");
            }

            if (string.IsNullOrWhiteSpace(platformUrl))
            {
                string? defaultAlias = _config?.DefaultPlatformAlias?.Trim().ToLowerInvariant();
                LogHelper.Info($"🔍 Default alias from config: {defaultAlias}");

                var platforms = _config?.Platforms?.ToList();
                if (platforms == null || platforms.Count == 0)
                {
                    LogHelper.Info("⚠️ No platforms loaded from config.");
                    return null;
                }

                LogHelper.Info("🧪 Available platforms:");
                foreach (var p in platforms)
                {
                    LogHelper.Info($"  → Alias: \"{p.Alias?.Trim()}\", FQDN: \"{p.PlatformFqdn}\"");
                }

                var defaultPlatform = platforms.FirstOrDefault(p =>
                    !string.IsNullOrWhiteSpace(p.Alias) &&
                    p.Alias.Trim().ToLowerInvariant() == defaultAlias);

                if (defaultPlatform == null)
                {
                    LogHelper.Info("⚠️ No matching platform found for DefaultPlatformAlias. Falling back to first valid platform.");
                    defaultPlatform = platforms.FirstOrDefault(p =>
                        !string.IsNullOrWhiteSpace(p.PlatformFqdn));
                }

                platformUrl = defaultPlatform?.PlatformFqdn?.Trim();
                LogHelper.Info($"🌐 Resolved platformUrl = {platformUrl}");
            }


            return platformUrl;
        }


        private async Task AuthenticateAndInitialize()
        {
            // 0) If we already have a token, nothing to do
            if (!string.IsNullOrEmpty(_token))
                return;

            try
            {
                // 1) Resolve whatever URL/text is currently in play
                _fqdn = ResolvePlatformUrl();

                // 2) FIRST RUN OR NO PLATFORMS CONFIGURED?
                if (_config?.Platforms == null || _config.Platforms.Count == 0 || string.IsNullOrWhiteSpace(_fqdn))
                {
                    Dispatcher.UIThread.Post(async () =>
                    {
                        // a) Jump the main UI into the Config tab
                        var mainTabs = this.FindControl<TabControl>("MainTabControl");
                        if (mainTabs != null)
                            mainTabs.SelectedIndex = 2; // index of “Config”

                        // b) Switch to the Platforms sub-tab
                        _configTab?.SwitchToPlatformTab("⚠️ Please add or select a platform before proceeding.");

                        // c) Programmatically “click” your Add button so fields appear
                        var platformsView = _configTab?.FindControl<PlatformsTab>("PlatformsTabHost");
                        if (platformsView?.DataContext is PlatformConfigViewModel pvm)
                            pvm.AddPlatformCommand.Execute().Subscribe();

                        // d) Prompt the user
                        await MessageBox.Show(this, "Please add a new platform entry to continue.");
                    });

                    return;
                }

                // 3) NORMAL RUN: pick up the user’s choice or fallback to the Fqdn text-box
                var selectedPlatform = _platformComboBox?.SelectedItem as Platform;

                if (selectedPlatform == null)
                {
                    LogHelper.Info("...... No platform is selected yet (ConfigTab not ready). Skipping automatic authentication.");
                    return;
                }

                if (selectedPlatform != null)
                {
                    _fqdn = selectedPlatform.PlatformFqdn;
                }
                else
                {
                    _fqdnBox ??= this.FindControl<TextBox>("FqdnBox");
                    _fqdn = _fqdnBox?.Text?.Trim();
                    if (string.IsNullOrWhiteSpace(_fqdn))
                        return; // nothing to authenticate against
                }

                // 4) Build your settings object
                var settings = new PlatformSettings
                {
                    PlatformFqdn = _fqdn,
                    AppId = selectedPlatform?.AppId ?? "",
                    CertThumbprint = selectedPlatform?.CertThumbprint ?? "",
                    // Prefer the platform's configured auth mode; fall back to UI radio.
                    UseCert = selectedPlatform?.UseCert ?? (_authCertRadio?.IsChecked == true),
                    // IMPORTANT: Pass through UPN/UserId when configured. Some tenants require this
                    // for cert principal mapping when a kid matches multiple entries/wildcards.
                    UserId = selectedPlatform?.UserId ?? "",
                    AuthenticationMode = (_authModeComboBox?.SelectedItem as ComboBoxItem)?
                                            .Content?.ToString() ?? ""
                };

                Log($"🔐 Authenticating to {_fqdn} using {(settings.UseCert ? "Certificate" : "Interactive")}…");

                // 5) Call your auth service
                var result = await _authService.AuthenticateAsync(settings);

                if (!string.IsNullOrWhiteSpace(result?.Token))
                {
                    // 6) Success!
                    _token = result.Token;

                    // 6a) Optionally save for dev reuse
                    var cfg = new ConfigHelper().Load();
                    if (cfg.EnableDevTokenReuse)
                        _tokenStoreService.SaveToken(_authService.CurrentPlatformFqdn, _authService.Token);

                    // 6b) Update displays
                    SelectedPlatformDisplay = $"Server: {_fqdn}";
                    var displayName = await _authService.GetDisplayNameFromWhoAmIAsync(_fqdn, _token);
                    LoggedInUserDisplay = $"User: {displayName ?? result.PrincipalName ?? "Unknown"}";

                    _logTextBox.Text +=
                        $"🔧 Updated bindings → UserDisplay: {LoggedInUserDisplay}, PlatformDisplay: {SelectedPlatformDisplay}";
                    Log("✅ Authentication successful.");

                    // 6c) Initialize the rest of your data
                    await InitializeDataAsync();
                    _allInstructions = await _instructionHelper.LoadInstructionsAsync(_fqdn, _token, _logTextBox);
                    if (_configTab != null)
                    {
                        _configTab.SetInstructions(_allInstructions);
                    }
                    else
                    {
                        _logTextBox.Text += "⚠️ ConfigTab is null. Cannot set instructions list.\n";
                    }
                }
                else
                {
                    // 7) Failure path
                    Log("❌ Authentication failed.");
                    await MessageBox.Show(this, "Authentication failed.");
                }
            }
            catch (Exception ex)
            {
                // 8) Unexpected errors
                Log($"❌ Auth error: {ex.Message}");
                await MessageBox.Show(this, $"Auth error: {ex.Message}");
            }
        }

        public async Task InitializePlatformAsync()
        {
            await _instructionHelper.LoadManagementGroupsAsync(_fqdn, _token, _mgDropdown, _logTextBox);
            await _instructionHelper.LoadCustomPropertiesAsync(_fqdn, _token, _coverageTagNameDropdown, _coverageTagValueDropdown, _logTextBox);
            await OnLoadConsumersAsync();
            _allInstructions = await _instructionHelper.LoadInstructionsAsync(_fqdn, _token, _logTextBox);
        }
        public void UpdatePlatformDisplayState(PlatformDisplay display)
        {
            _fqdn = display.PlatformFqdn;
            _consumerName = string.IsNullOrWhiteSpace(display.DefaultConsumer)
                ? "Explorer"
                : display.DefaultConsumer;

            LogHelper.Info($"🌐 Selected platform → FQDN: {display.PlatformFqdn}\n");
        }

        private void OnExportPathClicked(object? sender, PointerPressedEventArgs e)
        {
            if (sender is TextBlock tb)
            {
                var path = tb.Tag as string;
                if (string.IsNullOrWhiteSpace(path))
                    path = tb.Text;

                if (string.IsNullOrWhiteSpace(path))
                    return;

                try
                {
                    // File/dir path or URL.
                    if (File.Exists(path) || Directory.Exists(path) || path.StartsWith("http://", StringComparison.OrdinalIgnoreCase) || path.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
                    {
                        Process.Start(new ProcessStartInfo
                        {
                            FileName = path,
                            UseShellExecute = true
                        });
                    }
                }
                catch (Exception ex)
                {
                    LogHelper.Warn($"⚠️ Failed to open export path: {ex.Message}");
                }
            }
        }


        private async Task InitializeInstructionsAsync()
        {
            try
            {
                _allInstructions = await _instructionHelper
                    .LoadInstructionsAsync(_fqdn, _token, _logTextBox);
                _configTab?.SetInstructions(_allInstructions);

            }
            catch (Exception ex)
            {
                _logTextBox.Text += $"❌ Failed to load instructions: {ex.Message}\n";
            }
        }
        public void SetPlatformState(string fqdn, string token, string consumer)
        {
            _fqdn = fqdn;
            _token = token;
            _consumerName = consumer;
        }


        public async Task InitializeDataAsync()
        {
            try
            {
                await OnLoadConsumersAsync();
                await _instructionHelper.LoadManagementGroupsAsync(_fqdn, _token, _managementGroupComboBox, _logTextBox);

                await _instructionHelper.LoadCustomPropertiesAsync(
            _fqdn,
            _token,
            _coverageTagNameDropdown,
            _coverageTagValueDropdown,
            _logTextBox);

                // Hook event to dynamically load values for the selected tag
                if (_coverageTagNameDropdown != null && _coverageTagValueDropdown != null)
                {
                    _coverageTagNameDropdown.SelectionChanged += (_, _) =>
                    {
                        if (_coverageTagNameDropdown.SelectedItem is not string selectedTag) return;

                        var values = _instructionHelper.GetTagValuesByName(selectedTag);
                        _coverageTagValueDropdown.ItemsSource = values;
                        if (values?.Count > 0)
                            _coverageTagValueDropdown.SelectedIndex = 0;
                    };
                }
                else
                {
                    // LogHelper.Info("⚠️ Coverage tag dropdowns are not initialized.\n");
                }


                if (_createJobButton != null)
                    _createJobButton.Click += CreateOrUpdateJobButton_Click;   // ← new name


                // await LoadScheduledJobs();
                //_scheduledJobsDataGrid.ItemsSource = ScheduledJobs;
                //RefreshScheduledJobsGrid();


                if (_platformComboBox == null)
                {
                    // ConfigTab may not be loaded yet; don't treat as a hard error.
                    _logTextBox.Text += "ℹ️ PlatformComboBox not yet available (ConfigTab not loaded).\n";
                }
                else
                {
                    _platformComboBox.SelectionChanged += PlatformComboBox_SelectionChanged;
                }

                _allInstructions = await _instructionHelper.LoadInstructionsAsync(_fqdn, _token, _logTextBox);
                if (_instructionListBox != null)
                {
                }
                else
                {
                    _logTextBox.Text += "⚠️ _instructionListBox is null. Cannot set ItemsSource.\n";
                }

                _configTab?.SetInstructions(_allInstructions);


                Log("📦 Loaded instructions and dropdown data.");
            }
            catch (Exception ex)
            {
                Log($"❌ Error loading data: {ex.Message}");
                await MessageBox.Show(this, $"Error loading data: {ex.Message}");
            }
        }

        private void Log(string message)
        {
            if (_logTextBox != null)
            {
                _logTextBox.Text += $"{DateTime.Now:HH:mm:ss} {message}\n";
            }
        }


        public static class MessageBox
        {
            public static async Task Show(Window parent, string message)
            {
                var dialog = new Window
                {
                    Title = "Message",
                    Width = 400,
                    Height = 180,
                    WindowStartupLocation = WindowStartupLocation.CenterOwner,
                    Content = new StackPanel
                    {
                        Children =
                {
                    new TextBlock
                    {
                        Text = message,
                        Margin = new Thickness(20),
                        TextWrapping = TextWrapping.Wrap
                    },
                    new Button
                    {
                        Content = "OK",
                        HorizontalAlignment = HorizontalAlignment.Center,
                        Width = 80,
                        Margin = new Thickness(0, 10, 0, 0),
                        IsDefault = true,
                        IsCancel = true
                    }
                }
                    }
                };

                ((Button)((StackPanel)dialog.Content).Children[1]).Click += (_, _) => dialog.Close();

                await dialog.ShowDialog(parent);
            }
        }

        private void ScheduledJobsListBox_SelectionChanged(object? sender, SelectionChangedEventArgs e)
        {
            // Ignore if there is no newly-added item
            if (e.AddedItems == null || e.AddedItems.Count == 0) return;

            if (e.AddedItems[0] is not ScheduledJob selected) return;

            // Ignore if we already pointed to this job
            if (ReferenceEquals(selected, _jobsVm.SelectedScheduledJob)) return;

            _logTextBox.Text += $"📌 Selected job: {selected.InstructionName} (ID: {selected.InstructionId})\n";
            _jobsVm.SelectedScheduledJob = selected;
        }


        private async void CreateOrUpdateJobButton_Click(object? sender, RoutedEventArgs e)
        {
            try
            {
                // 0️⃣ Are we editing an existing job?
                bool isEdit = _jobsVm.SelectedScheduledJob != null;
                string jobId = isEdit
                    ? _jobsVm.SelectedScheduledJob!.JobId
                    : Guid.NewGuid().ToString();

                // ① Gather instruction parameters
                var objectParams = _configTab.CollectParametersFromPanels();

                var paramDict = objectParams
                    .Where(kvp => kvp.Value != null)
                    .ToDictionary(kvp => kvp.Key, kvp => kvp.Value?.ToString() ?? "");

                // ✅ Per-job export settings must come from the ConfigTab UI (not global defaults).
                var selectedPlatform = _configTab?.GetSelectedPlatform();
                var exportModeFromUi = _configTab?.GetSelectedExportModeFromUi() ?? ExportMode.PagingOnly;
                var exportFolderModeFromUi = _configTab?.GetSelectedExportFolderModeFromUi() ?? ExportFolderMode.ByInstructionThenDate;

                // Determine targeting strictly from the currently-selected radio button.
                // Do NOT persist multiple targeting types in the job JSON.
                string method = string.Empty;
                string fqdn = string.Empty;
                string mg = string.Empty;
                string tagName = string.Empty;
                string tagValue = string.Empty;
                int? mgUsableId = null;

                try
                {
                    if (_fqdnRadio?.IsChecked == true)
                    {
                        method = "FQDN";
                        fqdn = (_targetingFqdnBox?.Text ?? string.Empty).Trim();
                    }
                    else if (_mgRadio?.IsChecked == true)
                    {
                        method = "MG";

                        var sel = _mgDropdown?.SelectedItem;
                        if (sel is ComboBoxItem cbi)
                        {
                            mg = (cbi.Content?.ToString() ?? string.Empty).Trim();
                        }
                        else if (sel is string s)
                        {
                            mg = s.Trim();
                        }
                        else if (sel != null)
                        {
                            var t = sel.GetType();
                            var nameProp = t.GetProperty("Name");
                            var idProp = t.GetProperty("UsableId") ?? t.GetProperty("Id") ?? t.GetProperty("ManagementGroupId");
                            if (nameProp != null)
                                mg = (nameProp.GetValue(sel)?.ToString() ?? string.Empty).Trim();
                            if (idProp != null)
                            {
                                var raw = idProp.GetValue(sel);
                                if (raw is int i) mgUsableId = i;
                                else if (raw is long l) mgUsableId = (int)l;
                                else if (raw != null && int.TryParse(raw.ToString(), out var parsed)) mgUsableId = parsed;
                            }
                        }

                        if (!string.IsNullOrWhiteSpace(mg) &&
                            (string.Equals(mg, "All Devices", StringComparison.OrdinalIgnoreCase) ||
                             string.Equals(mg, "Global", StringComparison.OrdinalIgnoreCase) ||
                             string.Equals(mg, "global", StringComparison.OrdinalIgnoreCase)))
                        {
                            mgUsableId = -1;
                            mg = "All Devices";
                        }
                    }
                    else if (_coverageRadio?.IsChecked == true)
                    {
                        method = "Tag";
                        tagName = (_coverageTagNameComboBox?.SelectedItem?.ToString() ?? string.Empty).Trim();
                        tagValue = (_coverageTagValueComboBox?.SelectedItem?.ToString() ?? string.Empty).Trim();

                        // When coverage is compulsory for a platform, multi-tenant expects managementgroup == "global".
                        // Persist "All Devices" (-1) alongside the tag so the scheduler can build the correct scope.
                        var platform = _configTab?.GetSelectedPlatform();
                        if (platform?.RequireCoverage == true)
                        {
                            mgUsableId = -1;
                            mg = "All Devices";
                        }
                    }
                }
                catch
                {
                    // Never block job save on targeting UI resolution.
                }

                Log($"🧪 Collected {paramDict.Count} parameters");

                var pickedTime = _startTimePicker?.SelectedTime;
                if (pickedTime is null)
                {
                    pickedTime = DateTime.Now.TimeOfDay.Truncate(TimeSpan.FromMinutes(1));
                    Log($"⚠️ No StartTime picked. Using fallback: {pickedTime:hh\\:mm}");
                }
                else
                {
                    Log($"⏰ StartTime picked: {pickedTime:hh\\:mm}");
                }

                // ② Build the job object
                var newJob = new ScheduledJob
                {
                    JobId = jobId,

                    InstructionName = _currentInstructionName ?? "Instruction",
                    InstructionId = _currentInstructionId,

                    InstructionTtlMinutes = int.TryParse(_instructionTtlBox?.Text, out var ttl) ? ttl : 10,
                    InstructionTtlUnit = (_instructionTtlUnitDropdown?.SelectedItem as ComboBoxItem)
                                 ?.Content?.ToString() ?? "Minutes",

                    ResponseTtlMinutes = int.TryParse(_responseTtlBox?.Text, out var rttl) ? rttl : 24,
                    ResponseTtlUnit = (_responseTtlUnitDropdown?.SelectedItem as ComboBoxItem)
                                 ?.Content?.ToString() ?? "Hours",

                    StartTime = pickedTime,

                    Recurrence = (_recurrenceComboBox?.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Once",
                    DaysOfWeek = GetSelectedDaysOfWeek(),
                    WeeklyRepeatCount = (int)(_weeklyRepeatCount?.Value ?? 1),
                    MonthlyRepeatCount = (int)(_monthlyRepeatCount?.Value ?? 1),
                    MonthlyDayFallback = (int)(_monthlyDay?.Value ?? 1),
                    MonthlyWeekOffsets = GetSelectedMonthlyWeekOffsets(),

                    StartDate = GetCalendarDate(_startDatePicker?.SelectedDate),
                    EndDate = GetCalendarDate(_endDatePicker?.SelectedDate),

                    TargetingMethod = method,
                    TargetingFqdn = fqdn,
                    TargetingManagementGroup = mg,
                    ManagementGroupId = mgUsableId,
                    CoverageTagName = tagName,
                    CoverageTagValue = tagValue,

                    PlatformAlias = selectedPlatform?.Alias ?? string.Empty,
                    PlatformFqdn = selectedPlatform?.PlatformFqdn ?? _platformFqdnTextBox?.Text ?? "",
                    AppRegistrationId = _appRegIdTextBox?.Text ?? "",
                    CertThumbprint = _certThumbprintTextBox?.Text ?? "",

                    ExportFormat = (_exportFormatComboBox?.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "CSV",
                    Consumer = (_consumerDropdown?.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Explorer",
                    AuthenticationMode = (_authModeComboBox?.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "",

                    EnableExport = true,
                    ExportTtlMinutes = int.TryParse(_responseTtlBox?.Text, out var exportTtl) ? exportTtl : 24,
                    ExportMode = exportModeFromUi,
                    ExportFolderMode = exportFolderModeFromUi,

                    Parameters = paramDict
                };

                LogHelper.Info($"JOB SAVE DEBUG: exportMode={newJob.ExportMode} folderMode={newJob.ExportFolderMode} alias='{newJob.PlatformAlias}' fqdn='{newJob.PlatformFqdn}'");

                // ③ Save job

                _jobsVm.SelectedScheduledJob = newJob;
                await _jobsVm.CreateJobAsync();  // ✅ Handles both Create and Update
                RefreshScheduledJobs();

                if (isEdit)
                {
                    Log($"✏️ Updated job “{newJob.InstructionName}”.");
                }
                else
                {
                    Log($"➕ Added job “{newJob.InstructionName}”.");
                }
            }
            catch (Exception ex)
            {
                Log($"❌ Failed to create/update job: {ex.Message}");
            }
        }



        private async void CopyScheduledJobButton_Click(object? sender, RoutedEventArgs e)
        {
            // We allow copy from either DataGrid or ListBox
            var selectedJob =
                   _scheduledJobsDataGrid?.SelectedItem as ScheduledJob;       // new DataGrid

            if (selectedJob == null)
            {
                _logTextBox.Text += "⚠️ No scheduled job selected to copy.\n";
                return;
            }

            // Deep-clone the job (manual copy so we can tweak fields)
            var copiedJob = new ScheduledJob
            {
                JobId = Guid.NewGuid().ToString(),
                InstructionName = selectedJob.InstructionName + " (Copy)",
                InstructionId = selectedJob.InstructionId,

                PlatformAlias = selectedJob.PlatformAlias,
                PlatformFqdn = selectedJob.PlatformFqdn,
                AppRegistrationId = selectedJob.AppRegistrationId,
                CertThumbprint = selectedJob.CertThumbprint,
                AuthenticationMode = selectedJob.AuthenticationMode,

                InstructionTtlMinutes = selectedJob.InstructionTtlMinutes,
                InstructionTtlUnit = selectedJob.InstructionTtlUnit,
                ResponseTtlMinutes = selectedJob.ResponseTtlMinutes,
                ResponseTtlUnit = selectedJob.ResponseTtlUnit,

                ExportFormat = selectedJob.ExportFormat,
                Consumer = selectedJob.Consumer,

                StartDate = selectedJob.StartDate,
                EndDate = selectedJob.EndDate,
                StartTime = selectedJob.StartTime,

                Recurrence = selectedJob.Recurrence,
                DaysOfWeek = new List<DayOfWeek>(selectedJob.DaysOfWeek),
                WeeklyRepeatCount = selectedJob.WeeklyRepeatCount,
                MonthlyRepeatCount = selectedJob.MonthlyRepeatCount,
                MonthlyWeekOffsets = new List<int>(selectedJob.MonthlyWeekOffsets),
                MonthlyDayFallback = selectedJob.MonthlyDayFallback,

                TargetingMethod = selectedJob.TargetingMethod,
                IsRunning = false,

                // NEW: copy any instruction parameters
                Parameters = selectedJob.Parameters != null
                                       ? new Dictionary<string, string>(selectedJob.Parameters)
                                       : new Dictionary<string, string>()
            };

            // Add to the single source of truth
            _jobsVm.ScheduledJobs.Add(copiedJob);
            await _jobsVm.SaveJobsAsync();
            RefreshScheduledJobs();

            _logTextBox.Text += $"✅ Copied job: {copiedJob.InstructionName} (New ID: {copiedJob.JobId})\n";

            // Reselect in whichever control you’re displaying
            if (_scheduledJobsDataGrid != null)
                _scheduledJobsDataGrid.SelectedItem = copiedJob;

            _jobsVm.SelectedScheduledJob = copiedJob;   // keep ViewModel in sync
        }

        private void LogMessageHandler(string message)
        {
            // Append to your log TextBox on the UI thread:
            Dispatcher.UIThread.Post(() =>
            {
                var logTextBox = this.FindControl<TextBox>("LogTextBox");
                if (logTextBox != null)
                {
                    logTextBox.Text += message + Environment.NewLine;
                }
            });
        }


        public void SetLoggedInUserDisplay(string? user)
        {
            LoggedInUserDisplay = $"User: {user ?? "Unknown"}";
            LogHelper.Info($"👤 LoggedInUserDisplay set to: {LoggedInUserDisplay}");
        }

        public void AppendUiLog(string message)
        {
            try
            {
                if (_logTextBox == null)
                    return;

                _logTextBox.Text += $"{DateTime.Now:HH:mm:ss} {message}\n";
            }
            catch
            {
                // Never throw from logging
            }
        }


        public void SetSelectedPlatformDisplay(string fqdn)
        {
            SelectedPlatformDisplay = $"Server: {fqdn}";
            LogHelper.Info($"🌍 SelectedPlatformDisplay set to: {SelectedPlatformDisplay}");
        }


        private async Task OnPlatformSelectedAsync(Platform sel)
        {
            // 1. Update text-boxes
            _platformFqdnTextBox?.SetCurrentValue(TextBox.TextProperty, sel.PlatformFqdn);
            _appRegIdTextBox?.SetCurrentValue(TextBox.TextProperty, sel.AppId);
            _certThumbprintTextBox?.SetCurrentValue(TextBox.TextProperty, sel.CertThumbprint);


            // 2. Auth / token reuse exactly like before …
            // (use the body of your former PlatformComboBox_SelectionChanged)
        }
        private void OnConfigTabLoaded(object? sender, RoutedEventArgs e)
        {
            Log("✅ ConfigTab loaded – running HookConfigTabControls");
            HookConfigTabControls();   // ← now safe
        }


        private void HookConfigTabControls()
        {
            if (_configTabControlsHooked) return;

            _configTab = this.FindControl<ConfigTab>("ConfigTabHost");
            if (_configTab is null)
            {
                LogHelper.Info("❌ ConfigTabHost missing");
                return;
            }

            // If the scheduler is already created (e.g., jobs loaded before ConfigTab visual tree), attach it now.
            if (_scheduler != null)
            {
                _configTab.SetJobScheduler(_jobsVm, _scheduler);
            }
            _configTab.SetDependencies(
                _instructionService,
                _tokenStoreService,
                _authService,
                _instructionHelper,
                _jobsVm,
                _jobSchedulerService);

            _instructionListBox = _configTab.FindControl<ListBox>("InstructionListBox");
            _platformComboBox = _configTab.FindControl<ComboBox>("PlatformComboBox");
            _jobsDataGrid = this.FindControl<DataGrid>("JobsDataGrid");

            if (_instructionListBox != null)
            {
                _instructionListBox.SelectionChanged -= OnInstructionSelected;
                _instructionListBox.SelectionChanged += OnInstructionSelected;
                LogHelper.Info("✅ InstructionListBox found and SelectionChanged wired");
            }
            else
            {
                LogHelper.Info("❌ InstructionListBox still null.");
            }

            if (_jobsDataGrid == null)
                LogHelper.Info("❌ JobsDataGrid not found – check x:Name in XAML.");

            _consumerComboBox = _configTab?.FindControl<ComboBox>("ConsumerDropdown");

            _configTab.AttachedToVisualTree += async (_, _) =>
            {
                _parametersPanel = _configTab.FindControl<StackPanel>("ParametersPanel");
                _instructionDescriptionTextBlock = _configTab.FindControl<TextBlock>("InstructionDescriptionTextBlock");
                _instructionListBox = _configTab.FindControl<ListBox>("InstructionListBox");

                _fqdnRadio = _configTab.FindControl<RadioButton>("FqdnRadio");
                _mgRadio = _configTab.FindControl<RadioButton>("MgRadio");
                _coverageRadio = _configTab.FindControl<RadioButton>("CoverageTagRadio");

                _fqdnRadio.Checked += TargetModeRadio_Checked;
                _mgRadio.Checked += TargetModeRadio_Checked;
                _coverageRadio.Checked += TargetModeRadio_Checked;
                TargetModeRadio_Checked(null, null);

                _fqdnTextBox = _configTab.FindControl<TextBox>("FqdnInputBox");
                _managementGroupComboBox = _configTab.FindControl<ComboBox>("ManagementGroupDropdown");
                _consumerDropdown = _configTab.FindControl<ComboBox>("ConsumerDropdown");
                _coverageTagNameComboBox = _configTab.FindControl<ComboBox>("CoverageTagNameDropdown");
                _coverageTagValueComboBox = _configTab.FindControl<ComboBox>("CoverageTagValueDropdown");
                _coverageTagNameDropdown = _coverageTagNameComboBox;
                _coverageTagValueDropdown = _coverageTagValueComboBox;

                _recurrenceComboBox = _configTab.FindControl<ComboBox>("RecurrenceComboBox");
                _startTimePicker = _configTab.FindControl<TimePicker>("StartTimePicker");
                _startDatePicker = _configTab.FindControl<DatePicker>("StartDatePicker");
                _endDatePicker = _configTab.FindControl<DatePicker>("EndDatePicker");
                _recurrenceDayPanel = _configTab.FindControl<StackPanel>("RecurrenceDayPanel");
                _weeklyRepeatRow = _configTab.FindControl<StackPanel>("WeeklyRepeatRow");
                _daysOfWeekRow = _configTab.FindControl<StackPanel>("DaysOfWeekRow");
                _monthlyPanel = _configTab.FindControl<StackPanel>("MonthlyPanel");
                _monthlyRepeatCount = _configTab.FindControl<NumericUpDown>("MonthlyRepeatCount");

                _previewTargetButton = _configTab.FindControl<Button>("PreviewTargetsButton");
                _runNowButton = _configTab.FindControl<Button>("RunNowButton");
                _searchBox = _configTab.FindControl<TextBox>("InstructionSearchBox_2");

                _chkMon = _configTab.FindControl<CheckBox>("ChkMon");
                _chkTue = _configTab.FindControl<CheckBox>("ChkTue");
                _chkWed = _configTab.FindControl<CheckBox>("ChkWed");
                _chkThu = _configTab.FindControl<CheckBox>("ChkThu");
                _chkFri = _configTab.FindControl<CheckBox>("ChkFri");
                _chkSat = _configTab.FindControl<CheckBox>("ChkSat");
                _chkSun = _configTab.FindControl<CheckBox>("ChkSun");

                if (_previewTargetButton != null)
                {
                    // IMPORTANT:
                    // Preview/Run buttons are owned and wired by ConfigTab.axaml.cs.
                    // Wiring here as well causes duplicate execution (two handlers on the same button).
                    // We still locate the controls so we can enable/disable them as needed, but we do
                    // not attach Click handlers in MainWindow.
                    _previewTargetButton.Click -= Preview_Click;
                    _previewTargetButton.IsEnabled = true;
                }

                if (_runNowButton != null)
                {
                    // See note above – avoid double-wiring.
                    _runNowButton.Click -= Run_Click;
                    // Do NOT force IsEnabled here. ConfigTab owns the UX rules:
                    // - Disabled until Preview succeeds
                    // - Enabled after Preview
                }

                _platformComboBox = _configTab.FindControl<ComboBox>("PlatformComboBox");
                if (_platformComboBox != null)
                {
                    _platformComboBox.SelectionChanged -= PlatformComboBox_SelectionChanged;
                    _platformComboBox.SelectionChanged += PlatformComboBox_SelectionChanged;
                }

                // Check item count and log types
                if (_platformComboBox?.Items != null && _platformComboBox.Items.Count > 0)
                {
                    LogHelper.Info($"🔍 PlatformComboBox item count: {_platformComboBox.Items.Count}");

                    foreach (var item in _platformComboBox.Items)
                    {
                        LogHelper.Info($"🧪 PlatformComboBox item type: {item?.GetType()?.FullName}");
                    }

                    var platforms = _platformComboBox.Items.OfType<Platform>().ToList();

                    LogHelper.Info($"📦 Filtered valid Platform items: {platforms.Count}");

                    var defaultKey = _config?.DefaultPlatformFqdn;

                    // DefaultPlatformFqdn in config might be either an Alias or an actual FQDN depending on older builds.
                    var match = platforms.FirstOrDefault(p =>
                                    string.Equals(p.PlatformFqdn, defaultKey, StringComparison.OrdinalIgnoreCase) ||
                                    string.Equals(p.Alias, defaultKey, StringComparison.OrdinalIgnoreCase) ||
                                    string.Equals(p.GroupName, defaultKey, StringComparison.OrdinalIgnoreCase))
                              ?? platforms.FirstOrDefault();

                    if (match != null)
                    {
                        _platformComboBox.SelectedItem = match;
                        LogHelper.Info($"✅ Selected platform = {match.GroupName}");
                    }
                    else
                    {
                        LogHelper.Info("⚠️ No platform found to select.");
                    }
                }
                else
                {
                    LogHelper.Info("⚠️ PlatformComboBox has no items.");
                }

                if (_instructionListBox != null && _instructionListBox.ItemCount > 0 && _instructionListBox.SelectedIndex < 0 && (_configTab?.IsPopulatingJob != true))
                {
                    _instructionListBox.SelectedIndex = 0;
                    LogHelper.Info("ℹ️ Auto-selected first instruction.");
                }

                if (_consumerComboBox != null && !_consumersLoaded)
                    _ = OnLoadConsumersAsync();

                // Safety logging
                LogHelper.Info(_managementGroupComboBox == null ? "⚠️ mgDropdown is null." : "✅ mgDropdown found.");
                LogHelper.Info(_consumerDropdown == null ? "⚠️ ConsumerDropdown is null." : "✅ ConsumerDropdown found.");
                LogHelper.Info(_coverageTagNameDropdown == null ? "⚠️ CoverageTagNameDropdown is null." : "✅ CoverageTagNameDropdown found.");
                LogHelper.Info(_coverageTagValueDropdown == null ? "⚠️ CoverageTagValueDropdown is null." : "✅ CoverageTagValueDropdown found.");

                if (_configTab.DataContext is ConfigTabViewModel vm)
                {
                    vm.PlatformSelected
                      .Where(p => p != null)
                      .ObserveOn(RxApp.MainThreadScheduler)
                      .Subscribe(async p => await OnPlatformSelectedAsync(p!));
                }

                _configTab.InstructionSelected += def =>
                {
                    _selectedInstruction = def;
                    LogHelper.Info($"📌 Instruction manually selected: {def?.Name ?? "(null)"}");

                    if (def != null)
                    {
                        RenderParameters(_parametersPanel, def.Parameters);
                        if (_instructionDescriptionTextBlock != null)
                            _instructionDescriptionTextBlock.Text = def.Description ?? "(no description)";
                        _configTab.PopulateTtlFields(def);
                    }
                };

                async void Preview_Click(object? s, RoutedEventArgs e) => await OnPreviewTargetClicked();
                async void Run_Click(object? s, RoutedEventArgs e) => await TryRunSelectedInstructionAsync();

                // ✅ Run this LAST after all controls are ready
                await InitializeDataAsync();
            };

            _configTabControlsHooked = true;
        }



        private static int ConvertTtlToMinutes(int value, string unit)
        {
            if (value < 0) value = 0;

            var u = (unit ?? "").Trim().ToLowerInvariant();
            return u switch
            {
                "minute" or "minutes" => value,
                "hour" or "hours" => checked(value * 60),
                "day" or "days" => checked(value * 60 * 24),
                _ => value
            };
        }

        private static ExportMode ParseExportMode(string? mode)
        {
            if (string.IsNullOrWhiteSpace(mode))
                return ExportMode.PagingThenServer;

            var m = mode.Trim();

            // Accept both friendly strings and enum names.
            if (m.Equals("PagingOnly", StringComparison.OrdinalIgnoreCase) ||
                m.Equals("Pagination", StringComparison.OrdinalIgnoreCase))
                return ExportMode.PagingOnly;

            if (m.Equals("ServerOnly", StringComparison.OrdinalIgnoreCase) ||
                m.Equals("Server-side", StringComparison.OrdinalIgnoreCase) ||
                m.Equals("ServerSide", StringComparison.OrdinalIgnoreCase))
                return ExportMode.ServerOnly;

            if (m.Equals("PagingThenServer", StringComparison.OrdinalIgnoreCase) ||
                m.Equals("Both", StringComparison.OrdinalIgnoreCase))
                return ExportMode.PagingThenServer;

            // Try numeric
            if (int.TryParse(m, out var n))
            {
                if (Enum.IsDefined(typeof(ExportMode), n))
                    return (ExportMode)n;
            }

            return ExportMode.PagingThenServer;
        }
    }
}





