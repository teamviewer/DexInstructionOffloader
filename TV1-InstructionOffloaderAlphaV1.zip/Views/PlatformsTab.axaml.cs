﻿
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.VisualTree;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using TV1_InstructionOffloader.Helpers;
using TV1_InstructionOffloader.Models;
using TV1_InstructionOffloader.Services;
using TV1_InstructionOffloader.ViewModels;
using static TV1_InstructionOffloader.MainWindow;

namespace TV1_InstructionOffloader.Views
{
    public partial class PlatformsTab : UserControl
    {
        private ConfigTab? _configTab;
        private AuthenticationService? _authService;
        private List<PlatformSettings> _platforms = new();
        private PlatformSettings? _selectedPlatform;
        private CheckBox? _useCertCheckbox;
        private ComboBox? _platformComboBox;
        private RadioButton? _interactiveRadio;
        private RadioButton? _certRadio;
        private Button? _authButton;
        private TextBlock? _platformDisplayText;

        public PlatformsTab()
        {
            InitializeComponent();
            AttachControls();
            AttachEvents();
        

// Subscribe to ConfigTab sync events when attached
this.AttachedToVisualTree += (_, __) =>
{
    var cfg = this.FindAncestorOfType<ConfigTab>();
    if (cfg != null && _configTab != cfg)
    {
        _configTab = cfg;
        LogHelper.Info("🔗 PlatformsTab: Subscribed to ConfigTab.PlatformChanged & PlatformListChanged");
        _configTab.PlatformChanged += (alias, fqdn) =>
        {
            try
            {
                var combo = this.FindControl<ComboBox>("PlatformComboBox");
                if (combo == null) return;
                var current = combo.SelectedItem?.ToString();
                if (string.Equals(current, alias, StringComparison.OrdinalIgnoreCase)) return;
                foreach (var it in (combo.Items as System.Collections.IEnumerable) ?? new object[0])
                {
                    var s = it?.ToString();
                    if (!string.IsNullOrWhiteSpace(s) && string.Equals(s, alias, StringComparison.OrdinalIgnoreCase))
                    {
                        combo.SelectedItem = it;
                        LogHelper.Info($"🔄 PlatformsTab: Synced selection to '{alias}' ({fqdn})");
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                LogHelper.Error($"❌ PlatformsTab sync failed: {ex.Message}");
            }
        };
        _configTab.PlatformListChanged += () =>
        {
            try
            {
                LogHelper.Info("🆕 PlatformsTab: Platform list changed → reloading dropdown.");
                var combo = this.FindControl<ComboBox>("PlatformComboBox");
                if (combo == null) return;
                var settings = new ConfigHelper().Load();
                var aliases = (settings?.Platforms ?? new System.Collections.Generic.List<TV1_InstructionOffloader.Models.PlatformSettings>())
                    .Select(p => p.Alias)
                    .Where(a => !string.IsNullOrWhiteSpace(a))
                    .Distinct(StringComparer.OrdinalIgnoreCase)
                    .OrderBy(a => a, StringComparer.OrdinalIgnoreCase)
                    .ToList();
                combo.ItemsSource = aliases;
            }
            catch (Exception ex)
            {
                LogHelper.Error($"❌ PlatformsTab list reload failed: {ex.Message}");
            }
        };
    }
};

}

        public void SetAuthService(AuthenticationService authService)
        {
            _authService = authService;
        }
        public void SetPlatforms(List<PlatformSettings> platforms)
        {
            _platforms = platforms ?? new List<PlatformSettings>();

            if (_platformComboBox != null)
            {
                _platformComboBox.ItemsSource = _platforms;

                // Force selection to first item if none selected
                if (_platformComboBox.SelectedIndex == -1 && _platforms.Count > 0)
                {
                    _platformComboBox.SelectedIndex = 0;
                }
            }
        }

        
        private void AttachControls()
        {
            //  _platformComboBox = this.FindControl<ComboBox>("PlatformComboBox");
            _useCertCheckbox = this.FindControl<CheckBox>("UseCertCheckbox");
            _interactiveRadio = this.FindControl<RadioButton>("AuthInteractiveRadio");
            _certRadio = this.FindControl<RadioButton>("AuthCertRadio");
            _authButton = this.FindControl<Button>("PlatformAuthButton");
            _platformDisplayText = this.FindControl<TextBlock>("PlatformDisplayText");
        }


        private void AttachEvents()
        {
            //if (_platformComboBox != null)
                //_platformComboBox.SelectionChanged += PlatformComboBox_SelectionChanged;

            if (_authButton != null)
                _authButton.Click += PlatformAuthButton_Click;
        }



        private async void PlatformAuthButton_Click(object? sender, RoutedEventArgs e)
        {
            // Grab the MainWindow (so we can update its top-bar displays)
            var ownerWindow = this.GetVisualRoot() as MainWindow;

            if (_authService == null)
            {
                LogHelper.Info("❌ No authentication service available.");
                return;
            }

            // 1) Get the selected platform from your VM
            if (this.DataContext is not PlatformConfigViewModel vm || vm.SelectedPlatform is not Platform selectedPlatform)
            {
                LogHelper.Info("❌ No platform selected.");
                return;
            }

            // 2) Decide between Cert vs Interactive *only* from your radio buttons
            var certRadio = this.FindControl<RadioButton>("AuthCertRadio");
            // concise
            bool useCert = certRadio != null && certRadio.IsChecked == true;

            if (certRadio != null && certRadio.IsChecked == true) useCert = true;
            else useCert = false;



            // 3) Build the settings, only set thumbprint if cert mode
            var settings = new PlatformSettings
            {
                PlatformFqdn = selectedPlatform.PlatformFqdn,
                AppId = selectedPlatform.AppId,
                UseCert = useCert,
                UserId = string.IsNullOrWhiteSpace(selectedPlatform.UserId) ? null : selectedPlatform.UserId,
                CertThumbprint = useCert
                                   ? (selectedPlatform.CertThumbprint ?? "")
                                   : ""
            };

            LogHelper.Info($"🔐 Authenticating to {settings.PlatformFqdn} using " +
                           $"{(useCert ? "Certificate" : "Interactive")}…");

            // 4) Call your auth service (forceReauth for interactive)
            AuthenticationResult result = useCert
                ? await _authService.AuthenticateAsync(settings)
                : await _authService.AuthenticateAsync(settings, forceReauth: true);

            // 5) If it failed, show a dialog
            if (string.IsNullOrWhiteSpace(result?.Token))
            {
                LogHelper.Info($"❌ Authentication failed for {settings.PlatformFqdn}");
                if (ownerWindow != null)
                    await MessageBox.Show(ownerWindow, "Authentication failed.");
                return;
            }

            // 6) Success! Update MainWindow’s displays
            LogHelper.Info($"✅ Authentication successful for {settings.PlatformFqdn}");
            if (ownerWindow != null)
            {
                ownerWindow.SelectedPlatformDisplay = $"Server: {settings.PlatformFqdn}";
                var displayName = await _authService.GetDisplayNameFromWhoAmIAsync(
                                      settings.PlatformFqdn, result.Token);
                ownerWindow.LoggedInUserDisplay =
                    $"User: {displayName ?? result.PrincipalName ?? "Unknown"}";
            }
        }



    }
}
