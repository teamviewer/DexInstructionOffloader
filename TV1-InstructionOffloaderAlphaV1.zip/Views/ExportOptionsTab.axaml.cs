﻿
using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;
using Avalonia.VisualTree;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using TV1_InstructionOffloader.Helpers;
using TV1_InstructionOffloader.Models;
using TV1_InstructionOffloader.Services;

namespace TV1_InstructionOffloader.Views
{
    public partial class ExportOptionsTab : UserControl
    {
        private ComboBox? _platformDropdown;
        private TextBox? _exportFolderBox;
        private TextBlock? _statusLabel;

        private AppSettings? _settings;
        private Dictionary<string, ExportOption> _exportOptions = new();

        public ExportOptionsTab()
        {
            AvaloniaXamlLoader.Load(this);

            _platformDropdown = this.FindControl<ComboBox>("PlatformComboBox");
            _exportFolderBox = this.FindControl<TextBox>("ExportFilePathBox");
            _statusLabel = this.FindControl<TextBlock>("SaveStatusLabel");

            _settings = new ConfigHelper().Load();
            _exportOptions = _settings?.ExportOptions ?? new();

            if (_platformDropdown != null)
            {
                _platformDropdown.AddHandler(ComboBox.SelectionChangedEvent, PlatformDropdown_SelectionChanged);
            }

            LoadPlatformDropdown();
        }

        protected override void OnAttachedToVisualTree(VisualTreeAttachmentEventArgs e)
        {
            base.OnAttachedToVisualTree(e);
            RefreshPlatforms();
        }

        public void RefreshPlatforms(string? selectAlias = null)
        {
            try
            {
				LogHelper.Debug("🔁 ExportOptionsTab.RefreshPlatforms called");

                _settings = new ConfigHelper().Load();
				_exportOptions = _settings?.ExportOptions ?? new Dictionary<string, ExportOption>(StringComparer.OrdinalIgnoreCase);

				// The dropdown should reflect configured platforms (not stale ExportOptions keys).
				var aliases = (_settings?.Platforms ?? new List<PlatformSettings>())
					.Select(p => (p.Alias ?? string.Empty).Trim())
					.Where(a => !string.IsNullOrWhiteSpace(a))
					.Distinct(StringComparer.OrdinalIgnoreCase)
					.OrderBy(a => a, StringComparer.OrdinalIgnoreCase)
					.ToList();

				// Cleanup stale ExportOptions entries that no longer have a matching platform.
				if (_exportOptions.Count > 0)
				{
					var aliasSet = new HashSet<string>(aliases, StringComparer.OrdinalIgnoreCase);
					var stale = _exportOptions.Keys.Where(k => !aliasSet.Contains(k)).ToList();
					if (stale.Count > 0)
					{
						foreach (var k in stale)
							_exportOptions.Remove(k);

						// Persist cleanup so the config stays consistent.
						if (_settings != null)
						{
							_settings.ExportOptions = _exportOptions;
							new ConfigHelper().Save(_settings);
						}

						LogHelper.Info($"🧹 Removed {stale.Count} stale ExportOptions entr{(stale.Count == 1 ? "y" : "ies")}: {string.Join(", ", stale)}");
					}
				}

				_platformDropdown.ItemsSource = aliases;

                // Preselect if requested
                if (!string.IsNullOrWhiteSpace(selectAlias) &&
                    aliases.Any(a => a.Equals(selectAlias, StringComparison.OrdinalIgnoreCase)))
                {
                    _platformDropdown.SelectedItem = aliases.First(a => a.Equals(selectAlias, StringComparison.OrdinalIgnoreCase));
                }
                else if (_platformDropdown.SelectedItem == null && aliases.Count > 0)
                {
                    _platformDropdown.SelectedIndex = 0;
                }

				// Populate fields for selected alias
                var selected = _platformDropdown.SelectedItem?.ToString();
                if (!string.IsNullOrWhiteSpace(selected) &&
                    _exportOptions.TryGetValue(selected, out var opt))
                {
                    _exportFolderBox.Text = opt.ExportFolder ?? string.Empty;
                    // Optional: update format dropdown
                    var formatDropdown = this.FindControl<ComboBox>("FormatDropdown");
                    if (formatDropdown != null)
                        formatDropdown.SelectedItem = string.IsNullOrWhiteSpace(opt.Format) ? "CSV" : opt.Format;
                }
            }
            catch (Exception ex)
            {
                LogHelper.Error($"❌ RefreshPlatforms failed: {ex}");
            }
        }


        public void SetPlatforms(List<Platform> platforms)
        {
            LogHelper.Info($"📥 ExportOptionsTab.SetPlatforms called with {platforms.Count} platforms");

            if (_platformDropdown == null)
            {
                LogHelper.Warn("⚠️ _platformDropdown is null in SetPlatforms");
                return;
            }

            _platformDropdown.ItemsSource = platforms;
            if (platforms.Count > 0)
                _platformDropdown.SelectedItem = platforms.First();
        }

        public void LoadPlatformDropdown()
        {
            if (_settings?.Platforms is null || _platformDropdown is null)
            {
                LogHelper.Warn("⚠️ Cannot load platform dropdown — settings or dropdown is null");
                return;
            }

			var aliases = _settings.Platforms
				.Select(p => (p.Alias ?? string.Empty).Trim())
				.Where(a => !string.IsNullOrWhiteSpace(a))
				.Distinct(StringComparer.OrdinalIgnoreCase)
				.OrderBy(a => a, StringComparer.OrdinalIgnoreCase)
				.ToList();

			LogHelper.Debug($"📋 Populating export platform dropdown with {aliases.Count} alias(es).");

			_platformDropdown.ItemsSource = aliases;
			if (_platformDropdown.SelectedItem == null && aliases.Count > 0)
				_platformDropdown.SelectedIndex = 0;
        }

        private void PlatformDropdown_SelectionChanged(object? sender, SelectionChangedEventArgs e)
        {
            var selectedAlias = _platformDropdown?.SelectedItem?.ToString();
            if (string.IsNullOrWhiteSpace(selectedAlias) || _exportOptions == null)
                return;

            if (_exportOptions.TryGetValue(selectedAlias, out var opt))
            {
                _exportFolderBox.Text = opt.ExportFolder ?? string.Empty;

                var formatDropdown = this.FindControl<ComboBox>("FormatDropdown");
                if (formatDropdown != null)
                    formatDropdown.SelectedItem = string.IsNullOrWhiteSpace(opt.Format) ? "CSV" : opt.Format;
            }
            else
            {
                _exportFolderBox.Text = string.Empty;
            }
        }


        private void SetRadioFormat(string? format)
        {
            this.FindControl<RadioButton>("CsvRadio").IsChecked = format == "CSV";
            this.FindControl<RadioButton>("TsvRadio").IsChecked = format == "TSV";
            this.FindControl<RadioButton>("XlsxRadio").IsChecked = format == "XLSX";
            this.FindControl<RadioButton>("SqlRadio").IsChecked = format == "SQL";
            this.FindControl<RadioButton>("MySqlRadio").IsChecked = format == "MySQL";
            this.FindControl<RadioButton>("OracleRadio").IsChecked = format == "Oracle";
        }

        private void ExportFormatRadio_Checked(object? sender, RoutedEventArgs e)
        {
            if (sender is not RadioButton rb)
                return;

            bool isFileFormat = rb.Name is "CsvRadio" or "TsvRadio" or "XlsxRadio";

            this.FindControl<StackPanel>("FileExportOptionsPanel").IsVisible = isFileFormat;
            this.FindControl<StackPanel>("DbExportOptionsPanel").IsVisible = !isFileFormat;
        }

        private async void OnBrowseExportFolder(object? sender, RoutedEventArgs e)
        {
            var dialog = new OpenFolderDialog();
            var result = await dialog.ShowAsync((Window)this.VisualRoot);
            if (result != null)
            {
                _exportFolderBox!.Text = result;
            }
        }

        private async void BrowseExportPathButton_Click(object? sender, RoutedEventArgs e)
        {
            var dialog = new OpenFolderDialog();
            var result = await dialog.ShowAsync((Window)this.VisualRoot);
            if (result != null)
            {
                _exportFolderBox!.Text = result;
            }
        }



private void OnSaveExportSettings(object? sender, RoutedEventArgs e)
    {
        try
        {
            var selectedAlias = _platformDropdown?.SelectedItem?.ToString()?.Trim();
            if (string.IsNullOrWhiteSpace(selectedAlias))
            {
                LogHelper.Warn("⚠️ No platform alias selected. Cannot save export settings.");
                if (_statusLabel != null) _statusLabel.Text = "Select a platform first.";
                return;
            }

            var exportFolder = _exportFolderBox?.Text?.Trim() ?? string.Empty;
            if (string.IsNullOrWhiteSpace(exportFolder))
            {
                LogHelper.Warn("⚠️ No export folder provided.");
                if (_statusLabel != null) _statusLabel.Text = "Enter an export folder.";
                return;
            }

            if (!Directory.Exists(exportFolder))
            {
                try
                {
                    Directory.CreateDirectory(exportFolder);
                }
                catch (Exception ex)
                {
                    LogHelper.Error($"❌ Failed to create export folder '{exportFolder}': {ex.Message}");
                    if (_statusLabel != null) _statusLabel.Text = "Failed to create folder.";
                    return;
                }
            }

            var format = "CSV";
            var formatDropdown = this.FindControl<ComboBox>("FormatDropdown");
            if (formatDropdown != null && formatDropdown.SelectedItem != null)
                format = formatDropdown.SelectedItem.ToString()?.Trim() ?? "CSV";

            if (_settings == null)
                _settings = new ConfigHelper().Load();

            if (_exportOptions == null)
                _exportOptions = _settings?.ExportOptions ?? new Dictionary<string, ExportOption>(StringComparer.OrdinalIgnoreCase);

            _exportOptions[selectedAlias] = new ExportOption
            {
                ExportFolder = exportFolder,
                Format = format
            };

            if (_settings != null)
                _settings.ExportOptions = _exportOptions;

            new ConfigHelper().Save(_settings);

            LogHelper.Info($"💾 Saved export settings for '{selectedAlias}' → Folder='{exportFolder}', Format='{format}'");
            if (_statusLabel != null) _statusLabel.Text = $"Saved for '{selectedAlias}'.";
        }
        catch (Exception ex)
        {
            LogHelper.Error($"❌ OnSaveExportSettings failed: {ex}");
            if (_statusLabel != null) _statusLabel.Text = "Save failed. Check logs.";
        }
    }


}
}
