﻿using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Controls.Primitives;
using Avalonia.Interactivity;
using Avalonia.VisualTree;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using TV1_InstructionOffloader.Helpers;
using TV1_InstructionOffloader.Models;
using TV1_InstructionOffloader.Services;
using ViewModels;

namespace TV1_InstructionOffloader.Views
{
    public partial class AutomationTab : UserControl
    {
        private PlatformContext? _platformContext;
        private ComboBox? _platformDropdown;
        private TextBox? _policySearchBox;
        private ListBox? _policiesListBox;
        private ListBox? _policyRulesListBox;
        private ListBox? _availableMGsListBox;
        private ListBox? _selectedMGsListBox;
        private TextBox? _logBox;
        private ComboBox? _dateRangeCombo;
        private DatePicker? _startDatePicker;
        private DatePicker? _endDatePicker;
        private AuthenticationService? _authService;
        private MainWindow? _mainWindow;
        private InstructionService _instructionHelper = new();
        private string _fqdn = string.Empty;
        private string _token = string.Empty;
        private ComboBox? _recurrenceCombo;
        private List<PolicySummary> _policies = new();
        private PolicySummary? _selectedPolicy;
        private List<PolicyRule> _allRules = new();
        private StackPanel? _dayCheckPanel;
        private StackPanel? _weekRadioPanel;
        private TimePicker? _startTimePicker;
        private WrapPanel? _monthDayWrapPanel;
        private StackPanel? _monthlyDayPanel;
        private UniformGrid? _monthDayGrid;
        private int _selectedMonthDay = 1;


        private int SelectedMonthDay = 1;

        private bool _isHandlingPlatformChange = false;

        public AutomationTab()
        {
            InitializeComponent();
            AttachControls();
            AttachEvents();
        }

        public void SetDependencies(InstructionService instructionService, string fqdn, string token, TextBox logBox, AuthenticationService authService)
        {
            _instructionHelper = instructionService;
            _fqdn = fqdn;
            _token = token;
            _logBox = logBox;
            _authService = authService;

            _ = LoadPoliciesAsync();
        }

        public void SetPlatformList(List<Platform> platforms)
        {
            _platformDropdown.ItemsSource = platforms;
            if (platforms.Count > 0)
                _platformDropdown.SelectedItem = platforms.First();
        }

        private void AttachControls()
        {
            _platformDropdown = this.FindControl<ComboBox>("PlatformComboBox");
            _policySearchBox = this.FindControl<TextBox>("PolicySearchBox");
            _policiesListBox = this.FindControl<ListBox>("PoliciesListBox");
            _policyRulesListBox = this.FindControl<ListBox>("PolicyRulesListBox");
            _policyRulesListBox.SelectionMode = SelectionMode.Multiple;

            _availableMGsListBox = this.FindControl<ListBox>("AvailableMGsListBox");
            _selectedMGsListBox = this.FindControl<ListBox>("SelectedMGsListBox");

            _dateRangeCombo = this.FindControl<ComboBox>("DateRangeComboBox");
            _startDatePicker = this.FindControl<DatePicker>("StartDatePicker");
            _endDatePicker = this.FindControl<DatePicker>("EndDatePicker");

            _recurrenceCombo = this.FindControl<ComboBox>("RecurrenceComboBox");
            _dayCheckPanel = this.FindControl<StackPanel>("DayCheckPanel");
            _weekRadioPanel = this.FindControl<StackPanel>("WeekRadioPanel");
            _monthlyDayPanel = this.FindControl<StackPanel>("MonthlyDayPanel");
            _monthDayGrid = this.FindControl<UniformGrid>("MonthDayGrid");

            _monthDayWrapPanel = this.FindControl<WrapPanel>("MonthDayWrapPanel");  // Correct name
            
            _startTimePicker = this.FindControl<TimePicker>("StartTimePicker");
            if (_recurrenceCombo?.SelectedItem != null)
            {
                // Trigger logic to set proper panel visibility
                RecurrenceChanged(_recurrenceCombo, null);
            }

        }



        private void AttachEvents()
        {
            _platformDropdown?.AddHandler(ComboBox.SelectionChangedEvent, PlatformChanged);
            _policiesListBox?.AddHandler(ListBox.SelectionChangedEvent, PolicySelected);
            _policySearchBox?.AddHandler(TextBox.KeyUpEvent, (_, __) => ApplyPolicySearch());
            ExportButton.Click += OnExportPoliciesClicked;
            _recurrenceCombo.SelectionChanged += RecurrenceChanged;
            
        
        _mainWindow = Application.Current?.ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop
                ? desktop.MainWindow as MainWindow
                : null;
        }

        private async void PlatformChanged(object? sender, SelectionChangedEventArgs e)
        {
            LogHelper.Info("⚙️1 PlatformChanged event fired in AutomationTab.");

            if (_isHandlingPlatformChange) return;

            try
            {
                _isHandlingPlatformChange = true;
                LogHelper.Info("⚙️ 2 PlatformChanged event fired in AutomationTab.");

                if (_platformDropdown?.SelectedItem is not Platform selectedPlatform || _authService == null)
                {
                    LogHelper.Info("⚠️ Platform selection or auth service missing.");
                    return;
                }

                _fqdn = selectedPlatform.PlatformFqdn;

                var platformSettings = new PlatformSettings
                {
                    Alias = selectedPlatform.Alias,
                    PlatformFqdn = selectedPlatform.PlatformFqdn,
                    CertThumbprint = selectedPlatform.CertThumbprint,
                    AppId = selectedPlatform.AppId,
                    DefaultConsumer = selectedPlatform.DefaultConsumer
                };

                var authResult = await _authService.AuthenticateAsync(platformSettings, forceReauth: true);
                _token = authResult?.Token ?? "";
                if (!string.IsNullOrWhiteSpace(authResult?.Token))
                {
                    _token = authResult.Token;
                    LogHelper.Info("🔑 Token refreshed.");
                }
                else
                {
                    LogHelper.Info("⚠️ Failed to refresh token.");
                }

                LogHelper.Info($"🔍 Loading policies for FQDN: {_fqdn} with token ending: {_token?.Substring(Math.Max(0, _token.Length - 6))}");

                await LoadPoliciesAsync();
            }
            finally
            {
                _isHandlingPlatformChange = false;
            }
        }

        public async Task LoadPoliciesAsync()
        {
            var policies = await _instructionHelper.LoadPoliciesAsync(_fqdn, _token, _logBox);
            _policies = policies ?? new List<PolicySummary>();
            ApplyPolicySearch();
        }

        private void ApplyPolicySearch()
        {
            string filter = _policySearchBox?.Text ?? "";
            var filtered = string.IsNullOrWhiteSpace(filter)
                ? _policies
                : _policies.Where(p => p.Name.Contains(filter, StringComparison.OrdinalIgnoreCase) ||
                                       p.Description.Contains(filter, StringComparison.OrdinalIgnoreCase)).ToList();
            _policiesListBox.ItemsSource = filtered;
        }

        private async void PolicySelected(object? sender, SelectionChangedEventArgs e)
        {
            if (_policiesListBox?.SelectedItem is not PolicySummary selected)
                return;

            _selectedPolicy = selected;

            _allRules = await _instructionHelper.GetPolicyRulesAsync(_fqdn, _token);

            var matchedRules = selected.Rules != null && selected.Rules.Count > 0
                ? _allRules.Where(r => selected.Rules.Contains(r.Id)).ToList()
                : _allRules;

            LogHelper.Info($"✅ Loaded all rules count: {_allRules.Count}");
            LogHelper.Info($"✅ Policy '{selected.Name}' has rule IDs: {string.Join(",", selected.Rules)}");
            LogHelper.Info($"✅ Matched rules count: {matchedRules.Count}");
            LogHelper.Info($"✅ Matched Rule IDs: {string.Join(",", matchedRules.Select(r => r.Id))}");

            _policyRulesListBox.ItemsSource = matchedRules;

            _availableMGsListBox?.SetValue(ItemsControl.ItemsSourceProperty, selected.ManagementGroups?.ToList());

        }

        private (DateTime StartUtc, DateTime EndUtc) GetDateRange()
        {
            var now = DateTime.UtcNow;

            if (_dateRangeCombo?.SelectedIndex == 0)
                return (now.AddDays(-1), now);
            if (_dateRangeCombo?.SelectedIndex == 1)
                return (now.AddDays(-7), now);
            if (_dateRangeCombo?.SelectedIndex == 2)
                return (now.AddDays(-30), now);
            if (_dateRangeCombo?.SelectedIndex == 3)
            {
                var start = _startDatePicker?.SelectedDate?.UtcDateTime ?? now.AddDays(-1);
                var end = _endDatePicker?.SelectedDate?.UtcDateTime ?? now;
                return (start, end);
            }

            return (now.AddDays(-1), now);
        }

        private async void OnExportPoliciesClicked(object? sender, RoutedEventArgs e)
        {
            if (_selectedPolicy == null || string.IsNullOrWhiteSpace(_fqdn) || string.IsNullOrWhiteSpace(_token))
            {
                LogHelper.Info("⚠️ Missing required information for export.");
                return;
            }

            var selectedRules = _policyRulesListBox.SelectedItems.Cast<PolicyRule>()
                .Select(r => r.Id)
                .ToList();

            var ruleIds = selectedRules.Any() ? selectedRules.ToArray() : new int[] { 0 };
            LogHelper.Info($"📋 Selected Rule IDs: {string.Join(",", ruleIds)}");
            var (startUtc, endUtc) = GetDateRange();
            LogHelper.Info($"🔢 Date Range UTC: {startUtc:u} → {endUtc:u}");

            long startEpoch = new DateTimeOffset(startUtc).ToUnixTimeSeconds();
            long endEpoch = new DateTimeOffset(endUtc).ToUnixTimeSeconds();

            var filter = new
            {
                Operator = "AND",
                Operands = new object[]
                {
                    new {
                        Operator = "AND",
                        Operands = new object[]
                        {
                            new { Attribute = "Timestamp", Operator = ">=", Value = startEpoch },
                            new { Attribute = "Timestamp", Operator = "<=", Value = endEpoch }
                        }
                    },
                    new {
                        Operator = "OR",
                        Operands = new object[]
                        {
                            new { Attribute = "Status", Operator = "==", Value = 4 },
                            new { Attribute = "Status", Operator = "==", Value = 5 },
                            new { Attribute = "Status", Operator = "==", Value = 6 }
                        }
                    }
                }
            };

            var payload = new Dictionary<string, object>
            {
                { "Filter", filter },
                { "Start", "0;0" },
                { "PageSize", 2000 },
                { "Sort", new[] { new { Column = "Timestamp", Direction = "DESC" } } },
                { "ClobDefaultReadSize", 200 }
            };

            if (ruleIds != null && ruleIds.Any())
            {
                payload["RuleIds"] = ruleIds;
            }

            var saveFileDialog = new SaveFileDialog
            {
                Title = "Export Policy Results",
                InitialFileName = $"PolicyExport_{DateTime.Now:yyyyMMdd_HHmmss}.csv",
                Filters = new List<FileDialogFilter>
                {
                    new FileDialogFilter { Name = "CSV Files", Extensions = { "csv" } },
                    new FileDialogFilter { Name = "Excel Files", Extensions = { "xlsx" } }
                }
            };
            var filePath = await saveFileDialog.ShowAsync(this.GetVisualRoot() as Window);
            if (string.IsNullOrWhiteSpace(filePath)) return;

            var results = await _instructionHelper.GetPolicyResultsAsync(_fqdn, _token, _selectedPolicy.Id, payload);

            if (results == null || !results.Any())
            {
                LogHelper.Info("⚠️ No data found to export.");
                return;
            }

            var ruleNameMap = _allRules
                .Where(r => _selectedPolicy.Rules.Contains(r.Id))
                .ToDictionary(r => r.Id, r => r.Name);

            var allRows = results.Select(item => new Dictionary<string, string>
            {
                { "PolicyId", _selectedPolicy.Id.ToString() },
                { "PolicyName", _selectedPolicy.Name ?? "" },
                { "RuleId", item.RuleId.ToString() },
                { "RuleName", ruleNameMap.ContainsKey(item.RuleId) ? ruleNameMap[item.RuleId] : "" },
                { "Device", item.Fqdn ?? "" },
                { "Timestamp", item.Timestamp == default ? "" : item.Timestamp.ToLocalTime().ToString("u") },
                { "Status", GetStatusText(item.Status) },
                { "Data", item.Data ?? "" }
            }).ToList();

            var format = filePath.EndsWith(".xlsx", StringComparison.OrdinalIgnoreCase) ? "xlsx" : "csv";
            await ExportHelper.ExportDictionaryListAsync(allRows, filePath, format, null, msg => LogHelper.Info(msg));
            LogHelper.Info($"✅ Export complete: {filePath}");
        }

        private static string GetStatusText(int statusCode) =>
            statusCode switch { 4 => "Fix Errored", 5 => "Fix Passed", 6 => "Fix Failed", _ => $"Unknown ({statusCode})" };

        public void SetPlatformContext(PlatformContext context)
        {
            _platformContext = context;
            if (_platformDropdown != null)
            {
                _platformDropdown.ItemsSource = context.Platforms;
                _platformDropdown.SelectedItem = context.SelectedPlatform;
            }

            context.PropertyChanged += async (s, e) =>
            {
                if (e.PropertyName == nameof(context.SelectedPlatform))
                {
                    _fqdn = context.SelectedPlatform?.PlatformFqdn ?? "";
                    _token = context.Token ?? "";
                    await LoadPoliciesAsync();
                }
                else if (e.PropertyName == nameof(context.Token))
                {
                    _token = context.Token ?? "";
                }
            };
        }

        private void CreateScheduledExportJob(object? sender, RoutedEventArgs e)
        {
            if (_selectedPolicy == null)
            {
                LogHelper.Info("⚠️ No policy selected.");
                return;
            }

            string recurrence = _dateRangeCombo?.SelectedIndex switch
            {
                0 => "Daily",
                1 => "Weekly",
                2 => "Biweekly",
                3 => "Monthly",
                _ => "Once"
            };

            var job = new ScheduledJob
            {
                JobId = Guid.NewGuid().ToString(),
                InstructionName = $"ExportPolicy-{_selectedPolicy.Name}",
                InstructionId = 0,
                InstructionType = "Automation",
                PlatformFqdn = _fqdn,
                PlatformAlias = _fqdn,
                AppRegistrationId = "",
                CertThumbprint = "",
                AuthenticationMode = "Cert",
                InstructionTtlMinutes = 5,
                InstructionTtlUnit = "Minutes",
                ResponseTtlMinutes = 60,
                ResponseTtlUnit = "Minutes",
                ExportFormat = "CSV",
                Consumer = "Explorer",
                JobType = "Automation",
                Status = "Enabled",
                StartDate = DateTime.Today,
                EndDate = DateTime.Today.AddYears(1),
                StartTime = new TimeSpan(9, 0, 0),
                Recurrence = recurrence,
                EnableExport = true,
                RuntimeStatus = "Waiting",
                MaxRetries = 3,
                RetryCount = 0,
                Cooldown = TimeSpan.FromMinutes(5),
                DaysOfWeek = new List<DayOfWeek> { DateTime.Today.DayOfWeek },
                WeeklyRepeatCount = 1,
                MonthlyRepeatCount = 1,
                MonthlyDayFallback = DateTime.Today.Day,
                Parameters = new Dictionary<string, string>
                {
                    { "PolicyId", _selectedPolicy.Id.ToString() },
                    { "ExportRange", recurrence }
                },
                TargetingMethod = "Policy",
                IsRunning = false,
                IsEnabled = true
            };

            string path = TV1_InstructionOffloader.Helpers.AppPaths.ScheduledJobsPath;
            Directory.CreateDirectory(Path.GetDirectoryName(path)!);
            List<ScheduledJob> jobs = File.Exists(path)
                ? JsonConvert.DeserializeObject<List<ScheduledJob>>(File.ReadAllText(path)) ?? new()
                : new();

            jobs.Add(job);
            File.WriteAllText(path, JsonConvert.SerializeObject(jobs, Formatting.Indented));


            LogHelper.Info($"✅ Scheduled export job created: {job.InstructionName}");

            _mainWindow?.RefreshScheduledJobs();
        }
        private void RecurrenceChanged(object? sender, SelectionChangedEventArgs? e)
        {
            LogHelper.Debug("🔁 RecurrenceChanged event fired.");

            if (_recurrenceCombo?.SelectedItem is not ComboBoxItem selectedItem)
            {
                LogHelper.Warn("⚠️ _recurrenceCombo is null or has no selected item.");
                return;
            }

            string sel = selectedItem.Content?.ToString() ?? "1 Day";
            LogHelper.Debug($"🔁 Selected recurrence: {sel}");

            int days = sel switch
            {
                "1 Day" => 1,
                "7 Day" => 7,
                "30 Day" => 30,
                _ => 0
            };
            LogHelper.Debug($"📆 Days to export: {days}");

            if (_startDatePicker?.SelectedDate is DateTimeOffset startOffset && _endDatePicker != null)
            {
                DateTime start = startOffset.Date;
                DateTime end = start.AddDays(days - 1);
                _endDatePicker.SelectedDate = end;
                _endDatePicker.IsEnabled = false;

                LogHelper.Debug($"🗓 Auto-set end date: {end:d}");
            }
            else if (_endDatePicker != null)
            {
                _endDatePicker.IsEnabled = true;
                LogHelper.Debug("🗓 Custom range enabled (end date is editable).");
            }

            // Toggle visibility of panels
            if (_dayCheckPanel != null) _dayCheckPanel.IsVisible = sel == "1 Day";
            if (_weekRadioPanel != null) _weekRadioPanel.IsVisible = sel == "7 Day";
            if (_monthlyDayPanel != null)
            {
                _monthlyDayPanel.IsVisible = sel == "30 Day";
                if (sel == "30 Day")
                    GenerateMonthDayButtons();
            }



            var selectedTime = _startTimePicker?.SelectedTime;
            if (selectedTime.HasValue)
            {
                var time = selectedTime.Value;
                LogHelper.Debug($"⏰ Start time selected: {time}");
            }
        }



        private void GenerateMonthDayButtons()
        {
            if (_monthDayGrid == null) return;

            _monthDayGrid.Children.Clear();

            for (int day = 1; day <= 31; day++)
            {
                var btn = new ToggleButton
                {
                    Content = day.ToString(),
                    Width = 44,
                    Height = 44,
                    FontSize = 14,
                    Margin = new Thickness(4),
                    Tag = day,
                    IsChecked = day == SelectedMonthDay
                };


                btn.Checked += (_, _) =>
                {
                    _selectedMonthDay = (int)btn.Tag!;
                    LogHelper.Info($"📅 Selected monthly day: {_selectedMonthDay}");

                    foreach (var child in _monthDayGrid.Children.OfType<ToggleButton>())
                    {
                        if (child != btn) child.IsChecked = false;
                    }
                };

                _monthDayGrid.Children.Add(btn);
            }
        }

    }
}
