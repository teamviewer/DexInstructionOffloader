﻿using Avalonia.Controls;
using Avalonia.Threading;
using System;

namespace TV1_InstructionOffloader.Services
{
    public class TextBoxLogger : ILogger
    {
        private readonly TextBox _textBox;

        public TextBoxLogger(TextBox textBox)
        {
            _textBox = textBox;
        }

        public void Log(string message)
        {
            if (_textBox != null)
            {
                Dispatcher.UIThread.Post(() =>
                {
                    _textBox.Text += message + "\n";
                });
            }
        }

        public void LogInformation(string message) => Log(message);
        public void LogWarning(string message) => Log(message);
        public void LogDebug(string message) => Log(message);
    }
}
