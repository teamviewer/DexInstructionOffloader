﻿using System;
using System.IO;

namespace TV1_InstructionOffloader.Services
{
    public class FileLogger : ILogger
    {
        private readonly string _logFilePath;
        private readonly bool _logToConsole;

        public FileLogger(string logFilePath, bool logToConsole = false)
        {
            _logFilePath = logFilePath;
            _logToConsole = logToConsole;
        }

        public void Log(string message) => WriteLog(message);

        public void LogInformation(string message) => WriteLog("[INFO] " + message);

        public void LogWarning(string message) => WriteLog("[WARN] " + message);

        public void LogDebug(string message) => WriteLog("[DEBUG] " + message);

        private void WriteLog(string message)
        {
            var fullMessage = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} {message}";

            try
            {
                File.AppendAllText(_logFilePath, fullMessage + Environment.NewLine);
            }
            catch (Exception ex)
            {
                if (_logToConsole)
                    Console.WriteLine($"❌ Log file write failed: {ex.Message}");
            }

            if (_logToConsole)
                Console.WriteLine(fullMessage);
        }
    }
}
