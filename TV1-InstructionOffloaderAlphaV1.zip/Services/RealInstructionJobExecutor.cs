using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using TV1_InstructionOffloader.Models;
using TV1_InstructionOffloader.Services;

public sealed class RealInstructionJobExecutor : IInstructionJobExecutor
{
    private readonly InstructionService _service;
    private readonly Func<ScheduledJob, string?> _tokenProvider;

    public RealInstructionJobExecutor(InstructionService service, string token)
    {
        _service = service ?? throw new ArgumentNullException(nameof(service));
        _tokenProvider = _ => token;
    }

    public RealInstructionJobExecutor(InstructionService service, Func<ScheduledJob, string?> tokenProvider)
    {
        _service = service ?? throw new ArgumentNullException(nameof(service));
        _tokenProvider = tokenProvider ?? throw new ArgumentNullException(nameof(tokenProvider));
    }

    public async Task<JobRunResult> RunJobAsync(ScheduledJob job, CancellationToken ct)
    {
        var token = _tokenProvider(job);
        if (string.IsNullOrWhiteSpace(token))
            throw new InvalidOperationException("No authentication token found");

        return await RunJobAsync(job, token, ct);
    }


    public async Task<JobRunResult> RunJobAsync(ScheduledJob job, string token, CancellationToken ct)
    {
        try
        {
            var parametersList = job.Parameters?.ToDictionary(kvp => kvp.Key, kvp => (object)kvp.Value)
                                 ?? new Dictionary<string, object>();

            var instructionDef = new InstructionDefinition
            {
                Id = job.InstructionId,
                Name = job.InstructionName
            };

            var targetingMode = job.TargetingMethod ?? "FQDN";
            var matchType = job.MatchType ?? "Begins With";
            var fqdnInput = job.TargetingFqdn ?? "";
            ManagementGroup? mg = job.ManagementGroupId is > 0
                ? new ManagementGroup { UsableId = job.ManagementGroupId.Value }
                : null;

            var coverageTag = job.CoverageTagName;
            var coverageValue = job.CoverageTagValue;

            await _service.RunInstructionFromMainTabAsync(
                instructionDef,
                parametersList,
                targetingMode,
                job.PlatformFqdn,
                token,
                job.Consumer,
                fqdnInput,
                matchType,
                mg,
                coverageTag,
                coverageValue,
                new List<string>(), // ← no specific device list
                job.InstructionTtlMinutes,
                job.ResponseTtlMinutes,
                null // logger
            );

            LogHelper.Info($"✅ Job {job.InstructionName} completed.");

            return new JobRunResult
            {
                Success = true,
                ResponseId = null
            };
        }
        catch (Exception ex)
        {
            LogHelper.Info($"❌ Instruction job failed: {ex.Message}");
            return new JobRunResult
            {
                Success = false,
                ErrorMessage = ex.Message
            };
        }
    }


}
