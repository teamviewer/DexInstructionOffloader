using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Microsoft.IdentityModel.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using TV1_InstructionOffloader.Models;
using TV1_InstructionOffloader.Services;
using TV1_InstructionOffloader.Views;


namespace TV1_InstructionOffloader.Services
{
    public class InstructionService
    {
        public List<SchemaColumn> LatestSchema { get; private set; } = new();

        public async Task<List<string>> SearchDeviceFqdnsAsync(
            string platformFqdn,
            string token,
            string query,
            int take,
            System.Threading.CancellationToken cancellationToken)
        {
            var list = new List<string>();

            if (string.IsNullOrWhiteSpace(platformFqdn) || string.IsNullOrWhiteSpace(token))
                return list;

            query = (query ?? string.Empty).Trim();
            if (query.Length < 2)
                return list;

            // Match Device Explorer behavior: POST /consumer/Devices with a JSON body.
            // Some platforms also support GET with filter querystring; we can fall back if needed.
            var url = $"https://{platformFqdn}/consumer/Devices";

            var body = new
            {
                Filter = new { Attribute = "Fqdn", Operator = "like", Value = $"%{query}%" },
                Sort = new[]
                {
                    new { label = "Device name A-Z", Column = "Fqdn", Direction = "ASC" }
                },
                Start = 1,
                PageSize = Math.Max(1, take)
            };

            using var client = new HttpClient();
            client.DefaultRequestHeaders.Add("X-Tachyon-Consumer", "Explorer");
            client.DefaultRequestHeaders.Add("X-Tachyon-Authenticate", token);

            string json;

            try
            {
                using var resp = await client.PostAsync(
                    url,
                    new StringContent(JsonConvert.SerializeObject(body), Encoding.UTF8, "application/json"),
                    cancellationToken);

                json = await resp.Content.ReadAsStringAsync(cancellationToken);

                if (!resp.IsSuccessStatusCode)
                {
                    // Fallback: GET /Consumer/Devices?take=..&filter=..
                    var filter = $"Fqdn like '%{query.Replace("'", "''")}%'";
                    var urlGet = $"https://{platformFqdn}/Consumer/Devices?take={Math.Max(1, take)}&filter={Uri.EscapeDataString(filter)}";
                    using var resp2 = await client.GetAsync(urlGet, cancellationToken);
                    json = await resp2.Content.ReadAsStringAsync(cancellationToken);
                    if (!resp2.IsSuccessStatusCode)
                        return list;
                }
            }
            catch
            {
                return list;
            }

            JToken parsed;
            try { parsed = JToken.Parse(json); }
            catch { return list; }

            IEnumerable<JToken> items;

            // Common shapes:
            // { Items: [...] }
            // { Devices: [...] }
            // [ ... ]
            if (parsed.Type == JTokenType.Array)
            {
                items = parsed;
            }
            else
            {
                items = (parsed["Items"] as JArray)
                        ?? (parsed["items"] as JArray)
                        ?? (parsed["Devices"] as JArray)
                        ?? (parsed["devices"] as JArray)
                        ?? (parsed["Data"] as JArray)
                        ?? (parsed["data"] as JArray)
                        ?? new JArray();
            }

            foreach (var it in items)
            {
                var fqdn = it["Fqdn"]?.ToString()
                           ?? it["fqdn"]?.ToString()
                           ?? it["Device"]?["Fqdn"]?.ToString()
                           ?? it["device"]?["fqdn"]?.ToString();
                if (string.IsNullOrWhiteSpace(fqdn))
                    continue;

                fqdn = fqdn.Trim();
                if (!list.Contains(fqdn, StringComparer.OrdinalIgnoreCase))
                    list.Add(fqdn);
            }

            return list;
        }

        public async Task<JobRunResult> RunInstructionFromMainTabAsync(
           InstructionDefinition selectedInstruction,
           Dictionary<string, object> parametersDict,
           string targetingMode,
           string platformUrl,
           string token,
           string consumerName,
           string fqdnInput,
           string matchType,
           ManagementGroup? selectedMG,
           string? coverageTag,
           string? coverageValue,
           List<string> selectedFqdns,
           int instructionTtlMinutes,
           int responseTtlMinutes,
           ILogger? logger = null,
            bool compulsoryCoverageEnabled = false
,
            bool requestServerSideExport = false
        )
        {
            int instructionId = selectedInstruction.Id;
            string selectedInstructionName = selectedInstruction.Name;

            var parametersList = parametersDict.Select(p => new Dictionary<string, string>
            {
                ["Name"] = p.Key,
                ["Value"] = p.Value?.ToString() ?? ""
            }).ToList();

            LogHelper.Info($"🧭 MG Passed In: {(selectedMG == null ? "null" : $"UsableId={selectedMG.UsableId}")}");

            var payload = new Dictionary<string, object>
            {
                ["DefinitionId"] = instructionId,
                ["KeepRaw"] = 1,
                ["Parameters"] = parametersList,
                ["InstructionTtlMinutes"] = instructionTtlMinutes,
                ["ResponseTtlMinutes"] = responseTtlMinutes,
                ["ReadablePayload"] = selectedInstruction.Name,
                ["Devices"] = new List<string>()
            };

            // ✅ FIX: issue-time server export option
            // This is the "Export" flag on the instruction issue payload (separate from your ExportMode 0/1/2).
            // When true, the issued instruction object will show Export=true and the platform will perform its export behavior.
            if (requestServerSideExport)
            {
                payload["Export"] = true;
                payload["ExportLocation"] = ""; // leave blank unless you have a specific location configured/required
            }
            else
            {
                payload["Export"] = false;
                // Do NOT send ExportLocation when export is disabled
                if (payload.ContainsKey("ExportLocation"))
                    payload.Remove("ExportLocation");
            }

            string endpoint;
            if (selectedFqdns.Count > 0)
            {
                payload["Devices"] = selectedFqdns;
                endpoint = $"https://{platformUrl}/Consumer/Instructions/Targeted";
            }
            else if (targetingMode == "FQDN")
            {
                payload["Scope"] = new Dictionary<string, string>
                {
                    ["Attribute"] = "Fqdn",
                    ["Operator"] = "Like",
                    ["Value"] = matchType switch
                    {
                        "Begins With" => $"{fqdnInput}%",
                        "Contains" => $"%{fqdnInput}%",
                        "Equals" => fqdnInput,
                        _ => $"{fqdnInput}%"
                    }
                };
                endpoint = $"https://{platformUrl}/Consumer/Instructions";
            }
            else if (targetingMode == "MG")
            {
                // "All devices" may arrive as a null MG selection (radio selected but no MG chosen)
                // or as a sentinel usable id (0 / -1 depending on how the list is built).
                // In practice (and matching your console app), "All Devices" must be expressed as:
                //   managementgroup == "global"
                // even when compulsory coverage is not enabled.
                if (selectedMG == null || selectedMG.UsableId <= 0)
                {
                    payload["Scope"] = new Dictionary<string, object>
                    {
                        ["Attribute"] = "managementgroup",
                        ["Operator"] = "==",
                        ["Value"] = "global"
                    };
                }
                else
                {
                    payload["Scope"] = new Dictionary<string, object>
                    {
                        ["Attribute"] = "managementgroup",
                        ["Operator"] = "==",
                        ["Value"] = selectedMG.UsableId.ToString()
                    };
                }
                endpoint = $"https://{platformUrl}/Consumer/Instructions";
            }
            else if (targetingMode == "Coverage")
            {
                if (string.IsNullOrWhiteSpace(coverageTag) || string.IsNullOrWhiteSpace(coverageValue))
                {
                    LogHelper.Info("❌ Coverage tag/value missing.");
                    return new JobRunResult { Success = false, ErrorMessage = "Coverage tag/value missing" };
                }

                payload["Scope"] = new Dictionary<string, object>
                {
                    ["Attribute"] = "TagTxt",
                    ["Operator"] = "",
                    ["Value"] = $"{coverageTag}={coverageValue}"
                };
                endpoint = $"https://{platformUrl}/Consumer/Instructions";
            }
            else
            {
                LogHelper.Info($"❌ Unknown targeting mode. {targetingMode}");
                return new JobRunResult { Success = false, ErrorMessage = "Unknown targeting mode" };
            }

            LogHelper.Info($"📦 Issue Export flag: {(requestServerSideExport ? "TRUE" : "FALSE")}");
            LogHelper.Debug($"🛰 Sending payload:\n{JsonConvert.SerializeObject(payload, Formatting.Indented)}");
            LogHelper.Info($"📡 POST to: {endpoint} using Token ending in: ...{(token?.Length >= 6 ? token[^6..] : "??")}");

            using var client = new HttpClient();
            client.DefaultRequestHeaders.Add("X-Tachyon-Consumer", consumerName);
            client.DefaultRequestHeaders.Add("X-Tachyon-Authenticate", token);

            var content = new StringContent(JsonConvert.SerializeObject(payload), Encoding.UTF8, "application/json");
            var response = await client.PostAsync(endpoint, content);
            var result = await response.Content.ReadAsStringAsync();

            LogHelper.Debug($"📬 Raw response ({(int)response.StatusCode} {response.StatusCode}): {result}");

            if (!response.IsSuccessStatusCode)
            {
                // Do not treat non-2xx responses as successful runs.
                return new JobRunResult
                {
                    Success = false,
                    ErrorMessage = $"Instruction POST failed: {(int)response.StatusCode} {response.StatusCode}"
                };
            }

            string? responseId = null;
            JToken? parsed = null;
            try
            {
                parsed = JToken.Parse(result);
            }
            catch
            {
                // Some platform versions can return a plain numeric/string response without JSON structure.
                var trimmed = (result ?? string.Empty).Trim().Trim('"');
                if (!string.IsNullOrWhiteSpace(trimmed) && trimmed.All(char.IsDigit))
                {
                    responseId = trimmed;
                }
            }

            if (responseId == null && parsed != null && parsed.Type == JTokenType.Object)
            {
                var obj = (JObject)parsed;
                // Handle common shapes and case variants.
                responseId = obj["Id"]?.ToString()
                             ?? obj["id"]?.ToString()
                             ?? obj["ResponseId"]?.ToString()
                             ?? obj["responseId"]?.ToString();
            }
            else if (responseId == null && parsed != null && parsed.Type == JTokenType.Array)
            {
                var array = (JArray)parsed;
                responseId = array.FirstOrDefault()?["Id"]?.ToString()
                             ?? array.FirstOrDefault()?["id"]?.ToString()
                             ?? array.FirstOrDefault()?["ResponseId"]?.ToString()
                             ?? array.FirstOrDefault()?["responseId"]?.ToString();
            }
            else if (responseId == null && parsed != null)
            {
                // Some versions return a raw integer/string token (e.g. 5112)
                if (parsed.Type == JTokenType.Integer || parsed.Type == JTokenType.Float || parsed.Type == JTokenType.String)
                {
                    var trimmed = parsed.ToString().Trim().Trim('"');
                    if (!string.IsNullOrWhiteSpace(trimmed) && trimmed.All(char.IsDigit))
                        responseId = trimmed;
                }
            }

            if (responseId == null)
            {
                LogHelper.Info("⚠️ Unable to extract ResponseId from result.");
                return new JobRunResult { Success = false, ErrorMessage = "No ResponseId returned" };
            }

            // Optional: log to file
            string instructionNameSanitized = selectedInstructionName.Replace(" ", "_").Replace("/", "_");
            string timestamp = DateTime.Now.ToString("yyyyMMdd-HHmmss");
            string logFileName = $"{instructionNameSanitized}-{responseId}-{timestamp}.log";
            string logFilePath = Path.Combine("Logs", logFileName);
            Directory.CreateDirectory("Logs");
            await File.WriteAllTextAsync(logFilePath, result);
            return new JobRunResult
            {
                Success = true,
                ResponseId = int.TryParse(responseId, out var id) ? id : (int?)null
            };

        }



        public async Task<JObject> PreviewTargetsAsync(
            string platformUrl,
            string token,
            int instructionId,
            JObject scopeQuery)
        {
            var url = $"https://{platformUrl}/consumer/Devices/ApproxTarget/{instructionId}";

            using var client = new HttpClient();
            client.DefaultRequestHeaders.Add("X-Tachyon-Consumer", "Explorer"); // Optional: inject this
            client.DefaultRequestHeaders.Add("X-Tachyon-Authenticate", token);

            var content = new StringContent(scopeQuery.ToString(), Encoding.UTF8, "application/json");
            var response = await client.PostAsync(url, content);
            var json = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"Preview API failed: {response.StatusCode} - {json}");
            }

            return JObject.Parse(json);
        }

        public async Task<List<ManagementGroup>> GetManagementGroupsAsync(string fqdn, string token)
        {
            if (string.IsNullOrWhiteSpace(fqdn) || string.IsNullOrWhiteSpace(token))
                throw new ArgumentException("FQDN or token is missing.");

            try
            {
                using var client = new HttpClient();
                client.DefaultRequestHeaders.Add("X-Tachyon-Consumer", "Explorer");
                client.DefaultRequestHeaders.Add("X-Tachyon-Authenticate", token);

                var url = $"https://{fqdn}/Consumer/ManagementGroups";
                var json = await client.GetStringAsync(url);
                var array = JArray.Parse(json);

                return array.Select(g => new ManagementGroup
                {
                    Name = g["Name"]?.ToString() ?? "(Unknown)",
                    UsableId = g["UsableId"]?.ToObject<int>() ?? 0
                }).ToList();
            }
            catch (Exception ex)
            {
                LogHelper.Error($"❌ Failed to fetch MGs from {fqdn}: {ex.Message}");
                return new List<ManagementGroup>();
            }
        }

        public async Task<List<Dictionary<string, string>>> LoadInstructionResultsAsync(
          string platformUrl,
          string token,
          string consumerName,
          int instructionId,
          ILogger logger,
          int pageSize = 500,
          int maxConcurrentRequests = 6)
        {
            var allResults = new List<Dictionary<string, string>>();
            bool morePages = true;

            using var client = new HttpClient();
            client.DefaultRequestHeaders.Add("X-Tachyon-Authenticate", token);
            client.DefaultRequestHeaders.Add("X-Tachyon-Consumer", consumerName);

            // Initialize the start tokens list with a null or empty string for the first request
            var startTokens = new List<string?> { null };

            while (morePages)
            {
                var tasks = new List<Task<(List<Dictionary<string, string>> rows, string? nextRange)>>();

                // For each concurrent request, get the start token if available
                for (int i = 0; i < maxConcurrentRequests; i++)
                {
                    string? startToken = i < startTokens.Count ? startTokens[i] : null;
                    tasks.Add(FetchPageAsync(client, platformUrl, instructionId, startToken, pageSize, logger));
                }

                var pages = await Task.WhenAll(tasks);

                // Reset startTokens for next batch
                startTokens.Clear();

                int batchFetched = 0;

                foreach (var page in pages)
                {
                    batchFetched += page.rows.Count;
                    allResults.AddRange(page.rows);

                    if (!string.IsNullOrEmpty(page.nextRange))
                    {
                        startTokens.Add(page.nextRange);
                    }
                }

                if (batchFetched == 0)
                {
                    morePages = false;
                }
            }

            logger.Log($"✅ Total fetched rows: {allResults.Count}");
            return allResults;
        }



        private async Task<(List<Dictionary<string, string>> rows, string? nextRange)> FetchPageAsync(
        HttpClient client,
        string platformUrl,
        int instructionId,
        string? startToken,
        int pageSize,
        ILogger logger)
        {
            var url = $"https://{platformUrl}/Consumer/Responses/{instructionId}";

            var payload = new
            {
                Filter = (object?)null,
                Start = startToken,
                PageSize = pageSize
            };

            var jsonPayload = JsonConvert.SerializeObject(payload);
            var content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");

            LogHelper.Info($"📥 Fetching page for instruction {instructionId} starting at '{startToken ?? "start"}'");

            var response = await client.PostAsync(url, content);
            if (!response.IsSuccessStatusCode)
            {
                LogHelper.Info($"❌ Failed to fetch page: {response.StatusCode}");
                return (new List<Dictionary<string, string>>(), null);
            }

            var jsonResponse = await response.Content.ReadAsStringAsync();
            var parsed = JObject.Parse(jsonResponse);

            var responsesArray = parsed["Responses"] as JArray;
            var nextRange = parsed["Range"]?.ToString();

            var rows = new List<Dictionary<string, string>>();
            if (responsesArray != null)
            {
                foreach (var obj in responsesArray)
                {
                    var fqdn = obj["Fqdn"]?.ToString() ?? obj["Device"]?["Fqdn"]?.ToString() ?? "Unknown";
                    var values = obj["Values"]?.ToObject<Dictionary<string, string>>() ?? new();
                    values["Fqdn"] = fqdn;
                    rows.Add(values);
                }
            }

            LogHelper.Info($"✅ Fetched {rows.Count} rows, next range token: {nextRange ?? "none"}");
            return (rows, nextRange);
        }

        public async Task<List<string>> LoadConsumersAsync(string fqdn, string token)
        {
            var consumers = new List<string>();

            try
            {
                using var client = new HttpClient
                {
                    BaseAddress = new Uri($"https://{fqdn}/")
                };
                client.DefaultRequestHeaders.Add("X-Tachyon-Authenticate", token);

                var response = await client.GetAsync("Consumer/Consumers");
                if (!response.IsSuccessStatusCode)
                {
                    LogHelper.Warn($"⚠️ LoadConsumersAsync: Failed to load consumers — Status: {response.StatusCode}");
                    return consumers;
                }

                var json = await response.Content.ReadAsStringAsync();

                try
                {
                    var doc = JsonDocument.Parse(json);

                    // Some platforms return a bare array: [ {"Name":"Explorer"}, ... ]
                    // Others return an object with an Items array.
                    JsonElement itemsElement;
                    if (doc.RootElement.ValueKind == JsonValueKind.Array)
                    {
                        itemsElement = doc.RootElement;
                    }
                    else if (doc.RootElement.ValueKind == JsonValueKind.Object &&
                             doc.RootElement.TryGetProperty("Items", out var tmp) &&
                             tmp.ValueKind == JsonValueKind.Array)
                    {
                        itemsElement = tmp;
                    }
                    else
                    {
                        LogHelper.Warn("⚠️ LoadConsumersAsync: Unexpected JSON shape for consumers.");
                        return consumers;
                    }

                    consumers = itemsElement
                        .EnumerateArray()
                        .Select(item => item.ValueKind == JsonValueKind.Object && item.TryGetProperty("Name", out var nameProp) ? nameProp.GetString() : null)
                        .Where(name => !string.IsNullOrWhiteSpace(name))
                        .ToList();
                }
                catch (System.Text.Json.JsonException jex)
                {
                    LogHelper.Error($"❌ LoadConsumersAsync: Failed to parse JSON → {jex.Message}");
                }

            }
            catch (Exception ex)
            {
                LogHelper.Error($"❌ LoadConsumersAsync: Exception → {ex.Message}");
            }

            return consumers;
        }


        public async Task<List<PolicySummary>?> LoadPoliciesAsync(string fqdn, string token, TextBox logBox)
        {
            try
            {
                var url = $"https://{fqdn}/consumer/policies/shallow/search";

                using var client = new HttpClient();
                client.DefaultRequestHeaders.Remove("X-Tachyon-Authenticate");
                client.DefaultRequestHeaders.Add("X-Tachyon-Authenticate", token);
                client.DefaultRequestHeaders.Remove("X-Tachyon-Consumer");
                client.DefaultRequestHeaders.Add("X-Tachyon-Consumer", "Explorer");

                var body = new
                {
                    Start = 1,
                    PageSize = 100,
                    Filter = (object?)null,
                    Sort = new object[] { }
                };

                var jsonBody = System.Text.Json.JsonSerializer.Serialize(body);
                var content = new StringContent(jsonBody, System.Text.Encoding.UTF8, "application/json");  // ✅ Content-Type is set here

                var response = await client.PostAsync(url, content);

                if (!response.IsSuccessStatusCode)
                {
                    LogHelper.Info($"❌ Failed to load policies: {response.StatusCode}\n");
                    return null;
                }

                var responseJson = await response.Content.ReadAsStringAsync();
                //   LogHelper.Info($"🔍 Raw JSON: {responseJson}\n");  // optional debug

                var result = System.Text.Json.JsonSerializer.Deserialize<PolicySearchResult>(responseJson, new System.Text.Json.JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

                var count = result?.Items?.Count ?? 0;
                LogHelper.Info($"✅ Loaded {count} policies.\n");

                return result?.Items ?? new List<PolicySummary>();
            }
            catch (Exception ex)
            {
                LogHelper.Info($"❌ Error loading policies: {ex.Message}\n");
                return null;
            }
        }


        public async Task<List<PolicyResultItem>> GetPolicyResultsAsync(
      string fqdn,
      string token,
      int policyId,
      object payload,
      List<int>? selectedRuleIds = null,
      bool local = true)
        {
            var results = new List<PolicyResultItem>();
            var seenIds = new HashSet<long>();


            try
            {
                if (policyId <= 0)
                    throw new ArgumentException("Invalid Policy ID");

                string url = $"https://{fqdn}/consumer/policy/responses/history/{policyId}/search/";

                using var client = new HttpClient();
                client.DefaultRequestHeaders.Add("X-Tachyon-Authenticate", token);
                client.DefaultRequestHeaders.Add("X-Tachyon-Consumer", "Explorer");

                string? bookmark = null;
                string? lastBookmark = null;
                int page = 1;

                do
                {
                    var payloadDict = JsonConvert.DeserializeObject<Dictionary<string, object>>(JsonConvert.SerializeObject(payload)) ?? new();
                    if (!string.IsNullOrEmpty(bookmark))
                        payloadDict["Bookmark"] = bookmark;
                    else
                        payloadDict.Remove("Bookmark");

                    var json = JsonConvert.SerializeObject(payloadDict);
                    var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

                    LogHelper.Info($"📤 Sending page {page} with Bookmark: {bookmark ?? "null"}");
                    var response = await client.PostAsync(url, content);
                    response.EnsureSuccessStatusCode();

                    var responseString = await response.Content.ReadAsStringAsync();
                    var policyResponse = JsonConvert.DeserializeObject<PolicyHistoryResponse>(responseString);

                    var items = policyResponse?.Items ?? new List<PolicyResultItem>();

                    var newItems = items.Where(i => !seenIds.Contains((int)i.Id)).ToList();


                    if (newItems.Count == 0)
                    {
                        LogHelper.Info($"🚫 Page {page} → No new items returned — stopping.");
                        break;
                    }

                    foreach (var item in newItems)
                        seenIds.Add(item.Id);

                    results.AddRange(newItems);
                    LogHelper.Info($"📄 Page {page} → Retrieved {newItems.Count} new items (Total so far: {results.Count})");

                    lastBookmark = bookmark;
                    bookmark = policyResponse?.Bookmark;

                    LogHelper.Info($"🔖 Bookmark returned: {bookmark ?? "null"}");

                    if (string.IsNullOrWhiteSpace(bookmark) || bookmark == lastBookmark)
                    {
                        LogHelper.Info($"✅ No more pages or stuck bookmark ({bookmark ?? "null"}) — stopping.");
                        break;
                    }

                    page++;
                }
                while (true);

                // Apply Rule filtering
                if (selectedRuleIds != null && selectedRuleIds.Count > 0)
                {
                    results = results
                        .Where(item => selectedRuleIds.Contains(item.RuleId))
                        .ToList();
                }
            }
            catch (Exception ex)
            {
                LogHelper.Error($"❌ GetPolicyResultsAsync failed: {ex.Message}");
            }

            return results;
        }




        public async Task<List<PolicyRule>> GetPolicyRulesAsync(string fqdn, string token)
        {
            var rules = new List<PolicyRule>();

            try
            {
                var url = $"https://{fqdn}/consumer/rules/shallow/search";
                LogHelper.Info($"🔗 Requesting policy rules from: {url} with Token ending in: ...{token[^6..]}");

                using var client = new HttpClient();
                client.DefaultRequestHeaders.Add("X-Tachyon-Authenticate", token);
                client.DefaultRequestHeaders.Add("X-Tachyon-Consumer", "Explorer");

                var body = new
                {
                    Type = "rules",
                    Start = 1,
                    PageSize = 1000,
                    Filter = (object?)null,
                    Sort = new[]
                    {
                new { Column = "Name", Direction = "ASC" }
            }
                };

                var jsonBody = System.Text.Json.JsonSerializer.Serialize(body);
                LogHelper.Info($"📤 Request Body: {jsonBody}");

                var content = new StringContent(jsonBody, System.Text.Encoding.UTF8, "application/json");

                var response = await client.PostAsync(url, content);

                var rawResponse = await response.Content.ReadAsStringAsync();
                //LogHelper.Info($"📥 Raw Response: {rawResponse}");

                if (!response.IsSuccessStatusCode)
                {
                    LogHelper.Warn($"⚠️ GetPolicyRulesAsync failed → StatusCode: {response.StatusCode}");
                    return rules;
                }

                var parsed = System.Text.Json.JsonDocument.Parse(rawResponse);

                if (parsed.RootElement.TryGetProperty("Items", out var items) && items.ValueKind == System.Text.Json.JsonValueKind.Array)
                {
                    foreach (var item in items.EnumerateArray())
                    {
                        var rule = new PolicyRule
                        {
                            Id = item.TryGetProperty("Id", out var idProp) && idProp.TryGetInt32(out var idVal) ? idVal : 0,
                            Name = item.TryGetProperty("Name", out var nameProp) ? nameProp.GetString() ?? "" : "",
                            Description = item.TryGetProperty("Description", out var descProp) ? descProp.GetString() ?? "" : ""
                        };
                        rules.Add(rule);
                    }

                    LogHelper.Info($"✅ Parsed {rules.Count} policy rules.");
                }
                else
                {
                    LogHelper.Warn("⚠️ GetPolicyRulesAsync: No 'Items' array found in response.");
                }
            }
            catch (Exception ex)
            {
                LogHelper.Error($"❌ GetPolicyRulesAsync failed: {ex.Message}");
            }

            return rules;
        }



        public class PolicyRuleSearchResult
        {
            public List<PolicyRule> Items { get; set; } = new();
        }


    }
}
