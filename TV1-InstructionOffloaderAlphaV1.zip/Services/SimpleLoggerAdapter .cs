﻿using Microsoft.Extensions.Logging;
using System;

namespace TV1_InstructionOffloader.Services
{
    public class SimpleLoggerAdapter : Microsoft.Extensions.Logging.ILogger
    {
        private readonly ILogger _simpleLogger;

        public SimpleLoggerAdapter(ILogger simpleLogger)
        {
            _simpleLogger = simpleLogger;
        }

        public IDisposable BeginScope<TState>(TState state) => null!;

        public bool IsEnabled(LogLevel logLevel) => true;

        public void Log<TState>(LogLevel logLevel, EventId eventId,
            TState state, Exception? exception, Func<TState, Exception?, string> formatter)
        {
            if (formatter == null) return;
            string message = formatter(state, exception);

            // Map logLevel to your interface methods
            switch (logLevel)
            {
                case LogLevel.Trace:
                case LogLevel.Debug:
                    _simpleLogger.LogDebug(message);
                    break;
                case LogLevel.Information:
                    _simpleLogger.LogInformation(message);
                    break;
                case LogLevel.Warning:
                    _simpleLogger.LogWarning(message);
                    break;
                case LogLevel.Error:
                case LogLevel.Critical:
                    _simpleLogger.Log(message);
                    break;
                case LogLevel.None:
                default:
                    break;
            }
        }
    }
}
