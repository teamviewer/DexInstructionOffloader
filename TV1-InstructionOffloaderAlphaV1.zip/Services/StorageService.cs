// Represents the available export and storage formats
public enum ExportFormat
{
    JSON,
    SQLite,
    SQLServer,
    Oracle,
    CSV,
    TSV,
    XLSX
}

public class ExportConfig
{
    public ExportFormat Format { get; set; } = ExportFormat.JSON;

    // Common properties
    public string ExportPathOrConnectionString { get; set; } = string.Empty;

    // Optional database-specific properties
    public string? Server { get; set; }     // For SQL Server, Oracle
    public string? Database { get; set; }
    public string? Username { get; set; }
    public string? EncryptedPassword { get; set; } // Encrypted per machine
    public int? Port { get; set; }

    // Additional options
    public bool OverwriteExisting { get; set; } = true;
    public bool IncludeHeaders { get; set; } = true;
    public bool UseMachineEncryption { get; set; } = true; // Flag for password protection
}
