﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;



public class ResultTrackerService
{
    private readonly string _filePath;
    private List<InstructionRunMetadata> _runs = new();

    public ResultTrackerService(string filePath)
    {
        _filePath = filePath;
        Load();
    }

    public void AddOrUpdateRun(InstructionRunMetadata run)
    {
        var existing = _runs.FirstOrDefault(r => r.InstructionId == run.InstructionId);
        if (existing != null)
            _runs.Remove(existing);

        _runs.Add(run);
        Save();
    }

    public List<InstructionRunMetadata> GetPendingRuns()
    {
        return _runs.Where(r =>
            !r.ResultsFetched &&
            DateTime.UtcNow >= r.RunTimeUtc.AddMinutes(r.TTLMinutes)
        ).ToList();
    }

    public void MarkAsFetched(int instructionId)
    {
        var run = _runs.FirstOrDefault(r => r.InstructionId == instructionId);
        if (run != null)
        {
            run.ResultsFetched = true;
            Save();
        }
    }

    private void Load()
    {
        if (File.Exists(_filePath))
        {
            var json = File.ReadAllText(_filePath);
            _runs = JsonConvert.DeserializeObject<List<InstructionRunMetadata>>(json) ?? new();
        }
    }

    private void Save()
    {
        var json = JsonConvert.SerializeObject(_runs, Formatting.Indented);
        File.WriteAllText(_filePath, json);
    }
}
