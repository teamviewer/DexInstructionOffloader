﻿using System;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using TV1_InstructionOffloader.Models;

namespace TV1_InstructionOffloader.Services
{
    public class SettingsService
    {
        private readonly string _configPath;

        public SettingsService(string configPath)
        {
            _configPath = configPath;
        }

        public async Task<Settings> LoadSettingsAsync()
        {
            if (!File.Exists(_configPath))
            {
                var defaultSettings = new Settings();
                await SaveSettingsAsync(defaultSettings);
                return defaultSettings;
            }

            using FileStream fs = File.OpenRead(_configPath);
            return await JsonSerializer.DeserializeAsync<Settings>(fs) ?? new Settings();
        }

        public async Task SaveSettingsAsync(Settings settings)
        {
            using FileStream fs = File.Create(_configPath);
            await JsonSerializer.SerializeAsync(fs, settings, new JsonSerializerOptions { WriteIndented = true });
        }

        // Placeholder for SQL import/export
        public Task ImportFromSqlAsync()
        {
            // TODO: Implement SQL import logic
            return Task.CompletedTask;
        }

        public Task ExportToSqlAsync()
        {
            // TODO: Implement SQL export logic
            return Task.CompletedTask;
        }
    }
}
