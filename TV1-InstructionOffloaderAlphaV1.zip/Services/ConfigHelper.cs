﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using TV1_InstructionOffloader.Helpers;
using TV1_InstructionOffloader.Models;

namespace TV1_InstructionOffloader.Services
{
    public class ConfigHelper
    {
        private readonly string _configPath;

        public string ConfigPath => _configPath;

        public ConfigHelper()
        {
            _configPath = AppPaths.AppSettingsPath;
        }

        public AppSettings Load()
        {
            if (!File.Exists(_configPath))
            {
                var defaultSettings = GetDefaultSettings();
                Save(defaultSettings);
                return defaultSettings;
            }

            var json = File.ReadAllText(_configPath);
            var loaded = JsonConvert.DeserializeObject<AppSettings>(json) ?? new AppSettings();

            // Some callers previously saved platform objects without newer optional fields (e.g., Alias/UserId).
            // Newtonsoft should normally populate them, but to be robust we also merge directly from the raw JSON.
            try
            {
                var root = JObject.Parse(json);
                var platformsArr = root["Platforms"] as JArray;
                if (platformsArr != null && loaded.Platforms != null)
                {
                    static string? GetStringCI(JObject o, string name)
                    {
                        // JObject property lookup is case-sensitive; allow UserId/userId/etc.
                        foreach (var p in o.Properties())
                        {
                            if (p.Name.Equals(name, StringComparison.OrdinalIgnoreCase))
                                return p.Value?.ToString();
                        }
                        return null;
                    }

                    static bool? GetBoolCI(JObject o, string name)
                    {
                        foreach (var p in o.Properties())
                        {
                            if (!p.Name.Equals(name, StringComparison.OrdinalIgnoreCase))
                                continue;

                            if (p.Value == null)
                                return null;

                            if (p.Value.Type == JTokenType.Boolean)
                                return p.Value.Value<bool>();

                            if (p.Value.Type == JTokenType.String && bool.TryParse(p.Value.ToString(), out var b))
                                return b;
                        }
                        return null;
                    }

                    foreach (var obj in platformsArr.OfType<JObject>())
                    {
                        var fqdn = (GetStringCI(obj, "PlatformFqdn") ?? "").Trim();
                        if (string.IsNullOrWhiteSpace(fqdn))
                            continue;

                        var existing = loaded.Platforms.FirstOrDefault(p =>
                            string.Equals((p.PlatformFqdn ?? "").Trim(), fqdn, StringComparison.OrdinalIgnoreCase));
                        if (existing == null)
                            continue;

                        // Merge fields that may be missing due to older save logic or partial platform objects.
                        var alias = GetStringCI(obj, "Alias");
                        if (!string.IsNullOrWhiteSpace(alias) && string.IsNullOrWhiteSpace(existing.Alias))
                            existing.Alias = alias;

                        var userId = GetStringCI(obj, "UserId");
                        if (!string.IsNullOrWhiteSpace(userId) && string.IsNullOrWhiteSpace(existing.UserId))
                            existing.UserId = userId;

                        // Ensure UseCert survives even if older files used AuthenticationMode only.
                        var useCert = GetBoolCI(obj, "UseCert");
                        if (useCert.HasValue)
                            existing.UseCert = useCert.Value;

                        // Preserve RequireCoverage even if older models did not include it.
                        var requireCoverage = GetBoolCI(obj, "RequireCoverage");
                        if (requireCoverage.HasValue)
                            existing.RequireCoverage = requireCoverage.Value;
                    }
                }
            }
            catch
            {
                // Non-fatal: keep the deserialized result.
            }

            if (loaded.Platforms == null)
                loaded.Platforms = new List<PlatformSettings>();

            if (loaded.Headless == null)
                loaded.Headless = new HeadlessSettings();

            return loaded;
        }

        public void Save(AppSettings config)
        {
            var json = JsonConvert.SerializeObject(config, Formatting.Indented);
            File.WriteAllText(_configPath, json);
        }

        private AppSettings GetDefaultSettings()
        {
            return new AppSettings
            {
                Platforms = new List<PlatformSettings>
                {
                    new PlatformSettings
                    {
                        PlatformFqdn = "",
                        DefaultConsumer = "Explorer",
                        IsDefault = true
                    }
                },
                Headless = new HeadlessSettings
                {
                    UseSql = false,
                    SqlConnectionString = "",
                    JsonStorePath = "InstructionRunStore.json",
                    OutputFolder = "Exports",
                    LogFilePath = "headless.log",
                    ResultCheckIntervalMinutes = 10,
                    AutoRecover = true
                },
                ReauthMinutes = 5,
                EnableDevTokenReuse = false,

                // Display defaults
                UseUtcTimestamps = false,
                DefaultExportFolder = "",
                DefaultExportMode = "PagingThenServer"

            };
        }

        public static string GetDefaultPlatformUrl()
        {
            string roaming = AppPaths.AppSettingsPath;

            string fallback = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "data", "appsettings.json");

            string path = File.Exists(roaming) ? roaming :
                          File.Exists(fallback) ? fallback :
                          "";

            if (string.IsNullOrWhiteSpace(path))
            {
                LogHelper.Warn("⚠️ No appsettings.json found in roaming or data folder. Using fallback URL.");
                return "https://localhost";
            }

            try
            {
                var json = JObject.Parse(File.ReadAllText(path));
                string defaultAlias = json["DefaultPlatformAlias"]?.ToString()?.Trim() ?? "";
                var platforms = json["Platforms"] as JArray;

                foreach (var entry in platforms?.OfType<JObject>() ?? Enumerable.Empty<JObject>())
                {
                    var url = entry["PlatformFqdn"]?.ToString()?.Trim();
                    var alias = entry["Alias"]?.ToString()?.Trim();

                    if (!string.IsNullOrEmpty(url) &&
                        !string.IsNullOrEmpty(alias) &&
                        alias.Equals(defaultAlias, StringComparison.OrdinalIgnoreCase))
                        return url;
                }

                return platforms?.OfType<JObject>().FirstOrDefault()?["PlatformFqdn"]?.ToString()?.Trim() ?? "https://localhost";
            }
            catch (Exception ex)
            {
                LogHelper.Error($"❌ Failed to parse platform from appsettings.json: {ex.Message}");
                return "https://localhost";
            }
        }

        public void AddOrUpdatePlatform(PlatformSettings platform)
        {
            var config = Load();

            config.Platforms.RemoveAll(p =>
                string.Equals(p.PlatformFqdn?.Trim(), platform.PlatformFqdn?.Trim(), StringComparison.OrdinalIgnoreCase));

            config.Platforms.Add(platform);

            if (platform.IsDefault)
            {
                config.DefaultPlatformAlias = platform.Alias;
                config.DefaultPlatformFqdn = platform.PlatformFqdn;
            }

            Save(config);
        }
    }
}
