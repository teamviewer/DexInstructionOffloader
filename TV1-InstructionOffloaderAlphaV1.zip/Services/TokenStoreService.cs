using System;
using System.Runtime.InteropServices;
using System.Text;

namespace TV1_InstructionOffloader.Services
{
    /// <summary>
    /// Windows Credential Manager�backed token store with in-process cache.
    /// Provides StoreToken/TryGetToken/RemoveToken, plus SaveToken alias for backward compatibility.
    /// </summary>
    public sealed class TokenStoreService
    {
        // ---------------- In-process cache (avoids roundtrips to CredMan) ----------------
        private static readonly System.Collections.Concurrent.ConcurrentDictionary<string, string> _mem =
            new System.Collections.Concurrent.ConcurrentDictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        // ---------------- Public API ----------------
        public void StoreToken(string platformFqdn, string token)
        {
            if (string.IsNullOrWhiteSpace(platformFqdn)) throw new ArgumentNullException(nameof(platformFqdn));
            if (token == null) token = string.Empty;

            var key = NormalizeKey(platformFqdn);
            _mem[key] = token;

            try
            {
                // Persist to Windows Credential Manager
                WriteCred(key, token);
            }
            catch
            {
                // Ignore CredMan failures; memory cache still works
            }
        }

        // Legacy alias to keep older call sites compiling
        public void SaveToken(string platformFqdn, string token) => StoreToken(platformFqdn, token);

        public bool TryGetToken(string platformFqdn, out string token)
        {
            token = null;
            if (string.IsNullOrWhiteSpace(platformFqdn)) return false;

            var key = NormalizeKey(platformFqdn);

            // 1) Memory
            if (_mem.TryGetValue(key, out var t) && !string.IsNullOrWhiteSpace(t))
            {
                token = t;
                return true;
            }

            // 2) CredMan
            try
            {
                var read = ReadCred(key);
                if (!string.IsNullOrWhiteSpace(read))
                {
                    _mem[key] = read;
                    token = read;
                    return true;
                }
            }
            catch { }

            return false;
        }

        public void RemoveToken(string platformFqdn)
        {
            if (string.IsNullOrWhiteSpace(platformFqdn)) return;
            var key = NormalizeKey(platformFqdn);

            _mem.TryRemove(key, out _);
            try { DeleteCred(key); } catch { }
        }

        private static string NormalizeKey(string fqdn)
        {
            fqdn = fqdn.Trim();
            if (fqdn.StartsWith("http://", StringComparison.OrdinalIgnoreCase)) fqdn = fqdn.Substring(7);
            if (fqdn.StartsWith("https://", StringComparison.OrdinalIgnoreCase)) fqdn = fqdn.Substring(8);
            fqdn = fqdn.TrimEnd('/').ToLowerInvariant();
            return "TV1_InstructionOffloader:" + fqdn;
        }

        // ---------------- Windows CredMan P/Invoke ----------------
        private const int CRED_TYPE_GENERIC = 1;

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct CREDENTIAL
        {
            public int Flags;
            public int Type;
            public string TargetName;
            public string Comment;
            public System.Runtime.InteropServices.ComTypes.FILETIME LastWritten;
            public int CredentialBlobSize;
            public IntPtr CredentialBlob;
            public int Persist;
            public int AttributeCount;
            public IntPtr Attributes;
            public string TargetAlias;
            public string UserName;
        }

        [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        private static extern bool CredWrite([In] ref CREDENTIAL userCredential, [In] uint flags);

        [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        private static extern bool CredRead(string target, int type, int reservedFlag, out IntPtr CredentialPtr);

        [DllImport("advapi32.dll", SetLastError = true)]
        private static extern bool CredDelete(string target, int type, int flags);

        [DllImport("advapi32.dll")]
        private static extern void CredFree([In] IntPtr cred);

        private static void WriteCred(string targetName, string secret)
        {
            var bytes = Encoding.Unicode.GetBytes(secret ?? string.Empty);

            var cred = new CREDENTIAL
            {
                TargetName = targetName,
                Type = CRED_TYPE_GENERIC,
                Persist = 2, // CRED_PERSIST_LOCAL_MACHINE
                CredentialBlobSize = bytes.Length,
                AttributeCount = 0,
                UserName = Environment.UserName
            };

            // allocate unmanaged buffer for blob
            cred.CredentialBlob = Marshal.AllocHGlobal(bytes.Length);
            try
            {
                Marshal.Copy(bytes, 0, cred.CredentialBlob, bytes.Length);
                if (!CredWrite(ref cred, 0))
                {
                    // swallow; caller tolerates persistence failures
                }
            }
            finally
            {
                if (cred.CredentialBlob != IntPtr.Zero)
                    Marshal.FreeHGlobal(cred.CredentialBlob);
            }
        }

        private static string ReadCred(string targetName)
        {
            if (!CredRead(targetName, CRED_TYPE_GENERIC, 0, out var credPtr))
                return null;

            try
            {
                var cred = Marshal.PtrToStructure<CREDENTIAL>(credPtr);
                if (cred.CredentialBlob == IntPtr.Zero || cred.CredentialBlobSize <= 0)
                    return null;

                var bytes = new byte[cred.CredentialBlobSize];
                Marshal.Copy(cred.CredentialBlob, bytes, 0, cred.CredentialBlobSize);
                return Encoding.Unicode.GetString(bytes);
            }
            finally
            {
                CredFree(credPtr);
            }
        }

        private static void DeleteCred(string targetName)
        {
            CredDelete(targetName, CRED_TYPE_GENERIC, 0);
        }
    }
}
