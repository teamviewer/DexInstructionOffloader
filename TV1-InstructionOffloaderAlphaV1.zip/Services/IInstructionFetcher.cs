﻿using System.Threading.Tasks;

namespace TV1_InstructionOffloader.Services
{
    public interface IInstructionFetcher
    {
        Task<bool> FetchResultsAsync(int instructionId);
    }
}
