﻿// ILogger.cs
namespace TV1_InstructionOffloader.Services
{
    public interface ILogger
    {
        void Log(string message);
        void LogInformation(string message);
        void LogWarning(string message);
        void LogDebug(string message);
    }
}
