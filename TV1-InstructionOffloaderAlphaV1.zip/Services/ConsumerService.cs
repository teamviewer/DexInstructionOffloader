﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using TV1_InstructionOffloader.Models;

namespace TV1_InstructionOffloader.Services
{
    public class ConsumerService
    {
        private readonly Action<string>? _log;

        public ConsumerService(Action<string>? log = null)
        {
            _log = log;
        }

        private void Log(string message)
        {
            _log?.Invoke(message);
        }

        public async Task<List<string>> GetConsumersAsync(string platformUrl, string token)
        {
            var consumers = new List<string>();
            try
            {
                string tokenLogSafe = string.IsNullOrWhiteSpace(token) || token.Length < 6
                    ? "[too short]"
                    : $"...{token[^6..]}";  // logs last 6 characters

                LogHelper.Info($"🔐 Using token for {platformUrl} ending in: {tokenLogSafe}\n");

                using var client = new HttpClient();
                client.DefaultRequestHeaders.Add("X-Tachyon-Authenticate", token);

                var url = $"https://{platformUrl}/Consumer/Consumers";
                Log($"🌐 Requesting Consumers from: {url}");

                var response = await client.GetAsync(url);
                var json = await response.Content.ReadAsStringAsync();
                Log($"📦 Raw Consumer JSON: {json}");

                if (response.IsSuccessStatusCode)
                {
                    var fullList = JsonConvert.DeserializeObject<List<ConsumerInfo>>(json);
                    consumers = fullList?
                        .Where(c => c.IsEnabled && !string.IsNullOrWhiteSpace(c.Name))
                        .Select(c => c.Name)
                        .Distinct()
                        .ToList() ?? new List<string>();

                    Log($"✅ Loaded {consumers.Count} consumers.");
                }
                else
                {
                    Log($"❌ Failed to load consumers: {response.ReasonPhrase} ({(int)response.StatusCode})");
                }
            }
            catch (Exception ex)
            {
                Log($"❌ Exception while loading consumers: {ex.Message}");
            }

            return consumers;
        }


    }

}
