﻿using Avalonia.Threading;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using TV1_InstructionOffloader.Models;
using TV1_InstructionOffloader.Services;
using TV1_InstructionOffloader.Helpers;

public interface IInstructionJobExecutor
{
    Task<JobRunResult> RunJobAsync(ScheduledJob job, CancellationToken ct);
    Task<JobRunResult> RunJobAsync(ScheduledJob job, string token, CancellationToken ct);
}

public class JobRunResult
{
    public int? ResponseId { get; set; }
    public bool Success { get; set; }
    public string? ErrorMessage { get; set; }
}

public sealed class FakeInstructionJobExecutor : IInstructionJobExecutor
{
    private readonly Action<string> _log;

    public FakeInstructionJobExecutor(Action<string> logger) => _log = logger;

    public async Task<JobRunResult> RunJobAsync(ScheduledJob job, CancellationToken ct)
    {
        await Dispatcher.UIThread.InvokeAsync(() =>
        {
            _log($"▶️  FAKE-RUN start for {job.InstructionName}");
        });

        await Task.Delay(TimeSpan.FromSeconds(10), ct);

        var fakeResponseId = new Random().Next(1000, 9999); // simulate a numeric response ID

        return new JobRunResult
        {
            Success = true,
            ResponseId = fakeResponseId
        };
    }


    public Task<JobRunResult> RunJobAsync(ScheduledJob job, string token, CancellationToken ct)
    {
        // Token is ignored in fake executor
        return RunJobAsync(job, ct);
    }
}