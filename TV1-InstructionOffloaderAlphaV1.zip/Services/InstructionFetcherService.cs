﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using TV1_InstructionOffloader.Models;

namespace TV1_InstructionOffloader.Services
{
    public class InstructionFetcherService : IInstructionFetcher
    {
        private readonly string _platformUrl;
        private readonly string _token;

        public InstructionFetcherService(string platformUrl, string token)
        {
            if (string.IsNullOrWhiteSpace(platformUrl))
                throw new ArgumentNullException(nameof(platformUrl), "Platform URL cannot be null or empty.");

            if (string.IsNullOrWhiteSpace(token))
                throw new ArgumentNullException(nameof(token), "Token cannot be null or empty.");

            _platformUrl = platformUrl.TrimEnd('/');
            _token = token;
        }


        public async Task<bool> FetchResultsAsync(int instructionId)
        {
            try
            {
                var url = $"https://{_platformUrl}/Consumer/Responses/{instructionId}";
                using var client = new HttpClient();

                client.DefaultRequestHeaders.Add("X-Tachyon-Authenticate", _token);
                client.DefaultRequestHeaders.Add("X-Tachyon-Consumer", "TV1_Offloader");

                var response = await client.GetAsync(url);
                if (!response.IsSuccessStatusCode)
                {
                    Console.WriteLine($"⚠️ Failed to fetch results: {response.StatusCode}");
                    return false;
                }

                var content = await response.Content.ReadAsStringAsync();
                Console.WriteLine($"✅ Received results for ID {instructionId}:\n{content.Substring(0, Math.Min(300, content.Length))}...");
                // TODO: Save/export results

                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Exception fetching results for {instructionId}: {ex.Message}");
                return false;
            }
        }
    }
}
