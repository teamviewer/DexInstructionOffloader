using Avalonia.Controls;                 // Avalonia UI controls like TextBox
using Avalonia.Threading;                // UI thread dispatch
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.WebSockets;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Security.Claims;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.Win32;
using TV1_InstructionOffloader.Models;
using TV1_InstructionOffloader.Services; // TokenStoreService & ExperienceService

namespace TV1_InstructionOffloader.Services
{
    // ------------------------------------------------------------------------
    // Public result model (keep same as original)
    // ------------------------------------------------------------------------
    public class AuthenticationResult
    {
        public string Token { get; set; }
        public string PrincipalName { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? ConsumerName { get; set; }
        public string? FailureReason { get; set; }
    }

    // ------------------------------------------------------------------------
    // Main service
    // ------------------------------------------------------------------------
    public sealed class AuthenticationService
    {
        #region === Fields (keep names to match original call sites) ===

        private readonly TimeSpan _httpTimeout = TimeSpan.FromSeconds(15);

        private string _token = string.Empty;
        private string _platformUrl = string.Empty;

        // In-process memory token cache (shared across service instances)
        private static readonly ConcurrentDictionary<string, string> s_memoryTokens =
            new ConcurrentDictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        // Some environments require the JWT "aud" claim to be the IdP token endpoint (e.g. https://login.microsoftonline.com/<tenant>/oauth2/v2.0/token)
        // rather than the platform FQDN. We learn the correct audience from platform validation errors and cache it per platform+appId.
        private static readonly ConcurrentDictionary<string, string> s_certJwtAudienceCache =
            new ConcurrentDictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        private static string NormalizeFqdnSimple(string urlOrHost)
        {
            if (string.IsNullOrWhiteSpace(urlOrHost)) return string.Empty;
            var s = urlOrHost.Trim();
            if (s.StartsWith("http://", StringComparison.OrdinalIgnoreCase)) s = s.Substring(7);
            if (s.StartsWith("https://", StringComparison.OrdinalIgnoreCase)) s = s.Substring(8);
            s = s.TrimEnd('/');
            return s.ToLowerInvariant();
        }

        private static string BuildMemKey(string platformUrl, string appId)
            => NormalizeFqdnSimple(platformUrl) + "|" + (appId ?? string.Empty);

        private static string BuildAudKey(string platformUrl, string appId)
            => BuildMemKey(platformUrl, appId) + "|aud";

        private Timer? _authCheckTimer;
        private int _reauthThresholdMinutes = 5;

        private TextBox? _logTextBox;
        private DateTime? _expirationTime;

        private void AppendLogUi(string text)
        {
            try
            {
                var box = _logTextBox;
                if (box == null) return;

                if (Dispatcher.UIThread.CheckAccess())
                {
                    box.Text += text;
                }
                else
                {
                    Dispatcher.UIThread.Post(() =>
                    {
                        try
                        {
                            var b = _logTextBox;
                            if (b != null)
                                b.Text += text;
                        }
                        catch { }
                    });
                }
            }
            catch { }
        }

        /// <summary>
        /// Always cache to memory; persist to Windows Credential Vault only when true.
        /// </summary>
        private readonly bool _enableDevTokenReuse;

        public event Action<string>? TokenTimeRemainingUpdated;

        // (Legacy) file-path members are retained to avoid breaking references,
        // but all disk persistence is disabled in this implementation.
        private readonly string _tokenFolderPath =
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "TVInstructionRunner");
        private readonly string _tokenFileName = "tvappdata.bin";
        private string TokenFilePath => Path.Combine(_tokenFolderPath, _tokenFileName);

        private bool _tokenRefreshInProgress = false;

        private readonly ExperienceService? _experienceService; // if you wire it
        private readonly TokenStoreService _tokenStoreService;

        private MainWindow? _mainWindow;
        private string? _fqdn;
        private string? _appId;
        private string? _certThumbprint;
        private PlatformConfigData? _currentPlatform;
        private bool _logoutInProgress = false;
        private bool _authInProgress = false; // keep single definition
        private DateTime _lastLogoutTime = DateTime.MinValue;
        private readonly TimeSpan _logoutCooldown = TimeSpan.FromSeconds(5);
        private int _authRetryCount = 0;
        private const int MaxAuthRetries = 1;
        private bool _browserOpened = false;

        private string _TachyonConsumer = "Explorer";
        public string TachyonConsumer { set { _TachyonConsumer = value; } }

        private string _ApplicationId = "";
        public string ApplicationId { set { _ApplicationId = value; } }

        private string _TachyonServer = "";
        public string TachyonServer { set { _TachyonServer = value; } }

        private string _CertificateThumbprint = "";
        public string CertificateThumbprint { set { _CertificateThumbprint = value; } }

        private const int ExpirationSeconds = 3600;

        private readonly string _consumerName = "Explorer";

        private bool _isCertAuth = false;

        // Cooldowns and concurrency
        private readonly Dictionary<string, DateTime> _lastAuthAttempts = new();
        private static readonly ConcurrentDictionary<string, SemaphoreSlim> _authLocks = new();
        private readonly TimeSpan _authCooldown = TimeSpan.FromSeconds(5);

        #endregion

        #region === Constructors (keep overloads to match original) ===

        // Original-style ctor with many dependencies
        public AuthenticationService(
            ConfigHelper configHelper,
            TextBox logTextBox,
            ExperienceService experienceService,
            TokenStoreService tokenStoreService,
            string consumerName,
            MainWindow mainWindow)
        {
            // Keep config wire-up (reauth minutes)
            var config = (configHelper ?? new ConfigHelper()).Load();
            _reauthThresholdMinutes = config.ReauthMinutes;

            _logTextBox = logTextBox;
            _experienceService = experienceService;
            _tokenStoreService = tokenStoreService ?? new TokenStoreService();
            _mainWindow = mainWindow;
            _TachyonConsumer = string.IsNullOrWhiteSpace(consumerName) ? "Explorer" : consumerName;

            Console.WriteLine($"🔁 Reauth threshold set to {_reauthThresholdMinutes} minutes.");
        }

        // Lightweight ctor the rest of the app sometimes uses
        public AuthenticationService(bool enableDevTokenReuse = false, TokenStoreService tokenStoreService = null)
        {
            _enableDevTokenReuse = enableDevTokenReuse;
            _tokenStoreService = tokenStoreService ?? new TokenStoreService();
        }

        #endregion

        #region === Public Token property (with side-effects exactly like original) ===

        public string Token
        {
            get => _token;
            set
            {
                _token = value;

                var parts = _token?.Split('.') ?? Array.Empty<string>();
                AppendLogUi($"🧪 Token Part Count: {parts.Length}\n");

                if (parts.Length < 2)
                {
                    LogHelper.Info("⚠️ Invalid token format.\n");
                    return;
                }

                // Try to decode payload expiration
                DumpJwtPayload(_token);

                if (_expirationTime == null)
                {
                    var headerExpiration = GetTokenExpirationTime();
                    if (headerExpiration != null)
                    {
                        _expirationTime = headerExpiration;
                        LogHelper.Info($"🕓 Token Expiration (from header): {_expirationTime} UTC \n");
                    }
                    else
                    {
                        LogHelper.Info("⚠️ No expiration found in token. Using fallback.\n");
                        _expirationTime = DateTime.UtcNow.AddMinutes(10);
                    }
                }

                // Start monitoring
                StartAuthCheckTimer();
                _ = CheckTokenExpirationAsync();
                RaiseAuthStatusChanged();
            }
        }

        #endregion

        #region === Expiration monitoring / UI updates ===

        private void DumpJwtPayload(string? token)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(token))
                {
                    Console.WriteLine("⚠️ Token is null or empty.");
                    return;
                }

                var parts = token.Split('.');
                if (parts.Length < 2)
                {
                    Console.WriteLine("❌ Invalid JWT format.");
                    return;
                }

                string payload = parts[1];
                payload = payload.PadRight(payload.Length + (4 - payload.Length % 4) % 4, '=');

                byte[] jsonBytes = Convert.FromBase64String(payload.Replace('-', '+').Replace('_', '/'));
                string json = Encoding.UTF8.GetString(jsonBytes);

                Console.WriteLine("🔎 JWT Payload:");
                Console.WriteLine(json);

                dynamic decoded = JsonConvert.DeserializeObject(json);
                var expUnix = decoded?.exp;
                if (expUnix != null)
                {
                    long expSeconds = (long)expUnix;
                    DateTimeOffset expDate = DateTimeOffset.FromUnixTimeSeconds(expSeconds).UtcDateTime;
                    Console.WriteLine($"🕓 Token Expiration: {expDate:u} ({(expDate - DateTimeOffset.UtcNow).TotalMinutes:F1} mins from now)");
                    _expirationTime = expDate.UtcDateTime;
                }
                else
                {
                    Console.WriteLine("⚠️ No 'exp' claim found in JWT.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error decoding JWT: {ex.Message}");
            }
        }

        public void StartAuthCheckTimer()
        {
            _authCheckTimer?.Dispose();

            if (_expirationTime != null)
            {
                _authCheckTimer = new Timer(_ =>
                {
                    try { _ = CheckTokenExpirationAsync(); }
                    catch (Exception ex) { LogHelper.Info($"⚠️ Timer error: {ex.Message}\n"); }
                }, null, TimeSpan.FromSeconds(30), TimeSpan.FromSeconds(30));

                var nowLocal = DateTime.Now;
                var nowUtc = DateTime.UtcNow;

                var expirationLocal = _expirationTime.Value.ToLocalTime();
                var expirationUtc = _expirationTime.Value;

                var refreshAtLocal = expirationLocal.AddMinutes(-_reauthThresholdMinutes);
                var refreshAtUtc = expirationUtc.AddMinutes(-_reauthThresholdMinutes);

                string tokenSuffix = string.IsNullOrWhiteSpace(_token) || _token.Length < 6 ? "(none)" : _token[^6..];
                string platformInfo = string.IsNullOrWhiteSpace(_platformUrl) ? "(no platform)" : _platformUrl;

                LogHelper.Info($"⏳ Token monitoring started (expires at {expirationLocal} local / {expirationUtc} UTC)");
                LogHelper.Info($"⚙️ Reauth threshold from appsettings: {_reauthThresholdMinutes} minutes");
                LogHelper.Info($"🧮 Now: {nowLocal:T} local / {nowUtc:T} UTC | Expires: {expirationLocal:T} / {expirationUtc:T} | Will refresh: {refreshAtLocal:T} / {refreshAtUtc:T}");
                LogHelper.Info($"🔗 Platform: {platformInfo} | Token ending: ...{tokenSuffix}");
            }
            else
            {
                LogHelper.Info("⚠️ Skipping token expiration monitoring — no expiration time set.\n");
            }
        }

        public void NotifyTokenTimeRemaining(TimeSpan remaining)
        {
            string formatted = $"{(int)remaining.TotalMinutes}m {remaining.Seconds:D2}s";
            RaiseTokenTimeRemainingUpdated(formatted);
        }

        public async Task CheckTokenExpirationAsync()
        {
            if (_isCertAuth)
            {
                // For cert-based flows you might skip refresh mechanics.
                return;
            }

            if (_expirationTime == null)
            {
                Dispatcher.UIThread.Post(() => LogHelper.Info("⚠️ No expiration time available.\n"));
                return;
            }

            var expirationLocal = _expirationTime.Value.ToLocalTime();
            var nowLocal = DateTime.Now;
            var timeRemaining = expirationLocal - nowLocal;

            string remainingText = $"{(int)timeRemaining.TotalMinutes}m {timeRemaining.Seconds}s";
            RaiseTokenTimeRemainingUpdated(remainingText);

            if (timeRemaining <= TimeSpan.Zero)
            {
                Dispatcher.UIThread.Post(() => LogHelper.Info("❌ Token expired. Logging out.\n"));
                RaiseTokenTimeRemainingUpdated("Expired");
                await LogoutAsync();

                if (_currentPlatform != null)
                {
                    LogHelper.Info("🔁 Attempting re-authentication after logout...\n");
                    var platformSettings = new PlatformSettings
                    {
                        PlatformFqdn = _currentPlatform.PlatformFqdn,
                        AppId = _currentPlatform.AppId,
                        CertThumbprint = _currentPlatform.CertThumbprint,
                        UseCert = _currentPlatform.UseCert
                    };

                    var result = await AuthenticateAsync(platformSettings, forceReauth: true);
                    if (!string.IsNullOrWhiteSpace(result?.Token))
                        LogHelper.Info("✅ Re-authentication successful.\n");
                    else
                        LogHelper.Info("❌ Re-authentication failed.\n");
                }
                else
                {
                    LogHelper.Info("⚠️ Cannot re-authenticate — _currentPlatform is null.\n");
                }

                return;
            }

            if (timeRemaining <= TimeSpan.FromMinutes(_reauthThresholdMinutes))
            {
                if (_tokenRefreshInProgress) return;
                _tokenRefreshInProgress = true;

                Dispatcher.UIThread.Post(() =>
                {
                    LogHelper.Info($"🔁 Token expiring soon ({remainingText}), attempting refresh...\n");
                    LogHelper.Info($"⏱ Refresh threshold (ReauthMinutes): {_reauthThresholdMinutes} minutes\n");
                    LogHelper.Info($"🧮 Now: {nowLocal:t} | Expiration: {expirationLocal:t}\n");
                });

                bool refreshed = await RefreshTokenAsync();
                if (!refreshed)
                {
                    Dispatcher.UIThread.Post(() =>
                    {
                        LogHelper.Info("❌ Token refresh failed. Logging out.\n");
                        _ = LogoutAsync(); // fire-and-forget
                    });
                }
                else
                {
                    Dispatcher.UIThread.Post(() => LogHelper.Info("✅ Token refreshed.\n"));
                }

                _tokenRefreshInProgress = false;
            }
        }

        // Get the token expiration time from the JWT token (payload 'exp' or optional header "Expiration")
        public DateTime? GetTokenExpirationTime()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(_token)) return null;

                var parts = _token.Split('.');
                if (parts.Length < 2) return null;

                // header
                var headerJson = JObject.Parse(DecodeBase64Url(parts[0]));
                if (headerJson.TryGetValue("Expiration", out var expHeader))
                {
                    var expirationUtc = DateTimeOffset.Parse(
                        expHeader.ToString(),
                        CultureInfo.InvariantCulture,
                        DateTimeStyles.AssumeUniversal | DateTimeStyles.AdjustToUniversal
                    ).UtcDateTime;
                    return expirationUtc;
                }

                // payload
                var payload = JObject.Parse(DecodeBase64Url(parts[1]));
                if (payload.TryGetValue("exp", out var expPayload))
                {
                    var expirationUtc = DateTimeOffset
                        .FromUnixTimeSeconds(expPayload.Value<long>())
                        .UtcDateTime;
                    return expirationUtc;
                }

                return null;
            }
            catch { return null; }
        }

        public void SetExpirationTime(DateTime expiration) => _expirationTime = expiration;

        public bool IsTokenExpired()
        {
            var expiration = GetTokenExpirationTime();
            if (!expiration.HasValue) return true;
            return DateTime.UtcNow >= expiration.Value;
        }

        #endregion

        #region === Platform config ===

        public void SetPlatformConfig(PlatformSettings platform)
        {
            _fqdn = platform.PlatformFqdn;
            _platformUrl = platform.PlatformFqdn;
            _appId = platform.AppId;
            _certThumbprint = platform.CertThumbprint;
            _isCertAuth = platform.UseCert;

            LogHelper.Info($"🌐 Platform config set: {_platformUrl} (CertAuth: {_isCertAuth})");
        }

        private static string DecodeBase64Url(string input)
        {
            var output = input.Replace('-', '+').Replace('_', '/');
            switch (output.Length % 4)
            {
                case 2: output += "=="; break;
                case 3: output += "="; break;
            }
            var base64Bytes = Convert.FromBase64String(output);
            return Encoding.UTF8.GetString(base64Bytes);
        }

        #endregion

        #region === Logout ===
        private void RaiseAuthStatusChanged()
        {
            // Auth callbacks may be raised from scheduler/background threads; marshal to UI thread.
            Dispatcher.UIThread.Post(() =>
            {
                try { AuthStatusChanged?.Invoke(); }
                catch { }
            });
        }

        private void RaiseTokenTimeRemainingUpdated(string value)
        {
            // Token countdown callbacks may be raised from timer/background threads; marshal to UI thread.
            Dispatcher.UIThread.Post(() =>
            {
                try { TokenTimeRemainingUpdated?.Invoke(value); }
                catch { }
            });
        }

        public event Action? AuthStatusChanged;
        public DateTime? ExpirationTime => _expirationTime;

        public async Task LogoutAsync()
        {
            if (_logoutInProgress) return;
            _logoutInProgress = true;

            try
            {
                if (!string.IsNullOrWhiteSpace(_token))
                {
                    try
                    {
                        using var client = new HttpClient { Timeout = _httpTimeout };
                        client.DefaultRequestHeaders.Add("X-Tachyon-Authenticate", _token);
                        client.DefaultRequestHeaders.Add("X-Tachyon-Consumer", _consumerName);

                        var url = $"https://{_platformUrl}/tachyon/api/Authentication/Logout";
                        await client.GetAsync(url);
                        Console.WriteLine("👋 Logged out successfully.");
                    }
                    catch { /* ignore */ }
                }
            }
            finally
            {
                _logoutInProgress = false;
                Logout(); // local cleanup
            }
        }

        public void Logout()
        {
            DeleteSavedToken(_platformUrl);
            _token = string.Empty;
            _expirationTime = null;

            _authCheckTimer?.Dispose();
            _authCheckTimer = null;

            RaiseAuthStatusChanged();

            Console.WriteLine("❌ Logged out. Cleared saved token for this platform.");
        }

        #endregion

        #region === WhoAmI (display only) ===

        public async Task<string?> GetDisplayNameFromWhoAmIAsync(string fqdn, string token)
        {
            try
            {
                using var client = new HttpClient { Timeout = _httpTimeout };
                client.DefaultRequestHeaders.Add("X-Tachyon-Consumer", "Explorer");
                if (client.DefaultRequestHeaders.Contains("X-Tachyon-Authenticate"))
                    client.DefaultRequestHeaders.Remove("X-Tachyon-Authenticate");
                client.DefaultRequestHeaders.Add("X-Tachyon-Authenticate", token);

                var url = $"https://{fqdn}/Consumer/PrincipalSearch/whoami";
                var response = await client.GetAsync(url);
                if (!response.IsSuccessStatusCode)
                {
                    LogHelper.Info($"❌ whoami failed → {response.StatusCode} {response.ReasonPhrase}");
                    return null;
                }

                var json = await response.Content.ReadAsStringAsync();
                dynamic obj = JsonConvert.DeserializeObject(json);
                string? name = obj?.DisplayName ?? obj?.Name ?? obj?.UserName;
                return name;
            }
            catch (Exception ex)
            {
                LogHelper.Info($"❌ whoami exception: {ex.Message}");
                return null;
            }
        }

        #endregion

        #region === Diagnostic token dumping ===

        public void DumpCustomTokenPayload(string token)
        {
            try
            {
                var parts = token.Split('.');
                if (parts.Length != 3)
                {
                    LogHelper.Info("⚠️ Invalid token format.");
                    return;
                }

                var payload = parts[1];
                payload = payload.PadRight(payload.Length + (4 - payload.Length % 4) % 4, '=');
                var json = Encoding.UTF8.GetString(Convert.FromBase64String(payload));

                dynamic obj = JsonConvert.DeserializeObject(json);
                AppendLogUi("🔍 Token Payload:");
                AppendLogUi(JsonConvert.SerializeObject(obj, Formatting.Indented));
            }
            catch (Exception ex)
            {
                LogHelper.Info($"⚠️ Error while dumping token payload: {ex.Message}");
            }
        }

        #endregion

        #region === Token persistence: memory always; Windows Vault only when _enableDevTokenReuse ===

        public void SaveToken(string token)
        {
            try
            {
                // 1) Process-wide memory (ALWAYS)
                var memKey = BuildMemKey(_platformUrl, _ApplicationId ?? string.Empty);
                s_memoryTokens[memKey] = token;

                // 2) Windows Credential Manager (ONLY if allowed)
                if (_enableDevTokenReuse)
                {
                    try { _tokenStoreService?.StoreToken(_platformUrl, token); } catch { }
                }

                _token = token; // keep instance copy
            }
            catch (Exception ex)
            {
                LogHelper.Info($"❌ Error saving token: {ex.Message}");
            }
        }

        private string? GetSavedToken(string platformUrl)
        {
            // 1) Memory first (always)
            var memKey = BuildMemKey(platformUrl, _ApplicationId ?? string.Empty);
            if (s_memoryTokens.TryGetValue(memKey, out var tok) &&
                !string.IsNullOrWhiteSpace(tok) &&
                IsJwtStillValid(tok))
            {
                return tok;
            }

            // 2) Windows Credential Manager (only if enabled)
            if (_enableDevTokenReuse)
            {
                try
                {
                    string vaultTok;
                    if (_tokenStoreService != null &&
                        _tokenStoreService.TryGetToken(platformUrl, out vaultTok) &&
                        !string.IsNullOrWhiteSpace(vaultTok) &&
                        IsJwtStillValid(vaultTok))
                    {
                        s_memoryTokens[memKey] = vaultTok;
                        return vaultTok;
                    }
                }
                catch { }
            }

            // 3) Legacy disk path is intentionally disabled.
            return null;
        }

        private void DeleteSavedToken(string platformUrl)
        {
            try
            {
                var memKey = BuildMemKey(platformUrl, _ApplicationId ?? string.Empty);
                s_memoryTokens.TryRemove(memKey, out _);

                if (_enableDevTokenReuse)
                {
                    _tokenStoreService?.RemoveToken(platformUrl);
                }
            }
            catch (Exception ex)
            {
                LogHelper.Info($"⚠️ DeleteSavedToken error: {ex.Message}");
            }
        }

        #endregion

        #region === Authenticate flows (single & multi tenant) ===

        public async Task<AuthenticationResult> AuthenticateAsync(PlatformSettings platform, bool forceReauth = false)
        {
            // Prevent concurrent authentication for the same platform/appId.
            // This is critical for cert auth where issuing a second token can invalidate the first.
            var lockKey = BuildMemKey(platform?.PlatformFqdn ?? string.Empty, platform?.AppId ?? string.Empty);
            var sem = _authLocks.GetOrAdd(lockKey, _ => new SemaphoreSlim(1, 1));
            await sem.WaitAsync().ConfigureAwait(false);

            try
            {
                var now = DateTime.UtcNow;

                // Hydrate missing cert auth UPN/UserId from appsettings when possible.
                // Some IdP configurations require a UPN claim when a cert KID maps to multiple entries or a wildcard.
                if (platform != null && platform.UseCert && string.IsNullOrWhiteSpace(platform.UserId))
                {
                    try
                    {
                        var cfg = new ConfigHelper().Load();
                        var pf = platform.PlatformFqdn ?? string.Empty;
                        var pa = platform.Alias ?? string.Empty;
						var match = cfg?.Platforms
							?.FirstOrDefault(p =>
								(!string.IsNullOrWhiteSpace(pf) && string.Equals(p.PlatformFqdn, pf, StringComparison.OrdinalIgnoreCase)) ||
								(!string.IsNullOrWhiteSpace(pa) && string.Equals(p.Alias, pa, StringComparison.OrdinalIgnoreCase)));

                        if (match != null)
                        {
                            if (string.IsNullOrWhiteSpace(platform.Alias) && !string.IsNullOrWhiteSpace(match.Alias))
                                platform.Alias = match.Alias;

                            if (string.IsNullOrWhiteSpace(platform.UserId) && !string.IsNullOrWhiteSpace(match.UserId))
                                platform.UserId = match.UserId;
                        }
                    }
                    catch (Exception ex)
                    {
                        LogHelper.Info($"⚠️ AUTH DEBUG: Could not hydrate UserId from config: {ex.Message}");
                    }
                }


            // Always set platform context for later
            _platformUrl = platform.PlatformFqdn;
            _ApplicationId = platform.AppId;
            _CertificateThumbprint = platform.CertThumbprint;
            _isCertAuth = platform.UseCert;
            var userId = platform.UserId;

            // Cooldown only when we already have a valid token
            if (!forceReauth &&
                _lastAuthAttempts.TryGetValue(platform.PlatformFqdn, out var lastAttempt) &&
                (now - lastAttempt) < _authCooldown &&
                !IsTokenExpired())
            {
                LogHelper.Debug($"⏳ Skipping auth for {platform.PlatformFqdn} — last attempt at {lastAttempt.ToLocalTime():T}, cooldown: {_authCooldown.TotalSeconds} seconds.");
                return new AuthenticationResult
                {
                    Token = this.Token ?? string.Empty,
                    PrincipalName = ExtractPrincipalFromToken(this.Token) ?? string.Empty
                };
            }

            _lastAuthAttempts[platform.PlatformFqdn] = now;

            // TEMP DEBUG (safe): shows which inputs are being used without dumping secrets
            var thumbMasked = string.IsNullOrWhiteSpace(platform.CertThumbprint)
                ? "(missing)"
                : (platform.CertThumbprint.Length > 6
                    ? new string('*', Math.Max(0, platform.CertThumbprint.Length - 6)) + platform.CertThumbprint[^6..]
                    : platform.CertThumbprint);
            LogHelper.Info($"🧪 AUTH DEBUG → Platform='{platform.PlatformFqdn}', Alias='{platform.Alias}', UseCert={platform.UseCert}, AppId={(string.IsNullOrWhiteSpace(platform.AppId) ? "(missing)" : "(set)")}, Thumb={thumbMasked}, UserId={(string.IsNullOrWhiteSpace(userId) ? "(none)" : "(set)")}");

            // Certificate-based auth path
            if (platform.UseCert)
            {
                string? lastError = null;
                LogHelper.Info($"🔐 Using certificate-based authentication (Thumbprint: {thumbMasked}) and AppID: {_ApplicationId}\n");

                if (string.IsNullOrWhiteSpace(_platformUrl) ||
                    string.IsNullOrWhiteSpace(_ApplicationId) ||
                    string.IsNullOrWhiteSpace(_CertificateThumbprint))
                {
                    LogHelper.Info("❌ Certificate login requires Platform URL, AppId, and Thumbprint.\n");
                    return new AuthenticationResult { Token = string.Empty, PrincipalName = string.Empty, FailureReason = "Missing required cert auth fields (PlatformFqdn/AppId/Thumbprint)." };
                }

                try
                {
                    _TachyonServer = $"https://{_platformUrl.Trim().TrimEnd('/')}";

                    // Real JWT + cert exchange (matches 1E SDK flow):
                    // POST https://{fqdn}/api/Authentication/RequestJwtAuthentication
                    for (int attempt = 1; attempt <= 2; attempt++)
                    {
                        try
                        {
                            var token = await AcquireCertJwtTokenAsync(_platformUrl, _ApplicationId, _CertificateThumbprint, userId);

                            if (!string.IsNullOrWhiteSpace(token))
                            {
                                // Use the property to preserve original side-effects (timers/UI state)
                                this.Token = token;
                                _tokenStoreService.StoreToken(platform.PlatformFqdn, token);
                                SaveToken(token); // legacy/disk behavior is gated internally

                                var suffix = token.Length >= 6 ? token[^6..] : "??";
                                var exp = GetTokenExpirationTime();
                                var expiry = exp?.ToLocalTime().ToString("g") ?? DateTime.Now.AddMinutes(55).ToString("g");

                                LogHelper.Info($"🛡️ Cached token via cert auth for {_platformUrl} ... ending in: {suffix} | Expires at: {expiry}");

                                return new AuthenticationResult
                                {
                                    Token = token,
                                    // Cert tokens may be opaque (non-JWT) on some platforms. Prefer configured principal when provided.
                                    PrincipalName = ExtractPrincipalFromToken(token) ?? userId ?? Environment.UserName,
                                    FirstName = ExtractClaim(token, "FirstName"),
                                    LastName = ExtractClaim(token, "LastName")
                                };
                            }

                            LogHelper.Warn($"⚠️ Cert token response was empty (attempt {attempt}) — retrying...");
                            lastError = $"Empty token response (attempt {attempt}).";
                        }
                        catch (Exception ex)
                        {
                            LogHelper.Warn($"⚠️ Cert auth attempt {attempt} failed: {ex.Message}");
                            lastError = ex.Message;
                        }

                        await Task.Delay(750);
                    }

                    LogHelper.Error("❌ Failed to acquire cert token after retry attempts.");
                    return new AuthenticationResult { Token = string.Empty, PrincipalName = string.Empty, FailureReason = lastError };
                }
                catch (Exception ex)
                {
                    LogHelper.Info($"❌ Certificate authentication error:\n{ex}\n");
                    return new AuthenticationResult { Token = string.Empty, PrincipalName = string.Empty, FailureReason = ex.Message };
                }
            }

            // Password/interactive token path
            string? savedToken = GetSavedToken(_platformUrl);

            if (!string.IsNullOrWhiteSpace(savedToken))
            {
                this.Token = savedToken;
                _tokenStoreService.StoreToken(platform.PlatformFqdn, savedToken);
                DumpJwtPayload(savedToken);

                // Optional: platform match check via claim
                string? tokenTenantId = ExtractClaim(savedToken, "TenantId") ?? "";
                if (!string.IsNullOrEmpty(tokenTenantId) &&
                    !_platformUrl.Contains(tokenTenantId, StringComparison.OrdinalIgnoreCase))
                {
                    LogHelper.Info("❌ Token does not match selected platform. Forcing reauthentication.\n");
                    DeleteSavedToken(_platformUrl);
                    return await AuthenticateAsync(platform, forceReauth: true);
                }

                var expiration = GetTokenExpirationTime();
                if (expiration != null)
                    SetExpirationTime(expiration.Value);
                else
                    SetExpirationTime(DateTime.UtcNow.AddMinutes(10));

                if (IsTokenExpired())
                {
                    LogHelper.Info("❌ Cached token is expired. Forcing reauthentication.\n");
                    DeleteSavedToken(_platformUrl);
                    return await AuthenticateAsync(platform, forceReauth: true);
                }

                await CheckTokenExpirationAsync();
                _authRetryCount = 0;

                return new AuthenticationResult
                {
                    Token = savedToken,
                    PrincipalName = ExtractPrincipalFromToken(savedToken)
                };
            }

            LogHelper.Info($"🌐 Attempting interactive auth for platform: {_platformUrl}\n");

            string socketUrl = $"wss://{_platformUrl}/tachyon/api/Authentication/RequestAuthentication";
            string interactiveToken = await AuthenticateSingleTenant(socketUrl);

            if (string.IsNullOrWhiteSpace(interactiveToken))
            {
                LogHelper.Info("❌ WebSocket failed. Trying multi-tenant...\n");
                interactiveToken = await AuthenticateMultiTenant(_platformUrl);
            }

            if (!string.IsNullOrWhiteSpace(interactiveToken))
            {
                LogHelper.Info("✅ Interactive login succeeded.\n");
                this.Token = interactiveToken;
                _tokenStoreService.StoreToken(platform.PlatformFqdn, interactiveToken);
                SaveToken(interactiveToken);

                return new AuthenticationResult
                {
                    Token = interactiveToken,
                    PrincipalName = ExtractPrincipalFromToken(interactiveToken)
                };
            }

            LogHelper.Info("❌ Authentication failed completely.\n");
            return new AuthenticationResult { Token = string.Empty, PrincipalName = string.Empty };
            }
            finally
            {
                sem.Release();
            }
        }

        private static async Task<string?> AcquireCertJwtTokenAsync(string platformFqdn, string appId, string thumbprint, string? userId)
        {
            if (string.IsNullOrWhiteSpace(platformFqdn)) throw new ArgumentException("platformFqdn is required.", nameof(platformFqdn));
            if (string.IsNullOrWhiteSpace(appId)) throw new ArgumentException("appId is required.", nameof(appId));
            if (string.IsNullOrWhiteSpace(thumbprint)) throw new ArgumentException("thumbprint is required.", nameof(thumbprint));

            var cert = FindCertificateByThumbprint(thumbprint);
            if (cert == null)
                throw new InvalidOperationException($"Certificate not found (thumbprint ends with ...{(thumbprint.Length > 6 ? thumbprint[^6..] : thumbprint)}) in CurrentUser/My or LocalMachine/My.");

            if (!cert.HasPrivateKey)
                throw new InvalidOperationException("Certificate was found but does not have a private key.");

            // PSToolkit behavior:
            //   - JWT is signed with the cert
            //   - UPN (principal) is optional and included as Tachyon.upn when provided
            //   - JWT 'aud' MUST be the IdP token endpoint in some environments (platform will tell us the expected audience)
            //   - POST body MUST be a JSON string literal (quoted JWT), not an object

            var now = DateTime.UtcNow;
            var expires = now.AddMinutes(5);

            var normalizedFqdn = platformFqdn.Trim().TrimEnd('/');
            var audKey = BuildAudKey(normalizedFqdn, appId);
            var cachedAud = s_certJwtAudienceCache.TryGetValue(audKey, out var a) ? a : null;

            // Default audience: keep legacy behavior unless we already learned a required IdP token endpoint.
            var audToTry1 = string.IsNullOrWhiteSpace(cachedAud) ? normalizedFqdn : cachedAud;

            using var client = new HttpClient { Timeout = TimeSpan.FromSeconds(60) };
            var url = $"https://{normalizedFqdn}/api/Authentication/RequestJwtAuthentication";
            LogHelper.Debug($"🧪 AUTH DEBUG: Cert JWT endpoint = {url}");

            // Try up to 2 attempts: first with cached/legacy aud, second with expected aud parsed from platform error.
            for (int attempt = 1; attempt <= 2; attempt++)
            {
                var aud = (attempt == 1) ? audToTry1 : cachedAud;
                if (string.IsNullOrWhiteSpace(aud))
                    aud = normalizedFqdn;

                // Build the client assertion JWT in a way that matches typical AAD/IdP validation expectations.
                // In particular, include stable kid/x5t derived from the certificate thumbprint.
                // (Some environments reject assertions without kid/x5t even if the signature is correct.)
                var handler = new JwtSecurityTokenHandler();

                var certHash = cert.GetCertHash();
                var certHashB64Url = Base64UrlEncoder.Encode(certHash);

                var key = new X509SecurityKey(cert)
                {
                    KeyId = certHashB64Url
                };

                var signingCredentials = new SigningCredentials(key, SecurityAlgorithms.RsaSha256);
                var header = new JwtHeader(signingCredentials);
                header["typ"] = "JWT";
                header["kid"] = certHashB64Url;
                header["x5t"] = certHashB64Url;

                // Payload: iss=sub=appid; aud = (platform fqdn OR idp token endpoint learned from platform); optional UPN claim.
                var nbf = now.AddSeconds(-10);
                var payloadObj = new JwtPayload(appId, aud, claims: null, notBefore: nbf, expires: expires, issuedAt: now);
                payloadObj[JwtRegisteredClaimNames.Sub] = appId;
                payloadObj[JwtRegisteredClaimNames.Jti] = Guid.NewGuid().ToString();
                payloadObj[JwtRegisteredClaimNames.Iat] = DateTimeOffset.UtcNow.ToUnixTimeSeconds();

                if (!string.IsNullOrWhiteSpace(userId))
                    payloadObj["Tachyon.upn"] = userId.Trim();

                var jwtToken = new JwtSecurityToken(header, payloadObj);
                var assertion = handler.WriteToken(jwtToken);

                // IMPORTANT: /api/Authentication/RequestJwtAuthentication expects the JWT assertion as the *root* JSON value
                // (a JSON string literal). Equivalent to PSToolkit's "quotify(...)".
                var payload = JsonConvert.SerializeObject(assertion);

                var preview = payload?.TrimStart();
                var firstChar = string.IsNullOrEmpty(preview) ? "(empty)" : preview![0].ToString();
                LogHelper.Info($"🧪 AUTH DEBUG: JWT POST body starts with '{firstChar}' (expected '\"'); aud={(aud.StartsWith("https://", StringComparison.OrdinalIgnoreCase) ? "(idp)" : "(platform)")}; upn={(string.IsNullOrWhiteSpace(userId) ? "(none)" : "(set)")}; kid/x5t={(string.IsNullOrWhiteSpace(certHashB64Url) ? "(none)" : "(set)")}");

                using var req = new HttpRequestMessage(HttpMethod.Post, url)
                {
                    Content = new StringContent(payload, Encoding.UTF8, "application/json")
                };

                using var resp = await client.SendAsync(req).ConfigureAwait(false);
                var respText = await resp.Content.ReadAsStringAsync().ConfigureAwait(false);

                if (!resp.IsSuccessStatusCode)
                {
                    // If the platform tells us the expected audience, cache it and retry once.
                    var expectedAud = TryExtractExpectedAudienceFromError(respText);
                    if (!string.IsNullOrWhiteSpace(expectedAud))
                    {
                        s_certJwtAudienceCache[audKey] = expectedAud;
                        cachedAud = expectedAud;

                        // Retry once if attempt 1 used a different audience.
                        if (attempt == 1 && !string.Equals(aud, expectedAud, StringComparison.OrdinalIgnoreCase))
                        {
                            LogHelper.Info($"🧪 AUTH DEBUG: Platform returned expected JWT audience. Retrying with IdP audience.");
                            continue;
                        }
                    }

                    throw new InvalidOperationException($"JWT auth failed: HTTP {(int)resp.StatusCode} {resp.StatusCode}. Body: {respText}");
                }

                // Response usually contains token property. Try common shapes.
                try
                {
                    var jo = JObject.Parse(respText);
                    var token = jo["Token"]?.ToString() ?? jo["token"]?.ToString() ?? jo["AccessToken"]?.ToString() ?? jo["accessToken"]?.ToString();
                    return string.IsNullOrWhiteSpace(token) ? null : token;
                }
                catch
                {
                    return string.IsNullOrWhiteSpace(respText) ? null : respText.Trim('"', ' ', '\r', '\n');
                }
            }

            return null;
        }

        private static string? TryExtractExpectedAudienceFromError(string responseBody)
        {
            if (string.IsNullOrWhiteSpace(responseBody))
                return null;

            try
            {
                // Platform errors are often JSON arrays with objects: [{"ErrorCode":"...","Message":"...","Data":[expected,received,token]}]
                var token = JToken.Parse(responseBody);
                var first = token is JArray arr ? arr.FirstOrDefault() : token;
                if (first is JObject obj)
                {
                    var errorCode = obj["ErrorCode"]?.ToString() ?? string.Empty;
                    if (!errorCode.Contains("TokenAudienceDoesNotMatch", StringComparison.OrdinalIgnoreCase))
                        return null;

                    var data = obj["Data"] as JArray;
                    if (data != null && data.Count > 0)
                    {
                        var expected = data[0]?.ToString();
                        if (!string.IsNullOrWhiteSpace(expected))
                            return expected.Trim();
                    }

                    // Fallback: parse message text "Expected 'X' but received 'Y'"
                    var msg = obj["Message"]?.ToString() ?? string.Empty;
                    var m = Regex.Match(msg, "Expected '([^']+)'", RegexOptions.IgnoreCase);
                    if (m.Success)
                        return m.Groups[1].Value.Trim();
                }
            }
            catch
            {
                // ignore
            }

            return null;
        }

        private static X509Certificate2? FindCertificateByThumbprint(string thumbprint)
        {
            static X509Certificate2? Find(StoreLocation location, string thumb)
            {
                using var store = new X509Store(StoreName.My, location);
                store.Open(OpenFlags.ReadOnly);
                var matches = store.Certificates.Find(X509FindType.FindByThumbprint, thumb, validOnly: false);
                return matches.Count > 0 ? matches[0] : null;
            }

            var normalized = new string(thumbprint.Where(c => !char.IsWhiteSpace(c)).ToArray()).ToUpperInvariant();
            return Find(StoreLocation.CurrentUser, normalized) ?? Find(StoreLocation.LocalMachine, normalized);
        }

        private static string? ExtractClaim(string token, string claimName)
        {
            try
            {
                var parts = token.Split('.');
                if (parts.Length < 2) return null;

                var payload = parts[1].PadRight(parts[1].Length + (4 - parts[1].Length % 4) % 4, '=');
                var bytes = Convert.FromBase64String(payload.Replace('-', '+').Replace('_', '/'));
                var json = Encoding.UTF8.GetString(bytes);

                dynamic obj = JsonConvert.DeserializeObject(json);
                var val = obj?[claimName];
                return val?.ToString();
            }
            catch { return null; }
        }

        // Single-tenant via WebSocket
        private async Task<string> AuthenticateSingleTenant(string socketUrl)
        {
            using var ws = new ClientWebSocket();
            ws.Options.UseDefaultCredentials = true;
            CancellationToken ct = CancellationToken.None;

            try
            {
                await ws.ConnectAsync(new Uri(socketUrl), ct);
                byte[] command = Encoding.UTF8.GetBytes("ACTION=Command");
                await ws.SendAsync(new ArraySegment<byte>(command), WebSocketMessageType.Text, true, ct);

                var buffer = new byte[4096];
                var result = await ws.ReceiveAsync(new ArraySegment<byte>(buffer), ct);
                string response = Encoding.UTF8.GetString(buffer, 0, result.Count);

                dynamic authResponse = JsonConvert.DeserializeObject(response);
                if (authResponse != null && authResponse.Status == "AuthenticationRequested")
                {
                    string authUrl = authResponse.Data?.ToString() ?? string.Empty;
                    if (!_browserOpened && !string.IsNullOrWhiteSpace(authUrl))
                    {
                        OpenBrowser(authUrl);
                        _browserOpened = true;
                    }
                    return await PollForToken(ws, ct);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"⚠️ WebSocket auth failed: {ex.Message}");
            }

            return string.Empty;
        }

        private async Task<string> PollForToken(ClientWebSocket ws, CancellationToken ct)
        {
            var buffer = new byte[4096];
            while (ws.State == WebSocketState.Open)
            {
                var result = await ws.ReceiveAsync(new ArraySegment<byte>(buffer), ct);
                string response = Encoding.UTF8.GetString(buffer, 0, result.Count);

                if (response.Contains("AuthenticationSuccessful"))
                {
                    dynamic authResponse = JsonConvert.DeserializeObject(response);
                    return authResponse?.Data?.ToString() ?? string.Empty;
                }

                await Task.Delay(1000);
            }

            return string.Empty;
        }

        // Multi-tenant via HTTP polling
        private async Task<string> AuthenticateMultiTenant(string platformUrl)
        {
            byte[] nonceBytes = new byte[32];
            new Random().NextBytes(nonceBytes);
            string nonceEncoded = Convert.ToBase64String(nonceBytes);
            byte[] nonceHashed = SHA256.HashData(Convert.FromBase64String(nonceEncoded));
            string nonceHashEncoded = ToBase64Url(nonceHashed);

            string url = $"https://{platformUrl}/tachyon/api/Authentication/RequestAuthentication?ecpn={nonceHashEncoded}";

            using var client = new HttpClient { Timeout = _httpTimeout };
            var response = await client.GetAsync(url);
            var json = await response.Content.ReadAsStringAsync();

            dynamic authResponse = JsonConvert.DeserializeObject(json);
            if (authResponse is Newtonsoft.Json.Linq.JArray arr)
                authResponse = arr[0];

            string authUrl = authResponse?.AuthenticationUrl;
            string state = authResponse?.State;
            if (string.IsNullOrEmpty(authUrl) || string.IsNullOrEmpty(state)) return string.Empty;

            OpenBrowser(authUrl);
            _browserOpened = true;

            string pollUrl = $"https://{platformUrl}/tachyon/api/Authentication/CheckAuthenticationState";
            return await PollForToken(client, pollUrl, state, nonceEncoded);
        }

        private async Task<string> PollForToken(HttpClient client, string url, string state, string nonceEncoded)
        {
            string payload = $"{{ \"state\" : \"{state}\", \"nonce\" : null }}";
            string responseJson = await PostHttpRequest(client, url, payload);

            while (!responseJson.Contains("AuthenticationSuccessful"))
            {
                await Task.Delay(1000);
                responseJson = await PostHttpRequest(client, url, payload);
            }

            payload = $"{{ \"state\" : \"{state}\", \"nonce\" : \"{nonceEncoded}\" }}";
            responseJson = await PostHttpRequest(client, url, payload);

            dynamic result = JsonConvert.DeserializeObject(responseJson);
            return result?.Data?.ToString() ?? string.Empty;
        }

        private static async Task<string> PostHttpRequest(HttpClient client, string url, string payload)
        {
            // Safe debug: log only the first non-whitespace character so we can confirm payload shape.
            // This is especially useful when troubleshooting JWT auth flows where the endpoint expects a JSON string literal.
            var preview = payload?.TrimStart();
            var firstChar = string.IsNullOrEmpty(preview) ? "(empty)" : preview![0].ToString();
            LogHelper.Info($"🧪 AUTH DEBUG: POST {url} body starts with '{firstChar}'");

            var content = new StringContent(payload, Encoding.UTF8, "application/json");
            var response = await client.PostAsync(url, content);
            return await response.Content.ReadAsStringAsync();
        }

        #endregion

        #region === Minimal refresh & helpers required by other call sites ===

        private async Task<bool> RefreshTokenAsync()
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(_token) && IsJwtStillValid(_token))
                    return true;
                await Task.CompletedTask;
                return false;
            }
            catch { return false; }
        }

        private string GetToken() => _token;

        private static void OpenBrowser(string url)
        {
            try
            {
                var psi = new ProcessStartInfo
                {
                    FileName = url,
                    UseShellExecute = true
                };
                Process.Start(psi);
            }
            catch { }
        }

        public static bool IsJwtStillValid(string token)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(token)) return false;
                var parts = token.Split('.');
                if (parts.Length < 2) return false;

                var payload = parts[1];
                var b64 = payload.Replace('-', '+').Replace('_', '/');
                switch (b64.Length % 4) { case 2: b64 += "=="; break; case 3: b64 += "="; break; }
                var json = Encoding.UTF8.GetString(Convert.FromBase64String(b64));

                var m = Regex.Match(json, "\"exp\"\\s*:\\s*(\\d+)");
                if (!m.Success) return false;

                var exp = DateTimeOffset.FromUnixTimeSeconds(long.Parse(m.Groups[1].Value, CultureInfo.InvariantCulture));
                return exp > DateTimeOffset.UtcNow.AddMinutes(1);
            }
            catch { return false; }
        }

        public static string? ExtractPrincipalFromToken(string token)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(token))
                    return null;

                token = token.Trim();
                if (token.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
                    token = token.Substring("Bearer ".Length).Trim();

                var parts = token.Split('.');
                if (parts.Length < 2) return null;

                // JWT payload is base64url encoded. Convert to base64 and pad to multiple of 4.
                var payload = parts[1].Replace('-', '+').Replace('_', '/');
                switch (payload.Length % 4)
                {
                    case 2: payload += "=="; break;
                    case 3: payload += "="; break;
                }

                var bytes = Convert.FromBase64String(payload);
                var json = Encoding.UTF8.GetString(bytes);

                // If this doesn't look like JSON, treat it as non-JWT / opaque token.
                var trimmed = json.TrimStart();
                if (!trimmed.StartsWith("{", StringComparison.Ordinal))
                    return null;

                var obj = JObject.Parse(json);

                var first = obj["FirstName"]?.ToString();
                var last = obj["LastName"]?.ToString();
                if (!string.IsNullOrWhiteSpace(first) && !string.IsNullOrWhiteSpace(last))
                    return $"{first} {last}";

                return obj["unique_name"]?.ToString()
                    ?? obj["upn"]?.ToString()
                    ?? obj["UserName"]?.ToString()
                    ?? obj["name"]?.ToString();
            }
            catch (Exception ex)
            {
                // Token may be opaque (not a JWT) depending on platform mode; don't treat as fatal.
                LogHelper.Debug($"❌ Error decoding token: {ex.Message}");
                return null;
            }
        }

        #endregion

        #region === Legacy compatibility stubs (no-ops; safe to keep) ===

        private static string GetPlatformHash(string platformUrl, string machineId)
        {
            // Previously used as a disk key; now return a stable base64url hash (no file I/O).
            var composite = $"{platformUrl}_{machineId}";
            var bytes = SHA256.HashData(Encoding.UTF8.GetBytes(composite));
            return ToBase64Url(bytes);
        }

        private static string EncryptToken(string token, string secret) => token ?? string.Empty;   // no-op
        private static string DecryptToken(string data, string secret) => data ?? string.Empty;     // no-op

        #endregion

        #region === Low-level helpers ===

        private static string ToBase64Url(byte[] input)
            => Convert.ToBase64String(input).Replace("+", "-").Replace("/", "_").TrimEnd('=');

        private static string Base64Url(byte[] input) => ToBase64Url(input);

        private static string Base64UrlFromHex(string hexThumbprint)
        {
            if (string.IsNullOrWhiteSpace(hexThumbprint)) return string.Empty;
            hexThumbprint = hexThumbprint.Replace(" ", string.Empty).ToUpperInvariant();
            var bytes = new byte[hexThumbprint.Length / 2];
            for (int i = 0; i < bytes.Length; i++)
                bytes[i] = Convert.ToByte(hexThumbprint.Substring(i * 2, 2), 16);
            return Base64Url(bytes);
        }

        private static X509Certificate2? FindCertificateByThumbprint(string thumbprint, StoreLocation location)
        {
            try
            {
                using var store = new X509Store(StoreName.My, location);
                store.Open(OpenFlags.ReadOnly);
                var col = store.Certificates.Find(X509FindType.FindByThumbprint, thumbprint?.Replace(" ", string.Empty), validOnly: false);
                return col.Count > 0 ? col[0] : null;
            }
            catch { return null; }
        }

        private static string GetMachineId()
        {
            try
            {
                var nics = System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces();
                var firstUp = nics.FirstOrDefault(nic =>
                    nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up &&
                    nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback);

                if (firstUp != null)
                    return BitConverter.ToString(firstUp.GetPhysicalAddress().GetAddressBytes()).Replace("-", "");
            }
            catch { /* ignore */ }

            // Fallback: deterministic-ish by machine name
            return Convert.ToBase64String(SHA256.HashData(Encoding.UTF8.GetBytes(Environment.MachineName)));
        }
        public string CurrentPlatformFqdn => _platformUrl ?? string.Empty;

        // Optional: client assertion (RS256) if your backend supports exchange
        private static string TryCreateClientAssertionJwt(string audienceFqdn, string appId, string thumbprint)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(audienceFqdn) ||
                    string.IsNullOrWhiteSpace(appId) ||
                    string.IsNullOrWhiteSpace(thumbprint))
                    return string.Empty;

                var cert = FindCertificateByThumbprint(thumbprint, StoreLocation.CurrentUser)
                           ?? FindCertificateByThumbprint(thumbprint, StoreLocation.LocalMachine);
                if (cert == null || !cert.HasPrivateKey) return string.Empty;

                string aud = $"https://{NormalizeFqdnSimple(audienceFqdn)}/";
                var now = DateTimeOffset.UtcNow;

                var header = new Dictionary<string, object>
                {
                    { "alg", "RS256" },
                    { "typ", "JWT" },
                    { "x5t", Base64UrlFromHex(cert.Thumbprint) }
                };

                var payload = new Dictionary<string, object>
                {
                    { "iss", appId },
                    { "sub", appId },
                    { "aud", aud },
                    { "nbf", now.ToUnixTimeSeconds() },
                    { "iat", now.ToUnixTimeSeconds() },
                    { "exp", now.AddMinutes(30).ToUnixTimeSeconds() },
                    { "jti", Guid.NewGuid().ToString("N") }
                };

                var headerJson = JsonConvert.SerializeObject(header);
                var payloadJson = JsonConvert.SerializeObject(payload);

                var signingInput = $"{Base64Url(Encoding.UTF8.GetBytes(headerJson))}.{Base64Url(Encoding.UTF8.GetBytes(payloadJson))}";
                var data = Encoding.ASCII.GetBytes(signingInput);

                using var rsa = cert.GetRSAPrivateKey();
                var sig = rsa.SignData(data, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
                return $"{signingInput}.{Base64Url(sig)}";
            }
            catch
            {
                return string.Empty;
            }
        }

        #endregion
    }
}
