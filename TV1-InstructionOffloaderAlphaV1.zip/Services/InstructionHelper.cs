﻿using Avalonia.Controls;
using Avalonia.Threading;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using TV1_InstructionOffloader.Models;

namespace TV1_InstructionOffloader.Services
{
    public class InstructionHelper
    {
        private readonly Dictionary<string, List<string>> _tagValueMap = new();
        private static bool _loggedNullMgDropdown;


		private static void AppendLog(TextBox logBox, string message)
		{
			if (logBox == null) return;
			try
			{
				if (Dispatcher.UIThread.CheckAccess())
					logBox.Text += message;
				else
					Dispatcher.UIThread.Post(() => logBox.Text += message);
			}
			catch
			{
				// Never allow logging to crash app.
			}
		}

		private static void SetComboItems(ComboBox combo, System.Collections.IEnumerable itemsSource, int? selectedIndex = null)
		{
			if (combo == null) return;
			try
			{
				void Apply()
				{
					combo.ItemsSource = itemsSource;
					if (selectedIndex.HasValue)
						combo.SelectedIndex = selectedIndex.Value;
				}

				if (Dispatcher.UIThread.CheckAccess())
					Apply();
				else
					Dispatcher.UIThread.Post(Apply);
			}
			catch
			{
				// Ignore UI binding errors to avoid crash during startup.
			}
		}

        public List<string>? GetTagValuesByName(string tagName)
        {
            return _tagValueMap.TryGetValue(tagName, out var values) ? values : null;
        }

        public async Task LoadManagementGroupsAsync(string fqdn, string token, ComboBox mgDropdown, TextBox logBox)
        {
            if (string.IsNullOrEmpty(fqdn) || string.IsNullOrEmpty(token))
            {
                AppendLog(logBox, "⚠️ Platform or token missing — can't load MG list.\n");
                return;
            }

            if (mgDropdown == null)
            {
                if (!_loggedNullMgDropdown)
                {
                    LogHelper.Info("⚠️ mgDropdown is null in LoadManagementGroupsAsync (startup) — skipping MG load.");
                    _loggedNullMgDropdown = true;
                }
                return;
            }

            try
            {
                using var client = new HttpClient();
                client.DefaultRequestHeaders.Add("X-Tachyon-Consumer", "Explorer");
                if (client.DefaultRequestHeaders.Contains("X-Tachyon-Authenticate"))
                    client.DefaultRequestHeaders.Remove("X-Tachyon-Authenticate");

                client.DefaultRequestHeaders.Add("X-Tachyon-Authenticate", token);

                LogHelper.Info($"🔎 Calling MG API with FQDN: {fqdn}, Token ending in: ...{token[^6..]}");
                
                var url = $"https://{fqdn}/Consumer/ManagementGroups";
                LogHelper.Info($"URL = {url}");
                var json = await client.GetStringAsync(url);
                var array = JArray.Parse(json);

                var groups = array.Select(g => new ManagementGroup
                {
                    Name = g["Name"]?.ToString() ?? "(Unknown)",
                    UsableId = g["UsableId"]?.ToObject<int>() ?? 0
                }).ToList();

	                // Add a synthetic "All Devices" (global) option at the top.
	                // Several platforms treat this as the required scope when coverage targeting is enforced.
	                if (groups.All(g => !string.Equals(g.Name, "All Devices", StringComparison.OrdinalIgnoreCase)))
	                {
	                    groups.Insert(0, new ManagementGroup { Name = "All Devices", UsableId = -1 });
	                }

                if (mgDropdown == null)
                {
                    LogHelper.Info("⚠️ mgDropdown is null in LoadManagementGroupsAsync.\n");
                    return;
                }

                SetComboItems(mgDropdown, groups, groups.Count > 0 ? 0 : (int?)null);

                LogHelper.Info($"📋 Loaded {groups.Count} management groups.\n");
            }
            catch (Exception ex)
            {
                LogHelper.Info($"❌ Failed to load management groups: {ex.Message}\n");
            }
        }

     


        public async Task<List<InstructionDefinition>> LoadInstructionsAsync(string fqdn, string token, TextBox logTextBox)
        {
            try
            {
                using var client = new HttpClient();
                client.DefaultRequestHeaders.Add("X-Tachyon-Consumer", "Explorer");
                client.DefaultRequestHeaders.Add("X-Tachyon-Authenticate", token);

                var url = $"https://{fqdn}/Consumer/InstructionDefinitions?InstructionType=0&InstructionType=1&InstructionType=2";
                //logTextBox.Text += $"📋 Loading Instructions from {url} .\n";

                var response = await client.GetAsync(url);
                if (!response.IsSuccessStatusCode)
                {
                    LogHelper.Info($"❌ Failed to load instructions: {response.ReasonPhrase}\n");
                    return new List<InstructionDefinition>();
                }

                var json = await response.Content.ReadAsStringAsync();
                var instructionArray = JsonConvert.DeserializeObject<List<InstructionDefinition>>(json);

                if (instructionArray == null || instructionArray.Count == 0)
                {
                    LogHelper.Info($"⚠️ No instructions found.\n");
                    return new List<InstructionDefinition>();
                }

                return instructionArray;
            }
            catch (Exception ex)
            {
            //    logTextBox.Text += $"❌ Exception while loading instructions: {ex.Message}\n";
                return new List<InstructionDefinition>();
            }
        }



        public async Task LoadCustomPropertiesAsync(
            string fqdn,
            string token,
            ComboBox tagNameDropdown,
            ComboBox tagValueDropdown,
            TextBox logBox)
        {
            try
            {
                // These can be null early in startup or when called from non-ConfigTab contexts (e.g. platform editor).
                if (tagNameDropdown == null || tagValueDropdown == null)
                {
                    LogHelper.Info("⚠️ Coverage tags skipped: tag dropdown controls are not available yet.\n");
                    return;
                }

                if (string.IsNullOrWhiteSpace(token))
                {
                    LogHelper.Info("⚠️ Coverage tags skipped: token is empty.\n");
                    return;
                }

                // Normalize fqdn input (some call sites may pass a URL with scheme/path)
                fqdn = (fqdn ?? string.Empty).Trim();
                if (fqdn.StartsWith("http://", StringComparison.OrdinalIgnoreCase)) fqdn = fqdn.Substring("http://".Length);
                if (fqdn.StartsWith("https://", StringComparison.OrdinalIgnoreCase)) fqdn = fqdn.Substring("https://".Length);
                fqdn = fqdn.Trim().TrimEnd('/');
                if (fqdn.Contains("/"))
                {
                    // If someone passed a full URL like host/path, keep only host
                    fqdn = fqdn.Split('/')[0];
                }

                if (string.IsNullOrWhiteSpace(fqdn))
                {
                    LogHelper.Info("⚠️ Coverage tags skipped: platform host is empty.\n");
                    return;
                }

                using var client = new HttpClient();
                client.DefaultRequestHeaders.Add("X-Tachyon-Consumer", "Explorer");
                client.DefaultRequestHeaders.Add("X-Tachyon-Authenticate", token);

                var url = $"https://{fqdn}/Consumer/CustomProperties/Search";
                var body = new
                {
                    start = 1,
                    pageSize = 50,
                    sort = new object[] { },
                    Filter = new { Attribute = "TypeName", Operator = "==", Value = "CoverageTag" }
                };

                var jsonBody = JsonConvert.SerializeObject(body);
                var content = new StringContent(jsonBody, Encoding.UTF8, "application/json");

                var response = await client.PostAsync(url, content);
                var resultJson = await response.Content.ReadAsStringAsync();
                if (!response.IsSuccessStatusCode)
                {
                    LogHelper.Info($"❌ Error loading coverage tags: {response.StatusCode} {response.ReasonPhrase}\n");
                    return;
                }

                // API responses vary by platform/version:
                // - Some return: { "Items": [ ... ] }
                // - Some return: [ ... ]
                var parsed = JToken.Parse(resultJson);

                List<JToken> tagItems;
                if (parsed is JObject obj)
                {
                    tagItems = obj["Items"]?.ToList() ?? new List<JToken>();
                }
                else if (parsed is JArray arr)
                {
                    tagItems = arr.ToList();
                }
                else
                {
                    tagItems = new List<JToken>();
                }

                _tagValueMap.Clear();

                foreach (var item in tagItems)
                {
                    var name = item["Name"]?.ToString();
                    if (string.IsNullOrWhiteSpace(name)) continue;

                    var values = item["Values"]
                        ?.Select(v => v["Value"]?.ToString())
                        .Where(v => !string.IsNullOrWhiteSpace(v))
                        .Distinct()
                        .ToList();

                    if (values == null || values.Count == 0) continue;

                    _tagValueMap[name] = values;
                }

                
                var tagNames = _tagValueMap.Keys.ToList();
                SetComboItems(tagNameDropdown, tagNames, tagNames.Count > 0 ? 0 : (int?)null);

                LogHelper.Info($"🏷️ Loaded {tagNames.Count} coverage tag names.\n");
            }
            catch (Exception ex)
            {
                LogHelper.Info($"❌ Error loading coverage tags: {ex.Message}\n");
            }
        }
    }
}
