﻿using System.Collections.Generic;
using TV1_InstructionOffloader.Models; // or wherever Platform is

namespace TV1_InstructionOffloader.Services
{
    public static class PlatformService
    {
        public static List<Platform> KnownPlatforms { get; set; } = new();
    }
}
