﻿using Avalonia.Platform;
using Avalonia.Threading;
using DocumentFormat.OpenXml.Bibliography;
using Splat.ModeDetection;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using TV1_InstructionOffloader.Helpers;
using TV1_InstructionOffloader.Models;
using TV1_InstructionOffloader.Services; // LogHelper
using TV1_InstructionOffloader.ViewModels;
using static System.Reflection.Metadata.BlobBuilder;

namespace TV1_InstructionOffloader.Services
{
    public sealed class JobSchedulerService : IDisposable
    {
        private bool _isTickRunning = false;
        private readonly ScheduledJobsViewModel _vm;
        private readonly IInstructionJobExecutor _exec;
        private readonly DispatcherTimer _pulse;
        private static readonly TimeSpan Window = TimeSpan.FromSeconds(60);
        private bool _useUtc = false; // default to local time
        private readonly Dictionary<string, DateTime> _lastSkipLogged = new();
        private List<ScheduledJob> _jobs = new();
        private readonly AuthenticationService _authService;
        private AppSettings _settings;
        private List<JobExecutionHistory> _history = new();
        // Persist scheduler state under LocalAppData so it survives upgrades and doesn't depend on
        // the current working directory.
        private static readonly string HistoryFilePath = AppPaths.ExecutionHistoryPath;
        private const int KeepDays = 30;
        private readonly InstructionService _instructionService;
        private readonly ILogger _logger;
        private Dictionary<string, ExportOption> _exportOptions = new();
        private readonly HashSet<string> _queuedExports = new();
        private readonly object _queuedExportsLock = new();

        private static string BuildExportDedupKey(ScheduledJob job)
        {
            var rid = job?.ResponseId?.ToString() ?? string.Empty;
            return $"{job?.JobId}_{rid}";
        }


        public List<JobExecutionHistory> ExecutionHistory { get; set; } = new();



        public JobSchedulerService(
             ScheduledJobsViewModel vm,
             InstructionService instructionService,
             IInstructionJobExecutor exec,
             AuthenticationService authService)
        {
            _vm = vm;
            _instructionService = instructionService;
            _exec = exec;
            _authService = authService;

            // 🔑 Load the AppSettings instance (single source of truth for platforms + export options)
            _settings = new ConfigHelper().Load();

            // UI/log display preference; scheduler execution should still use UTC internally.
            _useUtc = _settings.UseUtcTimestamps;
            LogHelper.UseUtc = _useUtc;

            var logLevel = _settings.LogLevel ?? "Info";
            var maxLines = _settings.MaxLogLines > 0 ? _settings.MaxLogLines : 5000;
            var maxSize = _settings.MaxLogFileSizeMB > 0 ? _settings.MaxLogFileSizeMB : 10;

            LogHelper.Initialize(logLevel, maxLines, maxSize);

            // Scheduler cadence is controlled by Start()/Stop().
            _pulse = new DispatcherTimer { Interval = TimeSpan.FromSeconds(30) };
            _pulse.Tick += async (_, _) => await OnTickAsync();

            WriteLog($"[⏱ Scheduler starting at {Now():T}] Loaded {_vm.ScheduledJobs?.Count ?? 0} job(s) from disk");
            LoadHistory();
            ResumeOrExpirePendingExports();

        }

        private void WriteLog(string msg)
        {
            //  _vm.Log(msg);
            LogHelper.Info(msg);
        }

        private DateTime Now() => _useUtc ? DateTime.UtcNow : DateTime.Now;

        private bool LoadUtcSetting()
        {
            try
            {
                var json = File.ReadAllText("appsettings.json");
                using var doc = JsonDocument.Parse(json);
                return doc.RootElement.GetProperty("UseUtcTimestamps").GetBoolean();
            }
            catch
            {
                return false;
            }
        }
        private static bool _resumeAlreadyCalled = false;

        private void ResumeOrExpirePendingExports()
        {
            if (_resumeAlreadyCalled)
            {
                WriteLog("⚠️ ResumeOrExpirePendingExports skipped — already called.");
                return;
            }

            _resumeAlreadyCalled = true;
            WriteLog("🔍 Entered ResumeOrExpirePendingExports()");

            foreach (var job in _vm.ScheduledJobs.Where(j =>
                j.EnableExport &&
                j.ResponseId != null &&
                (j.ResponseCapturedTimeUtc != null || j.LastRunUtc != null || j.CompletedUtc != null) &&
                !_exportTimers.ContainsKey(j.JobId)))
            {
                WriteLog($"🔍 Evaluating job '{job.InstructionName}' (JobId {job.JobId}), Alias: {job.PlatformAlias}) for catch-up export...");

                // Normalize persisted runtime timestamps + flags so recovery status is accurate after restart.
                // Some older builds persisted CompletedUtc/ServerExportIssued in ways that do not match the latest run.
                var baselineUtc = job.ResponseCapturedTimeUtc ?? job.LastRunUtc ?? job.CompletedUtc;
                if (baselineUtc.HasValue)
                {
                    if (!job.CompletedUtc.HasValue || job.CompletedUtc.Value < baselineUtc.Value)
                        job.CompletedUtc = baselineUtc.Value;

                    // Ensure LastRunUtc exists for downstream calculations.
                    if (!job.LastRunUtc.HasValue)
                        job.LastRunUtc = baselineUtc.Value;
                }

                // Sanitize invalid mode-specific flags persisted by older builds.
                if (job.ExportMode == ExportMode.PagingOnly)
                {
                    job.ServerExportIssued = false;
                    job.ServerExportIssuedUtc = null;
                    job.LastServerExportPath = null;
                    job.LastServerDownloadUrl = null;
                }
                else if (job.ExportMode == ExportMode.ServerOnly)
                {
                    job.PagingExportCompleted = false;
                    job.PagingExportCompletedUtc = null;
                    job.LastPagingExportPath = null;
                }

                // If the current response has already been exported for this mode, do not resume/queue again.
                if (job.ExportMode == ExportMode.PagingOnly && job.PagingExportCompleted && !string.IsNullOrWhiteSpace(job.LastPagingExportPath))
                    continue;

                if (job.ExportMode == ExportMode.PagingThenServer && job.ServerExportIssued && !string.IsNullOrWhiteSpace(job.LastServerExportPath))
                    continue;

                var avgDuration = GetEstimatedExportDurationSeconds(job.JobId);
                var baseRunUtc = baselineUtc ?? job.LastRunUtc ?? job.CompletedUtc ?? DateTime.UtcNow;
                var elapsed = (DateTime.UtcNow - baseRunUtc).TotalSeconds;
                var responseTtlMinutes = job.ResponseTtlMinutes > 0 ? job.ResponseTtlMinutes : job.ExportTtlMinutes;
                var responseExpiryUtc = baseRunUtc.AddMinutes(responseTtlMinutes);
                // Per rules: paging and server-side export start after instruction TTL ends.
                var instructionTtlEndUtc = baseRunUtc.AddMinutes(Math.Max(0, job.InstructionTtlMinutes));
                var pagingStartUtc = instructionTtlEndUtc;
                if (pagingStartUtc < DateTime.UtcNow)
                    pagingStartUtc = DateTime.UtcNow;
                var serverStartUtc = instructionTtlEndUtc.AddSeconds(5);
                var ttlExpiry = responseExpiryUtc;
                var resumeThreshold = DateTime.UtcNow.AddSeconds(avgDuration);
                var instructionExpiry = instructionTtlEndUtc;

                if (DateTime.UtcNow < (job.ExportMode == ExportMode.ServerOnly ? serverStartUtc : pagingStartUtc))
                {
                    job.CurrentExecutionId ??= Guid.NewGuid();
                    job.LastRunExecutionId = job.CurrentExecutionId?.ToString();
                    job.JobName = string.IsNullOrWhiteSpace(job.InstructionName) ? "(Unnamed)" : job.InstructionName;
                    var delayUntil = job.ExportMode == ExportMode.ServerOnly ? serverStartUtc : pagingStartUtc;
                    string key = BuildExportDedupKey(job);

                    bool queued;
                    lock (_queuedExportsLock)
                    {
                        queued = _queuedExports.Add(key);
                    }

                    if (queued)
                    {
                        _pendingExports.Add((job, delayUntil));
                        WriteLog($"⏲️ Queued export for '{job.InstructionName}' (JobId {job.JobId}), Alias: {job.PlatformAlias}) to run at {delayUntil:T} via OnTick. ExecId: {job.CurrentExecutionId}");
                        job.RuntimeStatus = "PendingExport";
                    }
                    else
                    {
                        WriteLog($"⚠️ Duplicate export skipped for JobId {job.JobId} with ResponseId {job.ResponseId}");
                    }

                    continue;
                }

                if (resumeThreshold >= ttlExpiry)
                {
                    WriteLog($"💥 Export expired for '{job.InstructionName}' (JobId {job.JobId}), Alias: {job.PlatformAlias}) — resume threshold {resumeThreshold:T} exceeds TTL expiry {ttlExpiry:T}.");
                    job.IsExporting = false;
                    job.CompletedUtc = DateTime.UtcNow;
                    job.RuntimeStatus = "Expired";

                    SaveHistory(new JobExecutionHistory
                    {
                        ExecutionId = job.CurrentExecutionId ??= Guid.NewGuid(),
                        ResponseId = job.ResponseId?.ToString(),
                        JobId = job.JobId,
                        JobName = string.IsNullOrWhiteSpace(job.InstructionName) ? "(Unnamed)" : job.InstructionName,
                        JobType = "Instruction",
                        StartTime = baseRunUtc,
                        EndTime = DateTime.UtcNow,
                        DurationSeconds = (int)(DateTime.UtcNow - baseRunUtc).TotalSeconds,
                        Status = "Expired",
                        ExportPath = "(expired)",
                        Notes = "Export skipped — TTL expired",
                        TriggeredBy = "Startup",
                        PlatformFqdn = job.PlatformFqdn,
                        PlatformAlias = job.PlatformAlias
                    });
                }
                else if (elapsed >= avgDuration)
                {
                    WriteLog($"📤 Resuming pending export for '{job.InstructionName}' (JobId {job.JobId}), Alias: {job.PlatformAlias}) — elapsed {elapsed:F1}s, avg {avgDuration}s, TTL expires at {ttlExpiry:T}.");
                    // Deduplicate exports by JobId+ResponseId (NOT ExecutionId).
                    string key = BuildExportDedupKey(job);
                        LogHelper.Debug($"🧠 Export dispatch for JobId: {job.JobId}, Instruction: {job.InstructionName}, ResponseId: {job.ResponseId} → Key: {key}");
                        // The key is added when the export is queued; when it is time to run, DO NOT block on it.
                        lock (_queuedExportsLock)
                        {
                            if (!_queuedExports.Contains(key))
                                _queuedExports.Add(key);
                        }

                        _ = Task.Run(() => QueueExport(job));


                    job.IsExporting = true;
                    job.RuntimeStatus = "Exporting";
                    _exportTimers[job.JobId] = true;
                }
                else
                {
                    WriteLog($"⏳ Skipping export resume for '{job.InstructionName}' (JobId {job.JobId}), Alias: {job.PlatformAlias}) — not ready yet (elapsed {elapsed:F1}s, avg {avgDuration}s).");
                }
            }
        }


        private bool TryScheduleExportRetry(ScheduledJob job, string reason, TimeSpan? delay = null, TimeSpan? grace = null)
        {
            try
            {
                if (job == null)
                    return false;

                if (job.LastRunUtc == null)
                    return false;

                if (job.ResponseId == null)
                    return false;

                var nowUtc = DateTime.UtcNow;
                var capturedUtc = job.ResponseCapturedTimeUtc ?? job.LastRunUtc.Value;
                var ttlMinutes = job.ResponseTtlMinutes > 0 ? job.ResponseTtlMinutes : job.ExportTtlMinutes;
                var ttlExpiryUtc = capturedUtc.AddMinutes(ttlMinutes);

                var effectiveExpiryUtc = grace.HasValue ? ttlExpiryUtc.Add(grace.Value) : ttlExpiryUtc;

                // If we are using server-side export (ServerOnly/Both) or we've already issued a server export,
                // allow a grace window beyond the response TTL so the server-side export has time to appear and download.
                if (!grace.HasValue && (job.ExportMode == ExportMode.ServerOnly || job.ExportMode == ExportMode.PagingThenServer || job.ServerExportIssued))
                {
                    effectiveExpiryUtc = ttlExpiryUtc.Add(TimeSpan.FromMinutes(30));
                }

                var retryDelay = delay ?? TimeSpan.FromSeconds(60);
                var nextAttemptUtc = nowUtc.Add(retryDelay);

                // If we would retry after TTL expiry, do not requeue.
                if (nextAttemptUtc >= effectiveExpiryUtc)
                {
                    WriteLog($"💥 Not re-queuing export for '{job.InstructionName}' (ResponseId {job.ResponseId}) — would retry at {nextAttemptUtc:T} but TTL expires at {ttlExpiryUtc:T}{(grace.HasValue ? $" (+{grace.Value.TotalMinutes:F0}m grace)" : "")}. Reason: {reason}");
                    return false;
                }

                // Allow retries: remove the current dedupe key so the next attempt isn't blocked.
                var key = BuildExportDedupKey(job);
                lock (_queuedExportsLock)
                {
                    _queuedExports.Remove(key);
                }

                // Remove any existing pending entry for the same job/response to avoid duplicates.
                for (int i = _pendingExports.Count - 1; i >= 0; i--)
                {
                    var (pendingJob, _) = _pendingExports[i];
                    if (pendingJob?.JobId == job.JobId &&
                        string.Equals(pendingJob?.ResponseId?.ToString(), job.ResponseId.ToString(), StringComparison.OrdinalIgnoreCase))
                    {
                        _pendingExports.RemoveAt(i);
                    }
                }

                _pendingExports.Add((job, nextAttemptUtc));
                job.IsExporting = false;
                job.RuntimeStatus = "PendingExport";
                _exportTimers[job.JobId] = false;

                WriteLog($"🕒 Re-queued export for '{job.InstructionName}' (ResponseId {job.ResponseId}) in {retryDelay.TotalMinutes:F1} min (at {nextAttemptUtc:T}). Reason: {reason}");
                return true;
            }
            catch (Exception ex)
            {
                WriteLog($"❌ Failed to re-queue export for '{job?.InstructionName}': {ex.Message}");
                return false;
            }
        }

    private async Task QueueExport(ScheduledJob job)
{
    try
    {
        await Task.Delay(TimeSpan.FromMilliseconds(Random.Shared.Next(250, 2000))); // jitter

        var platform = ResolvePlatformForJob(job);
        if (platform == null)
        {
            WriteLog($"❌ Cannot export '{job.InstructionName}' — unknown platform '{LogRedaction.PlatformTag(job.PlatformAlias, job.PlatformFqdn)}'");
            return;
        }

        // Backfill PlatformAlias on the job if missing
        if (string.IsNullOrWhiteSpace(job.PlatformAlias) && !string.IsNullOrWhiteSpace(platform.Alias))
            job.PlatformAlias = platform.Alias;

        var authResult = await _authService.AuthenticateAsync(platform).ConfigureAwait(false);
        if (string.IsNullOrWhiteSpace(authResult?.Token))
            throw new UnauthorizedAccessException("Token is null after authentication.");

        job.Token = authResult.Token;
        job.Consumer = authResult.ConsumerName ?? platform.DefaultConsumer ?? "Explorer";

        _settings ??= new ConfigHelper().Load();
        _exportOptions = _settings?.ExportOptions ?? new();

        string exportBasePath;
        string exportFormat;

        if (!string.IsNullOrWhiteSpace(job.PlatformAlias) &&
            _exportOptions.TryGetValue(job.PlatformAlias, out var optByAlias) &&
            optByAlias != null &&
            !string.IsNullOrWhiteSpace(optByAlias.ExportFolder))
        {
            exportBasePath = optByAlias.ExportFolder;
            exportFormat = optByAlias.Format ?? (job.ExportFormat ?? "csv");
        }
        else if (!string.IsNullOrWhiteSpace(platform.Alias) &&
                 _exportOptions.TryGetValue(platform.Alias, out var optByResolvedAlias) &&
                 optByResolvedAlias != null &&
                 !string.IsNullOrWhiteSpace(optByResolvedAlias.ExportFolder))
        {
            exportBasePath = optByResolvedAlias.ExportFolder;
            exportFormat = optByResolvedAlias.Format ?? (job.ExportFormat ?? "csv");
        }
        else if (!string.IsNullOrWhiteSpace(job.PlatformFqdn) &&
                 _exportOptions.TryGetValue(job.PlatformFqdn, out var optByFqdn) &&
                 optByFqdn != null &&
                 !string.IsNullOrWhiteSpace(optByFqdn.ExportFolder))
        {
            exportBasePath = optByFqdn.ExportFolder;
            exportFormat = optByFqdn.Format ?? (job.ExportFormat ?? "csv");
        }
        else
        {
            exportBasePath = "C:\\temp";
            exportFormat = job.ExportFormat ?? "csv";
        }

        var alias = !string.IsNullOrWhiteSpace(job.PlatformAlias) ? job.PlatformAlias : (platform.Alias ?? "unknown");
        var ext = (exportFormat ?? "csv").Trim().TrimStart('.').ToLowerInvariant();

        var safeInstr = SanitizeFileName(job.InstructionName);
        var ts = DateTime.Now.ToString("yyyyMMdd_HHmmss");

        var pagingFilename = $"{safeInstr}_{job.ResponseId}_P_{ts}.{ext}";
        var serverFilename = $"{safeInstr}_{job.ResponseId}_S_{ts}.tsv";

        string exportDir = Path.Combine(exportBasePath, alias);
        var folderMode = job.ExportFolderMode;
        if (folderMode == ExportFolderMode.ByInstruction)
        {
            exportDir = Path.Combine(exportDir, safeInstr);
        }
        else if (folderMode == ExportFolderMode.ByDate)
        {
            exportDir = Path.Combine(exportDir, DateTime.Now.ToString("yyyy-MM-dd"));
        }
        else if (folderMode == ExportFolderMode.ByInstructionThenDate)
        {
            exportDir = Path.Combine(exportDir, safeInstr, DateTime.Now.ToString("yyyy-MM-dd"));
        }

        Directory.CreateDirectory(exportDir);

        var exportPathPaging = Path.Combine(exportDir, pagingFilename);
        var exportPathServer = Path.Combine(exportDir, serverFilename);

        var exportConsumer = !string.IsNullOrWhiteSpace(job.Consumer) ? job.Consumer : "Explorer";
        var responseIdInt = Convert.ToInt32(job.ResponseId);

        var capturedUtc = job.ResponseCapturedTimeUtc ?? job.LastRunUtc ?? DateTime.UtcNow;
        var instructionTtlMinutes = Math.Max(0, job.InstructionTtlMinutes);
        var instructionTtlEndUtc = capturedUtc.AddMinutes(instructionTtlMinutes);

        bool pagingProducedFile = false;
        bool serverProducedFile = false;

        void SaveExportHistory(string status, string notes, string? pagingPath, string? serverPath, string? downloadUrl)
        {
            try
            {
                var startUtc = job.LastRunUtc ?? job.ResponseCapturedTimeUtc ?? DateTime.UtcNow;
                var endUtc = DateTime.UtcNow;
                var exportPath = !string.IsNullOrWhiteSpace(pagingPath) ? pagingPath :
                                 (!string.IsNullOrWhiteSpace(serverPath) ? serverPath : (job.ExportPath ?? "(no export)"));

                SaveHistory(new JobExecutionHistory
                {
                    ExecutionId = job.CurrentExecutionId ?? Guid.NewGuid(),
                    JobId = job.JobId,
                    JobName = string.IsNullOrWhiteSpace(job.InstructionName) ? "(Unnamed)" : job.InstructionName,
                    JobType = string.IsNullOrWhiteSpace(job.JobType) ? "Instruction" : job.JobType,
                    StartTime = startUtc,
                    EndTime = endUtc,
                    DurationSeconds = (int)Math.Max(0, (endUtc - startUtc).TotalSeconds),
                    Status = status,
                    ExportPath = exportPath,
                    PagingExportPath = pagingPath,
                    ServerExportPath = serverPath,
                    ServerDownloadUrl = downloadUrl,
                    ServerExportIssued = job.ServerExportIssued,
                    ServerExportIssuedUtc = job.ServerExportIssuedUtc,
                    Notes = notes,
                    TriggeredBy = "Schedule",
                    PlatformFqdn = job.PlatformFqdn,
                    PlatformAlias = job.PlatformAlias,
                    ResponseId = job.ResponseId,
                    InstructionTtlMinutes = job.InstructionTtlMinutes,
                    ResponseTtlMinutes = job.ResponseTtlMinutes,
                    ExportFormat = job.ExportFormat ?? string.Empty,
                    RetryCount = job.RetryCount,
                    CompletedUtc = job.CompletedUtc
                });
            }
            catch
            {
                // ignore history write failures
            }
        }

        var pagingPathCurrent = job.LastPagingExportPath;
        var serverPathCurrent = job.LastServerExportPath;
        var serverDownloadCurrent = job.LastServerDownloadUrl;

        // ---------- SERVER ONLY ----------
        if (job.ExportMode == ExportMode.ServerOnly)
        {
            var serverEarliestUtc = instructionTtlEndUtc.AddSeconds(5);
            if (DateTime.UtcNow < serverEarliestUtc)
            {
                var wait = serverEarliestUtc - DateTime.UtcNow;
                if (wait < TimeSpan.FromSeconds(5)) wait = TimeSpan.FromSeconds(5);

                SaveExportHistory("WaitingServerExport", "Waiting for instruction TTL to elapse before server-side export", pagingPathCurrent, serverPathCurrent, serverDownloadCurrent);

                if (TryScheduleExportRetry(job, "waiting for TTL before server-side export", wait, TimeSpan.FromMinutes(30)))
                    return;
            }

            WriteLog($"🧊 Starting server-side export (poll + download) for '{job.InstructionName}' (ResponseId {job.ResponseId}) → {exportPathServer}");

            bool initiate = !job.ServerExportIssued;
            var serverInfo = await ExportHelper.TryServerSideExportAndDownloadWithInfoAsync(
                platform.PlatformFqdn,
                job.Token,
                exportConsumer,
                responseIdInt,
                exportPathServer,
                _logger,
                pollInterval: TimeSpan.FromSeconds(10),
                maxWait: TimeSpan.FromMinutes(15),
                initiateExport: initiate).ConfigureAwait(false);

            serverProducedFile = serverInfo?.Downloaded == true;
            if (serverInfo != null)
            {
                job.ServerExportIssued = true;
                job.ServerExportIssuedUtc ??= DateTime.UtcNow;

                job.LastServerExportPath = serverInfo.LocalPath ?? exportPathServer;
                job.LastServerDownloadUrl = serverInfo.DownloadUrl;
            }

            serverPathCurrent = job.LastServerExportPath;
            serverDownloadCurrent = job.LastServerDownloadUrl;

            if (serverProducedFile)
            {
                job.RetryCount = 0;
                job.PagingExportFailureCount = 0;
                job.RuntimeStatus = "Exported";
                job.CompletedUtc = DateTime.UtcNow;

                SaveExportHistory("Exported", "Server-side export downloaded", pagingPathCurrent, serverPathCurrent, serverDownloadCurrent);
                WriteLog($"✅ Server-side export complete for '{job.InstructionName}' (ResponseId {job.ResponseId}) → {serverPathCurrent}");
                return;
            }

            SaveExportHistory("WaitingServerExport", "Server-side export not ready yet", pagingPathCurrent, serverPathCurrent, serverDownloadCurrent);
            TryScheduleExportRetry(job, "server-side export not ready yet", TimeSpan.FromSeconds(60), TimeSpan.FromMinutes(30));
            return;
        }

        // ---------- PAGING (MODE 0 OR PAGING PHASE OF MODE 2) ----------
        bool shouldRunPaging = job.ExportMode == ExportMode.PagingOnly ||
                               (job.ExportMode == ExportMode.PagingThenServer && !job.PagingExportCompleted);

        if (shouldRunPaging)
        {
            if (DateTime.UtcNow < instructionTtlEndUtc)
            {
                var wait = instructionTtlEndUtc - DateTime.UtcNow;
                if (wait < TimeSpan.FromSeconds(5)) wait = TimeSpan.FromSeconds(5);

                SaveExportHistory("WaitingPagingExport", "Waiting for instruction TTL to elapse before paging export", pagingPathCurrent, serverPathCurrent, serverDownloadCurrent);
                if (TryScheduleExportRetry(job, "waiting for instruction TTL before paging export", wait, TimeSpan.FromMinutes(30)))
                    return;
            }

            WriteLog($"💾 Starting paging export for '{job.InstructionName}' (ResponseId {job.ResponseId}) → {exportPathPaging}");

            // IMPORTANT RULE (your requirement):
            // If the paging export API call succeeds (no exception), paging export is COMPLETE.
            // Do NOT retry or mark NoData based on file existence timing.
            await ExportHelper.ExportInstructionResultsWithProgressAsync(
                platform.PlatformFqdn,
                job.Token,
                exportConsumer,
                responseIdInt,
                exportPathPaging,
                exportFormat,
                _logger,
                pageSize: 2000,
                maxConcurrentRequests: 6
            ).ConfigureAwait(false);

            // Mark paging success immediately (API succeeded).
            pagingProducedFile = true;

            // Best-effort path verification (for nicer links), but never affects status/retry.
            string pagingPathFinal = exportPathPaging;
            try
            {
                for (int i = 0; i < 40; i++) // 10s best-effort
                {
                    if (File.Exists(pagingPathFinal))
                        break;

                    await Task.Delay(250).ConfigureAwait(false);
                }

                if (!File.Exists(pagingPathFinal))
                {
                    var pagingDir = Path.GetDirectoryName(exportPathPaging);
                    if (!string.IsNullOrWhiteSpace(pagingDir) && Directory.Exists(pagingDir))
                    {
                        var pattern = $"{safeInstr}_{job.ResponseId}_P_*.*";
                        var alt = Directory.EnumerateFiles(pagingDir, pattern, SearchOption.TopDirectoryOnly)
                            .Select(p => new FileInfo(p))
                            .OrderByDescending(fi => fi.LastWriteTimeUtc)
                            .FirstOrDefault();

                        if (alt != null && alt.Exists)
                            pagingPathFinal = alt.FullName;
                    }
                }
            }
            catch
            {
                // ignore
            }

            job.LastPagingExportPath = pagingPathFinal;
            job.ExportPath = pagingPathFinal;
            job.PagingExportFailureCount = 0;
            job.PagingExportCompleted = true;
            job.PagingExportCompletedUtc = DateTime.UtcNow;

            job.RetryCount = 0;
            job.IsExporting = false;
            job.CompletedUtc = DateTime.UtcNow;
            job.RuntimeStatus = "Exported";

            pagingPathCurrent = job.LastPagingExportPath;

            SaveExportHistory(job.ExportMode == ExportMode.PagingOnly ? "Exported" : "PagingExported",
                "Paging export completed",
                pagingPathCurrent,
                serverPathCurrent,
                serverDownloadCurrent);

            WriteLog($"✅ Paging export complete for '{job.InstructionName}' (ResponseId {job.ResponseId}) → {pagingPathCurrent}");

            // For paging-only jobs, paging success is terminal.
            if (job.ExportMode == ExportMode.PagingOnly)
                return;
        }

        // ---------- SERVER PHASE FOR BOTH (MODE 2) ----------
        if (job.ExportMode == ExportMode.PagingThenServer)
        {
            var serverEarliestUtc = instructionTtlEndUtc.AddSeconds(5);

            if (DateTime.UtcNow < serverEarliestUtc)
            {
                var wait = serverEarliestUtc - DateTime.UtcNow;
                if (wait < TimeSpan.FromSeconds(5)) wait = TimeSpan.FromSeconds(5);

                SaveExportHistory("WaitingServerExport", "Waiting for instruction TTL to elapse before server-side export", pagingPathCurrent, serverPathCurrent, serverDownloadCurrent);

                if (TryScheduleExportRetry(job, "waiting for TTL before server-side export (PagingThenServer)", wait, TimeSpan.FromMinutes(30)))
                    return;
            }

            WriteLog($"🧊 Starting server-side export (final) for '{job.InstructionName}' (ResponseId {job.ResponseId}) → {exportPathServer}");

            bool initiate = !job.ServerExportIssued;
            var serverInfo2 = await ExportHelper.TryServerSideExportAndDownloadWithInfoAsync(
                platform.PlatformFqdn,
                job.Token,
                exportConsumer,
                responseIdInt,
                exportPathServer,
                _logger,
                pollInterval: TimeSpan.FromSeconds(10),
                maxWait: TimeSpan.FromMinutes(15),
                initiateExport: initiate).ConfigureAwait(false);

            serverProducedFile = serverInfo2?.Downloaded == true;
            if (serverInfo2 != null)
            {
                job.ServerExportIssued = true;
                job.ServerExportIssuedUtc ??= DateTime.UtcNow;

                job.LastServerExportPath = serverInfo2.LocalPath ?? exportPathServer;
                job.LastServerDownloadUrl = serverInfo2.DownloadUrl;
            }

            serverPathCurrent = job.LastServerExportPath;
            serverDownloadCurrent = job.LastServerDownloadUrl;

            if (serverProducedFile)
            {
                job.RetryCount = 0;
                job.PagingExportFailureCount = 0;
                job.RuntimeStatus = "Exported";
                job.CompletedUtc = DateTime.UtcNow;

                SaveExportHistory("Exported", "Server-side export downloaded", pagingPathCurrent, serverPathCurrent, serverDownloadCurrent);
                WriteLog($"✅ Server-side export complete for '{job.InstructionName}' (ResponseId {job.ResponseId}) → {serverPathCurrent}");
                return;
            }

            SaveExportHistory("WaitingServerExport", "Server-side export not ready yet", pagingPathCurrent, serverPathCurrent, serverDownloadCurrent);
            TryScheduleExportRetry(job, "server-side export not ready yet (PagingThenServer)", TimeSpan.FromSeconds(60), TimeSpan.FromMinutes(30));
            return;
        }

        // If we ever land here, do NOT blindly mark NoData for paging-only successes.
        if (!pagingProducedFile && !serverProducedFile)
        {
            WriteLog($"⚠️ Export produced no file for '{job.InstructionName}' (ResponseId {job.ResponseId}) — treating as not ready.");
            SaveExportHistory("NoData", "Export produced no file (not ready / no results)", pagingPathCurrent, serverPathCurrent, serverDownloadCurrent);
            TryScheduleExportRetry(job, "export produced no file (results not ready yet)", null, TimeSpan.FromMinutes(30));
        }
    }
    catch (Exception ex)
    {
        WriteLog($"❌ Export failed for '{job.InstructionName}': {ex.Message}");
    }
    finally
    {
        _exportTimers[job.JobId] = false;
        job.IsExporting = false;

        // Persist export state (paths, completion flags, server-issued flags, etc.).
        // Without this, a restart can incorrectly treat already-exported runs as pending and
        // overwrite history with "Expired" entries.
        try
        {
            await _vm.SaveJobsAsync().ConfigureAwait(false);
        }
        catch
        {
            // best effort – history still captures paths/status even if job persistence fails
        }
    }
}



        private PlatformSettings? ResolvePlatformForJob(ScheduledJob job)
        {
            // Single platform demo-friendly behavior: if only one platform is configured, use it.
            var plats = _settings?.Platforms ?? new List<PlatformSettings>();
            if (plats.Count == 1)
                return plats[0];

            // Prefer alias
            if (!string.IsNullOrWhiteSpace(job.PlatformAlias))
            {
                var byAlias = plats.FirstOrDefault(p => string.Equals(p.Alias, job.PlatformAlias, StringComparison.OrdinalIgnoreCase));
                if (byAlias != null)
                    return byAlias;
            }

            // Fallback to FQDN
            if (!string.IsNullOrWhiteSpace(job.PlatformFqdn))
            {
                var byFqdn = plats.FirstOrDefault(p => string.Equals(p.PlatformFqdn, job.PlatformFqdn, StringComparison.OrdinalIgnoreCase));
                if (byFqdn != null)
                    return byFqdn;
            }

            return null;
        }

        private async Task OnTickAsync()
        {
            // Prevent re-entrancy if the UI pump fires while a tick is still running.
            if (_isTickRunning)
                return;

            _isTickRunning = true;
            try
            {
                // Process pending exports whose delayUntil has passed
                foreach (var (job, delayUntil) in _pendingExports.ToList())
                {
                    if (DateTime.UtcNow >= delayUntil)
                    {
                        WriteLog($"📤 Exporting resumed job '{job.JobName}' (execId {job.LastRunExecutionId})");

                        // Deduplicate exports by JobId+ResponseId (NOT ExecutionId).
                        // ExecutionId can change during resume/retry flows and would allow duplicate exports.
                        string key = BuildExportDedupKey(job);
                        LogHelper.Debug($"🧠 Export dispatch for JobId: {job.JobId}, Instruction: {job.InstructionName}, ResponseId: {job.ResponseId} → Key: {key}");
                        // The key is added when the export is queued; when it is time to run, DO NOT block on it.
                        lock (_queuedExportsLock)
                        {
                            if (!_queuedExports.Contains(key))
                                _queuedExports.Add(key);
                        }

                        _ = Task.Run(() => QueueExport(job));

                        job.IsExporting = true;
                        job.RuntimeStatus = "Exporting";
                        _exportTimers[job.JobId] = true;
                        _pendingExports.Remove((job, delayUntil));
                    }
                }
                var now = Now();
                if (_vm?.ScheduledJobs is null) return;

                foreach (var job in _vm.ScheduledJobs.ToList())
                {
                    var platformSettings = ResolvePlatformForJob(job);
                    job.PlatformMissing = platformSettings == null;
                    if (job.PlatformMissing)
                    {
                        job.RuntimeStatus = "InvalidPlatform";
                        LogSkip(job, $"🚫 Skipping '{job.InstructionName}' – platform not found.", now, true);
                        continue;
                    }

                    if (!job.IsEnabled)
                    {
                        job.RuntimeStatus = "Disabled";
                        continue;
                    }

                    if (job.IsRunning)
                    {
                        job.RuntimeStatus = "Running";
                        LogSkip(job, $"⏳ Skipping '{job.InstructionName}' – still running.", now, false);
                        continue;
                    }

                    if (job.LastRunUtc is DateTime lastOk && now - ConvertTime(lastOk) < job.Cooldown)
                    {
                        job.RuntimeStatus = "Cooldown";
                        LogSkip(job, $"🫊 Skipping '{job.InstructionName}' – cooldown.", now, false);
                        continue;
                    }

                    if (job.RetryCount > 0 && job.RetryCount < job.MaxRetries && job.LastRetryUtc is DateTime lastFail)
                    {
                        TimeSpan backoff = TimeSpan.FromMinutes(Math.Pow(2, job.RetryCount));
                        if (now - ConvertTime(lastFail) < backoff)
                        {
                            job.RuntimeStatus = "Retrying";
                            LogSkip(job, $"🔁 Skipping '{job.InstructionName}' – retry window.", now, false);
                            continue;
                        }
                    }

                    if (!IsDue(job, now, out string reason))
                    {
                        job.RuntimeStatus = "Waiting";
                        LogSkip(job, $"⏳ Skipping '{job.InstructionName}' – {reason}", now, true);
                        continue;
                    }

                    if (_lastStartedUtc.TryGetValue(job.JobId, out var lastStart) &&
                        (now - lastStart).TotalSeconds < Window.TotalSeconds)
                        continue;

                    _lastStartedUtc[job.JobId] = now;
                    var runExecutionId = Guid.NewGuid();
                    var runStartUtc = DateTime.UtcNow;
                    job.CurrentExecutionId = runExecutionId;
                    job.LastRunExecutionId = runExecutionId.ToString();
                    // Capture start immediately so history duration reflects reality.
                    job.LastRunUtc = runStartUtc;
                    job.RuntimeStatus = "Running";
                    job.IsRunning = true;
                    WriteLog($"🚀 Starting '{job.InstructionName}' at {now:T}");

                    // One row per scheduled run. This entry will be updated as the run progresses
                    // (instruction finished, export queued, export completed, etc.).
                    SaveHistory(new JobExecutionHistory
                    {
                        ExecutionId = (job.CurrentExecutionId ?? runExecutionId),
                        JobId = job.JobId,
                        JobName = string.IsNullOrWhiteSpace(job.InstructionName) ? "(Unnamed)" : job.InstructionName,
                        JobType = string.IsNullOrWhiteSpace(job.JobType) ? "Instruction" : job.JobType,
                        StartTime = runStartUtc,
                        EndTime = runStartUtc,
                        DurationSeconds = 0,
                        Status = "Running",
                        ExportPath = job.EnableExport ? "(pending export)" : "(no export)",
                        Notes = "Run started",
                        TriggeredBy = "Schedule",
                        PlatformFqdn = job.PlatformFqdn,
                        PlatformAlias = job.PlatformAlias,
                        InstructionTtlMinutes = job.InstructionTtlMinutes,
                        ResponseTtlMinutes = job.ResponseTtlMinutes,
                        ExportFormat = job.ExportFormat ?? string.Empty,
                        RetryCount = job.RetryCount
                    });

                    _ = Task.Run(async () =>
                    {
                        JobRunResult? result = null;
                        Exception? fatal = null;

                        try
                        {
                            await Task.Delay(TimeSpan.FromMilliseconds(Random.Shared.Next(1000, 3000)));

                            var platformSettings = ResolvePlatformForJob(job)
                                ?? throw new InvalidOperationException($"No matching platform found for {LogRedaction.PlatformTag(job.PlatformAlias, job.PlatformFqdn)}");

                            if (string.IsNullOrWhiteSpace(job.PlatformAlias) && !string.IsNullOrWhiteSpace(platformSettings.Alias))
                                job.PlatformAlias = platformSettings.Alias;

                            await Task.Delay(TimeSpan.FromMilliseconds(Random.Shared.Next(1000, 4000)));
                            LogHelper.Debug($"🔍 Auth Details → Platform: {LogRedaction.PlatformTag(platformSettings.Alias, platformSettings.PlatformFqdn)}, AppId: {(string.IsNullOrWhiteSpace(platformSettings.AppId) ? "missing" : "set")}, Thumb: {(string.IsNullOrWhiteSpace(platformSettings.CertThumbprint) ? "missing" : $"…{(platformSettings.CertThumbprint.Length > 6 ? platformSettings.CertThumbprint[^6..] : platformSettings.CertThumbprint)}")}, UseCert: {platformSettings.UseCert}");


                            var authResult = await _authService.AuthenticateAsync(platformSettings).ConfigureAwait(false);

                            if (string.IsNullOrWhiteSpace(authResult?.Token))
                                throw new UnauthorizedAccessException("Token is null after authentication.");

                            job.Token = authResult.Token;
                            job.Consumer = authResult.ConsumerName ?? platformSettings.DefaultConsumer ?? "Explorer";
                            string tokenSuffix = job.Token.Length >= 6 ? job.Token[^6..] : "??";
                            LogHelper.Info($"🔐 Scheduler token acquired for {LogRedaction.PlatformTag(platformSettings.Alias, platformSettings.PlatformFqdn)} ... ending in: ...{tokenSuffix}");

                            var parametersDict = job.Parameters?.ToDictionary(kvp => kvp.Key, kvp => (object)kvp.Value) ?? new();
                            string targetingMode = (job.TargetingMethod ?? "FQDN").Trim();
                            string fqdnInput = job.TargetingFqdn ?? "";
                            string matchType = job.MatchType ?? "Begins With";
                            ManagementGroup? mg = null;

                            if (string.Equals(targetingMode, "MG", StringComparison.OrdinalIgnoreCase))
                            {
                                // "All Devices" (global) must be runnable even when platform DefaultMG is not set.
                                // Treat empty MG selection, "All Devices", or a non-positive ID as global scope.
                                bool isGlobalAllDevices =
                                    (job.ManagementGroupId.HasValue && job.ManagementGroupId.Value <= 0) ||
                                    string.IsNullOrWhiteSpace(job.TargetingManagementGroup) ||
                                    string.Equals(job.TargetingManagementGroup, "All Devices", StringComparison.OrdinalIgnoreCase);

                                if (isGlobalAllDevices)
                                {
                                    job.TargetingManagementGroup = "All Devices";
                                    job.ManagementGroupId = job.ManagementGroupId.HasValue && job.ManagementGroupId.Value != 0
                                        ? job.ManagementGroupId
                                        : -1;

                                    // InstructionService expects a non-null MG object for MG targeting.
                                    mg = new ManagementGroup
                                    {
                                        UsableId = job.ManagementGroupId.Value,
                                        Name = "All Devices"
                                    };
                                }
                                else
                                {
                                    // Named MG targeting.
                                    if (!job.ManagementGroupId.HasValue || job.ManagementGroupId.Value <= 0)
                                    {
                                        var mgList = await _instructionService.GetManagementGroupsAsync(job.PlatformFqdn, job.Token);
                                        var match = mgList.FirstOrDefault(m =>
                                            string.Equals(m.Name, job.TargetingManagementGroup, StringComparison.OrdinalIgnoreCase));
                                        if (match == null)
                                            throw new InvalidOperationException($"❌ Targeting Mode is MG, but '{job.TargetingManagementGroup}' not found on platform {LogRedaction.PlatformTag(job.PlatformAlias, job.PlatformFqdn)}");

                                        job.ManagementGroupId = match.UsableId;
                                        LogHelper.Info($"🔍 Resolved MG '{job.TargetingManagementGroup}' → ID {match.UsableId}");
                                    }

                                    mg = new ManagementGroup
                                    {
                                        UsableId = job.ManagementGroupId ?? -1,
                                        Name = job.TargetingManagementGroup
                                    };
                                }
                            }
                            else if (targetingMode == "Coverage" &&
                                (string.IsNullOrWhiteSpace(job.CoverageTag) || string.IsNullOrWhiteSpace(job.CoverageValue)))
                            {
                                throw new InvalidOperationException("Coverage tag or value is missing.");
                            }
                            else if (targetingMode == "FQDN" && string.IsNullOrWhiteSpace(fqdnInput))
                            {
                                throw new InvalidOperationException("Targeting FQDN is missing.");


                            }
                            string exportTokenSuffix = job.Token.Length >= 6 ? job.Token[^6..] : "??";
                            LogHelper.Info($"🔐 Running Instruction with API Call Context → Platform: {LogRedaction.PlatformTag(platformSettings.Alias, platformSettings.PlatformFqdn)}, AppId: {(string.IsNullOrWhiteSpace(platformSettings.AppId) ? "missing" : "set")}, Thumb: {(string.IsNullOrWhiteSpace(platformSettings.CertThumbprint) ? "missing" : $"…{(platformSettings.CertThumbprint.Length > 6 ? platformSettings.CertThumbprint[^6..] : platformSettings.CertThumbprint)}")} for InstructionName: {job.InstructionName} Token: {exportTokenSuffix}");
                            result = await _instructionService.RunInstructionFromMainTabAsync(
                                new InstructionDefinition { Id = job.InstructionId, Name = job.InstructionName },
                                parametersDict,
                                targetingMode,
                                job.PlatformFqdn,
                                job.Token,
                                job.Consumer,
                                fqdnInput,
                                matchType,
                                mg,
                                job.CoverageTag,
                                job.CoverageValue,
                                new List<string>(),
                                job.InstructionTtlMinutes,
                                responseTtlMinutes: job.ResponseTtlMinutes,
                                logger: _logger,
                                compulsoryCoverageEnabled: platformSettings.RequireCoverage,
                                requestServerSideExport: (job.ExportMode != TV1_InstructionOffloader.Models.ExportMode.PagingOnly)
                            );
                        }
                        catch (Exception ex)
                        {
                            fatal = ex;
                            result = new JobRunResult { Success = false, ErrorMessage = ex.Message };
                        }

                        await Dispatcher.UIThread.InvokeAsync(async () =>
                        {
                            if (result!.Success)
                        {
                            var prevResponseId = job.ResponseId;
                            job.ResponseId = result.ResponseId.ToString();

                            // New response => reset export state so flags from a previous run can't force the wrong export path (e.g. paging-only trying server-side).
                            if (!string.Equals(prevResponseId, job.ResponseId, StringComparison.Ordinal))
                            {
                                job.PagingExportCompleted = false;
                                job.PagingExportCompletedUtc = null;
                                job.PagingExportFailureCount = 0;
                                job.LastPagingExportPath = null;

                                job.ServerExportIssued = false;
                                job.ServerExportIssuedUtc = null;
                                job.LastServerExportPath = null;
                                job.LastServerDownloadUrl = null;

                                job.ExportPath = null;
                            }
                                job.ResponseCapturedTimeUtc = DateTime.UtcNow;
                                job.RetryCount = 0;
                                job.RuntimeStatus = "Waiting";
                                WriteLog($"✅ Finished '{job.InstructionName}' successfully.");
                                SaveHistory(new JobExecutionHistory
                                {
                                    ExecutionId = (job.CurrentExecutionId ?? runExecutionId),
                                    ResponseId = job.ResponseId?.ToString(),
                                    JobId = job.JobId,
                                    JobName = string.IsNullOrWhiteSpace(job.InstructionName) ? "(Unnamed)" : job.InstructionName,
                                    JobType = "Instruction",
                                    StartTime = runStartUtc,
                                    EndTime = DateTime.UtcNow,
                                    DurationSeconds = (int)Math.Max(0, (DateTime.UtcNow - runStartUtc).TotalSeconds),
                                    Status = job.EnableExport ? "WaitingExport" : "Success",
                                    ExportPath = job.EnableExport ? "(pending export)" : "(no export)",
                                    Notes = job.EnableExport ? "Instruction completed; export scheduled" : "Instruction completed",
                                    TriggeredBy = "Schedule",
                                    PlatformFqdn = job.PlatformFqdn,
                                    PlatformAlias = job.PlatformAlias,
                                    InstructionTtlMinutes = job.InstructionTtlMinutes,
                                    ResponseTtlMinutes = job.ResponseTtlMinutes,
                                    ExportFormat = job.ExportFormat ?? string.Empty,
                                    RetryCount = job.RetryCount
                                });


                                if (job.EnableExport)
                                {
                                    try
                                    {
                                        // Schedule export via the shared OnTick pending export queue (no ad-hoc Task.Run timers).
                                        // Timing rules (UTC):
                                        //  - Paging export may start at instruction TTL end OR EarlyExportMinutes before response TTL expiry (whichever comes first).
                                        //  - Server-only export must start after response TTL expiry (platform behavior).
                                        var baseRunUtc = job.LastRunUtc ?? job.ResponseCapturedTimeUtc ?? DateTime.UtcNow;

                                        var instructionTtlMinutes = Math.Max(0, job.InstructionTtlMinutes);
                                        var responseTtlMinutes = job.ResponseTtlMinutes > 0 ? job.ResponseTtlMinutes : job.ExportTtlMinutes;

                                        var instructionTtlEndUtc = baseRunUtc.AddMinutes(instructionTtlMinutes);
                                        var responseTtlExpiryUtc = baseRunUtc.AddMinutes(responseTtlMinutes);

                                        var earlyMinutes = Math.Max(0, job.EarlyExportMinutes);
                                        var earlyHitUtc = responseTtlExpiryUtc.AddMinutes(-earlyMinutes);

                                        var pagingExportAtUtc = instructionTtlEndUtc <= earlyHitUtc ? instructionTtlEndUtc : earlyHitUtc;
                                        var serverExportAtUtc = responseTtlExpiryUtc.AddSeconds(5);

                                        if (pagingExportAtUtc < DateTime.UtcNow)
                                            pagingExportAtUtc = DateTime.UtcNow;

                                        var exportAtUtc = job.ExportMode == ExportMode.ServerOnly ? serverExportAtUtc : pagingExportAtUtc;
                                        if (exportAtUtc < DateTime.UtcNow)
                                            exportAtUtc = DateTime.UtcNow;

                                        // Ensure we have execution identifiers for dedup + history alignment.
                                        job.CurrentExecutionId ??= runExecutionId;
                                        job.LastRunExecutionId = job.CurrentExecutionId?.ToString();
                                        job.JobName = string.IsNullOrWhiteSpace(job.InstructionName) ? "(Unnamed)" : job.InstructionName;

                                        string key = BuildExportDedupKey(job);

                                        bool added;
                                        lock (_queuedExportsLock)
                                        {
                                            added = _queuedExports.Add(key);
                                        }

                                        if (added)
                                        {
                                            // Remove any existing pending entry for the same job/response to avoid duplicates.
                                            for (int i = _pendingExports.Count - 1; i >= 0; i--)
                                            {
                                                var (pendingJob, _) = _pendingExports[i];
                                                if (pendingJob?.JobId == job.JobId &&
                                                    string.Equals(pendingJob?.ResponseId?.ToString(), job.ResponseId?.ToString(), StringComparison.OrdinalIgnoreCase))
                                                {
                                                    _pendingExports.RemoveAt(i);
                                                }
                                            }

                                            _pendingExports.Add((job, exportAtUtc));
                                            job.RuntimeStatus = "PendingExport";
                                            job.IsExporting = false;
                                            _exportTimers[job.JobId] = false;

                                            WriteLog($"⏲️ Queued export ({job.ExportMode}) for '{job.InstructionName}' (ResponseId {job.ResponseId}) at {exportAtUtc:HH:mm:ss}Z.");
                                        }
                                        else
                                        {
                                            WriteLog($"⚠️ Duplicate export skipped for JobId {job.JobId} with ResponseId {job.ResponseId}");
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        WriteLog($"❌ Failed to queue export for '{job.InstructionName}': {ex.Message}");
                                    }
                                }


                                _vm.UpdateJobDurationsFromHistory();
                            }
                            else
                            {
                                job.RetryCount++;
                                job.LastRetryUtc = DateTime.UtcNow;
                                job.RuntimeStatus = "Failed";
                                string err = result.ErrorMessage ?? fatal?.Message ?? "Unknown error";
                                WriteLog($"💥 Error running '{job.InstructionName}': {err} (Retry #{job.RetryCount})");

                                // Update the previously written "Running" history row so the UI never gets stuck.
                                SaveHistory(new JobExecutionHistory
                                {
                                    ExecutionId = (job.CurrentExecutionId ?? runExecutionId),
                                    ResponseId = job.ResponseId?.ToString(),
                                    JobId = job.JobId,
                                    JobName = string.IsNullOrWhiteSpace(job.InstructionName) ? "(Unnamed)" : job.InstructionName,
                                    JobType = string.IsNullOrWhiteSpace(job.JobType) ? "Instruction" : job.JobType,
                                    StartTime = runStartUtc,
                                    EndTime = DateTime.UtcNow,
                                    DurationSeconds = (int)Math.Max(0, (DateTime.UtcNow - runStartUtc).TotalSeconds),
                                    Status = "Failed",
                                    ExportPath = job.EnableExport ? "(pending export)" : "(no export)",
                                    Notes = err,
                                    TriggeredBy = "Schedule",
                                    PlatformFqdn = job.PlatformFqdn,
                                    PlatformAlias = job.PlatformAlias,
                                    InstructionTtlMinutes = job.InstructionTtlMinutes,
                                    ResponseTtlMinutes = job.ResponseTtlMinutes,
                                    ExportFormat = job.ExportFormat ?? string.Empty,
                                    RetryCount = job.RetryCount
                                });
                                _vm.UpdateJobDurationsFromHistory();
                            }

                            job.IsRunning = false;
                            await _vm.SaveJobsAsync();
                        });
                    });
                }


                // Catch-up export logic
                foreach (var pending in _vm.ScheduledJobs.Where(j =>
                    j.EnableExport && !j.IsExporting &&
                    j.ResponseId != null && j.LastRunUtc != null &&
                    j.CompletedUtc == null &&
                    !_exportTimers.ContainsKey(j.JobId)))
                {
                    var lastRunLocal = pending.LastRunUtc.Value.ToLocalTime();
                    var nowLocal = DateTime.Now;
                    var delayMinutes = pending.ExportTtlMinutes - pending.EarlyExportMinutes;
                    var dueLocal = lastRunLocal.AddMinutes(delayMinutes);

                    if (dueLocal <= nowLocal)
                    {
                        WriteLog($"📤 Running catch-up export for '{pending.InstructionName}' immediately (was due at {dueLocal:T})");

                        _ = Task.Run(async () =>
                        {
                            try
                            {
                                await Task.Delay(TimeSpan.FromMilliseconds(new Random().Next(250, 2000))); // concurrency-safe auth

                                var matchingPlatform = PlatformService.KnownPlatforms.FirstOrDefault(p =>
                                    string.Equals(p.PlatformFqdn, pending.PlatformFqdn, StringComparison.OrdinalIgnoreCase));
                                if (matchingPlatform is null)
                                {
                                    WriteLog($"❌ Cannot export '{pending.InstructionName}' — unknown platform '{LogRedaction.PlatformTag(pending.PlatformAlias, pending.PlatformFqdn)}'");
                                    return;
                                }

                                var platformSettings = new PlatformSettings
                                {
                                    Alias = matchingPlatform.Alias,
                                    PlatformFqdn = matchingPlatform.PlatformFqdn,
                                    UserId = matchingPlatform.UserId,
                                    DefaultConsumer = matchingPlatform.DefaultConsumer,
                                    AppId = matchingPlatform.AppId,
                                    CertThumbprint = matchingPlatform.CertThumbprint,
                                    UseCert = matchingPlatform.UseCert
                                };
                                LogHelper.Debug($"🔍 Auth Details → Platform: {LogRedaction.PlatformTag(platformSettings.Alias, platformSettings.PlatformFqdn)}, AppId: {(string.IsNullOrWhiteSpace(platformSettings.AppId) ? "missing" : "set")}, Thumb: {(string.IsNullOrWhiteSpace(platformSettings.CertThumbprint) ? "missing" : $"…{(platformSettings.CertThumbprint.Length > 6 ? platformSettings.CertThumbprint[^6..] : platformSettings.CertThumbprint)}")}, UseCert: {platformSettings.UseCert}");

                                LogHelper.Info($"🔐 API Call Context → Platform: {LogRedaction.PlatformTag(platformSettings.Alias, platformSettings.PlatformFqdn)}, AppId: {(string.IsNullOrWhiteSpace(platformSettings.AppId) ? "missing" : "set")}, Thumb: {(string.IsNullOrWhiteSpace(platformSettings.CertThumbprint) ? "missing" : $"…{(platformSettings.CertThumbprint.Length > 6 ? platformSettings.CertThumbprint[^6..] : platformSettings.CertThumbprint)}")}");
                                // var authResult = await AuthHelper.AuthenticateIsolatedAsync(platformSettings);
                                var authResult = await AuthHelper.AuthenticateIsolatedAsync(platformSettings);

                                if (string.IsNullOrWhiteSpace(authResult?.Token))
                                    throw new UnauthorizedAccessException("Token is null after authentication.");

                                pending.Token = authResult.Token;
                                pending.Consumer = authResult.ConsumerName ?? matchingPlatform.DefaultConsumer ?? "Explorer";

                                string exportBasePath;
                                string exportFormat;
                                string? aliasKey = pending.PlatformAlias?.Trim().ToLowerInvariant();
                                string? fqdnKey = pending.PlatformFqdn?.Trim().ToLowerInvariant();
                                ExportOption? match = null;

                                if (!string.IsNullOrWhiteSpace(aliasKey) && _settings?.ExportOptions?.TryGetValue(aliasKey, out match) == true)
                                {
                                    exportBasePath = match.ExportFolder;
                                    exportFormat = match.Format ?? "csv";
                                }
                                else if (!string.IsNullOrWhiteSpace(fqdnKey) && _settings?.ExportOptions?.TryGetValue(fqdnKey, out match) == true)
                                {
                                    exportBasePath = match.ExportFolder;
                                    exportFormat = match.Format ?? "csv";
                                }
                                else
                                {
                                    exportBasePath = "C:\\temp";
                                    exportFormat = pending.ExportFormat ?? "csv";
                                    LogHelper.Warn($"⚠️ No ExportOptions match found for Platform '{LogRedaction.PlatformTag(pending.PlatformAlias, pending.PlatformFqdn)}' — using default. Available keys: {string.Join(", ", _settings.ExportOptions.Keys)}");
                                }


                                if (platformSettings == null)
                                {
                                    LogHelper.Warn($"❌ Could not resolve platform settings for export job '{pending.InstructionName}'");
                                    return;
                                }
                                LogHelper.Debug($"🔍 Auth Details → Platform: {LogRedaction.PlatformTag(platformSettings.Alias, platformSettings.PlatformFqdn)}, AppId: {(string.IsNullOrWhiteSpace(platformSettings.AppId) ? "missing" : "set")}, Thumb: {(string.IsNullOrWhiteSpace(platformSettings.CertThumbprint) ? "missing" : $"…{(platformSettings.CertThumbprint.Length > 6 ? platformSettings.CertThumbprint[^6..] : platformSettings.CertThumbprint)}")}, UseCert: {platformSettings.UseCert}");

                                LogHelper.Info($"🔐 API Call Context → Platform: {LogRedaction.PlatformTag(platformSettings.Alias, platformSettings.PlatformFqdn)}, AppId: {(string.IsNullOrWhiteSpace(platformSettings.AppId) ? "missing" : "set")}, Thumb: {(string.IsNullOrWhiteSpace(platformSettings.CertThumbprint) ? "missing" : $"…{(platformSettings.CertThumbprint.Length > 6 ? platformSettings.CertThumbprint[^6..] : platformSettings.CertThumbprint)}")}");
                                var exportAuthResult = await AuthHelper.AuthenticateIsolatedAsync(platformSettings);
                                string exportToken = exportAuthResult.Token;
                                string exportConsumer = exportAuthResult.ConsumerName;

                                string alias = pending.PlatformAlias ?? "unknown";
                                string safeInstr = SanitizeFileName(pending.InstructionName);
                                string ts = DateTime.Now.ToString("yyyyMMdd_HHmmss");
                                string ext = (pending.ExportFormat ?? "csv").Trim().TrimStart('.').ToLowerInvariant();

                                string exportPathPaging = Path.Combine(exportBasePath, alias, $"{safeInstr}_{pending.ResponseId}_P_{ts}.{ext}");
                                string exportPathServer = Path.Combine(exportBasePath, alias, $"{safeInstr}_{pending.ResponseId}_S_{ts}.tsv");

                                Directory.CreateDirectory(Path.GetDirectoryName(exportPathPaging)!);
                                Directory.CreateDirectory(Path.GetDirectoryName(exportPathServer)!);

                                bool pagingFileCreated = false;
                                bool serverFileCreated = false;
                                string? serverDownloadUrl = null;
                                string? serverExportServerPath = null;
                                string? finalExportPath = null;

                                // Paging export (if enabled)
                                if (pending.ExportMode != ExportMode.ServerOnly)
                                {
                                    await ExportHelper.ExportInstructionResultsWithProgressAsync(
                                        pending.PlatformFqdn,
                                        exportToken,
                                        exportConsumer,
                                        Convert.ToInt32(pending.ResponseId),
                                        exportPathPaging,
                                        pending.ExportFormat ?? "CSV",
                                        _logger,
                                        pageSize: 2000,
                                        maxConcurrentRequests: 6
                                    );

                                    pagingFileCreated = File.Exists(exportPathPaging);
                                    if (pagingFileCreated)
                                    {
                                        finalExportPath = exportPathPaging;
                                    }
                                }

                                // Server-side export after TTL expiry (only if paging failed and mode allows it, or ServerOnly)
                                if (pending.ExportMode == ExportMode.ServerOnly || pending.ExportMode == ExportMode.PagingThenServer)
                                {
                                    var capturedUtc2 = pending.ResponseCapturedTimeUtc ?? pending.LastRunUtc ?? DateTime.UtcNow;
                                    var ttlMinutes2 = pending.ResponseTtlMinutes > 0 ? pending.ResponseTtlMinutes : pending.ExportTtlMinutes;
                                    var ttlExpiryUtc2 = capturedUtc2.AddMinutes(ttlMinutes2);
                                    var serverEarliestUtc = ttlExpiryUtc2.AddSeconds(5);

                                    if (DateTime.UtcNow < serverEarliestUtc)
                                    {
                                        var wait = serverEarliestUtc - DateTime.UtcNow;
                                        if (wait < TimeSpan.FromSeconds(5)) wait = TimeSpan.FromSeconds(5);

                                        if (TryScheduleExportRetry(pending, "waiting for TTL before server-side export", wait, TimeSpan.FromMinutes(30)))
                                            return;

                                        // If we couldn't requeue (TTL too tight), treat as no data below.
                                    }
                                    else
                                    {
                                        bool initiate = !pending.ServerExportIssued;

                                        var serverInfo = await ExportHelper.TryServerSideExportAndDownloadWithInfoAsync(
                                            pending.PlatformFqdn,
                                            token,
                                            pending.ConsumerName ?? "Explorer",
                                            Convert.ToInt32(pending.ResponseId),
                                            exportPathServer,
                                            _logger,
                                            pollInterval: TimeSpan.FromSeconds(10),
                                            maxWait: TimeSpan.FromMinutes(15),
                                            initiateExport: initiate).ConfigureAwait(false);

                                        serverFileCreated = serverInfo?.Downloaded == true;
                                        if (serverInfo != null)
                                        {
                                            pending.ServerExportIssued = true;
                                            pending.ServerExportIssuedUtc ??= DateTime.UtcNow;
                                            pending.LastServerExportPath = serverInfo.LocalPath ?? exportPathServer;
                                            pending.LastServerDownloadUrl = serverInfo.DownloadUrl;
                                        }

                                        if (serverFileCreated)
                                            finalExportPath = exportPathServer;
                                    }
                                }

                                if (!(pagingFileCreated || serverFileCreated))
                                {
                                    if (TryScheduleExportRetry(pending, "catch-up export produced no file (results not ready yet)", null, TimeSpan.FromMinutes(30)))
                                        return;

                                    WriteLog($"⚠️ Export produced no file for '{pending.InstructionName}' (ResponseId {pending.ResponseId}) — treating as no data.");
                                }
                                else
                                {
                                    WriteLog($"✅ Export complete for '{pending.InstructionName}' (ResponseId {pending.ResponseId}) → {finalExportPath}");
                                }
                                await Dispatcher.UIThread.InvokeAsync(() =>
                                {
                                    pending.IsExporting = false;
                                    pending.CompletedUtc = DateTime.UtcNow;
                                    pending.RuntimeStatus = "Waiting";
                                });
                            }
                            catch (Exception ex)
                            {
                                WriteLog($"❌ Catch-up export failed for '{pending.InstructionName}': {ex.Message}");
                            }
                        });

                        pending.IsExporting = true;
                        pending.RuntimeStatus = "Exporting";
                        _exportTimers[pending.JobId] = true;
                    }
                    else
                    {
                        var delay = dueLocal - nowLocal;

                        WriteLog($"🕒 Catch-up export for '{pending.InstructionName}' scheduled in {delay.TotalMinutes:F1} min (at {dueLocal:T})");

                        _ = Task.Run(async () =>
                        {
                            await Task.Delay(delay);

                            try
                            {
                                await Task.Delay(TimeSpan.FromMilliseconds(new Random().Next(250, 2000))); // jitter for concurrency

                                var matchingPlatform = PlatformService.KnownPlatforms.FirstOrDefault(p =>
                                    string.Equals(p.PlatformFqdn, pending.PlatformFqdn, StringComparison.OrdinalIgnoreCase));
                                if (matchingPlatform is null)
                                {
                                    WriteLog($"❌ Cannot export '{pending.InstructionName}' — unknown platform '{LogRedaction.PlatformTag(pending.PlatformAlias, pending.PlatformFqdn)}'");
                                    return;
                                }

                                var platformSettings = new PlatformSettings
                                {
                                    PlatformFqdn = matchingPlatform.PlatformFqdn,
                                    AppId = matchingPlatform.AppId,
                                    CertThumbprint = matchingPlatform.CertThumbprint,
                                    UseCert = matchingPlatform.UseCert
                                };
                                LogHelper.Debug($"🔍 Auth Details → Platform: {LogRedaction.PlatformTag(platformSettings.Alias, platformSettings.PlatformFqdn)}, AppId: {(string.IsNullOrWhiteSpace(platformSettings.AppId) ? "missing" : "set")}, Thumb: {(string.IsNullOrWhiteSpace(platformSettings.CertThumbprint) ? "missing" : $"…{(platformSettings.CertThumbprint.Length > 6 ? platformSettings.CertThumbprint[^6..] : platformSettings.CertThumbprint)}")}, UseCert: {platformSettings.UseCert}");

                                LogHelper.Info($"🔐 API Call Context → Platform: {LogRedaction.PlatformTag(platformSettings.Alias, platformSettings.PlatformFqdn)}, AppId: {(string.IsNullOrWhiteSpace(platformSettings.AppId) ? "missing" : "set")}, Thumb: {(string.IsNullOrWhiteSpace(platformSettings.CertThumbprint) ? "missing" : $"…{(platformSettings.CertThumbprint.Length > 6 ? platformSettings.CertThumbprint[^6..] : platformSettings.CertThumbprint)}")}");
                                //                            var authResult = await AuthHelper.AuthenticateIsolatedAsync(platformSettings);
                                var authResult = await AuthHelper.AuthenticateIsolatedAsync(platformSettings);

                                if (string.IsNullOrWhiteSpace(authResult?.Token))
                                    throw new UnauthorizedAccessException("Token is null after authentication.");

                                pending.Token = authResult.Token;
                                pending.Consumer = authResult.ConsumerName ?? matchingPlatform.DefaultConsumer ?? "Explorer";

                                string exportBasePath;
                                string? aliasKey = pending.PlatformAlias?.Trim().ToLowerInvariant();
                                string? fqdnKey = pending.PlatformFqdn?.Trim().ToLowerInvariant();

                                if (!string.IsNullOrWhiteSpace(aliasKey) &&
                                    _settings?.ExportOptions?.TryGetValue(aliasKey, out var optByAlias) == true)
                                {
                                    exportBasePath = optByAlias.ExportFolder;
                                }
                                else if (!string.IsNullOrWhiteSpace(fqdnKey) &&
                                         _settings?.ExportOptions?.TryGetValue(fqdnKey, out var optByFqdn) == true)
                                {
                                    exportBasePath = optByFqdn.ExportFolder;
                                }
                                else
                                {
                                    exportBasePath = "C:\\temp";
                                    LogHelper.Warn($"⚠️ No ExportOptions match found for Platform '{LogRedaction.PlatformTag(pending.PlatformAlias, pending.PlatformFqdn)}' — using default. Available keys: {string.Join(", ", _settings.ExportOptions.Keys)}");
                                }



                                if (platformSettings == null)
                                {
                                    LogHelper.Warn($"❌ Could not resolve platform settings for export job '{pending.InstructionName}'");
                                    return; // or return Task.CompletedTask if you're inside Task.Run
                                }

                                string alias = pending.PlatformAlias ?? "unknown";
                                string safeInstr = SanitizeFileName(pending.InstructionName);
                                string ts = DateTime.Now.ToString("yyyyMMdd_HHmmss");
                                string ext = (pending.ExportFormat ?? "csv").Trim().TrimStart('.').ToLowerInvariant();

                                string exportPathPaging = Path.Combine(exportBasePath, alias, $"{safeInstr}_{pending.ResponseId}_P_{ts}.{ext}");
                                string exportPathServer = Path.Combine(exportBasePath, alias, $"{safeInstr}_{pending.ResponseId}_S_{ts}.tsv");

                                Directory.CreateDirectory(Path.GetDirectoryName(exportPathPaging)!);
                                Directory.CreateDirectory(Path.GetDirectoryName(exportPathServer)!);

                                var exportAuthResult = await AuthHelper.AuthenticateIsolatedAsync(platformSettings);
                                string exportToken = exportAuthResult.Token;
                                string exportConsumer = exportAuthResult.ConsumerName;

                                string exportTokenSuffix = exportToken?.Length >= 6 ? exportToken[^6..] : "??";
                                LogHelper.Info($"📁 Exporting '{pending.InstructionName}' from {LogRedaction.PlatformTag(pending.PlatformAlias, pending.PlatformFqdn)} using token ending: ...{exportTokenSuffix}");
                                // NOTE: Do not gate exports on InstructionStatistics/Combined. It can lag behind.

                                bool pagingFileCreated = false;
                                bool serverFileCreated = false;
                                string? serverDownloadUrl = null;
                                string? serverExportServerPath = null;
                                string? finalExportPath = null;

                                if (pending.ExportMode != ExportMode.ServerOnly)
                                {
                                    await ExportHelper.ExportInstructionResultsWithProgressAsync(
                                        pending.PlatformFqdn,
                                        exportToken,
                                        exportConsumer,
                                        Convert.ToInt32(pending.ResponseId),
                                        exportPathPaging,
                                        pending.ExportFormat ?? "CSV",
                                        _logger,
                                        pageSize: 2000,
                                        maxConcurrentRequests: 6
                                    );

                                    pagingFileCreated = File.Exists(exportPathPaging);
                                    if (pagingFileCreated)
                                        finalExportPath = exportPathPaging;
                                }

                                if (pending.ExportMode == ExportMode.ServerOnly || pending.ExportMode == ExportMode.PagingThenServer)
                                {
                                    var capturedUtc2 = pending.ResponseCapturedTimeUtc ?? pending.LastRunUtc ?? DateTime.UtcNow;
                                    var ttlMinutes2 = pending.ResponseTtlMinutes > 0 ? pending.ResponseTtlMinutes : pending.ExportTtlMinutes;
                                    var ttlExpiryUtc2 = capturedUtc2.AddMinutes(ttlMinutes2);
                                    var serverEarliestUtc = ttlExpiryUtc2.AddSeconds(5);

                                    if (DateTime.UtcNow < serverEarliestUtc)
                                    {
                                        var wait = serverEarliestUtc - DateTime.UtcNow;
                                        if (wait < TimeSpan.FromSeconds(5)) wait = TimeSpan.FromSeconds(5);

                                        if (TryScheduleExportRetry(pending, "waiting for TTL before server-side export", wait, TimeSpan.FromMinutes(30)))
                                            return;
                                    }
                                    else
                                    {
                                        bool initiate = !pending.ServerExportIssued;

                                        var serverInfo = await ExportHelper.TryServerSideExportAndDownloadWithInfoAsync(
                                            pending.PlatformFqdn,
                                            token,
                                            pending.ConsumerName ?? "Explorer",
                                            Convert.ToInt32(pending.ResponseId),
                                            exportPathServer,
                                            _logger,
                                            pollInterval: TimeSpan.FromSeconds(10),
                                            maxWait: TimeSpan.FromMinutes(15),
                                            initiateExport: initiate).ConfigureAwait(false);

                                        serverFileCreated = serverInfo?.Downloaded == true;
                                        if (serverInfo != null)
                                        {
                                            pending.ServerExportIssued = true;
                                            pending.ServerExportIssuedUtc ??= DateTime.UtcNow;
                                            pending.LastServerExportPath = serverInfo.LocalPath ?? exportPathServer;
                                            pending.LastServerDownloadUrl = serverInfo.DownloadUrl;
                                        }

                                        if (serverFileCreated)
                                            finalExportPath = exportPathServer;
                                    }
                                }

                                if (!(pagingFileCreated || serverFileCreated))
                                {
                                    if (TryScheduleExportRetry(pending, "catch-up export produced no file (results not ready yet)", null, TimeSpan.FromMinutes(30)))
                                        return;

                                    WriteLog($"⚠️ Export produced no file for '{pending.InstructionName}' (ResponseId {pending.ResponseId}) — treating as no data.");
                                }
                                else
                                {
                                    WriteLog($"✅ Export complete for '{pending.InstructionName}' (ResponseId {pending.ResponseId}) → {finalExportPath}");
                                }
                                await Dispatcher.UIThread.InvokeAsync(() =>
                                {
                                    pending.IsExporting = false;
                                    pending.CompletedUtc = DateTime.UtcNow;
                                    pending.RuntimeStatus = "Waiting";
                                });
                            }
                            catch (Exception ex)
                            {
                                WriteLog($"❌ Scheduled catch-up export failed for '{pending.InstructionName}': {ex.Message}");
                            }
                        });

                        pending.IsExporting = true;
                        pending.RuntimeStatus = "Exporting";
                        _exportTimers[pending.JobId] = true;
                    }
                }

            }
            finally
            {
                _isTickRunning = false;
            }
        }


        private string GetExportPathFromSettings(string platformKey, string instructionName, object? responseId, string format)
        {
            if (_settings?.ExportOptions == null)
                throw new InvalidOperationException("ExportOptions not configured in AppSettings.");

            // Try FQDN match, then alias fallback
            if (!_settings.ExportOptions.TryGetValue(platformKey, out var exportOption))
                throw new InvalidOperationException($"Export options not found for platform '{platformKey}'");

            string exportFolder = exportOption.ExportFolder ?? "C:\\Exports\\Fallback";
            string extension = format?.ToLower() ?? "csv";
            string fileName = $"{Sanitize(instructionName)}_{responseId}_{DateTime.Now:yyyyMMdd_HHmmss}.{extension}";

            return Path.Combine(exportFolder, fileName);
        }

        private static string Sanitize(string name)
        {
            foreach (var c in Path.GetInvalidFileNameChars())
                name = name.Replace(c, '_');
            return name;
        }

        private static string SanitizeFileName(string input)
        {
            foreach (char c in Path.GetInvalidFileNameChars())
                input = input.Replace(c, '_');
            return input.Trim();
        }


        private static string ResolveExportPath(string platformAlias, string jobName)
        {
            string baseFolder = "exports"; // or from config
            string safeJob = jobName.Replace(" ", "_").Replace(":", "-");
            string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
            return Path.Combine(baseFolder, platformAlias, $"{safeJob}_{timestamp}.csv");
        }



        public void Start(List<ScheduledJob> jobs)
        {
            LogHelper.Info($"🔄 Starting job scheduler with {jobs.Count} job(s)...");
            _jobs = jobs;

            // Call once immediately
            _ = OnTickAsync();

            if (!_pulse.IsEnabled)
                _pulse.Start();
        }

        public void Stop()
        {
            if (_pulse.IsEnabled)
                _pulse.Stop();
            LogHelper.Info("⏹️ Job scheduler stopped.");
        }

        public void SetUseUtcTimestamps(bool useUtc)
        {
            _useUtc = useUtc;
            LogHelper.UseUtc = useUtc;
        }



        // Used to make sure we only queue ONE delayed-export task per job
        private readonly Dictionary<string, bool> _exportTimers = new();
        private readonly List<(ScheduledJob job, DateTime delayUntil)> _pendingExports = new();



        private bool LoadUtc() { try { var j = File.ReadAllText("appsettings.json"); return JsonDocument.Parse(j).RootElement.GetProperty("UseUtcTimestamps").GetBoolean(); } catch { return false; } }

        private DateTime ConvertTime(DateTime dt) => _useUtc ? dt : dt.ToLocalTime();



        private readonly Dictionary<string, DateTime> _lastInstructionStartUtc = new();

        private readonly Dictionary<string, DateTime> _lastInstrSkipLogged = new();
        private readonly Dictionary<string, DateTime> _lastTtlWaitLog = new();


        private bool NearScheduledWindow(ScheduledJob job, DateTime now)
        {
            if (job.StartTime is null) return false;
            var target = now.Date + job.StartTime.Value;
            return Math.Abs((now - target).TotalSeconds) < Window.TotalSeconds;
        }

        private void LogSkip(ScheduledJob job, string message, DateTime now, bool onlyWhenNear)
        {
            // suppress unless we’re in the ±60-s fire window
            if (onlyWhenNear && !NearScheduledWindow(job, now)) return;

            if (_lastInstrSkipLogged.TryGetValue(job.InstructionName, out var lastSkip) &&
               lastSkip.Date == now.Date) return;                // once per day per instruction

            _lastInstrSkipLogged[job.InstructionName] = now;
            WriteLog(message);
        }
        // ─────────────────────── recurrence check ─────────────────────────
        private bool IsDue(ScheduledJob job, DateTime now, out string reason)
        {
            reason = "window-open";
            string rec = job.Recurrence?.Trim().ToLowerInvariant() ?? "once";

            int intervalMin = 0;
            if (rec == "hourly" || rec == "every hour" || rec == "every 60" || rec == "every 60 min" || rec == "every 60 minutes" || rec == "every60" || rec == "every60min")
            {
                intervalMin = 60;
                int targetMin = job.StartTime?.Minutes ?? 0;
                if (now.Minute == targetMin && now.Second < Window.TotalSeconds)
                {
                    if (job.LastRunUtc is DateTime last &&
                        (now - ConvertTime(last)).TotalMinutes < intervalMin - 1)
                    { reason = "already-ran"; return false; }
                    return true;
                }
            }
            else if (rec is "every15" or "every15min" or "every15minutes" or "every 15" or "every 15 min" or "every 15 minutes")
            {
                intervalMin = 15;
                int baseMin = (job.StartTime?.Minutes ?? 0) / 15 * 15;
                int diff = (now.Minute - baseMin + 60) % 15;
                if (diff == 0 && now.Second < Window.TotalSeconds)
                {
                    if (job.LastRunUtc is DateTime last &&
                        (now - ConvertTime(last)).TotalMinutes < intervalMin - 1)
                    { reason = "already-ran"; return false; }
                    return true;
                }
            }

            // ─── StartTime-based logic below ───────────────────────────────
            if (job.StartTime is null)
            { reason = "no-start-time"; return false; }

            var schedToday = now.Date + job.StartTime.Value;
            if (Math.Abs((now - schedToday).TotalSeconds) >= Window.TotalSeconds)
            { reason = "outside-schedule-window"; return false; }

            if (job.LastRunUtc is DateTime lastLocal &&
                now - ConvertTime(lastLocal) < Window)
            { reason = "already-ran"; return false; }

            // daily / weekly / monthly / once
            if (rec == "daily")
            {
                if (job.DaysOfWeek?.Any() == true &&
                    !job.DaysOfWeek.Contains(now.DayOfWeek))
                { reason = $"not scheduled for {now:dddd}"; return false; }
                return true;
            }
            if (rec == "weekly")
            {
                if (!(job.DaysOfWeek?.Contains(now.DayOfWeek) ?? false))
                { reason = $"not scheduled for {now:dddd}"; return false; }
                return true;
            }
            if (rec == "monthly")
            {
                if (now.Day != job.MonthlyDayFallback)
                { reason = $"not day {job.MonthlyDayFallback}"; return false; }
                return true;
            }
            if (rec is "once" or "one-time")
                return now >= ConvertTime(job.ScheduledDateTime);

            reason = $"unknown recurrence '{job.Recurrence}'";
            return false;
        }

        private readonly Dictionary<string, DateTime> _lastStartedUtc = new();


        public void LogInitialSchedule()
        {
            var now = Now();

            foreach (var job in _vm.ScheduledJobs ?? new())
            {
                if (!job.IsEnabled) continue;

                string recurrence = string.IsNullOrWhiteSpace(job.Recurrence) ? "(none)" : job.Recurrence;
                string timeStr = job.StartTime?.ToString() ?? "unset";
                string lastRun = job.LastRunUtc.HasValue ? ConvertTime(job.LastRunUtc.Value).ToString("g") : "never";

                WriteLog($"📌 {job.InstructionName} → Time: {timeStr}, Recurrence: {recurrence}, Last Run: {lastRun}");
            }
        }

        public void Dispose()
        {
            try
            {
                if (_pulse.IsEnabled)
                    _pulse.Stop();
            }
            catch { }
            LogHelper.Info("⏹️ Job scheduler stopped.");
        }
        private readonly object _historyLock = new();


        private void SaveHistory(JobExecutionHistory entry)
{
    // Disk persistence can run on any thread, but any UI-bound collection updates must run on the UI thread.
    try
    {
        lock (_historyLock)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(HistoryFilePath)!);

            // Prefer updating by ExecutionId, but fall back to (JobId + ResponseId) so
            // "WaitingExport" rows get updated even if an export occurs on a later tick/startup.
            JobExecutionHistory? existing = _history.FirstOrDefault(h => h.ExecutionId == entry.ExecutionId);

            if (existing == null &&
                !string.IsNullOrWhiteSpace(entry.JobId) &&
                !string.IsNullOrWhiteSpace(entry.ResponseId))
            {
                existing = _history.FirstOrDefault(h =>
                    string.Equals(h.JobId, entry.JobId, StringComparison.OrdinalIgnoreCase) &&
                    string.Equals(h.ResponseId, entry.ResponseId, StringComparison.OrdinalIgnoreCase) &&
                    (string.Equals(h.Status, "WaitingExport", StringComparison.OrdinalIgnoreCase) ||
                     (h.ExportPath != null && h.ExportPath.Contains("pending", StringComparison.OrdinalIgnoreCase))));
            }

            if (existing != null)
                _history.Remove(existing);

            _history.Add(entry);

            var cutoff = DateTime.UtcNow.AddDays(-KeepDays);
            _history = _history
                .Where(h => h.StartTime >= cutoff && !string.IsNullOrEmpty(h.JobId))
                .ToList();

            var json = JsonSerializer.Serialize(_history, new JsonSerializerOptions
            {
                WriteIndented = true,
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            });

            File.WriteAllText(HistoryFilePath, json);
        }

        // UI-bound updates must be marshaled.
        if (Dispatcher.UIThread.CheckAccess())
        {
            UpdateExecutionHistoryUi(entry);
        }
        else
        {
            Dispatcher.UIThread.Post(() => UpdateExecutionHistoryUi(entry));
        }
    }
    catch (Exception ex)
    {
        LogHelper.Error($"Failed to save history: {ex.Message}");
    }
}

private void UpdateExecutionHistoryUi(JobExecutionHistory entry)
{
    try
    {
        // Update the UI-bound history list without resetting the collection.
        if (_vm.ExecutionHistory != null)
        {
            int idx = _vm.ExecutionHistory.ToList().FindIndex(h => h.ExecutionId == entry.ExecutionId);

            if (idx < 0 && !string.IsNullOrWhiteSpace(entry.JobId) && !string.IsNullOrWhiteSpace(entry.ResponseId))
            {
                idx = _vm.ExecutionHistory.ToList().FindIndex(h =>
                    string.Equals(h.JobId, entry.JobId, StringComparison.OrdinalIgnoreCase) &&
                    string.Equals(h.ResponseId, entry.ResponseId, StringComparison.OrdinalIgnoreCase) &&
                    (string.Equals(h.Status, "WaitingExport", StringComparison.OrdinalIgnoreCase) ||
                     (h.ExportPath != null && h.ExportPath.Contains("pending", StringComparison.OrdinalIgnoreCase))));
            }

            if (idx >= 0)
                _vm.ExecutionHistory[idx] = entry;
            else
                _vm.ExecutionHistory.Insert(0, entry); // newest first
        }

        // Keep the Scheduled Jobs list in sync with the latest execution status so the UI icons update
        // immediately (Running/Exporting/Exported/Failed/etc.) without requiring a tab swap.
        try
        {
            var sj = _vm.ScheduledJobs?.FirstOrDefault(j =>
                !string.IsNullOrWhiteSpace(j.JobId) &&
                !string.IsNullOrWhiteSpace(entry.JobId) &&
                string.Equals(j.JobId, entry.JobId, StringComparison.OrdinalIgnoreCase));

            if (sj != null)
            {
                var status = entry.Status ?? string.Empty;
                if (string.Equals(status, "Running", StringComparison.OrdinalIgnoreCase))
                {
                    sj.IsRunning = true;
                    sj.IsExporting = false;
                    sj.RuntimeStatus = "Running";
                }
                else if (string.Equals(status, "Exporting", StringComparison.OrdinalIgnoreCase) ||
                         string.Equals(status, "PagingExported", StringComparison.OrdinalIgnoreCase) ||
                         string.Equals(status, "WaitingServerExport", StringComparison.OrdinalIgnoreCase) ||
                         string.Equals(status, "WaitingExport", StringComparison.OrdinalIgnoreCase) ||
                         string.Equals(status, "PendingExport", StringComparison.OrdinalIgnoreCase))
                {
                    sj.IsRunning = false;
                    sj.IsExporting = true;
                    sj.RuntimeStatus = string.IsNullOrWhiteSpace(status) ? "Exporting" : status;
                }
                else
                {
                    sj.IsRunning = false;
                    sj.IsExporting = false;
                    sj.RuntimeStatus = string.IsNullOrWhiteSpace(status) ? "Completed" : status;
                }

                // If the entry carries a response id, keep the job in sync for resume/export features.
                if (!string.IsNullOrWhiteSpace(entry.ResponseId))
                    sj.ResponseId = entry.ResponseId;

                // Keep the last-known export path in sync so links survive restart even if the job file
                // is the authoritative state used on startup.
                if (!string.IsNullOrWhiteSpace(entry.PagingExportPath))
                    sj.LastPagingExportPath = entry.PagingExportPath;
                if (!string.IsNullOrWhiteSpace(entry.ServerExportPath))
                    sj.LastServerExportPath = entry.ServerExportPath;
                if (!string.IsNullOrWhiteSpace(entry.ExportPath))
                    sj.ExportPath = entry.ExportPath;
            }
        }
        catch
        {
            // best effort – don't let UI status sync break history updates
        }

        _vm.UpdateJobDurationsFromHistory();
    }
    catch (Exception ex)
    {
        LogHelper.Error($"Failed to update history UI: {ex.Message}");
    }
}

        // track whether we've already warned about no history file about no history file
        private bool _hasNoHistoryWarned = false;
        private string token;

        private void LoadHistory()
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(HistoryFilePath)!);

                if (File.Exists(HistoryFilePath))
                {
                    var json = File.ReadAllText(HistoryFilePath);
                    var options = new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    };

                    _history = JsonSerializer.Deserialize<List<JobExecutionHistory>>(json, options)
                               ?? new List<JobExecutionHistory>();
                }
                else
                {
                    // only warn once on first missing‐file detection
                    if (!_hasNoHistoryWarned)
                    {
                        LogHelper.Warn("⚠️ No history file found. Starting fresh.");
                        _hasNoHistoryWarned = true;
                    }
                    _history = new List<JobExecutionHistory>();
                }

                ExecutionHistory = new List<JobExecutionHistory>(_history);

                // Keep the same ObservableCollection instance to avoid DataGrid sort/reset churn.
                if (_vm.ExecutionHistory != null)
                {
                    _vm.ExecutionHistory.Clear();
                    foreach (var h in _history.OrderByDescending(h => h.StartTime))
                        _vm.ExecutionHistory.Add(h);
                }
                UpdateOverloadedSlots();
            }
            catch (Exception ex)
            {
                LogHelper.Error($"❌ Failed to load history: {ex.Message}");
                _history = new List<JobExecutionHistory>(); // fallback
                ExecutionHistory = new List<JobExecutionHistory>();
                _vm.ExecutionHistory = new ObservableCollection<JobExecutionHistory>();
            }
        }


        public void SetUseUtc(bool useUtc)
        {
            _useUtc = useUtc;
        }



        private void UpdateOverloadedSlots()
        {
            var slotCounts = new Dictionary<DateTime, int>();
            foreach (var job in _history)
            {
                var start = job.StartTime;
                var end = job.EndTime;
                var current = start;
                while (current < end)
                {
                    var slot = new DateTime(current.Year, current.Month, current.Day, current.Hour, (current.Minute / 15) * 15, 0);
                    if (!slotCounts.ContainsKey(slot))
                        slotCounts[slot] = 0;
                    slotCounts[slot]++;
                    current = current.AddMinutes(15);
                }
            }
            var flagged = slotCounts.Where(kvp => kvp.Value > 5).Select(kvp => kvp.Key).ToList();
            if (_vm.OverloadedSlots != null)
                _vm.OverloadedSlots.Clear();
            else
                _vm.OverloadedSlots = new ObservableCollection<DateTime>();
            foreach (var dt in flagged)
                _vm.OverloadedSlots.Add(dt);
        }



        private int GetEstimatedExportDurationSeconds(string jobId)
        {
            var matchingHistory = _history
                .Where(h => h.JobId == jobId && h.DurationSeconds > 0)
                .Select(h => h.DurationSeconds)
                .ToList();

            if (matchingHistory.Count == 0)
                return 300; // default to 5 minutes

            return (int)Math.Ceiling(matchingHistory.Average());
        }

    }
}
