﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Avalonia.Threading;

namespace TV1_InstructionOffloader.Services
{
    public static class LogHelper
    {
        private static readonly StringBuilder LogBuffer = new StringBuilder();
        private static readonly List<string> LogLines = new List<string>();
        private static int MaxLogLines = 5000; // Default
        private static int MaxLogFileSizeMB = 10; // Default

        public static string CurrentLogLevel { get; set; } = "Info";
        public static string LogFilePath { get; set; } = "Offloader.log";

        public static void Initialize(string logLevel, int maxLines, int maxFileSizeMb)
        {
            CurrentLogLevel = logLevel ?? "Info";
            MaxLogLines = maxLines > 0 ? maxLines : 5000;
            MaxLogFileSizeMB = maxFileSizeMb > 0 ? maxFileSizeMb : 10;
        }

        public static void Info(string message)
        {
            WriteLog("INFO", message);
        }

        public static void Warn(string message)
        {
            WriteLog("WARN", message);
        }

        public static void Error(string message)
        {
            WriteLog("ERROR", message);
        }

        public static void Debug(string message)
        {
            if (CurrentLogLevel.Equals("Debug", StringComparison.OrdinalIgnoreCase))
                WriteLog("DEBUG", message);
        }
        public static bool UseUtc = false; // load from config

        public static void LogToFile(string filePath, string message)
        {
            var now = UseUtc ? DateTime.UtcNow : DateTime.Now;
            var formatted = now.ToString("yyyy-MM-dd hh:mm:ss tt");
            File.AppendAllText(filePath, $"[{formatted}] {message}\n");
        }

        private static void WriteLog(string level, string message)
        {
            DateTime now = UseUtc ? DateTime.UtcNow : DateTime.Now;
            string time = now.ToString("yyyy-MM-dd hh:mm:ss tt");
            string fullMessage = $"[{time}] [{level}] {message}";

            Dispatcher.UIThread.Post(() =>
            {
                LogLines.Add(fullMessage);
                if (LogLines.Count > MaxLogLines)
                {
                    LogLines.RemoveRange(0, LogLines.Count - MaxLogLines);
                }
            });

            AppendToFile(fullMessage);
        }


        private static void AppendToFile(string message)
        {
            try
            {
                FileInfo fi = new FileInfo(LogFilePath);
                if (fi.Exists && fi.Length > MaxLogFileSizeMB * 1024 * 1024)
                {
                    File.Move(LogFilePath, LogFilePath + ".old", true);
                }

                using (var sw = File.AppendText(LogFilePath))
                {
                    sw.WriteLine(message);
                }
            }
            catch
            {
                // Ignore
            }
        }

        public static string GetFullLog()
        {
            return string.Join(Environment.NewLine, LogLines);
        }

        public static void Clear()
        {
            LogLines.Clear();
        }
    }
}
