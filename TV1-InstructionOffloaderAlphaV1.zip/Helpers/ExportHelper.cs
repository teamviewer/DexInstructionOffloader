﻿using Avalonia.Controls;
using TV1_InstructionOffloader.Models;
using MyLogHelper = TV1_InstructionOffloader.Services.LogHelper;
using Avalonia.Threading;
using ClosedXML.Excel;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using System.Diagnostics;
using Microsoft.IdentityModel.Logging;
using TV1_InstructionOffloader.Services;

namespace TV1_InstructionOffloader.Helpers
{
    public static class ExportHelper
    {

        public static class Logger
        {
            public static void LogToFile(string filePath, string message)
            {
                try
                {
                    File.AppendAllText(filePath, $"[{DateTime.Now:HH:mm:ss}] {message}\n");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"❌ Failed to write log: {ex.Message}");
                }
            }
        }

        public static async Task ExportDictionaryListAsync(
         List<Dictionary<string, string>> rows,
         string filePath,
         string format,
         List<SchemaColumn> schema = null,
         Action<string> logFunc = null,
         string? logFilePath = null)  // New optional param
        {
            void Log(string message)
            {
                if (!string.IsNullOrWhiteSpace(logFilePath))
                {
                    Logger.LogToFile(logFilePath, message);
                }
                logFunc?.Invoke(message);
            }

            try
            {
                if (rows == null || rows.Count == 0)
                {
                    Log("⚠️ No data to export.");
                    return;
                }

                var headers = schema?.Select(col => col.Name).Distinct().ToList()
                    ?? rows.SelectMany(d => d.Keys).Distinct().ToList();

                var normalizedFormat = format?.ToUpperInvariant();

                if (normalizedFormat == "CSV" || normalizedFormat == "TSV")
                {
                    var delimiter = normalizedFormat == "TSV" ? "\t" : ",";

                    var sb = new StringBuilder();
                    sb.AppendLine(string.Join(delimiter, headers));

                    foreach (var row in rows)
                    {
                        var safeRow = row ?? new Dictionary<string, string>();
                        var line = string.Join(delimiter, headers.Select(h =>
                        {
                            var val = safeRow.TryGetValue(h, out var v) ? v : "";
                            val ??= "";
                            return $"\"{val.Replace("\"", "\"\"")}\"";
                        }));
                        sb.AppendLine(line);
                    }

                    await File.WriteAllTextAsync(filePath, sb.ToString());
                    Log($"✅ {normalizedFormat} export complete.");
                }
                else if (normalizedFormat == "XLSX")
                {
                    var wb = new XLWorkbook();
                    var ws = wb.Worksheets.Add("Results");

                    for (int i = 0; i < headers.Count; i++)
                        ws.Cell(1, i + 1).Value = headers[i];

                    int currentRow = 2;
                    foreach (var row in rows)
                    {
                        for (int i = 0; i < headers.Count; i++)
                        {
                            var header = headers[i];
                            ws.Cell(currentRow, i + 1).Value = row.TryGetValue(header, out var val) ? val : "";
                        }
                        currentRow++;
                    }

                    wb.SaveAs(filePath);
                    Log("✅ XLSX export complete.");
                }
                else
                {
                    Log("❌ Unsupported format.");
                }

                Log($"✅ Exported to: {filePath}");
            }
            catch (Exception ex)
            {
                Log($"❌ Export failed: {ex.Message}");
            }
        }


        public static async Task ExportExperienceResultsAsync(
            string platformUrl,
            string token,
            List<string> selectedMetrics,
            Dictionary<string, List<string>> selectedFilters,
            string filePath,
            string format,
            TextBox logBox = null,
            IProgress<(int RowCount, int TotalCount, double ElapsedSeconds)> progress = null)

        {
            await ExportLargeDatasetAsync(
                platformUrl,
                token,
                selectedMetrics,
                selectedFilters,
                filePath,
                format,
                logBox,
                progress);
        }



        public static async Task ExportLargeDatasetAsync(
            string platformUrl,
            string token,
            List<string> selectedMetrics,
            Dictionary<string, List<string>> selectedFilters,
            string filePath,
            string format,
            TextBox logBox = null,
            IProgress<(int RowCount, int TotalCount, double ElapsedSeconds)> progress = null)

        {
            try
            {
                int pageSize = 2000;
                int start = 1;
                int rowCount = 0;
                int sheetRowLimit = 1000000;
                int currentSheetIndex = 1;

                var headers = new List<string> { "Fqdn", "TachyonGuid", "Timestamp", "OperatingSystemType" };
                headers.AddRange(selectedMetrics);

                using var client = new HttpClient { Timeout = TimeSpan.FromMinutes(10) };
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Add("X-Tachyon-Authenticate", token);
                client.DefaultRequestHeaders.Add("X-Tachyon-Consumer", "Explorer");

                var stopwatch = Stopwatch.StartNew(); // ⏱️ Start timing

                void Log(string message)
                {
                    if (logBox != null)
                        logBox.Text += message + "\n";
                }

                if (format == "xlsx")
                {
                    var wb = new XLWorkbook();
                    var ws = wb.Worksheets.Add($"Sheet{currentSheetIndex}");

                    for (int i = 0; i < headers.Count; i++)
                        ws.Cell(1, i + 1).Value = headers[i];

                    int currentRow = 2;
                    int totalCount = 0;
                    object lockObj = new object();
                    int concurrency = 6;

                    await Task.Run(async () =>
                    {
                        while (true)
                        {
                            var tasks = new List<Task<(List<Dictionary<string, string>> Rows, int Total)>>();

                            for (int i = 0; i < concurrency; i++)
                            {
                                int pageStart = start + (i * pageSize);

                                tasks.Add(Task.Run(async () =>
                                {
                                    var payload = BuildSearchPayload(selectedFilters, selectedMetrics, pageStart, pageSize);
                                    var json = JsonConvert.SerializeObject(payload);

                                    /*await Dispatcher.UIThread.InvokeAsync(() =>
                                        Log($"📤 Start={pageStart}"));  */

                                    HttpResponseMessage response = null;
                                    int maxRetries = 3;
                                    int delaySeconds = 2;

                                    for (int attempt = 1; attempt <= maxRetries; attempt++)
                                    {
                                        try
                                        {
                                            response = await client.PostAsync(
                                                $"https://{platformUrl}/Experience/DeviceMetrics/Search",
                                                new StringContent(json, Encoding.UTF8, "application/json"));

                                            if (response.IsSuccessStatusCode)
                                                break;

                                            if ((int)response.StatusCode == 429 || (int)response.StatusCode >= 500)
                                            {
                                                await Dispatcher.UIThread.InvokeAsync(() =>
                                                    logBox.Text += $"⚠️ Attempt {attempt}: Server={response.StatusCode}. Retrying...\n");
                                            }
                                            else break;
                                        }
                                        catch (TaskCanceledException ex) when (!ex.CancellationToken.IsCancellationRequested)
                                        {
                                            await Dispatcher.UIThread.InvokeAsync(() =>
                                                logBox.Text += $"⏱️ Timeout attempt {attempt}, retrying...\n");
                                        }
                                        catch (Exception ex)
                                        {
                                            await Dispatcher.UIThread.InvokeAsync(() =>
                                                logBox.Text += $"❌ Attempt {attempt}: {ex.Message}\n");
                                            break;
                                        }

                                        await Task.Delay(TimeSpan.FromSeconds(delaySeconds * attempt));
                                    }

                                    if (!response.IsSuccessStatusCode)
                                    {
                                        await Dispatcher.UIThread.InvokeAsync(() =>
                                            Log($"❌ API error at start={pageStart}: {response.StatusCode}"));
                                        return (new List<Dictionary<string, string>>(), 0);
                                    }

                                    var content = await response.Content.ReadAsStringAsync();
                                    return ParseResultsJson(content);
                                }));
                            }

                            var results = await Task.WhenAll(tasks);
                            var totalThisBatch = results.Sum(r => r.Rows.Count);
                            if (totalThisBatch == 0) break;

                            foreach (var (rows, total) in results)
                            {
                                if (totalCount == 0 && total > 0)
                                    totalCount = total;

                                foreach (var row in rows)
                                {
                                    lock (lockObj)
                                    {
                                        for (int c = 0; c < headers.Count; c++)
                                            ws.Cell(currentRow, c + 1).Value = row.TryGetValue(headers[c], out var val) ? val : "";
                                        currentRow++;
                                        rowCount++;

                                        if (currentRow > sheetRowLimit)
                                        {
                                            currentSheetIndex++;
                                            ws = wb.Worksheets.Add($"Sheet{currentSheetIndex}");
                                            for (int i = 0; i < headers.Count; i++)
                                                ws.Cell(1, i + 1).Value = headers[i];
                                            currentRow = 2;
                                        }
                                    }
                                }
                            }

                            await Dispatcher.UIThread.InvokeAsync(() =>
                            {
                                var elapsedSeconds = stopwatch.Elapsed.TotalSeconds;
                                Log($"📤 Exported {rowCount:N0} of {totalCount:N0} rows... ⏱️ {stopwatch.Elapsed:hh\\:mm\\:ss}");
                                progress?.Report((rowCount, totalCount, elapsedSeconds));
                            });


                            start += concurrency * pageSize;
                        }

                        wb.SaveAs(filePath);
                    });
                    var elapsed = stopwatch.Elapsed.ToString(@"hh\:mm\:ss");
                    await Dispatcher.UIThread.InvokeAsync(() =>
                    Log($"✅ Export complete. Total rows: {rowCount:N0} - ⏱️ {elapsed}"));
                }
                else
                {
                    Log("❌ Unsupported export format.");
                }
            }
            catch (Exception ex)
            {
                logBox.Text += $"❌ Export failed: {ex.Message}\n";
            }
        }


        private static object BuildSearchPayload(Dictionary<string, List<string>> selectedFilters, List<string> metrics, int start, int pageSize)
        {
            var filterOperands = new List<object>();

            foreach (var kvp in selectedFilters)
            {
                var key = kvp.Key;
                var values = kvp.Value?.Where(v => !string.IsNullOrWhiteSpace(v)).ToList();
                if (values == null || values.Count == 0) continue;

                if (values.Count == 1)
                {
                    filterOperands.Add(new
                    {
                        Attribute = key,
                        Operator = "==",
                        Value = values.First()
                    });
                }
                else
                {
                    filterOperands.Add(new
                    {
                        Operator = "OR",
                        Operands = values.Select(val => new
                        {
                            Attribute = key,
                            Operator = "==",
                            Value = val
                        }).ToList()
                    });
                }
            }

            // Always include IsLatest = true
            filterOperands.Add(new
            {
                Attribute = "IsLatest",
                Operator = "==",
                Value = "true"
            });

            return new
            {
                Filter = new
                {
                    Operator = "AND",
                    Operands = filterOperands
                },
                GroupBy = new[] { "Fqdn", "TachyonGuid", "Timestamp", "OperatingSystemType" },
                Measures = metrics,
                RollUp = false,
                Start = start,
                PageSize = pageSize
            };
        }
        private static (List<Dictionary<string, string>> rows, int totalCount) ParseResultsJson(string json)
        {
            var root = JObject.Parse(json);
            int total = root["TotalCount"]?.Value<int>() ?? 0;
            var rows = new List<Dictionary<string, string>>();

            foreach (var item in root["Items"] ?? Enumerable.Empty<JToken>())
            {
                var row = item.Children<JProperty>().ToDictionary(p => p.Name, p => p.Value.ToString());
                rows.Add(row);
            }

            return (rows, total);
        }

        public class ExperienceFilter
        {
            public string Attribute { get; set; }
            public string Operator { get; set; }
            public string Value { get; set; }
        }
        public static class ExportLogger
        {
            private static string logFilePath = "export_log.txt";

            public static void Log(string message)
            {
                var entry = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {message}";
                Console.WriteLine(entry); // if CLI
                File.AppendAllText(logFilePath, entry + Environment.NewLine);
            }
        }

        public static async Task ExportInstructionResultsWithProgressAsync(
         string platformUrl,
         string token,
         string consumerName,
         int responseId,
         string filePath,
         string format,
         TV1_InstructionOffloader.Services.ILogger logger,
         int pageSize = 2000,
         int maxConcurrentRequests = 6)
        {
            using var client = new HttpClient();
            client.DefaultRequestHeaders.Add("X-Tachyon-Authenticate", token);
            client.DefaultRequestHeaders.Add("X-Tachyon-Consumer", consumerName);
            MyLogHelper.Info($"STARTING EXPORT FOR {responseId} from {platformUrl}");
            var statsUrl = $"https://{platformUrl}/Consumer/InstructionStatistics/Combined/{responseId}";
            MyLogHelper.Info($"📊 Retrieving statistics from: {statsUrl}");
            var statsResponse = await client.GetAsync(statsUrl);

            int totalRowsExpected = 0;
            int receivedCount = 0;

            if (!statsResponse.IsSuccessStatusCode)
            {
                // Statistics can lag behind or behave differently per platform/consumer.
                // Do not fail exports purely because stats are unavailable.
                MyLogHelper.Warn($"⚠️ Failed to get instruction statistics: {statsResponse.StatusCode} — continuing export without stats.");
            }
            else
            {
                var statsContent = await statsResponse.Content.ReadAsStringAsync();
                var statsJson = JObject.Parse(statsContent);
                totalRowsExpected = statsJson["Summary"]?["TotalRowInserts"]?.Value<int>() ?? 0;
                receivedCount = statsJson["Summary"]?["ReceivedCount"]?.Value<int>() ?? 0;

                if (receivedCount == 0)
                {
                    // GUI can still show results even when ReceivedCount is 0 (eventual consistency / combined stats).
                    // We'll attempt export and only treat as no-data if the Responses endpoint yields 0 rows.
                    logger?.LogWarning($"⚠️ Statistics report 0 received rows for ResponseId {responseId} — attempting export anyway.");
                }

	                if (totalRowsExpected > 0)
	                    logger?.LogInformation($"ℹ️ Total rows expected (stats): {totalRowsExpected:N0}");
            }

            if (totalRowsExpected == 0)
            {
                logger?.LogWarning("⚠️ Row estimate unavailable; proceeding without progress tracking.");
                totalRowsExpected = int.MaxValue; // avoid divide by zero
            }

            var allResults = new List<Dictionary<string, string>>();
            int totalFetched = 0;
            int lastLoggedCount = 0;
            int progressLogInterval = 12000;
            bool morePages = true;

            string EncodeToken(string raw) => Convert.ToBase64String(Encoding.UTF8.GetBytes(raw));

            List<string> GenerateTokens(int batchStartOffset, int pageSize, int batchCount)
            {
                var tokens = new List<string>();
                for (int i = 0; i < batchCount; i++)
                {
                    int offset = batchStartOffset + i * pageSize;
                    string tokenRaw = offset == 0 ? "0;0" : $"1;{offset + 1}";
                    string token = offset == 0 ? tokenRaw : EncodeToken(tokenRaw);
                    tokens.Add(token);
                }
                return tokens;
            }

            int currentOffset = 0;

            var url = $"https://{platformUrl}/Consumer/Responses/{responseId}";

            while (morePages)
            {
                var batchTokens = GenerateTokens(currentOffset, pageSize, maxConcurrentRequests);

                var tasks = batchTokens.Select(token => FetchPageAsync(client, url, token, pageSize, logger)).ToList();

                var results = await Task.WhenAll(tasks);

                int batchTotalFetched = 0;
                foreach (var result in results)
                {
                    var rows = result.rows;
                    var nextRange = result.nextRange;

                    allResults.AddRange(rows);
                    batchTotalFetched += rows.Count;
                }

                if (batchTotalFetched == 0)
                {
                    morePages = false;
                    break;
                }

                totalFetched += batchTotalFetched;

                if (totalFetched - lastLoggedCount >= progressLogInterval || totalFetched >= totalRowsExpected)
                {
                    lastLoggedCount = totalFetched;
                    double progressPercent = Math.Min(100.0, (totalFetched * 100.0) / totalRowsExpected);
                    if (logger != null)
                    {
                        MyLogHelper.Info($"📥 Progress: {totalFetched:N0} / {totalRowsExpected:N0} rows ({progressPercent:F2}%)");
                    }

                }

                currentOffset += maxConcurrentRequests * pageSize;
            }

            if (allResults.Count == 0)
            {

                MyLogHelper.Warn("⚠️ No data returned for export.");
                return;
            }

	            logger?.LogInformation($"💾 Exporting {allResults.Count:N0} rows to {filePath}");

	            await ExportDictionaryListAsync(allResults, filePath, format, null, msg => logger?.LogInformation(msg));

	            logger?.LogInformation("✅ Export complete.");
        }

        public static async Task<bool> TryServerSideExportAndDownloadAsync(
            string platformUrl,
            string token,
            string consumerName,
            int instructionId,
            string desiredFilePath,
            TV1_InstructionOffloader.Services.ILogger logger,
            TimeSpan? pollInterval = null,
            TimeSpan? maxWait = null,
            bool initiateExport = true)
        {
            var startUtc = DateTime.UtcNow;
            pollInterval ??= TimeSpan.FromSeconds(5);
            maxWait ??= TimeSpan.FromMinutes(5);

            using var client = new HttpClient { Timeout = TimeSpan.FromMinutes(5) };
            client.DefaultRequestHeaders.Clear();
            client.DefaultRequestHeaders.Add("X-Tachyon-Authenticate", token);
            client.DefaultRequestHeaders.Add("X-Tachyon-Consumer", consumerName);

            var baseUrl = $"https://{platformUrl}";
            var startUrl = $"{baseUrl}/Consumer/DataExport/ExportResponses";

            // If initiateExport is false, we assume the instruction run already requested server-side export (Export:true)
            // and we only poll/download the prepared artifact.


            try
            {
	                logger?.LogInformation($"🧊 Server-side export mode: {(initiateExport ? "initiate+poll" : "poll-only")} for Instruction/ResponseId {instructionId}...");

                if (initiateExport)
                {
                    var startPayload = new { InstructionId = instructionId };
                    var startJson = JsonConvert.SerializeObject(startPayload);
                    using var startResp = await client.PostAsync(startUrl, new StringContent(startJson, Encoding.UTF8, "application/json")).ConfigureAwait(false);
                    var startBody = await startResp.Content.ReadAsStringAsync().ConfigureAwait(false);

                    if (!startResp.IsSuccessStatusCode)
                    {
                        logger?.LogWarning($"❌ Server-side export start failed: {(int)startResp.StatusCode} {startResp.ReasonPhrase}. Body: {TrimForLog(startBody)}");
                        return false;
                    }

                    // Some platforms return {"Value":"..."}; keep for logging but we don't rely on it.
	                    logger?.LogInformation($"🧊 Server-side export started. Start response: {TrimForLog(startBody)}");
                }


                var exportedItem = await PollForExportedItemAsync(client, baseUrl, instructionId, startUtc, pollInterval.Value, maxWait.Value, logger).ConfigureAwait(false);
                if (exportedItem == null)
                {
                    logger?.LogWarning($"⚠️ Server-side export did not appear within {maxWait.Value.TotalSeconds:F0}s for {instructionId}.");
                    return false;
                }

                var tokenValue = exportedItem.Value<string>("Token") ?? string.Empty;
                var pathValue = exportedItem.Value<string>("Path") ?? string.Empty;

                if (string.IsNullOrWhiteSpace(tokenValue))
                {
                    logger?.LogWarning("⚠️ Server-side export returned an item with no Token.");
                    return false;
                }

                var finalPath = BuildServerSideFinalPath(desiredFilePath);

                Directory.CreateDirectory(Path.GetDirectoryName(finalPath)!);

                var downloadUrl = $"{baseUrl}/consumer/DataExport/Download?token={Uri.EscapeDataString(tokenValue)}";
	                logger?.LogInformation($"⬇️ Downloading server-side export: {downloadUrl}");

                using var dlResp = await client.GetAsync(downloadUrl, HttpCompletionOption.ResponseHeadersRead).ConfigureAwait(false);
                if (!dlResp.IsSuccessStatusCode)
                {
                    var dlBody = await dlResp.Content.ReadAsStringAsync().ConfigureAwait(false);
                    logger?.LogWarning($"❌ Server-side download failed: {(int)dlResp.StatusCode} {dlResp.ReasonPhrase}. Body: {TrimForLog(dlBody)}");
                    return false;
                }

                await using (var fs = new FileStream(finalPath, FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    await dlResp.Content.CopyToAsync(fs).ConfigureAwait(false);
                }

	                logger?.LogInformation($"✅ Server-side export downloaded: {finalPath}");
                return File.Exists(finalPath);
            }
            catch (Exception ex)
            {
                logger?.LogWarning($"❌ Server-side export failed for {instructionId}: {ex.Message}");
                return false;
            }
        }


private static string RedactToken(string token)
{
    if (string.IsNullOrWhiteSpace(token))
        return string.Empty;
    if (token.Length <= 8)
        return new string('*', token.Length);
    return token.Substring(0, 4) + new string('*', token.Length - 8) + token.Substring(token.Length - 4);
}



public sealed class ServerSideExportInfo
{
    public bool Downloaded { get; set; }
    public string? DownloadUrl { get; set; }
    public string? LocalPath { get; set; }
    public string? ServerPath { get; set; }
    public string? ExportToken { get; set; }
    public DateTime? CreatedTimestampUtc { get; set; }
}

public static async Task<ServerSideExportInfo?> TryServerSideExportAndDownloadWithInfoAsync(
    string platformUrl,
    string token,
    string consumer,
    int instructionId,
    string desiredFilePath,
    TV1_InstructionOffloader.Services.ILogger logger,
    TimeSpan? pollInterval = null,
    TimeSpan? maxWait = null,
    bool initiateExport = false)
{
    pollInterval ??= TimeSpan.FromSeconds(10);
    maxWait ??= TimeSpan.FromMinutes(15);

    var baseUrl = $"https://{platformUrl.Trim().TrimEnd('/')}";
    var exportStartUrl = $"{baseUrl}/Consumer/DataExport/ExportResponses";

    using var client = new HttpClient();
    client.DefaultRequestHeaders.Add("X-Tachyon-Authenticate", token);
    client.DefaultRequestHeaders.Add("X-Tachyon-Consumer", consumer);

    if (initiateExport)
    {
        var payload = new JObject { ["InstructionId"] = instructionId };
        var json = payload.ToString(Newtonsoft.Json.Formatting.None);
        using var content = new StringContent(json, Encoding.UTF8, "application/json");

        logger?.LogInformation($".... Initiating server-side export: POST {exportStartUrl} body={{InstructionId:{instructionId}}}");
        using var startResp = await client.PostAsync(exportStartUrl, content).ConfigureAwait(false);
        var startBody = await startResp.Content.ReadAsStringAsync().ConfigureAwait(false);
        if (!startResp.IsSuccessStatusCode)
            logger?.LogWarning($"⚠️ Server-side export start failed: {(int)startResp.StatusCode} {startResp.ReasonPhrase}. Body: {TrimForLog(startBody)}");
    }

    // Platform behavior observed: exported token often appears only after response TTL expiry.
    // Give a small not-before window to avoid older artifacts.
    var notBeforeUtc = DateTime.UtcNow.AddMinutes(-10);

    var exported = await PollForExportedItemAsync(
        client,
        baseUrl,
        instructionId,
        notBeforeUtc,
        pollInterval.Value,
        maxWait.Value,
        logger).ConfigureAwait(false);

    if (exported == null)
        return null;

    var exportToken = exported.Value<string>("Token");
    var serverPath = exported.Value<string>("Path");
    var createdUtc = exported.Value<DateTime?>("CreatedTimestampUtc");

    if (string.IsNullOrWhiteSpace(exportToken))
        return new ServerSideExportInfo { Downloaded = false, ServerPath = serverPath, ExportToken = null, CreatedTimestampUtc = createdUtc };

    var downloadUrl = $"{baseUrl}/Consumer/DataExport/Download?token={exportToken}";
            var finalPath = BuildServerSideFinalPath(desiredFilePath);


            logger?.LogInformation($".... Server-side export ready for {instructionId}: {serverPath} | {createdUtc:O} | token=(redacted)");
    logger?.LogInformation($".... Download URL: {downloadUrl.Replace(exportToken, RedactToken(exportToken))}");

    try
    {
        Directory.CreateDirectory(Path.GetDirectoryName(finalPath) ?? string.Empty);
        using var resp = await client.GetAsync(downloadUrl).ConfigureAwait(false);
        resp.EnsureSuccessStatusCode();

        await using var fs = File.Create(finalPath);
        await resp.Content.CopyToAsync(fs).ConfigureAwait(false);

        var ok = File.Exists(finalPath);
        return new ServerSideExportInfo
        {
            Downloaded = ok,
            DownloadUrl = downloadUrl,
            LocalPath = ok ? finalPath : null,
            ServerPath = serverPath,
            ExportToken = exportToken,
            CreatedTimestampUtc = createdUtc
        };
    }
    catch (Exception ex)
    {
        logger?.LogWarning($"⚠️ Server-side download failed for {instructionId}: {ex.Message}");
        return new ServerSideExportInfo
        {
            Downloaded = false,
            DownloadUrl = downloadUrl,
            LocalPath = null,
            ServerPath = serverPath,
            ExportToken = exportToken,
            CreatedTimestampUtc = createdUtc
        };
    }
}

        private static async Task<JObject?> PollForExportedItemAsync(
            HttpClient client,
            string baseUrl,
            int instructionId,
            DateTime notBeforeUtc,
            TimeSpan pollInterval,
            TimeSpan maxWait,
            TV1_InstructionOffloader.Services.ILogger logger)
        {
            var listUrl = $"{baseUrl}/Consumer/DataExport/Exported/Instruction/{instructionId}";
            var deadline = DateTime.UtcNow.Add(maxWait);

            while (DateTime.UtcNow < deadline)
            {
                using var resp = await client.GetAsync(listUrl).ConfigureAwait(false);
                var body = await resp.Content.ReadAsStringAsync().ConfigureAwait(false);

                if (!resp.IsSuccessStatusCode)
                {
                    logger?.LogWarning($"⚠️ Poll exported list failed: {(int)resp.StatusCode} {resp.ReasonPhrase}. Body: {TrimForLog(body)}");
                    await Task.Delay(pollInterval).ConfigureAwait(false);
                    continue;
                }

                try
                {
                    var arr = JArray.Parse(body);
                    JObject? newest = null;
                    DateTime newestUtc = DateTime.MinValue;

                    foreach (var item in arr.OfType<JObject>())
                    {
                        var created = item.Value<DateTime?>("CreatedTimestampUtc") ?? DateTime.MinValue;
                        if (created < notBeforeUtc)
                            continue;

                        if (created > newestUtc)
                        {
                            newestUtc = created;
                            newest = item;
                        }
                    }

                    if (newest != null)
                        return newest;
                }
                catch
                {
                    // ignore parse errors and continue polling
                }

                await Task.Delay(pollInterval).ConfigureAwait(false);
            }

            return null;
        }

        private static string BuildServerSideFinalPath(string desiredFilePath)
        {
            try
            {
                // Keep the folder structure from desiredFilePath (alias\instruction\date\...)
                var dir = Path.GetDirectoryName(desiredFilePath) ?? string.Empty;

                // Use the desired base name but normalize markers:
                // If paging filename already contains _P_, swap to _S_.
                // If neither marker exists, append _S_.
                var baseName = Path.GetFileNameWithoutExtension(desiredFilePath);

                if (baseName.Contains("_P_", StringComparison.OrdinalIgnoreCase))
                    baseName = baseName.Replace("_P_", "_S_", StringComparison.OrdinalIgnoreCase);
                else if (!baseName.Contains("_S_", StringComparison.OrdinalIgnoreCase))
                    baseName = baseName + "_S";

                // Server-side exports are TSV
                const string ext = ".tsv";

                return Path.Combine(dir, baseName + ext);
            }
            catch
            {
                return desiredFilePath;
            }
        }


        private static string TrimForLog(string? s)
        {
            if (string.IsNullOrWhiteSpace(s))
                return string.Empty;
            s = s.Trim();
            return s.Length <= 600 ? s : s.Substring(0, 600) + "…";
        }

        public static async Task<int> GetEstimatedRowCountFromStatistics(
            string platformUrl,
            int responseId,
            string token)
        {
            using var client = new HttpClient();
            client.DefaultRequestHeaders.Add("X-Tachyon-Authenticate", token);
            client.DefaultRequestHeaders.Add("X-Tachyon-Consumer", "Explorer");

            var statsUrl = $"https://{platformUrl}/Consumer/InstructionStatistics/Combined/{responseId}";
            var statsResponse = await client.GetAsync(statsUrl);

            if (!statsResponse.IsSuccessStatusCode)
                return 0;

            var statsContent = await statsResponse.Content.ReadAsStringAsync();
            var statsJson = JObject.Parse(statsContent);
            return statsJson["Summary"]?["ReceivedCount"]?.Value<int>() ?? 0;
        }


        private static async Task<(List<Dictionary<string, string>> rows, string? nextRange)> FetchPageAsync(
            HttpClient client,
            string url,
            string startToken,
            int pageSize,
            TV1_InstructionOffloader.Services.ILogger logger)
        {
            var payload = new
            {
                Filter = (object?)null,
                Start = startToken,
                PageSize = pageSize
            };

            var jsonPayload = JsonConvert.SerializeObject(payload);
            var content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");

            // logger.LogInformation($"🚀 Starting fetch for token '{startToken}'");

            var response = await client.PostAsync(url, content);
            if (!response.IsSuccessStatusCode)
            {
                logger.LogWarning($"❌ Failed to fetch page for token '{startToken}': {response.StatusCode}");
                return (new List<Dictionary<string, string>>(), null);
            }

            var jsonResponse = await response.Content.ReadAsStringAsync();
            var parsed = JObject.Parse(jsonResponse);

            var responsesArray = parsed["Responses"] as JArray;
            var nextRange = parsed["Range"]?.ToString();

            var rows = new List<Dictionary<string, string>>();
            if (responsesArray != null)
            {
                foreach (var obj in responsesArray)
                {
                    var fqdn = obj["Fqdn"]?.ToString() ?? obj["Device"]?["Fqdn"]?.ToString() ?? "Unknown";
                    var values = obj["Values"]?.ToObject<Dictionary<string, string>>() ?? new();
                    values["Fqdn"] = fqdn;
                    rows.Add(values);
                }
            }

            //logger.LogInformation($"✅ Fetched {rows.Count} rows, next range token: {nextRange ?? "none"} at {DateTime.Now:HH:mm:ss.fff}");

            return (rows, nextRange);
        }





        public static async Task ExportToCsvAsync(
       List<Dictionary<string, string>> rows,
       string path,
       TextBox? logBox = null)
        {
            var allHeaders = rows.SelectMany(d => d.Keys).Distinct().ToList();
            var sb = new StringBuilder();
            sb.AppendLine(string.Join(",", allHeaders));

            foreach (var row in rows)
            {
                var line = string.Join(",", allHeaders.Select(h =>
                {
                    var val = row.TryGetValue(h, out var v) ? v : "";
                    return $"\"{val.Replace("\"", "\"\"")}\"";
                }));
                sb.AppendLine(line);
            }

            await File.WriteAllTextAsync(path, sb.ToString());
            if (logBox != null)
                logBox.Text += "✅ Export complete.\n";
        }


        public static string GetAutoExportPath(int instructionId, string format)
        {
            var folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "InstructionExports");
            Directory.CreateDirectory(folder);
            return Path.Combine(folder, $"Instruction_{instructionId}_{DateTime.Now:yyyyMMdd_HHmmss}.{format}");
        }

    }


}
