﻿// TimeSpanExtensions.cs
using System;

namespace TV1_InstructionOffloader.Helpers   // <- use (or change to) any namespace you like
{
    /// <summary>
    /// Adds a <c>Truncate</c> extension so you can do:
    /// <code>var rounded = mySpan.Truncate(TimeSpan.FromMinutes(1));</code>
    /// </summary>
    public static class TimeSpanExtensions          // MUST be static and NOT generic
    {
        /// <summary>
        /// Rounds a TimeSpan *down* to the nearest <paramref name="interval"/>.
        /// </summary>
        public static TimeSpan Truncate(this TimeSpan span, TimeSpan interval)
        {
            if (interval == TimeSpan.Zero)
                return span;

            return TimeSpan.FromTicks(
                (span.Ticks / interval.Ticks) * interval.Ticks);
        }
    }
}
