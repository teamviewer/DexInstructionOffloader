﻿using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Controls.Notifications;
using Avalonia.Input;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Platform;
using ReactiveUI;
using System;
using Avalonia.Controls.ApplicationLifetimes;
using Microsoft.Extensions.Logging;
namespace TV1_InstructionOffloader
{
    public class TrayHelper : IDisposable
    {
        private readonly ILogger<TrayHelper> _logger;
        private Window? _mainWindow;
        private TrayIcon? _trayIcon;
        private Popup? _trayMenuPopup;

        public TrayHelper(ILogger<TrayHelper> logger)
        {
            _logger = logger;
        }
        public void AttachToWindow(Window mainWindow)
        {
            _mainWindow = mainWindow;

            var uri = new Uri("avares://TV1_InstructionOffloader_Modified/Assets/TV-1E.ico");
            using var stream = AssetLoader.Open(uri);
            var bitmap = new Bitmap(stream);
            var icon = new WindowIcon(bitmap);  // Declare icon here!

            _mainWindow.Icon = icon;
            _mainWindow.ShowInTaskbar = false;

            _trayIcon = new TrayIcon
            {
                Icon = icon,
                IsVisible = true,
            };

            _trayIcon.Clicked += TrayIcon_Clicked;

            // Initialize popup menu here, but you cannot trigger it from tray icon right-click
            _trayMenuPopup = new Popup
            {
                PlacementMode = PlacementMode.Bottom,
                PlacementTarget = mainWindow,
                Child = new Border
                {
                    Background = Brushes.White,
                    BorderBrush = Brushes.Gray,
                    BorderThickness = new Thickness(1),
                    Child = new StackPanel
                    {
                        Children =
        {
            CreateMenuItem("Show Window", () => _mainWindow?.Show()),
            CreateMenuItem("Hide Window", () => _mainWindow?.Hide()),
            CreateMenuItem("Start Headless", StartHeadless),
            CreateMenuItem("Stop Headless", StopHeadless),
            CreateMenuItem("Restart", Restart),
            new Separator(),
            CreateMenuItem("Exit", () =>
            {
                var lifetime = Application.Current.ApplicationLifetime as IClassicDesktopStyleApplicationLifetime;
                lifetime?.Shutdown();
            })
        }
                    }
                }

            };
        }


        private void TrayIcon_Clicked(object? sender, EventArgs e)
        {
            _logger.LogInformation("TrayIcon_Clicked fired at {Time}", DateTime.Now);

            Avalonia.Threading.Dispatcher.UIThread.Post(() =>
            {
                if (_mainWindow == null)
                {
                    _logger.LogWarning("MainWindow is null");
                    return;
                }

                if (_mainWindow.WindowState != WindowState.Minimized)
                {
                    _logger.LogInformation("Minimizing MainWindow");
                    _mainWindow.WindowState = WindowState.Minimized;
                }
                else
                {
                    _logger.LogInformation("Restoring MainWindow");
                    _mainWindow.WindowState = WindowState.Normal;
                    _mainWindow.ShowInTaskbar = true;
                    _mainWindow.Activate();
                }
            });
        }





        private MenuItem CreateMenuItem(string header, Action onClick)
        {
            var menuItem = new MenuItem { Header = header };
            menuItem.Click += (_, __) =>
            {
                onClick();
                _trayMenuPopup?.Close();
            };
            return menuItem;
        }

        private void StartHeadless()
        {
            ShowNotification("Headless Mode", "Started");
            // TODO: Add actual start logic here
        }

        private void StopHeadless()
        {
            ShowNotification("Headless Mode", "Stopped");
            // TODO: Add actual stop logic here
        }

        private void Restart()
        {
            StopHeadless();
            StartHeadless();
            ShowNotification("Headless Mode", "Restarted");
        }

        public void ShowNotification(string title, string message)
        {
            if (_mainWindow is null)
                return;

            var notificationManager = new WindowNotificationManager(_mainWindow)
            {
                Position = NotificationPosition.TopRight,
                MaxItems = 3
            };

            notificationManager.Show(new Notification(title, message, NotificationType.Information));
        }

        public void Dispose()
        {
            if (_trayIcon is not null)
            {
                _trayIcon.Clicked -= TrayIcon_Clicked;
                _trayIcon.Dispose();
            }
        }
    }
}
