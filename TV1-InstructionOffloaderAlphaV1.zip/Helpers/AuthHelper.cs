using System;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;
using TV1_InstructionOffloader.Models;
using TV1_InstructionOffloader.Services;

namespace TV1_InstructionOffloader.Helpers
{
    public static class AuthHelper
    {
        private static readonly ConcurrentDictionary<string, SemaphoreSlim> _authLocks =
            new ConcurrentDictionary<string, SemaphoreSlim>(StringComparer.OrdinalIgnoreCase);

        private static string NormalizeFqdnSimple(string urlOrHost)
        {
            if (string.IsNullOrWhiteSpace(urlOrHost)) return string.Empty;
            var s = urlOrHost.Trim();
            if (s.StartsWith("http://", StringComparison.OrdinalIgnoreCase)) s = s.Substring(7);
            if (s.StartsWith("https://", StringComparison.OrdinalIgnoreCase)) s = s.Substring(8);
            return s.TrimEnd('/').ToLowerInvariant();
        }

        private static string BuildKey(PlatformSettings s) =>
            NormalizeFqdnSimple(s?.PlatformFqdn ?? string.Empty) + "|" + (s?.AppId ?? string.Empty);

        public static async Task<AuthenticationResult> AuthenticateIsolatedAsync(PlatformSettings settings)
        {
            if (settings == null) throw new ArgumentNullException(nameof(settings));

            var key = BuildKey(settings);
            var gate = _authLocks.GetOrAdd(key, _ => new SemaphoreSlim(1, 1));
            await gate.WaitAsync().ConfigureAwait(false);
            try
            {
                var auth = new AuthenticationService(enableDevTokenReuse: false);
                auth.SetPlatformConfig(settings);

                try
                {
                    var reused = await auth.AuthenticateAsync(settings, false).ConfigureAwait(false);
                    if (reused != null &&
                        !string.IsNullOrWhiteSpace(reused.Token) &&
                        AuthenticationService.IsJwtStillValid(reused.Token))
                    {
                        LogHelper.Info($"✅ Reusing valid token for {settings.PlatformFqdn}.\n");
                        return reused;
                    }
                }
                catch (Exception ex)
                {
                    LogHelper.Info($"ℹ️ Token reuse attempt failed for {settings.PlatformFqdn}: {ex.Message}\n");
                }

                LogHelper.Info($"🔄 No valid token for {settings.PlatformFqdn} — authenticating...\n");
                var result = await auth.AuthenticateAsync(settings, true).ConfigureAwait(false);

                if (result == null || string.IsNullOrWhiteSpace(result.Token))
                {
                    LogHelper.Error($"❌ Authentication failed for {settings.PlatformFqdn}.\n");
                    return result ?? new AuthenticationResult { Token = string.Empty, PrincipalName = string.Empty };
                }

                try
                {
                    var config = new ConfigHelper().Load();
                    if (config != null && config.EnableDevTokenReuse)
                    {
                        auth.SaveToken(result.Token);
                        LogHelper.Info($"💾 Token saved to disk for {settings.PlatformFqdn}.\n");
                    }
                }
                catch (Exception ex)
                {
                    LogHelper.Info($"⚠️ Could not persist token for {settings.PlatformFqdn}: {ex.Message}\n");
                }

                return result;
            }
            finally
            {
                gate.Release();
            }
        }
    }
}
