﻿
// Helpers/Clock.cs
using System;

namespace TV1_InstructionOffloader.Helpers;

public interface IClock
{
    DateTime Now { get; }   // local *or* UTC, depending on Mode
    DateTime UtcNow { get; }  // always UTC (handy sometimes)
    DateTime ToLocal(DateTime utc);
    DateTime ToUtc(DateTime local);
    bool IsUtc { get; }
}

public sealed class SystemClock : IClock
{
    public enum ModeEnum { Local, Utc }

    public ModeEnum Mode { get; }

    public SystemClock(ModeEnum mode) => Mode = mode;

    public DateTime Now => Mode == ModeEnum.Local ? DateTime.Now : DateTime.UtcNow;
    public DateTime UtcNow => DateTime.UtcNow;
    public DateTime ToLocal(DateTime utc) => Mode == ModeEnum.Local ? utc.ToLocalTime() : utc;
    public DateTime ToUtc(DateTime local) => Mode == ModeEnum.Local ? local.ToUniversalTime() : local;
    public bool IsUtc => Mode == ModeEnum.Utc;
}
