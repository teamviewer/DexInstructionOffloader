﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using TV1_InstructionOffloader.Models;

namespace TV1_InstructionOffloader.Helpers
{
    public static class JobStorageHelper
    {
        private static readonly string JobsFilePath = AppPaths.ScheduledJobsPath;

        public static List<ScheduledJob> LoadJobs(Action<string>? logAction = null)
        {
            try
            {
                if (!File.Exists(JobsFilePath))
                {
                    logAction?.Invoke($"📂 No job file found at {JobsFilePath}. Returning empty list.");
                    return new List<ScheduledJob>();
                }

                var json = File.ReadAllText(JobsFilePath);
                var jobs = JsonConvert.DeserializeObject<List<ScheduledJob>>(json) ?? new List<ScheduledJob>();

                logAction?.Invoke($"✅ Loaded {jobs.Count} job(s) from disk.");
                return jobs;
            }
            catch (Exception ex)
            {
                logAction?.Invoke($"❌ Failed to load jobs: {ex.Message}");
                return new List<ScheduledJob>();
            }
        }

        public static void SaveJobs(List<ScheduledJob> jobs, Action<string>? logAction = null)
        {
            try
            {
                var folder = Path.GetDirectoryName(JobsFilePath);
                Directory.CreateDirectory(folder);

                var json = JsonConvert.SerializeObject(jobs, Formatting.Indented);
                File.WriteAllText(JobsFilePath, json);

                logAction?.Invoke($"💾 Saved {jobs.Count} job(s) to disk.");
            }
            catch (Exception ex)
            {
                logAction?.Invoke($"❌ Failed to save jobs: {ex.Message}");
            }
        }

    }
}
