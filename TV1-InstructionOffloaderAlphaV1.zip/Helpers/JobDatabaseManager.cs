
using System;
using System.Data.SqlClient;
using System.IO;
using Newtonsoft.Json;

public class JobDatabaseManager
{
    private readonly string _connectionString;
    private readonly string _jsonDirectory = "data";

    public JobDatabaseManager(string connectionString)
    {
        _connectionString = connectionString;
        EnsureJsonFilesExist();
    }

    public void InitializeDatabase()
    {
        using (var connection = new SqlConnection(_connectionString))
        {
            connection.Open();
            var command = connection.CreateCommand();
            command.CommandText = @"
                IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='JobDefinitions' AND xtype='U')
                CREATE TABLE JobDefinitions (
                    JobId UNIQUEIDENTIFIER PRIMARY KEY,
                    JobName NVARCHAR(255),
                    JobType NVARCHAR(50),
                    ScheduleType NVARCHAR(50),
                    StartTime DATETIME,
                    RecurrencePattern NVARCHAR(100),
                    ExportFormat NVARCHAR(20),
                    ExportTarget NVARCHAR(1024),
                    IsActive BIT,
                    CreatedAt DATETIME DEFAULT GETDATE()
                );

                IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='JobSettings' AND xtype='U')
                CREATE TABLE JobSettings (
                    SettingKey NVARCHAR(100) PRIMARY KEY,
                    SettingValue NVARCHAR(MAX),
                    Description NVARCHAR(255)
                );

                IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='JobHistory' AND xtype='U')
                CREATE TABLE JobHistory (
                    Id UNIQUEIDENTIFIER PRIMARY KEY,
                    JobId UNIQUEIDENTIFIER,
                    JobType NVARCHAR(50),
                    JobName NVARCHAR(255),
                    StartTime DATETIME,
                    EndTime DATETIME,
                    DurationSeconds INT,
                    Status NVARCHAR(50),
                    ExportType NVARCHAR(20),
                    ExportPath NVARCHAR(1024),
                    Notes NVARCHAR(MAX),
                    TriggeredBy NVARCHAR(20),
                    CpuPercent FLOAT,
                    MemoryMB INT,
                    ApiCalls INT
    InstructionTtlMinutes INT,
    ResponseTtlMinutes INT,
    EstimatedDurationSeconds INT,
    PlatformAlias NVARCHAR(100),
    ResponseId INT,
    ExecutionId NVARCHAR(100),
    LocalStartTime DATETIMEOFFSET,
                );

IF COL_LENGTH('JobHistory', 'InstructionTtlMinutes') IS NULL
    ALTER TABLE JobHistory ADD InstructionTtlMinutes INT;
IF COL_LENGTH('JobHistory', 'ResponseTtlMinutes') IS NULL
    ALTER TABLE JobHistory ADD ResponseTtlMinutes INT;
IF COL_LENGTH('JobHistory', 'EstimatedDurationSeconds') IS NULL
    ALTER TABLE JobHistory ADD EstimatedDurationSeconds INT;
IF COL_LENGTH('JobHistory', 'PlatformAlias') IS NULL
    ALTER TABLE JobHistory ADD PlatformAlias NVARCHAR(100);
IF COL_LENGTH('JobHistory', 'ResponseId') IS NULL
    ALTER TABLE JobHistory ADD ResponseId INT;
IF COL_LENGTH('JobHistory', 'ExecutionId') IS NULL
    ALTER TABLE JobHistory ADD ExecutionId NVARCHAR(100);
IF COL_LENGTH('JobHistory', 'LocalStartTime') IS NULL
    ALTER TABLE JobHistory ADD LocalStartTime DATETIMEOFFSET;
            ";
            command.ExecuteNonQuery();
        }
    }

    private void EnsureJsonFilesExist()
    {
        if (!Directory.Exists(_jsonDirectory))
            Directory.CreateDirectory(_jsonDirectory);

        string jobFile = Path.Combine(_jsonDirectory, "jobs.json");
        string settingsFile = Path.Combine(_jsonDirectory, "settings.json");

        if (!File.Exists(jobFile))
            File.WriteAllText(jobFile, "[]");

        if (!File.Exists(settingsFile))
            File.WriteAllText(settingsFile, "{}");
    }
}
