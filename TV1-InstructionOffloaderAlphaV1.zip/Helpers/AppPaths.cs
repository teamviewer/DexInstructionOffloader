using System;
using System.IO;

namespace TV1_InstructionOffloader.Helpers
{
    /// <summary>
    /// Canonical persistent storage paths for the app.
    /// Use this everywhere to avoid roaming/local/source-directory splits.
    /// </summary>
    public static class AppPaths
    {
        private const string AppFolderName = "TV1_InstructionOffloader";

        private static string? _baseDirectory;

        public static string BaseDirectory
        {
            get
            {
                if (!string.IsNullOrWhiteSpace(_baseDirectory))
                    return _baseDirectory;

                var appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                var baseDir = Path.Combine(appData, AppFolderName);
                Directory.CreateDirectory(baseDir);

                // Best-effort migration from older LocalAppData\...\data folder.
                // IMPORTANT: do not reference ScheduledJobsPath/AppSettingsPath properties in migration,
                // otherwise BaseDirectory will re-enter and recurse.
                TryMigrateLocalToRoaming(baseDir);

                _baseDirectory = baseDir;
                return _baseDirectory;
            }
        }

        public static string AppSettingsPath => Path.Combine(BaseDirectory, "appsettings.json");
        public static string ScheduledJobsPath => Path.Combine(BaseDirectory, "scheduled_jobs.json");
        public static string ExecutionHistoryPath => Path.Combine(BaseDirectory, "execution_history.json");

        private static void TryMigrateLocalToRoaming(string roamingBase)
        {
            try
            {
                var local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                var oldBaseA = Path.Combine(local, "TV1-InstructionOffloader", "data");
                var oldBaseB = Path.Combine(local, "TV1_InstructionOffloader", "data");

                string? oldBase = null;
                if (Directory.Exists(oldBaseA)) oldBase = oldBaseA;
                else if (Directory.Exists(oldBaseB)) oldBase = oldBaseB;

                if (string.IsNullOrWhiteSpace(oldBase))
                    return;

                // Use roamingBase directly to avoid BaseDirectory recursion.
                CopyIfMissing(Path.Combine(oldBase, "scheduled_jobs.json"), Path.Combine(roamingBase, "scheduled_jobs.json"));
                CopyIfMissing(Path.Combine(oldBase, "execution_history.json"), Path.Combine(roamingBase, "execution_history.json"));

                // Old builds sometimes wrote appsettings.json under roaming already; only migrate if missing.
                CopyIfMissing(Path.Combine(oldBase, "appsettings.json"), Path.Combine(roamingBase, "appsettings.json"));
            }
            catch
            {
                // non-fatal
            }
        }

        private static void CopyIfMissing(string src, string dest)
        {
            try
            {
                if (!File.Exists(src)) return;
                if (File.Exists(dest)) return;
                Directory.CreateDirectory(Path.GetDirectoryName(dest) ?? BaseDirectory);
                File.Copy(src, dest);
            }
            catch
            {
                // ignore
            }
        }
    }
}
