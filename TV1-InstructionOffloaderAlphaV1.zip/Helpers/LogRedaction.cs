using System;
using System.Security.Cryptography;
using System.Text;

namespace TV1_InstructionOffloader.Services
{
    internal static class LogRedaction
    {
        public static string PlatformTag(string? alias, string? fqdn)
        {
            var a = string.IsNullOrWhiteSpace(alias) ? "(no-alias)" : alias.Trim();
            return $"{a}#{ShortHash(fqdn)}";
        }

        private static string ShortHash(string? value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return "00000000";

            using var sha = SHA256.Create();
            var bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(value.Trim()));
            // 4 bytes = 8 hex chars; enough to correlate without exposing fqdn
            return Convert.ToHexString(bytes, 0, 4).ToLowerInvariant();
        }
    }
}
