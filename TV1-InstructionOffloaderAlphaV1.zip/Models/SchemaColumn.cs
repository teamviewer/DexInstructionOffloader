﻿// File: Models/SchemaColumn.cs (recommended location)
namespace TV1_InstructionOffloader.Models
{
    public class SchemaColumn
    {
        public string Name { get; set; }
        public string Type { get; set; }
        public int Length { get; set; }
        public string RenderAs { get; set; }
    }
}
