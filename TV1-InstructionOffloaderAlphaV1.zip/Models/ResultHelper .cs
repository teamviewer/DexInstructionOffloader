﻿using TV1_InstructionOffloader.Helpers;
using TV1_InstructionOffloader.Models;
using Avalonia.Controls;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace TV1_InstructionOffloader.Helpers
{
    internal class ResultHelper
    {
        public static async Task<(List<Dictionary<string, string>> Results, List<SchemaColumn> Schema)> LoadInstructionResultsAsync(
     string platformUrl,
     string token,
     string consumerName,
     int instructionId,
     int maxDisplay,
     TextBox logBox,
     string instructionName = null,
     string responseId = null)
        {
            var results = new List<Dictionary<string, string>>();
            var schema = new List<SchemaColumn>();
            int start = 0;
            const int pageSize = 2000;

            using var client = new HttpClient();
            client.DefaultRequestHeaders.Add("X-Tachyon-Authenticate", token);
            client.DefaultRequestHeaders.Add("X-Tachyon-Consumer", consumerName);

            string timestamp = DateTime.Now.ToString("yyyyMMdd-HHmmss");
            string safeName = (instructionName ?? "Instruction").Replace(" ", "_").Replace("/", "_");
            string logFileName = $"{safeName}-{responseId ?? instructionId.ToString()}-{timestamp}.log";
            string logFilePath = Path.Combine("Logs", logFileName);

            void Log(string message)
            {
                if (logBox != null)
                    logBox.Text += message + "\n";

                ExportHelper.Logger.LogToFile(logFilePath, message);
            }

            try
            {
                while (true)
                {
                    var url = $"https://{platformUrl}/Consumer/Responses/{instructionId}?start={start}&count={pageSize}";
                    Log($"📥 Fetching: {url}");

                    var response = await client.GetAsync(url);
                    if (!response.IsSuccessStatusCode)
                    {
                        Log($"❌ Failed to fetch: {response.StatusCode}");
                        break;
                    }

                    var content = await response.Content.ReadAsStringAsync();
                    var pageData = JsonConvert.DeserializeObject<List<JObject>>(content);

                    if (pageData == null || pageData.Count == 0)
                        break;

                    foreach (var obj in pageData)
                    {
                        var fqdn = obj["Fqdn"]?.ToString() ?? obj["Device"]?["Fqdn"]?.ToString() ?? "Unknown";
                        var values = obj["Values"]?.ToObject<Dictionary<string, string>>() ?? new();
                        values["Fqdn"] = fqdn;
                        results.Add(values);
                    }

                    Log($"✅ Fetched {pageData.Count} rows (Total: {results.Count})");

                    start += pageData.Count;
                    if (pageData.Count < pageSize || results.Count >= maxDisplay)
                        break;
                }

                // Schema fetch
                var schemaUrl = $"https://{platformUrl}/Consumer/Responses/Schema/{instructionId}";
                var schemaResponse = await client.GetAsync(schemaUrl);
                if (schemaResponse.IsSuccessStatusCode)
                {
                    var schemaJson = await schemaResponse.Content.ReadAsStringAsync();
                    schema = JsonConvert.DeserializeObject<List<SchemaColumn>>(schemaJson);

                    if (schema.Any(s => s.Type?.ToLower() == "clob"))
                    {
                        Log("⚠️ Warning: This instruction includes a 'clob' field — export may be limited.");
                    }
                }
                else
                {
                    Log($"⚠️ Could not fetch schema: {schemaResponse.StatusCode}");
                }

                return (results.Take(maxDisplay).ToList(), schema);
            }
            catch (Exception ex)
            {
                Log($"❌ Exception: {ex.Message}");
                return (new List<Dictionary<string, string>>(), new List<SchemaColumn>());
            }
        }

    }
}
