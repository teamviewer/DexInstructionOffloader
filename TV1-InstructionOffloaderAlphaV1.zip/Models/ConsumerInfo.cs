﻿using System.Collections.Generic;

namespace TV1_InstructionOffloader.Models
{
    public class ConsumerInfo
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string? OffloadTargetUrl { get; set; }
        public int? OffloadPostTimeoutSeconds { get; set; }
        public bool? OffloadUseWindowsAuth { get; set; }
        public string? ApplicationUrl { get; set; }
        public bool IsEnabled { get; set; }
        public bool SystemConsumer { get; set; }
        public int? MaximumSimultaneousInFlightInstructions { get; set; }
        public bool IsLicensed { get; set; }
        public string? Workflow { get; set; }
        public string? InstructionHandlerUrl { get; set; }
        public List<string>? DataSources { get; set; }
    }
}
