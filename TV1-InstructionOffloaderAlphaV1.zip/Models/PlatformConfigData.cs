namespace TV1_InstructionOffloader.Models
{
    public sealed class PlatformConfigData
    {
        public string PlatformFqdn { get; set; } = "";
        public string AppId { get; set; } = "";
        public string CertThumbprint { get; set; } = "";
        public bool UseCert { get; set; }

        public string Alias { get; set; } = "";
        public string GroupName { get; set; } = string.Empty;
        public bool IsDefault { get; set; }

        // Optional UPN/UserId for cert principal mapping (settings-only; UI may not expose it)
        public string UserId { get; set; } = "";
    }
}
