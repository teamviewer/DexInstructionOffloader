﻿using System;
namespace TV1_InstructionOffloader.Models;

/// <summary>
/// One row in the History tab – written to <c>data/execution_history.json</c>.
/// </summary>
public class JobExecutionHistory
{
    public string JobId { get; set; }
    public string JobName { get; set; }
    public string JobType { get; set; }
    public DateTime StartTime { get; set; }  // ✅ Required
    public DateTime EndTime { get; set; }    // ✅ Required
    public int DurationSeconds { get; set; }
    public string Status { get; set; }
    public string ExportPath { get; set; }
    public string? PagingExportPath { get; set; }
    public string? ServerExportPath { get; set; }
    public string? ServerDownloadUrl { get; set; }
    public bool? ServerExportIssued { get; set; }
    public DateTime? ServerExportIssuedUtc { get; set; }
    public string Notes { get; set; }
    public string TriggeredBy { get; set; }
    public string PlatformFqdn { get; set; }
    public string PlatformAlias { get; set; }
    public string? ResponseId { get; set; }
    public Guid ExecutionId { get; set; } = Guid.NewGuid();
    public int InstructionTtlMinutes { get; set; }
    public int ResponseTtlMinutes { get; set; }
    public string ExportFormat { get; set; }
    public int RetryCount { get; set; }
    public bool ExportAttempted { get; set; }
    public string ExportErrorMessage { get; set; }
    public string InstructionParameters { get; set; }
    public DateTime? CompletedUtc { get; set; }
    public DateTime StartTimeLocal => StartTime.ToLocalTime();

    public DateTime EndTimeLocal => EndTime.ToLocalTime();
    public DateTime? CompletedLocal => CompletedUtc?.ToLocalTime();



    public string PagingExportLinkText
        => string.IsNullOrWhiteSpace(PagingExportPath) ? "" : (string.IsNullOrWhiteSpace(ResponseId) ? "Open" : ResponseId);

    public string ServerExportLinkText
        => string.IsNullOrWhiteSpace(ServerExportPath) ? "" : (string.IsNullOrWhiteSpace(ResponseId) ? "Open" : ResponseId);

    public string ServerDownloadLinkText
        => string.IsNullOrWhiteSpace(ServerDownloadUrl) ? "" : "Download";

}
