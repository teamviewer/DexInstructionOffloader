﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace TV1_InstructionOffloader.Models
{
    public class PolicySearchResult
    {
        public List<PolicySummary> Items { get; set; } = new();
    }


    public class PolicySummary
    {
        public int Id { get; set; } = 0;
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public bool Enabled { get; set; } = true;


        public List<int> Rules { get; set; } = new();

        public List<string> ManagementGroups { get; set; } = new();
        public bool UsesUnlicensedFragment { get; set; } = false;
    }




    public class PolicyRule
    {
        [JsonProperty("Id")]
        public int Id { get; set; }

        [JsonProperty("Name")]
        public string Name { get; set; } = string.Empty;

        [JsonProperty("Description")]
        public string Description { get; set; } = string.Empty;
    }
    public class PolicyRuleResponse
    {
        public int TotalCount { get; set; }
        public string? Bookmark { get; set; }
        public List<PolicyRule> Items { get; set; } = new();
    }



    public class PolicyHistoryResponse
    {
        public List<PolicyResultItem> Items { get; set; } = new();
        public int AtLeastCount { get; set; } = 0;
        public string Bookmark { get; set; } = string.Empty;

    }



    public class PolicyResultItem
    {
        public long Id { get; set; }
        public int RuleId { get; set; }
        public int Revision { get; set; }
        public int ShardId { get; set; }
        public string RuleName { get; set; } = "";
        public string TachyonGuid { get; set; } = "";
        public string Fqdn { get; set; } = "";
        public int Status { get; set; }
        public DateTime Timestamp { get; set; }
        public string Data { get; set; } = "";
    }

}
