﻿using System;
public class InstructionRunMetadata
{
    public int InstructionId { get; set; }
    public string InstructionName { get; set; } = string.Empty;
    public DateTime RunTimeUtc { get; set; }
    public int TTLMinutes { get; set; } = 60;
    public bool ResultsFetched { get; set; } = false;
}
