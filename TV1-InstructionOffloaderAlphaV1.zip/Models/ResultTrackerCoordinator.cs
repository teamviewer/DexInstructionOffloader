﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using TV1_InstructionOffloader.Models;
using TV1_InstructionOffloader.Services; 





namespace TV1_InstructionOffloader.Services
{
    public class ResultTrackerCoordinator
    {
        private readonly IResultTracker _tracker;
        private readonly IInstructionFetcher _fetcher;
        private readonly Action<string> _logAction;
        private readonly Timer _timer;

        private readonly Dictionary<int, int> _retryCounts = new();
        private readonly int _retryLimit = 4;
        private readonly TimeSpan _checkInterval = TimeSpan.FromSeconds(60);
        

        public ResultTrackerCoordinator(IResultTracker tracker, IInstructionFetcher fetcher, Action<string> logAction)
        {
            _tracker = tracker;
            _fetcher = fetcher;
            _logAction = logAction;

            _timer = new Timer(CheckPendingRuns, null, TimeSpan.Zero, _checkInterval);
        }

        private async void CheckPendingRuns(object? state)
        {
            List<InstructionRunMetadata> pending;

            try
            {
                pending = _tracker.GetPendingRuns();
            }
            catch (Exception ex)
            {
                _logAction($"❌ Failed to get pending runs: {ex.Message}");
                return;
            }

            foreach (var run in pending)
            {
                if (_retryCounts.TryGetValue(run.InstructionId, out int retryCount) && retryCount >= _retryLimit)
                {
                    _logAction($"🚫 Skipping Instruction {run.InstructionId} — max retries reached.");
                    continue;
                }

                _logAction($"🔁 Attempting fetch for Instruction {run.InstructionId} (try #{retryCount + 1})...");

                try
                {
                    bool success = await _fetcher.FetchResultsAsync(run.InstructionId);

                    if (success)
                    {
                        _tracker.MarkAsFetched(run.InstructionId);
                        _logAction($"✅ Results fetched for Instruction {run.InstructionId}.");
                        _retryCounts.Remove(run.InstructionId);
                    }
                    else
                    {
                        _retryCounts[run.InstructionId] = retryCount + 1;
                        _logAction($"⚠️ Fetch failed for Instruction {run.InstructionId} (attempt #{retryCount + 1}).");
                    }
                }
                catch (Exception ex)
                {
                    _retryCounts[run.InstructionId] = retryCount + 1;
                    _logAction($"❌ Error fetching results for Instruction {run.InstructionId}: {ex.Message}");
                }
            }
        }

        public void Dispose()
        {
            _timer?.Dispose();
        }
    }
}
