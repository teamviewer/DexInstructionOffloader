﻿using System;

namespace TV1_InstructionOffloader.Models
{
    /// <summary>A single entry for the History tab / grid.</summary>
    public sealed class HistoryRow
    {
        public DateTimeOffset Time { get; set; }
        public string Fqdn { get; set; } = "";
        public string Name { get; set; } = "";
        public string Type { get; set; } = "";     // e.g. “Instruction”
        public string Status { get; set; } = "";     // “Running”, “Finished”, “Failed”
        public string? File { get; set; }           // path to exported CSV, etc.

        public HistoryRow() { }
        public HistoryRow(DateTimeOffset t, string fqdn, string name,
                          string type, string status, string? file = null)
        {
            Time = t;
            Fqdn = fqdn;
            Name = name;
            Type = type;
            Status = status;
            File = file;
        }
    }
}
