﻿namespace TV1_InstructionOffloader.Models
{
    public class ExportOption
    {
        public string? ExportFolder { get; set; }
        public string? Format { get; set; }
    }
}
