﻿namespace TV1_InstructionOffloader.Models
{
    public class PlatformDisplay
    {
        public string PlatformFqdn { get; set; } = string.Empty;
        public string AppId { get; set; } = string.Empty;
        public string CertThumbprint { get; set; } = string.Empty;
        public string DefaultConsumer { get; set; } = "Explorer";
        public string GroupName { get; set; } = string.Empty;
        public bool IsDefault { get; set; } = false;

        public override string ToString() => GroupName;
    }
}
