﻿using System.Collections.Generic;

public interface IResultTracker
{
    void AddOrUpdate(InstructionRunMetadata run);
    List<InstructionRunMetadata> GetPendingRuns();
    void MarkAsFetched(int instructionId);
    void Load();
    void Save(); // no-op for SQL version
}
