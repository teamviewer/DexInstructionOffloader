﻿using System;

namespace TV1_InstructionOffloader.Models
{
    public class Settings
    {
        // Concurrency
        public int ConcurrentApiCalls { get; set; } = 5;

        // Paging
        public int PageSize { get; set; } = 100;

        // Default timers (minutes)
        public int DefaultInstructionTtlMinutes { get; set; } = 10;
        public int DefaultResponseTtlMinutes { get; set; } = 10;

        // Export settings
        public string ExportFolderPath { get; set; } = "Exports";
        public string DefaultExportFormat { get; set; } = "CSV";

        // SQL Server config
        public bool UseSqlServer { get; set; } = false;
        public string SqlConnectionString { get; set; } = "";

        // Recovery
        public bool AutoRecover { get; set; } = true;

        // History
        public int HistoryMaxItems { get; set; } = 100;

        // Logging
        public bool ShowLogs { get; set; } = false;
        public string LogLevel { get; set; } = "Info";
        

        // Add more as needed
    }
}
