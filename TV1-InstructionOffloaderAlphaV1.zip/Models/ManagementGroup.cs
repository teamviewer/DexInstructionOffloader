﻿using System.Xml.Linq;

namespace TV1_InstructionOffloader.Models
{
    public class ManagementGroup
    {
        public string Name { get; set; }
        public int UsableId { get; set; }
        public int Id { get; set; } = 0;

        public override string ToString() => Name;
    }
}