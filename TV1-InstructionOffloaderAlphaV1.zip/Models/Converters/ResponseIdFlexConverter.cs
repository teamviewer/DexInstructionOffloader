using System;
using Newtonsoft.Json;

namespace TV1_InstructionOffloader.Models.Converters
{
    public sealed class ResponseIdFlexConverter : JsonConverter<string>
    {
        public override string ReadJson(JsonReader reader, Type objectType, string existingValue, bool hasExistingValue, JsonSerializer serializer)
        {
            if (reader.TokenType == JsonToken.Integer) return reader.Value?.ToString() ?? string.Empty;
            if (reader.TokenType == JsonToken.String)  return (string?)reader.Value ?? string.Empty;
            return string.Empty;
        }
        public override void WriteJson(JsonWriter writer, string? value, JsonSerializer serializer)
        {
            writer.WriteValue(value ?? string.Empty);
        }
    }
}
