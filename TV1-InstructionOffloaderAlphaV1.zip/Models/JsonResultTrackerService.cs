﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System; 

public class JsonResultTrackerService : IResultTracker
{
    private readonly string _filePath;
    private readonly object _lock = new();
    private List<InstructionRunMetadata> _runs = new();

    public JsonResultTrackerService(string filePath)
    {
        _filePath = filePath;
        Load();
    }

    public void AddOrUpdate(InstructionRunMetadata run)
    {
        lock (_lock)
        {
            _runs.RemoveAll(r => r.InstructionId == run.InstructionId);
            _runs.Add(run);
            Save();
        }
    }

    public List<InstructionRunMetadata> GetPendingRuns()
    {
        lock (_lock)
        {
            return _runs
                .Where(r => !r.ResultsFetched &&
                            DateTime.UtcNow >= r.RunTimeUtc.AddMinutes(r.TTLMinutes))
                .ToList();
        }
    }

    public void MarkAsFetched(int instructionId)
    {
        lock (_lock)
        {
            var match = _runs.FirstOrDefault(r => r.InstructionId == instructionId);
            if (match != null)
            {
                match.ResultsFetched = true;
                Save();
            }
        }
    }

    public void Load()
    {
        if (File.Exists(_filePath))
        {
            var json = File.ReadAllText(_filePath);
            _runs = JsonConvert.DeserializeObject<List<InstructionRunMetadata>>(json) ?? new();
        }
    }

    public void Save()
    {
        var json = JsonConvert.SerializeObject(_runs, Formatting.Indented);
        File.WriteAllText(_filePath, json);
    }
}
