﻿using System.Collections.Generic;

public class ParameterDefinition
{
    public string Name { get; set; } = "";                  // e.g., "ComputerName"
    public string DisplayName { get; set; } = "";           // e.g., "Target Computer"
    public string Type { get; set; } = "string";            // e.g., "int", "choice", "string"
    public List<string>? AllowedValues { get; set; }        // only for choice types
}
