﻿using System;
using System.Text.Json.Serialization;

namespace TV1_PlatformOffloader.Models   // <— ONE canonical namespace
{
    public sealed class Token3
    {
        [JsonPropertyName("token")]
        public string Token { get; init; } = string.Empty;

        [JsonPropertyName("expirationUtc")]
        public DateTime ExpirationUtc { get; init; }

        [JsonIgnore]
        public bool IsExpired => DateTime.UtcNow >= ExpirationUtc;
    }
}
