﻿using System.Collections.Generic;

namespace TV1_InstructionOffloader.Models
{
    public class PlatformSettings
    {
        public string? Alias { get; set; }                // Display name / dropdown key
        public string? PlatformFqdn { get; set; }         // FQDN of the platform
        public string? AppId { get; set; }                // Client ID
        public string? CertThumbprint { get; set; }       // Certificate thumbprint
        public string? UserId { get; set; }              // Optional UPN/UserId for cert principal mapping

        public string? DefaultConsumer { get; set; }      // Usually "Explorer"
        public string? DefaultMG { get; set; }            // Default management group (optional)

        /// <summary>
        /// When true, the platform requires explicit coverage targeting (MG/FQDN/CoverageTag) and should not
        /// allow "blank scope" instruction runs.
        /// </summary>
        public bool RequireCoverage { get; set; }

        public string? AuthenticationMode { get; set; }   // e.g. "Cert", "Interactive"
        public bool UseCert { get; set; }                 // Flag to use certificate-based auth
        public bool IsDefault { get; set; }               // Marks this as the default selected platform

        public List<AuthProfile> AuthProfiles { get; set; } = new(); // Optional multiple certs
        public override string ToString()
        {
            return Alias ?? PlatformFqdn ?? "(unnamed)";
        }


    }


    public class AuthProfile
    {
        public string? AppId { get; set; }
        public string? CertThumbprint { get; set; }
    }
}
