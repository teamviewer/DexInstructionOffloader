﻿using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace TV1_InstructionOffloader.Models
{
    public class Platform : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged;

        private string _groupName = "";
        private string _platformFqdn = "";
        private string _certThumbprint = "";
        private string _appId = "";
        private string _userId = "";
        private string _defaultConsumer = "";
        private string _alias = "";
        private bool _requireCoverage;
        public bool UseCert { get; set; } = true;

        public string Alias
        {
            get => _alias;
            set { _alias = value; OnPropertyChanged(); }
        }
        public override string ToString()
        {
            return GroupName ?? PlatformFqdn;
        }
        public string? Token { get; set; }


        public string GroupName
        {
            get => _groupName;
            set { _groupName = value; OnPropertyChanged(); }
        }

        public string PlatformFqdn
        {
            get => _platformFqdn;
            set { _platformFqdn = value; OnPropertyChanged(); }
        }

        public string CertThumbprint
        {
            get => _certThumbprint;
            set { _certThumbprint = value; OnPropertyChanged(); }
        }

        public string AppId
        {
            get => _appId;
            set { _appId = value; OnPropertyChanged(); }
        }

        
        public string UserId
        {
            get => _userId;
            set { _userId = value; OnPropertyChanged(); }
        }

public string DefaultConsumer
        {
            get => _defaultConsumer;
            set { _defaultConsumer = value; OnPropertyChanged(); }
        }

        /// <summary>
        /// When enabled, the platform requires explicit coverage targeting for instruction runs.
        /// This is a per-platform behavior toggle used by scheduled job validation and execution.
        /// </summary>
        public bool RequireCoverage
        {
            get => _requireCoverage;
            set { _requireCoverage = value; OnPropertyChanged(); }
        }

        // Models/Platform.cs  (add at the end)
        public bool IsDefault { get; set; }


        protected void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
