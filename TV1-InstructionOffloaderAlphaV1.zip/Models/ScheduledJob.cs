﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text.Json.Serialization;
namespace TV1_InstructionOffloader.Models
{
    public enum ExportMode
    {
        PagingOnly = 0,
        ServerOnly = 1,
        PagingThenServer = 2
    }

    public enum ExportFolderMode
    {
        Flat = 0,
        ByInstruction = 1,
        ByDate = 2,
        ByInstructionThenDate = 3
    }

    /// <summary>
    /// A fully-descriptive job definition used by the Scheduled-Jobs tab,
    /// serialization, and execution engine.
    /// </summary>
    public class ScheduledJob : INotifyPropertyChanged
    {
        // ─────────── Identity
        public string JobId { get; set; } = Guid.NewGuid().ToString();

        // Instruction meta
        public string InstructionName { get; set; } = "";
        public int InstructionId { get; set; }

        // 🔹 NEW: Instruction Type (Instruction, Experience, Automation, etc.)
        private string _instructionType = "Instruction";
        public string InstructionType
        {
            get => _instructionType;
            set
            {
                if (_instructionType != value)
                {
                    _instructionType = value;
                    OnPropertyChanged(nameof(InstructionType));
                }
            }
        }



        // Tenant / platform
        public string PlatformAlias { get; set; } = "";
        public string PlatformFqdn { get; set; } = "";
        public string AppRegistrationId { get; set; } = "";
        public string CertThumbprint { get; set; } = "";
        public string AuthenticationMode { get; set; } = "";
        public string ExportTarget { get; set; }
        public string? PlatformAppId { get; set; }
        public string? PlatformCertThumbprint { get; set; }
        [Newtonsoft.Json.JsonIgnore]
        public string? Token { get; set; }

        // TTL settings
        public int InstructionTtlMinutes { get; set; } = 10;
        public string InstructionTtlUnit { get; set; } = "Minutes";
        public int ResponseTtlMinutes { get; set; } = 24;
        public string ResponseTtlUnit { get; set; } = "Hours";
        public TimeSpan? AverageDuration { get; set; }
        public TimeSpan? MaxDuration { get; set; }

        // Export / consumer
        public string ExportFormat { get; set; } = "CSV";
        public string Consumer { get; set; } = "Explorer";

        // Export behavior
        public ExportMode ExportMode { get; set; } = ExportMode.PagingThenServer;
        public ExportFolderMode ExportFolderMode { get; set; } = ExportFolderMode.ByInstructionThenDate;
        public int ServerSideFallbackAfterFailures { get; set; } = 3;

        // Server-side export failsafe state (persisted with the job so we can resume after restart).
        public bool ServerExportIssued { get; set; }
        public DateTime? ServerExportIssuedUtc { get; set; }
        public int PagingExportFailureCount { get; set; }

        // Paging/server export progress (persisted so PagingThenServer can resume correctly).
        public bool PagingExportCompleted { get; set; }
        public DateTime? PagingExportCompletedUtc { get; set; }
        public string? LastPagingExportPath { get; set; }
        public string? LastServerExportPath { get; set; }
        public string? LastServerDownloadUrl { get; set; }

        // Scheduling basics
        public DateTime? StartDate;

        public string JobType { get; set; } = "Instruction";  // e.g., "Instruction", "Experience", "Export"
        public string Status { get; set; } = "Enabled";       // or "Disabled", "Pending", etc.{ get; set; }
        public DateTime? EndDate { get; set; }
        public TimeSpan? StartTime { get; set; }

        // Recurrence
        private string _recurrence = "Once";
        public string Recurrence
        {
            get => _recurrence;
            set
            {
                if (_recurrence != value)
                {
                    _recurrence = value;
                    OnPropertyChanged(nameof(Recurrence));
                }
            }
        }
        public bool EnableExport { get; set; } = true;
        private string _runtimeStatus = "Scheduled";
        public string RuntimeStatus
        {
            get => _runtimeStatus;
            set
            {
                if (!string.Equals(_runtimeStatus, value, StringComparison.Ordinal))
                {
                    _runtimeStatus = value;
                    OnPropertyChanged(nameof(RuntimeStatus));
                }
            }
        }
        public Guid? CurrentExecutionId { get; set; }

        public int MaxRetries { get; set; } = 3;
        public int RetryCount { get; set; } = 0;
        public TimeSpan Cooldown { get; set; } = TimeSpan.FromMinutes(5);
        public DateTime? LastRetryUtc { get; set; }

        public List<DayOfWeek> DaysOfWeek { get; set; } = new();
        public DateTime? LastRunUtc { get; set; }

        // Weekly
        public int WeeklyRepeatCount { get; set; } = 1;

        // Monthly
        public int MonthlyRepeatCount { get; set; } = 1;
        public List<int> MonthlyWeekOffsets { get; set; } = new();
        public int MonthlyDayFallback { get; set; } = 1;
        public Dictionary<string, string> Parameters { get; set; } = new();
        public int ExportTtlMinutes { get; set; } = 10;   // when export may start
        public DateTime? CompletedUtc { get; set; }         // set when RunJobAsync finishes

        private bool _isExporting;
        public bool IsExporting
        {
            get => _isExporting;
            set
            {
                if (_isExporting != value)
                {
                    _isExporting = value;
                    OnPropertyChanged(nameof(IsExporting));
                }
            }
        }
        /// <summary>
        /// Persisted response identifier for a run. Historically this was an integer response id.
        /// Newer builds may store GUID-like execution identifiers here. Keep as string to support both.
        /// </summary>
        private string? _responseId;
        public string? ResponseId
        {
            get => _responseId;
            set
            {
                if (!string.Equals(_responseId, value, StringComparison.Ordinal))
                {
                    _responseId = value;
                    OnPropertyChanged(nameof(ResponseId));
                    OnPropertyChanged(nameof(ResponseIdInt));
                    OnPropertyChanged(nameof(ResponseIdGuid));
                }
            }
        }

        [JsonIgnore]
        public int? ResponseIdInt
        {
            get
            {
                if (string.IsNullOrWhiteSpace(ResponseId))
                    return null;
                return int.TryParse(ResponseId, out var v) ? v : null;
            }
        }

        [JsonIgnore]
        public Guid? ResponseIdGuid
        {
            get
            {
                if (string.IsNullOrWhiteSpace(ResponseId))
                    return null;
                return Guid.TryParse(ResponseId, out var g) ? g : null;
            }
        }

        public int EarlyExportMinutes { get; set; } = 0; // buffer

        public Guid Id { get; set; }

        public string? JobName { get; set; }

        public string? LastRunExecutionId { get; set; }

        public string? LastRunResponseId { get; set; }

        public DateTime? ResponseCapturedTimeUtc { get; set; }

        public string TargetingFqdn { get; set; } = "";
        public string TargetingManagementGroup { get; set; } = "";
        public string CoverageTagName { get; set; } = "";
        public string CoverageTagValue { get; set; } = "";
        private string? _exportPath;
        public string? ExportPath
        {
            get => _exportPath;
            set
            {
                if (!string.Equals(_exportPath, value, StringComparison.Ordinal))
                {
                    _exportPath = value;
                    OnPropertyChanged(nameof(ExportPath));
                }
            }
        }

        public string? FqdnInput { get; set; }
        public string? MatchType { get; set; }
        public int? ManagementGroupId { get; set; }
        public string? CoverageTag { get; set; }
        public string? CoverageValue { get; set; }

        // Targeting
        public string TargetingMethod { get; set; } = "FQDN";

        // ─────────── Runtime state
        private bool _isRunning;
        public bool IsRunning
        {
            get => _isRunning;
            set
            {
                if (_isRunning != value)
                {
                    _isRunning = value;
                    OnPropertyChanged(nameof(IsRunning));
                }
            }
        }
        public bool HasLoggedInitialStatus { get; set; }
        public DateTime? LastEvaluatedWindow { get; set; } = null;
        public DateTime? LastLogWindowUtc { get; set; } = null;

        public DateTime? LastSkipLoggedUtc { get; set; }   // when we last wrote “Not due”
        public bool HasShownStartupInfo { get; set; } // prevents duplicate start-up lines

        // skip-log suppression
        private readonly Dictionary<string, DateTime> _lastSkipLogged = new(); // keyed by JobId  (old)
        private readonly Dictionary<string, DateTime> _lastInstrSkipLogged = new(); // keyed by InstructionName (NEW)
        internal readonly string? ConsumerName;

        public bool IsEnabled
        {
            get => string.Equals(Status, "Enabled", StringComparison.OrdinalIgnoreCase);
            set => Status = value ? "Enabled" : "Disabled";
        }

        public DateTime NextCheckUtc { get; set; } = DateTime.UtcNow;

        public DateTime ScheduledDateTime =>
            (StartDate ?? DateTime.Today) + (StartTime ?? TimeSpan.Zero);

        public override string ToString()
        {
            string when = StartDate.HasValue
                ? $"{StartDate:yyyy-MM-dd} {StartTime?.ToString(@"hh\:mm") ?? "00:00"}"
                : "unscheduled";

            return $"{InstructionName} ({Recurrence}) @ {when}";
        }
        public DateTime? ScheduledTime { get; set; } = DateTime.Today.AddHours(22); // or leave null/default

        public DateTime? LastRunTime { get; set; } = null;



        // 🧠 Determines when the job should next run
        public DateTime? GetNextRunTime(DateTime now)
        {
            if (!IsEnabled || ScheduledTime == null)
                return null;

            var baseTime = ScheduledTime.Value;

            return Recurrence switch
            {
                "Daily" => baseTime.Date.AddDays(1).Add(baseTime.TimeOfDay),
                "Weekly" => baseTime.AddDays(7),
                "Monthly" => baseTime.AddMonths(1),
                _ => baseTime
            };
        }
        public string StatusEmoji =>
            RuntimeStatus switch
            {
                "Running" => "⚙️",
                "Exporting" => "💾",
                "Cooldown" => "🧊",
                "Retrying" => "🔁",
                "Failed" => "💥",
                "Disabled" => "🚷",
                "Waiting" => "⏳",
                "Scheduled" => "📅",
                _ => ""
            };




        // 🖼 Display helpers for UI and logging
        public string DisplayTime => ScheduledTime?.ToString("HH:mm") ?? "unset";
        public string LastRunDisplay => LastRunTime?.ToString("g") ?? "never";

        // 🔹 Copy all editable fields from another ScheduledJob
        public void CopyFrom(ScheduledJob source)
        {
            if (source == null) return;

            PlatformAlias = source.PlatformAlias;
            PlatformFqdn = source.PlatformFqdn;
            AppRegistrationId = source.AppRegistrationId;
            CertThumbprint = source.CertThumbprint;
            AuthenticationMode = source.AuthenticationMode;

            InstructionType = source.InstructionType;
            InstructionName = source.InstructionName;
            InstructionId = source.InstructionId;

            InstructionTtlMinutes = source.InstructionTtlMinutes;
            InstructionTtlUnit = source.InstructionTtlUnit;
            ResponseTtlMinutes = source.ResponseTtlMinutes;
            ResponseTtlUnit = source.ResponseTtlUnit;

            ExportFormat = source.ExportFormat;
            Consumer = source.Consumer;

            StartDate = source.StartDate;
            EndDate = source.EndDate;
            StartTime = source.StartTime;

            Recurrence = source.Recurrence;
            DaysOfWeek = new List<DayOfWeek>(source.DaysOfWeek);

            WeeklyRepeatCount = source.WeeklyRepeatCount;

            MonthlyRepeatCount = source.MonthlyRepeatCount;
            MonthlyWeekOffsets = new List<int>(source.MonthlyWeekOffsets);
            MonthlyDayFallback = source.MonthlyDayFallback;

            TargetingMethod = source.TargetingMethod;
            IsRunning = source.IsRunning;
            FqdnInput = source.FqdnInput;
            MatchType = source.MatchType;
            ManagementGroupId = source.ManagementGroupId;
            CoverageTag = source.CoverageTag;
            CoverageValue = source.CoverageValue;
        }

        // ─────────── INotifyPropertyChanged
        public event PropertyChangedEventHandler? PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));




        // Convenience for grids – show alias if set otherwise FQDN
        public string PlatformDisplay => string.IsNullOrWhiteSpace(PlatformAlias) ? PlatformFqdn : PlatformAlias;

        [JsonIgnore]
        public bool PlatformMissing { get; set; }


    }
}
