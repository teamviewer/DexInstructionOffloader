﻿using System.Collections.Generic;

namespace TV1_InstructionOffloader.Models
{
    public class InstructionDefinition
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public int InstructionType { get; set; }
        public List<Parameter> Parameters { get; set; } = new();
        public int InstructionTtlMinutes { get; set; } = 60;
        public int ResponseTtlMinutes { get; set; } = 120;

    }

    public class Parameter
    {
        public string Name { get; set; } = string.Empty;
        public string DisplayName { get; set; } = string.Empty;
        public string? DefaultValue { get; set; }
        public ValidationData? Validation { get; set; }

        // ✅ Exposes allowed values directly from the Validation object
        public List<string>? AllowedValues => Validation?.AllowedValues;
    }

    public class ValidationData
    {
        public string? Regex { get; set; }
        public string? MaxLength { get; set; }
        public List<string>? AllowedValues { get; set; }
        public object? NumValueRestrictions { get; set; }
    }
}
