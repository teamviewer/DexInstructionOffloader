﻿using System;
using System.Collections.Generic;
using TV1_InstructionOffloader.Models;

namespace TV1_InstructionOffloader.Helpers
{



    public class AppSettings
    {
        public List<PlatformSettings> Platforms { get; set; } = new();
        public int ReauthMinutes { get; set; } = 55;
        public string DefaultConsumer { get; set; } = "Explorer";
        public string DefaultMG { get; set; } = "";
        public ExportSettings Export { get; set; } = new();
        public HeadlessSettings Headless { get; set; } = new();
        public string? DefaultPlatformAlias { get; set; }
        public string? DefaultPlatformFqdn { get; set; }
        public PlatformSettings? PlatformSettings { get; set; }
        public Dictionary<string, ExportOption> ExportOptions { get; set; } = new(StringComparer.OrdinalIgnoreCase);
        public bool EnableDevTokenReuse { get; set; } = false;

        // Display-only preference: whether UI/logs should show UTC timestamps.
        // Scheduler execution should still use UTC internally.
        public bool UseUtcTimestamps { get; set; } = false;

        // Optional global defaults used by first-run setup / fallback export behavior.
        public string DefaultExportFolder { get; set; } = "";

        // New jobs default to this export mode unless overridden in the UI.
        // Values should map to Models.ExportMode: PagingOnly, ServerOnly, PagingThenServer
        public string DefaultExportMode { get; set; } = "PagingThenServer";

        public string LogLevel { get; set; } = "Info";        // Default to Info
        public int MaxLogLines { get; set; } = 5000;          // Default to 5000
        public int MaxLogFileSizeMB { get; set; } = 10;       // Default to 10 MB
        public bool PurgeExpiredTokensOnStartup { get; set; } = true;
    }

    public class HeadlessSettings
    {
        public bool UseSql { get; set; } = false;
        public string SqlConnectionString { get; set; } = string.Empty;
        public string JsonStorePath { get; set; } = "InstructionRunStore.json";
        public string OutputFolder { get; set; } = "Exports";
        public string LogFilePath { get; set; } = "headless.log";
        public int ResultCheckIntervalMinutes { get; set; } = 10;
        public bool AutoRecover { get; set; } = true;
    }
    public class ExportSettings
    {
        public int PageSize { get; set; } = 2000;           // Allowed values: 25, 50, 200, 500, 2000
        public int MaxConcurrentRequests { get; set; } = 6; // Number of simultaneous page fetches
    }

}

