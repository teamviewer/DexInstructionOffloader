﻿namespace TV1_InstructionOffloader.Converters;

using Avalonia.Data.Converters;
using System;
using System.Globalization;

public class InstructionTypeToEmojiConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        return value switch
        {
            0 => "❓",
            1 => "⚙️",
            2 => "⏱️",
            _ => ""
        };
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        => throw new NotImplementedException();
}
