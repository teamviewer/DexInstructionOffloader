﻿using Avalonia.Data.Converters;
using System;
using System.Globalization;

namespace TV1_InstructionOffloader.Converters
{
    /// <summary>
    /// Returns <see cref="True"/> when the bound value is true,
    /// otherwise <see cref="False"/>.
    /// </summary>
    public class BoolToStringConverter : IValueConverter
    {
        public string True { get; set; } = " ★";
        public string False { get; set; } = "";

        public object Convert(object? value, Type targetType,
                              object? parameter, CultureInfo culture)
            => value is bool b && b ? True : False;

        public object ConvertBack(object? value, Type targetType,
                                  object? parameter, CultureInfo culture)
            => throw new NotSupportedException();
    }
}
