﻿using System;
using System.Globalization;
using Avalonia.Data.Converters;
using Avalonia.Media.Imaging;
using Avalonia.Platform;

namespace TV1_InstructionOffloader.Converters
{
    public class ChartImageConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var chartName = value?.ToString();
            var uri = chartName switch
            {
                "Heatmap" => "avares://TV1_InstructionOffloader/Assets/chart_heatmap.png",
                "Buckets" => "avares://TV1_InstructionOffloader/Assets/chart_duration_buckets.png",
                "AvgDuration" => "avares://TV1_InstructionOffloader/Assets/chart_avg_duration.png",
                _ => null
            };

            return uri != null ? new Bitmap(AssetLoader.Open(new Uri(uri))) : null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) =>
            throw new NotImplementedException();
    }
}
