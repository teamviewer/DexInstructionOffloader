﻿using Avalonia;
using Avalonia.ReactiveUI;
using System;
using System.Linq;
using System.Threading.Tasks;
using TV1_InstructionOffloader;
using TV1_InstructionOffloader.Headless;

public static class Program
{
    public static bool IsHeadless { get; private set; }

    [STAThread]
    public static async Task Main(string[] args)
    {
        if (args.Contains("--nogui"))
        {
            IsHeadless = true;
            await NoGuiRunner.RunAsync(args);
            return;
        }

        BuildAvaloniaApp().StartWithClassicDesktopLifetime(args);
    }

    public static AppBuilder BuildAvaloniaApp()
    {
        return AppBuilder.Configure<App>()
            .UsePlatformDetect()
            .UseReactiveUI()
            .WithInterFont();
    }
}
