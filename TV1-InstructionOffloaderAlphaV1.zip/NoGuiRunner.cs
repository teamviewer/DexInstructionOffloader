﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TV1_InstructionOffloader.Helpers;
using TV1_InstructionOffloader.Models;
using TV1_InstructionOffloader.Services;

namespace TV1_InstructionOffloader.Headless
{
    internal static class NoGuiRunner
    {
        public static async Task RunAsync(string[] args)
        {
            Console.WriteLine("🚀 NoGuiRunner starting...");

            // Load configuration
            var configHelper = new ConfigHelper();
            var settings = configHelper.Load();

            var platformSetting = settings.Platforms?.FirstOrDefault();
            if (platformSetting == null)
            {
                Console.WriteLine("❌ No PlatformSettings configured in appsettings.");
                return;
            }

            string? someValue = platformSetting.PlatformFqdn?.Trim();
            var platformConfig = settings.Platforms?.FirstOrDefault(p =>
                string.Equals(p.PlatformFqdn?.Trim(), someValue, StringComparison.OrdinalIgnoreCase));

            if (platformConfig == null)
            {
                Console.WriteLine("❌ No PlatformConfig found inside PlatformSettings.");
                return;
            }

            string platformUrl = platformConfig?.PlatformFqdn ?? platformSetting.PlatformFqdn;

            string consumerName = platformSetting.DefaultConsumer ?? settings.DefaultConsumer ?? "Explorer";

            // Build PlatformSettings for AuthenticationService
            var authPlatformConfig = new PlatformSettings
            {
                PlatformFqdn = platformUrl,
                AppId = platformConfig.AppId,
                CertThumbprint = platformConfig.CertThumbprint,
                UseCert = platformConfig.UseCert
            };

            // Authenticate
            var authService = new AuthenticationService();
            Console.WriteLine($"🔐 Authenticating to {platformUrl} as {consumerName}...");
            var authResult = await authService.AuthenticateAsync(authPlatformConfig);
            var token = authResult.Token;

            if (string.IsNullOrWhiteSpace(token))
            {
                Console.WriteLine("❌ Authentication failed.");
                return;
            }

            // Placeholder instruction definition
            var dummyDefinition = new InstructionDefinition
            {
                Id = 1234,
                Name = "Example Instruction",
                InstructionTtlMinutes = 60,
                ResponseTtlMinutes = 120
            };

            var logger = new FileLogger(settings.Headless?.LogFilePath ?? "headless.log");

            Console.WriteLine("📤 Sending instruction...");

            var mg = new ManagementGroup { Name = platformSetting.DefaultMG ?? "" };

            await new InstructionService().RunInstructionFromMainTabAsync(
                dummyDefinition,
                parametersDict: new Dictionary<string, object>(),
                targetingMode: "FQDN",
                platformUrl: platformUrl,
                token: token,
                consumerName: consumerName,
                fqdnInput: "myhost",
                matchType: "Begins With",
                selectedMG: mg,
                coverageTag: null,
                coverageValue: null,
                selectedFqdns: new List<string>(),
                instructionTtlMinutes: dummyDefinition.InstructionTtlMinutes,
                responseTtlMinutes: dummyDefinition.ResponseTtlMinutes,
                logger: logger
            );

            Console.WriteLine("✅ Instruction sent.");
        }
    }
}
