﻿using Avalonia.Threading;
using ReactiveUI;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Reactive;
using System.Reactive.Linq;
using System.Reflection;
using Newtonsoft.Json.Linq;
using TV1_InstructionOffloader.Helpers;
using TV1_InstructionOffloader.Models;
using TV1_InstructionOffloader.Services;
using TV1_InstructionOffloader.Views;

namespace TV1_InstructionOffloader.ViewModels
{
    /// <summary>
    /// View-model for the Platforms tab.  Handles Add / Edit / Delete,
    /// “Set Default”, and round-trips to <c>appsettings.json</c>.
    /// Uses reflection when mapping so we tolerate builds that omit
    /// AppId / CertThumbprint / UseCert, etc.
    /// </summary>
    public sealed class PlatformConfigViewModel : ReactiveObject
    {
        private readonly ConfigHelper _configHelper = new();
        
        private AppSettings _settings;
        private ObservableCollection<Platform> _platforms = new();
        private bool _defaultPlatformManuallyChanged = false;
       // private ExportOptionsTab? ExportOptionsHost;

        public event Action<IReadOnlyList<Platform>>? PlatformsChanged;
        public event Action? PlatformSaved;

        public ObservableCollection<Platform> Platforms
        {
            get => _platforms;
            set
            {
                _platforms = new ObservableCollection<Platform>(
                    value.OrderByDescending(p => p.IsDefault)
                         .ThenBy(p => p.GroupName));
                this.RaisePropertyChanged(nameof(Platforms));
            }
        }
        public ConfigTabViewModel? ConfigVm { get; set; }

        private Platform? _selectedPlatform;
        public Platform? SelectedPlatform
        {
            get => _selectedPlatform;
            set
            {
                // The Platforms collection is frequently rebuilt (new Platform instances) even when the
                // chosen platform (alias/fqdn) is logically unchanged. Treat those as the same selection
                // so we don't trigger duplicate downstream refreshes.
                if (_selectedPlatform != null && value != null)
                {
                    var sameFqdn = string.Equals(_selectedPlatform.PlatformFqdn, value.PlatformFqdn, StringComparison.OrdinalIgnoreCase);
                    var sameAlias = string.Equals(_selectedPlatform.GroupName, value.GroupName, StringComparison.OrdinalIgnoreCase);
                    if (sameFqdn && sameAlias)
                        return;
                }

                if (_selectedPlatform != value)
                {
                    this.RaiseAndSetIfChanged(ref _selectedPlatform, value);
                    LogHelper.Info($"🔄 Platform changed to: {_selectedPlatform?.PlatformFqdn}");
                    SelectedPlatformDisplay = $"Server: {_selectedPlatform?.GroupName ?? "(unset)"}";
                    PlatformsChanged?.Invoke(Platforms.ToList());
                }
            }
        }

        private string? _selectedPlatformDisplay;
        public string? SelectedPlatformDisplay
        {
            get => _selectedPlatformDisplay;
            set => this.RaiseAndSetIfChanged(ref _selectedPlatformDisplay, value);
        }

        private Platform? _editingPlatform;
        public Platform? EditingPlatform
        {
            get => _editingPlatform;
            set => this.RaiseAndSetIfChanged(ref _editingPlatform, value);
        }

        private bool _isEditing;
        public bool IsEditing
        {
            get => _isEditing;
            private set => this.RaiseAndSetIfChanged(ref _isEditing, value);
        }

        public ReactiveCommand<Unit, Unit> AddPlatformCommand { get; }
        public ReactiveCommand<Unit, Unit> EditPlatformCommand { get; }
        public ReactiveCommand<Unit, Unit> DeletePlatformCommand { get; }
        public ReactiveCommand<Unit, Unit> SaveCommand { get; }
        public ReactiveCommand<Unit, Unit> CancelCommand { get; }
        public ReactiveCommand<Unit, Unit> SetDefaultCommand { get; }

        public string? DefaultAlias
        {
            get => _settings.DefaultPlatformAlias;
            private set
            {
                if (_settings.DefaultPlatformAlias != value)
                {
                    _settings.DefaultPlatformAlias = value;
                    this.RaisePropertyChanged();
                }
            }
        }

        public PlatformConfigViewModel()
        {
            // 1️⃣ Load config & platforms
            _settings = _configHelper.Load();
            var loaded = _settings.Platforms.Select(p => ToPlatform(p)).ToList();
            Platforms = new ObservableCollection<Platform>(loaded);
            SelectedPlatform = Platforms.FirstOrDefault();

            // 2️⃣ Build commands
            AddPlatformCommand = ReactiveCommand.Create(AddPlatform);
            var canEditOrDelete = this.WhenAnyValue(x => x.SelectedPlatform).Select(p => p != null);
            EditPlatformCommand = ReactiveCommand.Create(EditPlatform, canEditOrDelete);
            DeletePlatformCommand = ReactiveCommand.Create(DeletePlatform, canEditOrDelete);
            var canSave = this.WhenAnyValue(x => x.IsEditing, x => x.EditingPlatform)
                                       .Select(t => t.Item1 && t.Item2 != null);
            SaveCommand = ReactiveCommand.Create(Save, canSave);
            CancelCommand = ReactiveCommand.Create(Cancel, canSave);
            SetDefaultCommand = ReactiveCommand.Create(SetDefault, canEditOrDelete);

            // 3️⃣ Flag whichever one is default
            if (!string.IsNullOrEmpty(_settings.DefaultPlatformAlias))
            {
                var def = Platforms.FirstOrDefault(p =>
                           p.GroupName == _settings.DefaultPlatformAlias);
                if (def != null) def.IsDefault = true;
            }
        }

        /// <summary>
        /// Reloads platforms from appsettings.json and optionally selects a specific alias.
        /// When <paramref name="openEditor"/> is true, enters edit mode for the selected platform
        /// using the existing EditPlatform command logic.
        /// </summary>
        public void ReloadFromConfig(string? selectAlias = null, bool openEditor = false)
        {
            try
            {
                _settings = _configHelper.Load();

                var loaded = (_settings.Platforms ?? new List<PlatformSettings>()).Select(p => ToPlatform(p)).ToList();
                Platforms = new ObservableCollection<Platform>(loaded);

                // Ensure there is always a placeholder entry so first-run has something to edit.
                if (Platforms.Count == 0)
                {
                    Platforms.Add(new Platform
                    {
                        GroupName = "Platform Placeholder - Edit Me",
                        Alias = "PH",
                        PlatformFqdn = string.Empty,
                        CertThumbprint = string.Empty,
                        AppId = string.Empty,
                        DefaultConsumer = _settings.DefaultConsumer ?? "Explorer",
                        RequireCoverage = false
                    });
                }

                var aliasToPick = string.IsNullOrWhiteSpace(selectAlias) ? "PH" : selectAlias.Trim();
                SelectedPlatform = Platforms.FirstOrDefault(p =>
                        !string.IsNullOrWhiteSpace(p.Alias) &&
                        string.Equals(p.Alias.Trim(), aliasToPick, StringComparison.OrdinalIgnoreCase))
                    ?? Platforms.FirstOrDefault();

                if (openEditor && SelectedPlatform != null)
                {
                    // Reuse the existing edit logic; do not duplicate mappings.
                    if (!IsEditing)
                    {
                        try
                        {
                            EditPlatformCommand.Execute().Subscribe();
                        }
                        catch
                        {
                            // Non-fatal; editor open is best-effort.
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LogHelper.Warn($"⚠️ ReloadFromConfig failed: {ex.Message}");
            }
        }

        // ────────── helpers ──────────
        private void AddPlatform()
        {
            EditingPlatform = new Platform
            {
                GroupName = "New Platform",
                PlatformFqdn = string.Empty,
                CertThumbprint = string.Empty,
                AppId = string.Empty,
                DefaultConsumer = _settings.DefaultConsumer ?? "Explorer",
                RequireCoverage = false
            };
            IsEditing = true;
        }

        private void EditPlatform()
        {
            if (SelectedPlatform is null) return;
            EditingPlatform = new Platform
            {
                GroupName = SelectedPlatform.GroupName,
                Alias = SelectedPlatform.Alias,
                PlatformFqdn = SelectedPlatform.PlatformFqdn,
                CertThumbprint = SelectedPlatform.CertThumbprint,
                AppId = SelectedPlatform.AppId,
                UserId = SelectedPlatform.UserId,
                DefaultConsumer = SelectedPlatform.DefaultConsumer,
                UseCert = SelectedPlatform.UseCert,
                RequireCoverage = SelectedPlatform.RequireCoverage,
                IsDefault = SelectedPlatform.IsDefault
            };
            IsEditing = true;
        }

        private void DeletePlatform()
        {
            if (SelectedPlatform is null) return;

            // Clean up any per-platform ExportOptions entries that were keyed by alias/group/fqdn.
            // (The UI uses aliases, but older configs may have used fqdn or group name.)
            try
            {
                if (_settings?.ExportOptions != null && _settings.ExportOptions.Count > 0)
                {
                    var keysToRemove = new List<string>();

                    foreach (var k in _settings.ExportOptions.Keys)
                    {
                        if (!string.IsNullOrWhiteSpace(SelectedPlatform.Alias) &&
                            k.Equals(SelectedPlatform.Alias, StringComparison.OrdinalIgnoreCase))
                            keysToRemove.Add(k);
                        else if (!string.IsNullOrWhiteSpace(SelectedPlatform.GroupName) &&
                                 k.Equals(SelectedPlatform.GroupName, StringComparison.OrdinalIgnoreCase))
                            keysToRemove.Add(k);
                        else if (!string.IsNullOrWhiteSpace(SelectedPlatform.PlatformFqdn) &&
                                 k.Equals(SelectedPlatform.PlatformFqdn, StringComparison.OrdinalIgnoreCase))
                            keysToRemove.Add(k);
                    }

                    foreach (var k in keysToRemove.Distinct(StringComparer.OrdinalIgnoreCase))
                        _settings.ExportOptions.Remove(k);
                }
            }
            catch (Exception ex)
            {
                LogHelper.Warn($"⚠️ Failed to remove ExportOptions for deleted platform: {ex.Message}");
            }

            Platforms.Remove(SelectedPlatform);
            SelectedPlatform = Platforms.FirstOrDefault();
            Persist();
            ResortPlatforms();
        }

        private void Cancel()
        {
            EditingPlatform = null;
            IsEditing = false;
        }

        private void SetDefault()
        {
            if (SelectedPlatform is null) return;
            LogHelper.Info($"🟢 SetDefault called for: {SelectedPlatform.GroupName} → FQDN: {SelectedPlatform.PlatformFqdn}, UseCert: {SelectedPlatform.UseCert}");
            if (SelectedPlatform.IsDefault)
            {
                LogHelper.Info($"⚠️ Skipping SetDefault — already default.");
                return;
            }
            foreach (var p in Platforms) p.IsDefault = false;
            SelectedPlatform.IsDefault = true;
            DefaultAlias = SelectedPlatform.GroupName;
            Persist();
            ResortPlatforms();
        }

        private void Save()
        {
            if (EditingPlatform is null || string.IsNullOrWhiteSpace(EditingPlatform.PlatformFqdn))
            {
                LogHelper.Warn("⚠️ Cannot save platform: FQDN is missing.");
                return;
            }

            // First-run placeholder behavior: the editor UI historically binds the "Platform Alias" textbox
            // to GroupName (display) instead of Alias (storage). The placeholder entry starts with Alias="PH".
            // When the user edits the placeholder and types a real alias, GroupName changes but Alias can
            // remain "PH". If we persist Alias="PH" we end up with dropdowns stuck on PH even though the
            // user entered a real alias. Normalize here so Alias reflects the user-entered friendly name.
            var trimmedGroup = (EditingPlatform.GroupName ?? string.Empty).Trim();
            var trimmedAlias = (EditingPlatform.Alias ?? string.Empty).Trim();

            // If alias is blank OR still the placeholder, prefer the edited GroupName.
            if (string.IsNullOrWhiteSpace(trimmedAlias) ||
                string.Equals(trimmedAlias, "PH", StringComparison.OrdinalIgnoreCase) ||
                trimmedAlias.Contains("placeholder", StringComparison.OrdinalIgnoreCase))
            {
                if (!string.IsNullOrWhiteSpace(trimmedGroup) &&
                    !string.Equals(trimmedGroup, "Platform Placeholder - Edit Me", StringComparison.OrdinalIgnoreCase) &&
                    !trimmedGroup.Contains("placeholder", StringComparison.OrdinalIgnoreCase))
                {
                    EditingPlatform.Alias = trimmedGroup;
                    trimmedAlias = trimmedGroup;
                }
            }

            // If GroupName is still the placeholder text but Alias is a real value, mirror Alias into GroupName
            // so UI list ordering/display uses the real friendly name.
            if (!string.IsNullOrWhiteSpace(trimmedAlias) &&
                (string.Equals(trimmedGroup, "Platform Placeholder - Edit Me", StringComparison.OrdinalIgnoreCase) ||
                 trimmedGroup.Contains("placeholder", StringComparison.OrdinalIgnoreCase)))
            {
                EditingPlatform.GroupName = trimmedAlias;
            }

            // Remove placeholder/duplicate, set default if first or manually changed
            Platforms = new ObservableCollection<Platform>(
                Platforms.Where(p => !string.IsNullOrWhiteSpace(p.PlatformFqdn) &&
                                     !p.PlatformFqdn.Equals(EditingPlatform.PlatformFqdn, StringComparison.OrdinalIgnoreCase)));

            bool isFirstPlatform = Platforms.Count == 0;
            if (isFirstPlatform || _defaultPlatformManuallyChanged)
            {
                foreach (var p in Platforms) p.IsDefault = false;
                EditingPlatform.IsDefault = true;
                _settings.DefaultPlatformAlias = EditingPlatform.GroupName;
                _settings.DefaultPlatformFqdn = EditingPlatform.PlatformFqdn;
            }

            Platforms.Add(EditingPlatform);
            SelectedPlatform = EditingPlatform;

            // Persist settings + UseCert
            Persist();
            var config = new ConfigHelper().Load();
            var entry = config.Platforms.FirstOrDefault(p =>
                p.PlatformFqdn.Equals(EditingPlatform.PlatformFqdn, StringComparison.OrdinalIgnoreCase));
            if (entry != null)
            {
                entry.UseCert = EditingPlatform.UseCert;
                new ConfigHelper().Save(config);
                LogHelper.Info($"✅ Updated UseCert for {EditingPlatform.PlatformFqdn} → {EditingPlatform.UseCert}");
            }

            ResortPlatforms();

            // Finish edit
            EditingPlatform = null;
            IsEditing = false;
            PlatformSaved?.Invoke();
         //   ExportOptionsHost?.SetPlatforms(Platforms.ToList());

            _defaultPlatformManuallyChanged = false;
            LogHelper.Info("✅ Platform saved.");
          //  ExportOptionsHost?.SetPlatforms(updatedPlatformList);

        }

        private void Persist()
        {
            // Preserve hidden / advanced fields (e.g., UserId/UPN) that are not exposed in the UI.
            // IMPORTANT: the Platforms tab UI does not surface UserId, so saving must NOT overwrite it.
            var existing = _configHelper.Load();

            // Build a raw JSON lookup (case-insensitive) so we preserve hidden fields even if
            // prior saves had casing differences (UserId vs userId) or missing model properties.
            var rawUserIdByFqdn = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            try
            {
                if (File.Exists(_configHelper.ConfigPath))
                {
                    var rawJson = File.ReadAllText(_configHelper.ConfigPath);
                    var root = JObject.Parse(rawJson);
                    var platformsArr = root["Platforms"] as JArray;
                    if (platformsArr != null)
                    {
                        foreach (var obj in platformsArr.OfType<JObject>())
                        {
                            string? fqdn = null;
                            string? userId = null;
                            foreach (var prop in obj.Properties())
                            {
                                if (prop.Name.Equals("PlatformFqdn", StringComparison.OrdinalIgnoreCase))
                                    fqdn = prop.Value?.ToString()?.Trim();
                                else if (prop.Name.Equals("UserId", StringComparison.OrdinalIgnoreCase))
                                    userId = prop.Value?.ToString()?.Trim();
                            }

                            if (!string.IsNullOrWhiteSpace(fqdn) && !string.IsNullOrWhiteSpace(userId))
                                rawUserIdByFqdn[fqdn] = userId;
                        }
                    }
                }
            }
            catch
            {
                // Non-fatal: we'll fall back to the deserialized model.
            }

            var existingByAlias = (existing.Platforms ?? new List<PlatformSettings>())
                .Where(ps => !string.IsNullOrWhiteSpace(ps.Alias))
                .GroupBy(ps => ps.Alias!, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);
            var existingByFqdn = (existing.Platforms ?? new List<PlatformSettings>())
                .Where(ps => !string.IsNullOrWhiteSpace(ps.PlatformFqdn))
                .GroupBy(ps => ps.PlatformFqdn!, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);

            _settings.Platforms = Platforms.Select(p =>
            {
                PlatformSettings? old = null;
                if (!string.IsNullOrWhiteSpace(p.Alias) && existingByAlias.TryGetValue(p.Alias, out var byAlias))
                    old = byAlias;
                else if (!string.IsNullOrWhiteSpace(p.PlatformFqdn) && existingByFqdn.TryGetValue(p.PlatformFqdn, out var byFqdn))
                    old = byFqdn;

                // Hidden field preservation logic:
                // 1) keep in-memory value if explicitly set
                // 2) else keep existing deserialized value
                // 3) else keep raw JSON value
                string? preservedUserId = null;
                if (!string.IsNullOrWhiteSpace(p.UserId))
                    preservedUserId = p.UserId.Trim();
                else if (!string.IsNullOrWhiteSpace(old?.UserId))
                    preservedUserId = old!.UserId!.Trim();
                else if (!string.IsNullOrWhiteSpace(p.PlatformFqdn) && rawUserIdByFqdn.TryGetValue(p.PlatformFqdn.Trim(), out var rawUserId))
                    preservedUserId = rawUserId;

                return new PlatformSettings
                {
                    Alias = string.IsNullOrWhiteSpace(p.Alias) ? p.GroupName : p.Alias,
                    PlatformFqdn = p.PlatformFqdn,
                    AppId = p.AppId,
                    CertThumbprint = p.CertThumbprint,
                    DefaultConsumer = p.DefaultConsumer,
                    IsDefault = p.IsDefault,
                    UseCert = p.UseCert,
                    RequireCoverage = p.RequireCoverage,
                    // Hidden field: preserve; NEVER overwrite with null/empty.
                    UserId = preservedUserId,
                    AuthProfiles = new List<AuthProfile>
                    {
                        new AuthProfile { AppId = p.AppId, CertThumbprint = p.CertThumbprint }
                    }
                };
            }).ToList();

            _settings.DefaultPlatformAlias = _settings.Platforms.FirstOrDefault(p => p.IsDefault)?.Alias;
            _settings.DefaultPlatformFqdn = _settings.Platforms.FirstOrDefault(p => p.IsDefault)?.PlatformFqdn;
            _configHelper.Save(_settings);
            PlatformsChanged?.Invoke(Platforms.ToList());
        }

        public void OnUseCertCheckboxChanged(string platformFqdn, bool newValue)
        {
            var config = new ConfigHelper().Load();
            var platform = config.Platforms.FirstOrDefault(p =>
                p.PlatformFqdn.Equals(platformFqdn, StringComparison.OrdinalIgnoreCase));
            if (platform != null)
            {
                platform.UseCert = newValue;
                new ConfigHelper().Save(config);
                LogHelper.Info($"✅ Updated UseCert for {platformFqdn} → {newValue}");
            }
            else
            {
                LogHelper.Warn($"⚠️ Platform not found: {platformFqdn}");
            }
        }

        private void ResortPlatforms()
        {
            var ordered = _platforms
                .OrderByDescending(p => p.IsDefault)
                .ThenBy(p => p.GroupName, StringComparer.OrdinalIgnoreCase);
            Platforms = new ObservableCollection<Platform>(ordered);
        }

        // ────────── reflection helpers ──────────
        private static string GetProp(object obj, string name) =>
            obj.GetType().GetProperty(name, BindingFlags.Public | BindingFlags.Instance)
               ?.GetValue(obj)?.ToString() ?? string.Empty;

        private static void SetProp(object obj, string name, object value)
        {
            var prop = obj.GetType().GetProperty(name, BindingFlags.Public | BindingFlags.Instance);
            if (prop != null && prop.CanWrite) prop.SetValue(obj, value);
        }

        // ────────── mapping ──────────
        private static Platform ToPlatform(PlatformSettings ps)
        {
            var fqdn = GetProp(ps, "PlatformFqdn");
            var alias = GetProp(ps, "Alias");

            bool isPlaceholder =
                string.IsNullOrWhiteSpace(alias) &&
                string.IsNullOrWhiteSpace(fqdn);

            // Force deterministic placeholder identity
            if (isPlaceholder)
            {
                alias = "PH";
                fqdn = string.Empty;
            }

            var display = !string.IsNullOrWhiteSpace(alias) ? alias : fqdn;

            return new Platform
            {
                // What UI shows
                GroupName = isPlaceholder
                    ? "Platform Placeholder - Edit Me"
                    : display,

                Alias = alias,
                PlatformFqdn = fqdn,
                CertThumbprint = GetProp(ps, "CertThumbprint"),
                AppId = GetProp(ps, "AppId"),
                DefaultConsumer = ps.DefaultConsumer ?? "Explorer",
                IsDefault = ps.IsDefault,
                UseCert = ps.UseCert,
                RequireCoverage = ps.RequireCoverage,
                UserId = ps.UserId ?? string.Empty
            };
        }


        private static PlatformSettings ToSettings(Platform p)
        {
            var ps = Activator.CreateInstance<PlatformSettings>();
            SetProp(ps, "PlatformFqdn", p.PlatformFqdn);
            SetProp(ps, "AppId", p.AppId);
            SetProp(ps, "CertThumbprint", p.CertThumbprint);
            SetProp(ps, "UseCert", p.UseCert);
            SetProp(ps, "RequireCoverage", p.RequireCoverage);
            // Persist Alias if present (or fall back to GroupName), so dropdowns can show friendly names.
            var alias = !string.IsNullOrWhiteSpace(p.Alias) ? p.Alias : p.GroupName;
            SetProp(ps, "Alias", alias);
            // UserId is a hidden/advanced setting. Preserve it if present on the platform object.
            if (!string.IsNullOrWhiteSpace(p.UserId))
                SetProp(ps, "UserId", p.UserId);
            return ps;
        }
    }
}
