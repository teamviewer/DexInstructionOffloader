﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Input;
using Avalonia.Threading;
using TV1_InstructionOffloader.Models;
using TV1_InstructionOffloader.Services;

namespace TV1_InstructionOffloader.ViewModels
{
    public class SettingsViewModel : INotifyPropertyChanged
    {
        private readonly SettingsService _settingsService;
        private Settings _settings = new();

        private string _statusMessage = "";

        public SettingsViewModel(SettingsService settingsService)
        {
            _settingsService = settingsService;

            SaveCommand = new RelayCommand(async _ => await SaveAsync(), _ => CanSave());
            ReloadCommand = new RelayCommand(async _ => await ReloadAsync());
            ImportCommand = new RelayCommand(async _ => await ImportAsync());
            ExportCommand = new RelayCommand(async _ => await ExportAsync());

            // Load settings initially
            _ = ReloadAsync();
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string? name = null) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));

        // Properties bound to UI
        public int ConcurrentApiCalls
        {
            get => _settings.ConcurrentApiCalls;
            set
            {
                if (_settings.ConcurrentApiCalls != value)
                {
                    _settings.ConcurrentApiCalls = value;
                    OnPropertyChanged();
                    OnPropertyChanged(nameof(CanSave));
                }
            }
        }

        public int PageSize
        {
            get => _settings.PageSize;
            set
            {
                if (_settings.PageSize != value)
                {
                    _settings.PageSize = value;
                    OnPropertyChanged();
                    OnPropertyChanged(nameof(CanSave));
                }
            }
        }

        public int DefaultInstructionTtlMinutes
        {
            get => _settings.DefaultInstructionTtlMinutes;
            set
            {
                if (_settings.DefaultInstructionTtlMinutes != value)
                {
                    _settings.DefaultInstructionTtlMinutes = value;
                    OnPropertyChanged();
                    OnPropertyChanged(nameof(CanSave));
                }
            }
        }

        public int DefaultResponseTtlMinutes
        {
            get => _settings.DefaultResponseTtlMinutes;
            set
            {
                if (_settings.DefaultResponseTtlMinutes != value)
                {
                    _settings.DefaultResponseTtlMinutes = value;
                    OnPropertyChanged();
                    OnPropertyChanged(nameof(CanSave));
                }
            }
        }

        public string ExportFolderPath
        {
            get => _settings.ExportFolderPath;
            set
            {
                if (_settings.ExportFolderPath != value)
                {
                    _settings.ExportFolderPath = value;
                    OnPropertyChanged();
                    OnPropertyChanged(nameof(CanSave));
                }
            }
        }

        public string DefaultExportFormat
        {
            get => _settings.DefaultExportFormat;
            set
            {
                if (_settings.DefaultExportFormat != value)
                {
                    _settings.DefaultExportFormat = value;
                    OnPropertyChanged();
                    OnPropertyChanged(nameof(CanSave));
                }
            }
        }

        public bool UseSqlServer
        {
            get => _settings.UseSqlServer;
            set
            {
                if (_settings.UseSqlServer != value)
                {
                    _settings.UseSqlServer = value;
                    OnPropertyChanged();
                    OnPropertyChanged(nameof(CanSave));
                }
            }
        }

        public string SqlConnectionString
        {
            get => _settings.SqlConnectionString;
            set
            {
                if (_settings.SqlConnectionString != value)
                {
                    _settings.SqlConnectionString = value;
                    OnPropertyChanged();
                    OnPropertyChanged(nameof(CanSave));
                }
            }
        }

        public bool AutoRecover
        {
            get => _settings.AutoRecover;
            set
            {
                if (_settings.AutoRecover != value)
                {
                    _settings.AutoRecover = value;
                    OnPropertyChanged();
                    OnPropertyChanged(nameof(CanSave));
                }
            }
        }

        public int HistoryMaxItems
        {
            get => _settings.HistoryMaxItems;
            set
            {
                if (_settings.HistoryMaxItems != value)
                {
                    _settings.HistoryMaxItems = value;
                    OnPropertyChanged();
                    OnPropertyChanged(nameof(CanSave));
                }
            }
        }

        public bool ShowLogs
        {
            get => _settings.ShowLogs;
            set
            {
                if (_settings.ShowLogs != value)
                {
                    _settings.ShowLogs = value;
                    OnPropertyChanged();
                    OnPropertyChanged(nameof(CanSave));
                }
            }
        }

        public string LogLevel
        {
            get => _settings.LogLevel;
            set
            {
                if (_settings.LogLevel != value)
                {
                    _settings.LogLevel = value;
                    OnPropertyChanged();
                    OnPropertyChanged(nameof(CanSave));
                }
            }
        }

        public string StatusMessage
        {
            get => _statusMessage;
            private set
            {
                if (_statusMessage != value)
                {
                    _statusMessage = value;
                    OnPropertyChanged();
                }
            }
        }

        // Commands
        public ICommand SaveCommand { get; }
        public ICommand ReloadCommand { get; }
        public ICommand ImportCommand { get; }
        public ICommand ExportCommand { get; }

        private bool CanSave()
        {
            // Simple validation example
            return ConcurrentApiCalls > 0 && PageSize > 0 && DefaultInstructionTtlMinutes > 0 && DefaultResponseTtlMinutes > 0;
        }

        private async Task SaveAsync()
        {
            try
            {
                await _settingsService.SaveSettingsAsync(_settings);
                StatusMessage = "Settings saved successfully.";
            }
            catch (Exception ex)
            {
                StatusMessage = $"Error saving settings: {ex.Message}";
            }
        }

        private async Task ReloadAsync()
        {
            try
            {
                _settings = await _settingsService.LoadSettingsAsync();
                // Raise all property changed events
                OnPropertyChanged(string.Empty);
                StatusMessage = "Settings reloaded.";
            }
            catch (Exception ex)
            {
                StatusMessage = $"Error loading settings: {ex.Message}";
            }
        }

        private async Task ImportAsync()
        {
            try
            {
                await _settingsService.ImportFromSqlAsync();
                await ReloadAsync();
                StatusMessage = "Settings imported from SQL.";
            }
            catch (Exception ex)
            {
                StatusMessage = $"Error importing from SQL: {ex.Message}";
            }
        }

        private async Task ExportAsync()
        {
            try
            {
                await _settingsService.ExportToSqlAsync();
                StatusMessage = "Settings exported to SQL.";
            }
            catch (Exception ex)
            {
                StatusMessage = $"Error exporting to SQL: {ex.Message}";
            }
        }
    }

    // RelayCommand Implementation
    public class RelayCommand : ICommand
    {
        private readonly Func<object?, Task>? _executeAsync;
        private readonly Predicate<object?>? _canExecute;

        public RelayCommand(Func<object?, Task> executeAsync, Predicate<object?>? canExecute = null)
        {
            _executeAsync = executeAsync;
            _canExecute = canExecute;
        }

        public bool CanExecute(object? parameter) => _canExecute == null || _canExecute(parameter);

        public event EventHandler? CanExecuteChanged;

        public async void Execute(object? parameter)
        {
            if (_executeAsync != null)
            {
                await _executeAsync(parameter);
            }
        }

        public void RaiseCanExecuteChanged() => CanExecuteChanged?.Invoke(this, EventArgs.Empty);
    }
}
