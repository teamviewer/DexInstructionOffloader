﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Threading.Tasks;
using TV1_InstructionOffloader.Models;
using TV1_InstructionOffloader.Services;

namespace ViewModels
{
    public class PlatformContext : INotifyPropertyChanged
    {
        public AuthenticationService AuthService { get; }
        public List<PlatformSettings> Platforms { get; set; } = new();

        private PlatformSettings? _selectedPlatform;
        public PlatformSettings? SelectedPlatform
        {
            get => _selectedPlatform;
            set
            {
                if (_selectedPlatform != value)
                {
                    _selectedPlatform = value;
                    OnPropertyChanged(nameof(SelectedPlatform));
                    _ = AuthenticateAsync();
                }
            }
        }

        private string? _token;
        public string? Token
        {
            get => _token;
            private set
            {
                _token = value;
                OnPropertyChanged(nameof(Token));
            }
        }

        public PlatformContext(AuthenticationService authService)
        {
            AuthService = authService;
        }

        public async Task AuthenticateAsync()
        {
            if (SelectedPlatform == null) return;
            var result = await AuthService.AuthenticateAsync(SelectedPlatform, forceReauth: true);
            Token = result?.Token;
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged(string name) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}