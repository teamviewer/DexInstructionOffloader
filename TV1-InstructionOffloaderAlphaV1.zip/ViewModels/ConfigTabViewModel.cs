﻿using System;
using System.Collections.ObjectModel;
using System.IO;
using Avalonia.Logging;
using Avalonia;
using Avalonia.Controls;
using Newtonsoft.Json;
using ReactiveUI;
using System.Reactive;
using System.Reactive.Linq;
using TV1_InstructionOffloader.Models;
using TV1_InstructionOffloader.Helpers;
using Splat;
using System.Linq;
using System.Collections.Generic;
using TV1_InstructionOffloader.Services;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

namespace TV1_InstructionOffloader.ViewModels
{
    public class ConfigTabViewModel : ReactiveObject
    {
        private const string ConfigFilePath = "config.json";
        private readonly ConsumerService _consumerService;
        private readonly InstructionHelper _instructionHelper;

        // The collection bound to your Instruction ListBox
        public ObservableCollection<InstructionDefinition> Instructions { get; } = new();

        private InstructionDefinition? _selectedInstruction;
        public InstructionDefinition? SelectedInstruction
        {
            get => _selectedInstruction;
            set => this.RaiseAndSetIfChanged(ref _selectedInstruction, value);
        }

        public ConfigTabViewModel()
        {
            _consumerService = new ConsumerService();

            _instructionHelper = new InstructionHelper();


            AddPlatformCommand = ReactiveCommand.Create(AddPlatform);
            EditPlatformCommand = ReactiveCommand.Create(EditPlatform, this.WhenAnyValue(x => x.SelectedPlatform).Select(sp => sp != null));
            DeletePlatformCommand = ReactiveCommand.Create(DeletePlatform, this.WhenAnyValue(x => x.SelectedPlatform).Select(sp => sp != null));
            SaveCommand = ReactiveCommand.Create(Save);
            CancelCommand = ReactiveCommand.Create(Cancel);
            BrowseExportFolderCommand = ReactiveCommand.Create(BrowseExportFolder);

            SaveApiSettingsCommand = ReactiveCommand.Create(SaveApiSettings);
            CancelApiSettingsCommand = ReactiveCommand.Create(CancelApiSettings);

            // Fire and forget async load instructions safely
            // _ = LoadInstructionsAsync();  // moved to LoadAfterLoginAsync

            LoadApiSettings();
            Load();

            this.WhenAnyValue(x => x.SelectedPlatform)
                .Where(sp => sp != null)
                .Subscribe(sp =>
                {
                    if (_isLoadingPlatforms)
                        return; // Ignore selection changes during loading

                    EditingPlatform = new Platform
                    {
                        GroupName = sp.GroupName,
                        Alias = sp.Alias,
                        PlatformFqdn = sp.PlatformFqdn,
                        CertThumbprint = sp.CertThumbprint,
                        AppId = sp.AppId,
                        DefaultConsumer = sp.DefaultConsumer,
                        UseCert = sp.UseCert,
                        UserId = sp.UserId
                    };

                    RefreshPlatformDependentData(sp);
                });
        }

        public Action<string> Logger { get; set; }
        public string Fqdn { get; set; } = "";
        public string Token { get; set; } = "";
        public PlatformConfigViewModel PlatformVm { get; } = new PlatformConfigViewModel();


        private TextBox? _logTextBox;
        public ScheduledJobsViewModel? JobsViewModel { get; set; }
        public JobSchedulerService? Scheduler { get; set; }

        public void SetLogTextBox(TextBox logTextBox)
        {
            _logTextBox = logTextBox;
        }

        public async Task LoadInstructionsAsync()
        {
            try
            {
                var instructions = await _instructionHelper.LoadInstructionsAsync(Fqdn, Token, null);
                if (instructions == null)
                    return;

                Instructions.Clear();
                foreach (var inst in instructions)
                    Instructions.Add(inst);
            }
            catch (Exception ex)
            {
                // Handle/log error as appropriate, e.g.:
                Console.WriteLine($"Error loading instructions: {ex.Message}");
            }
        }


        public void SetAuthContext(string fqdn, string token, Action<string> logger)
        {
            Fqdn = fqdn;
            Token = token;
            Logger = logger;
            // _ = LoadInstructionsAsync();  // moved to LoadAfterLoginAsync
        }



        public ObservableCollection<Platform> Platforms { get; } = new();

        private Platform? _selectedPlatform;
        public Platform? SelectedPlatform
        {
            get => _selectedPlatform;
            set
            {
                this.RaiseAndSetIfChanged(ref _selectedPlatform, value);
                // Mirror PlatformConfigViewModel behaviour so MainWindow is notified
                PlatformsChanged?.Invoke(Platforms.ToList());
            }
        }

        private Platform? _editingPlatform;
        public Platform? EditingPlatform
        {
            get => _editingPlatform;
            set => this.RaiseAndSetIfChanged(ref _editingPlatform, value);
        }

        private bool _isEditingPlatform;
        public bool IsEditingPlatform
        {
            get => _isEditingPlatform;
            set => this.RaiseAndSetIfChanged(ref _isEditingPlatform, value);
        }

        // Export settings properties
        private bool _isExportCsv = true; // Default
        public bool IsExportCsv
        {
            get => _isExportCsv;
            set => this.RaiseAndSetIfChanged(ref _isExportCsv, value);
        }

        private bool _isExportTsv;
        public bool IsExportTsv
        {
            get => _isExportTsv;
            set => this.RaiseAndSetIfChanged(ref _isExportTsv, value);
        }

        private bool _isExportXlsx;
        public bool IsExportXlsx
        {
            get => _isExportXlsx;
            set => this.RaiseAndSetIfChanged(ref _isExportXlsx, value);
        }

        private bool _isExportSql;
        public bool IsExportSql
        {
            get => _isExportSql;
            set
            {
                this.RaiseAndSetIfChanged(ref _isExportSql, value);
                this.RaisePropertyChanged(nameof(IsSqlExportSelected));
            }
        }

        private bool _isExportMySql;
        public bool IsExportMySql
        {
            get => _isExportMySql;
            set
            {
                this.RaiseAndSetIfChanged(ref _isExportMySql, value);
                this.RaisePropertyChanged(nameof(IsSqlExportSelected));
            }
        }

        private bool _isExportOracle;
        public bool IsExportOracle
        {
            get => _isExportOracle;
            set
            {
                this.RaiseAndSetIfChanged(ref _isExportOracle, value);
                this.RaisePropertyChanged(nameof(IsSqlExportSelected));
            }
        }

        public bool IsSqlExportSelected => IsExportSql || IsExportMySql || IsExportOracle;

        private string _exportFolderPath = "";
        public string ExportFolderPath
        {
            get => _exportFolderPath;
            set => this.RaiseAndSetIfChanged(ref _exportFolderPath, value);
        }

        private string _sqlServerInstance = "";
        public string SqlServerInstance
        {
            get => _sqlServerInstance;
            set => this.RaiseAndSetIfChanged(ref _sqlServerInstance, value);
        }

        private string _sqlPort = "";
        public string SqlPort
        {
            get => _sqlPort;
            set => this.RaiseAndSetIfChanged(ref _sqlPort, value);
        }

        private string _sqlDatabase = "";
        public string SqlDatabase
        {
            get => _sqlDatabase;
            set => this.RaiseAndSetIfChanged(ref _sqlDatabase, value);
        }

        private string _sqlUsername = "";
        public string SqlUsername
        {
            get => _sqlUsername;
            set => this.RaiseAndSetIfChanged(ref _sqlUsername, value);
        }

        private string _sqlPassword = "";
        public string SqlPassword
        {
            get => _sqlPassword;
            set => this.RaiseAndSetIfChanged(ref _sqlPassword, value);
        }

        public ObservableCollection<string> Consumers { get; } = new();

        public ReactiveCommand<Unit, Unit> AddPlatformCommand { get; }
        public ReactiveCommand<Unit, Unit> EditPlatformCommand { get; }
        public ReactiveCommand<Unit, Unit> DeletePlatformCommand { get; }
        public ReactiveCommand<Unit, Unit> SaveCommand { get; }
        public ReactiveCommand<Unit, Unit> CancelCommand { get; }
        public ReactiveCommand<Unit, Unit> BrowseExportFolderCommand { get; }
        public ReactiveCommand<Unit, Unit> SaveApiSettingsCommand { get; }
        public ReactiveCommand<Unit, Unit> CancelApiSettingsCommand { get; }

        private void AddPlatform()
        {
            EditingPlatform = new Platform
            {
                GroupName = "New Platform",
                PlatformFqdn = "",
                CertThumbprint = "",
                AppId = "",
                DefaultConsumer = Consumers.Count > 0 ? Consumers[0] : "Explorer"
            };
            IsEditingPlatform = true;
        }

        private void EditPlatform()
        {
            if (SelectedPlatform == null) return;

            EditingPlatform = new Platform
            {
                GroupName = SelectedPlatform.GroupName,
                Alias = SelectedPlatform.Alias,
                PlatformFqdn = SelectedPlatform.PlatformFqdn,
                CertThumbprint = SelectedPlatform.CertThumbprint,
                AppId = SelectedPlatform.AppId,
                DefaultConsumer = SelectedPlatform.DefaultConsumer
            };
            IsEditingPlatform = true;
        }

        private void DeletePlatform()
        {
            if (SelectedPlatform == null) return;

            Platforms.Remove(SelectedPlatform);
            SelectedPlatform = Platforms.Count > 0 ? Platforms[0] : null;

            Save();
        }

        private void Save()
        {
            if (EditingPlatform == null) return;

            if (string.IsNullOrWhiteSpace(EditingPlatform.DefaultConsumer))
                EditingPlatform.DefaultConsumer = "Explorer";

            var existing = Platforms.FirstOrDefault(p => p.GroupName == EditingPlatform.GroupName);

            if (existing == null)
            {
                Platforms.Add(EditingPlatform);
                SelectedPlatform = EditingPlatform;
            }
            else
            {
                existing.GroupName = EditingPlatform.GroupName;
                existing.Alias = EditingPlatform.Alias;
                existing.PlatformFqdn = EditingPlatform.PlatformFqdn;
                existing.CertThumbprint = EditingPlatform.CertThumbprint;
                existing.AppId = EditingPlatform.AppId;
                existing.DefaultConsumer = EditingPlatform.DefaultConsumer;

                SelectedPlatform = existing;
            }

            IsEditingPlatform = false;
            EditingPlatform = null;

            try
            {
                var json = JsonConvert.SerializeObject(Platforms, Formatting.Indented);
                File.WriteAllText(ConfigFilePath, json);
                Console.WriteLine("Config saved.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error saving config: {ex.Message}");
            }
        }

        private void Cancel()
        {
            EditingPlatform = null;
            IsEditingPlatform = false;
        }

        private bool _isLoadingPlatforms = false;

        private void Load()
        {
            try
            {
                _isLoadingPlatforms = true;
                Platforms.Clear();
                Console.WriteLine("Platforms cleared");

                if (!File.Exists(ConfigFilePath))
                {
                    Console.WriteLine("Config file missing, adding default platform");
                    Platforms.Add(new Platform
                    {
                        GroupName = "Default",
                        PlatformFqdn = "platform1.example.com",
                        CertThumbprint = "",
                        AppId = "",
                        DefaultConsumer = Consumers.Count > 0 ? Consumers[0] : "Explorer"
                    });
                    SelectedPlatform = Platforms[0];
                    IsEditingPlatform = false;
                    _isLoadingPlatforms = false;
                    return;
                }

                Console.WriteLine("Loading platforms from config file");
                var json = File.ReadAllText(ConfigFilePath);
                var platforms = JsonConvert.DeserializeObject<ObservableCollection<Platform>>(json);
                if (platforms != null)
                {
                    foreach (var p in platforms)
                    {
                        Console.WriteLine($"Adding platform {p.GroupName}");
                        Platforms.Add(p);
                    }
                    SelectedPlatform = Platforms.Count > 0 ? Platforms[0] : null;
                }

                IsEditingPlatform = false;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error loading config: {ex.Message}");
            }
            finally
            {
                _isLoadingPlatforms = false;
            }
        }

        public event Action<IReadOnlyList<Platform>>? PlatformsChanged;



        private void BrowseExportFolder()
        {
            // TODO: Implement folder browser dialog, platform-specific or Avalonia-based
        }

        // API Settings properties
        private string _apiBaseUrl = "";
        public string ApiBaseUrl
        {
            get => _apiBaseUrl;
            set => this.RaiseAndSetIfChanged(ref _apiBaseUrl, value);
        }

        private string _apiClientId = "";
        public string ApiClientId
        {
            get => _apiClientId;
            set => this.RaiseAndSetIfChanged(ref _apiClientId, value);
        }

        private string _apiCertThumbprint = "";
        public string ApiCertThumbprint
        {
            get => _apiCertThumbprint;
            set => this.RaiseAndSetIfChanged(ref _apiCertThumbprint, value);
        }

        private string _apiTenantId = "";
        public string ApiTenantId
        {
            get => _apiTenantId;
            set => this.RaiseAndSetIfChanged(ref _apiTenantId, value);
        }

        private string _apiClientSecret = "";
        public string ApiClientSecret
        {
            get => _apiClientSecret;
            set => this.RaiseAndSetIfChanged(ref _apiClientSecret, value);
        }

        public int PageSize
        {
            get => _pageSize;
            set => this.RaiseAndSetIfChanged(ref _pageSize, value);
        }
        private int _pageSize = 1000;

        public int DefaultInstructionTtlMinutes
        {
            get => _defaultInstructionTtlMinutes;
            set => this.RaiseAndSetIfChanged(ref _defaultInstructionTtlMinutes, value);
        }
        private int _defaultInstructionTtlMinutes = 60;

        public int DefaultResponseTtlMinutes
        {
            get => _defaultResponseTtlMinutes;
            set => this.RaiseAndSetIfChanged(ref _defaultResponseTtlMinutes, value);
        }
        private int _defaultResponseTtlMinutes = 60;

        public bool AutoRecover
        {
            get => _autoRecover;
            set => this.RaiseAndSetIfChanged(ref _autoRecover, value);
        }
        private bool _autoRecover;

        public int HistoryMaxItems
        {
            get => _historyMaxItems;
            set => this.RaiseAndSetIfChanged(ref _historyMaxItems, value);
        }
        private int _historyMaxItems = 100;

        public bool ShowLogs
        {
            get => _showLogs;
            set => this.RaiseAndSetIfChanged(ref _showLogs, value);
        }
        private bool _showLogs;

        public string LogLevel
        {
            get => _logLevel;
            set => this.RaiseAndSetIfChanged(ref _logLevel, value);
        }
        private string _logLevel = "Info";

        private string _loggedInUserDisplay = "Not logged in";
        public string LoggedInUserDisplay
        {
            get => _loggedInUserDisplay;
            set => this.RaiseAndSetIfChanged(ref _loggedInUserDisplay, value);
        }

        private string _selectedPlatformDisplay = "No platform selected";
        public string SelectedPlatformDisplay
        {
            get => _selectedPlatformDisplay;
            set => this.RaiseAndSetIfChanged(ref _selectedPlatformDisplay, value);
        }
        public IObservable<Platform?> PlatformSelected =>
            this.WhenAnyValue(vm => vm.SelectedPlatform);

        public bool IsInteractiveAuth
        {
            get => _isInteractiveAuth;
            set => this.RaiseAndSetIfChanged(ref _isInteractiveAuth, value);
        }
        private bool _isInteractiveAuth = true;

        public bool IsCertificateAuth
        {
            get => !_isInteractiveAuth;
            set => IsInteractiveAuth = !value;
        }
        public string[] Units { get; } = { "minutes", "hours", "days" };

        private int _instructionTtlValue = 30;
        public int InstructionTtlValue
        {
            get => _instructionTtlValue;
            set => this.RaiseAndSetIfChanged(ref _instructionTtlValue, value);
        }

        private string _instructionTtlUnit = "minutes";
        public string InstructionTtlUnit
        {
            get => _instructionTtlUnit;
            set => this.RaiseAndSetIfChanged(ref _instructionTtlUnit, value);
        }

        private int _responseTtlValue = 60;
        public int ResponseTtlValue
        {
            get => _responseTtlValue;
            set => this.RaiseAndSetIfChanged(ref _responseTtlValue, value);
        }

        private string _responseTtlUnit = "minutes";
        public string ResponseTtlUnit
        {
            get => _responseTtlUnit;
            set => this.RaiseAndSetIfChanged(ref _responseTtlUnit, value);
        }

        public ReactiveCommand<Unit, Unit>? AuthenticateCommand { get; private set; }

        private void SaveApiSettings()
        {
            // TODO: Implement saving API settings to file or config store
            Console.WriteLine("API Settings saved.");
        }

        private void CancelApiSettings()
        {
            // Reset or reload API settings to last saved values
            LoadApiSettings();
        }

        private void LoadApiSettings()
        {
            // TODO: Implement loading API settings from file or config store

            // Example defaults or loading logic:
            ApiBaseUrl = "https://your.api.url";
            ApiClientId = "";
            ApiCertThumbprint = "";
            ApiTenantId = "";
            ApiClientSecret = "";

            PageSize = 1000;
            DefaultInstructionTtlMinutes = 60;
            DefaultResponseTtlMinutes = 60;
            AutoRecover = false;
            HistoryMaxItems = 100;
            ShowLogs = false;
            LogLevel = "Info";
        }

        private void RefreshPlatformDependentData(Platform platform)
        {
            // TODO: Add your actual refresh logic here to reload instructions,
            // management groups, coverage tags based on the new platform
            Console.WriteLine($"Platform changed to {platform.GroupName}, refreshing dependent data...");
        }
    

public async Task LoadAfterLoginAsync(string fqdn, string token, Action<string> logger)
{
    Fqdn   = fqdn;
    Token  = token;
    Logger = logger;
    await LoadInstructionsAsync();
}
}
}
