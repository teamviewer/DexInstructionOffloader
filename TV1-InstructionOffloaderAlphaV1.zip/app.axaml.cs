﻿using Avalonia;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Markup.Xaml;
using Avalonia.Threading;
using Microsoft.Extensions.Logging;
using System;
using System.Reactive.Linq;
using TV1_InstructionOffloader;
using TV1_InstructionOffloader.Services;

namespace TV1_InstructionOffloader
{
    public partial class App : Application
    {
        private TrayHelper? _trayHelper;

        public App()
        {
            // Global exceptions from any thread
            AppDomain.CurrentDomain.UnhandledException += (sender, e) =>
            {
                var ex = e.ExceptionObject as Exception;
                Console.WriteLine("Unhandled exception: " + ex?.ToString());
                // TODO: log to your ILogger if you want
            };

            // UI thread exceptions
            Dispatcher.UIThread.UnhandledException += (sender, e) =>
            {
                Console.WriteLine("UI thread unhandled exception: " + e.Exception.ToString());
                e.Handled = true; // Prevent crash; set false to allow crash
                // TODO: log to your ILogger if you want
            };
        }

        public override void Initialize() => AvaloniaXamlLoader.Load(this);

        public override void OnFrameworkInitializationCompleted()
        {
            if (ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop)
            {
                var mainWindow = new MainWindow();
                var configHelper = new ConfigHelper();
                var settings = configHelper.Load();

                var logLevel = settings?.LogLevel ?? "Info";
                var maxLines = settings?.MaxLogLines ?? 5000;
                var maxFileSize = settings?.MaxLogFileSizeMB ?? 10;
                LogHelper.Initialize(logLevel, maxLines, maxFileSize);

                desktop.MainWindow = mainWindow;

                var loggerFactory = LoggerFactory.Create(builder =>
                {
                    builder.AddConsole();
                });

                var trayHelperLogger = loggerFactory.CreateLogger<TV1_InstructionOffloader.TrayHelper>();
                _trayHelper = new TrayHelper(trayHelperLogger);

                _trayHelper.AttachToWindow(mainWindow);

                // Startup: show a taskbar button so the app is discoverable when behind other windows.
                mainWindow.ShowInTaskbar = true;

                // When minimized to tray, hide the taskbar button (user expectation).
                // When restored, show the taskbar button again.
                // When minimized to tray, hide the taskbar button (user expectation).
                // When restored, show the taskbar button again.
                mainWindow.GetObservable(Avalonia.Controls.Window.WindowStateProperty).Subscribe(state =>
                {
                    try
                    {
                        mainWindow.ShowInTaskbar = state != Avalonia.Controls.WindowState.Minimized;
                    }
                    catch
                    {
                        // ignore
                    }
                });

                // Some environments delay taskbar registration until the window is opened.
                mainWindow.Opened += (_, _) =>
                {
                    try { mainWindow.ShowInTaskbar = true; } catch { }
                };


                desktop.Exit += (_, _) => _trayHelper?.Dispose();
            }

            base.OnFrameworkInitializationCompleted();
        }
    }
}